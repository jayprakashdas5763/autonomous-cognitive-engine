import copy
import inspect
import os

from langgraph.graph import StateGraph, END
from agents.writer import writer_agent
from nodes.supervisor import supervisor_node
from state import AgentState
from nodes.planner import planner_node
from nodes.executor import executor_node
from logging_config import get_logger
from tools.parallel_executor import parallel_executor_node
from tools.observability import (
    extract_graph_run_id,
    get_current_factcheck_verdict,
    get_task_context,
)

logger = get_logger(__name__)

# Maximum number of executor loop iterations before LangGraph stops.
# Import this constant in app.py / main.py to keep the limit consistent.
MAX_EXECUTOR_ITERATIONS = 150
_PARALLEL_FLAG = "ENABLE_PARALLEL_EXECUTION"


def _parallel_enabled() -> bool:
    return os.getenv(_PARALLEL_FLAG, "false").strip().lower() == "true"


def _log_node_observability(node_name, state, config, event):
    run_id = extract_graph_run_id(config)
    task_id, retry_count = get_task_context(state)
    verdict = get_current_factcheck_verdict(state) or "N/A"
    active_agent = state.get("active_agent", "") or "N/A"

    logger.info(
        "[OBS] event=%s run_id=%s node=%s active_agent=%s task_id=%s retry_count=%s factcheck_verdict=%s",
        event,
        run_id,
        node_name,
        active_agent,
        task_id,
        retry_count,
        verdict,
    )


def _find_todo_by_id(state, task_id):
    if task_id in (None, "?"):
        return None
    for todo in state.get("todos", []):
        if todo.get("id") == task_id:
            return todo
    return None


def _next_pending_todo(state):
    for todo in state.get("todos", []):
        if todo.get("status") == "pending":
            return todo
    return None


def _executor_reason(stage):
    if stage == "research":
        return "Task requires web research"
    if stage == "factcheck":
        return "Research output must be validated"
    return "Executor progressing task lifecycle"


def _executor_observation(before_todo, after_todo, created_files, verdict):
    if created_files:
        return f"created {', '.join(created_files)}"

    before_stage = before_todo.get("stage", "unknown") if before_todo else "unknown"
    after_stage = after_todo.get("stage", before_stage) if after_todo else before_stage
    after_status = after_todo.get("status", "pending") if after_todo else "pending"

    if before_stage != after_stage:
        return f"stage moved {before_stage} -> {after_stage}"
    if after_status in ("done", "failed"):
        return f"task status changed to {after_status}"
    if verdict and verdict != "N/A":
        return f"factcheck verdict {verdict}"

    return "task processed"


def _append_executor_react_log(updated_state, before_todo, after_todo, selected_agent, created_files):
    if not before_todo:
        return

    task_id = before_todo.get("id", "?")
    stage = before_todo.get("stage", "research")
    verdict = get_current_factcheck_verdict(updated_state) or "N/A"
    retry_count = 0
    if after_todo:
        retry_count = int(after_todo.get("retries", 0) or 0)

    updated_state.setdefault("execution_log", []).append(
        {
            "task_id": task_id,
            "reason": _executor_reason(stage),
            "action": "delegate",
            "agent": selected_agent or "N/A",
            "observation": _executor_observation(
                before_todo,
                after_todo,
                created_files,
                verdict,
            ),
            "retry_count": retry_count,
            "factcheck_verdict": verdict,
            "mode": "sequential",
        }
    )


def _wrap_node(node_name, node_func):
    signature = inspect.signature(node_func)
    accepts_config = len(signature.parameters) >= 2

    def _wrapped(state, config=None):
        _log_node_observability(node_name, state, config, event="start")

        before_todo = None
        before_files = set()
        selected_agent = "N/A"
        if node_name == "executor":
            todo_ref = _next_pending_todo(state)
            before_todo = copy.deepcopy(todo_ref) if todo_ref else None
            before_files = set(state.get("files", {}).keys())
            selected_agent = state.get("active_agent", "N/A")

        if accepts_config:
            updated_state = node_func(state, config)
        else:
            updated_state = node_func(state)

        if node_name == "executor" and before_todo:
            after_todo = _find_todo_by_id(updated_state, before_todo.get("id"))
            created_files = sorted(
                set(updated_state.get("files", {}).keys()) - before_files
            )
            _append_executor_react_log(
                updated_state,
                before_todo,
                after_todo,
                selected_agent,
                created_files,
            )

        _log_node_observability(node_name, updated_state, config, event="end")

        if node_name == "writer":
            final_report = updated_state.get("files", {}).get("final_report.txt", "")
            logger.info(
                "[OBS] run_id=%s node=writer final_report_generated=%s final_report_chars=%d",
                extract_graph_run_id(config),
                bool(final_report),
                len(final_report or ""),
            )

        return updated_state

    return _wrapped


def build_sequential_graph():
    graph = StateGraph(AgentState)

    graph.add_node("planner", _wrap_node("planner", planner_node))
    graph.add_node("supervisor", _wrap_node("supervisor", supervisor_node))
    graph.add_node("executor", _wrap_node("executor", executor_node))
    graph.add_node("writer", _wrap_node("writer", writer_agent))

    graph.set_entry_point("planner")
    graph.add_edge("planner", "supervisor")
    graph.add_edge("supervisor", "executor")

    def check_done(state):
        todos = state.get("todos", [])

        if not todos:
            logger.warning("No todos in state; routing directly to writer.")
            return True

        done = all(task.get("status") in ("done", "failed") for task in todos)

        pending = sum(1 for t in todos if t.get("status") not in ("done", "failed"))

        if done:
            logger.info("All %d task(s) completed. Moving to writer.", len(todos))
        else:
            logger.debug("%d task(s) still pending.", pending)

        return done

    graph.add_conditional_edges(
        "executor",
        check_done,
        {
            True: "writer",
            False: "supervisor",
        },
    )

    graph.add_edge("writer", END)

    return graph.compile()


def build_parallel_graph():
    graph = StateGraph(AgentState)

    graph.add_node("planner", _wrap_node("planner", planner_node))
    graph.add_node("parallel_executor", _wrap_node("parallel_executor", parallel_executor_node))
    graph.add_node("writer", _wrap_node("writer", writer_agent))

    graph.set_entry_point("planner")
    graph.add_edge("planner", "parallel_executor")
    graph.add_edge("parallel_executor", "writer")
    graph.add_edge("writer", END)

    return graph.compile()


def build_graph():
    if _parallel_enabled():
        logger.info("[OBS] parallel_execution enabled via %s=true", _PARALLEL_FLAG)
        return build_parallel_graph()

    logger.info("[OBS] parallel_execution disabled; using sequential graph")
    return build_sequential_graph()
