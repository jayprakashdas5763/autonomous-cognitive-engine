"""
Unit tests for tools/memory_store.py and writer memory persistence hook.
"""

import json
import os
from unittest.mock import patch

from agents.writer import writer_agent
from tools.memory_store import load_recent_memories, save_run_memory, search_memory


def _build_state(goal: str) -> dict:
    return {
        "goal": goal,
        "todos": [
            {
                "id": 1,
                "description": f"Research task for {goal}",
                "status": "done",
                "stage": "approval",
                "approval_status": "approved",
            }
        ],
        "files": {
            "research_task_1.md": f"Research output for {goal}",
            "factcheck_task_1.md": "# Fact Check Report\n\n## Verdict\nPASS",
            "final_report.txt": f"Final report for {goal}",
        },
        "messages": [goal],
        "current_task": "",
        "results": [],
        "active_agent": "",
        "agent_results": {},
        "raw_sources": {},
        "execution_log": [],
    }


class TestMemoryStore:
    @patch.dict(os.environ, {"ENABLE_PERSISTENT_MEMORY": "false"}, clear=False)
    def test_memory_disabled_does_nothing(self, tmp_path):
        memory_path = tmp_path / "memory.jsonl"

        with patch.dict(
            os.environ,
            {"PERSISTENT_MEMORY_PATH": str(memory_path)},
            clear=False,
        ):
            saved = save_run_memory(_build_state("disabled test"))

        assert saved is False
        assert not memory_path.exists()

    @patch.dict(os.environ, {"ENABLE_PERSISTENT_MEMORY": "true"}, clear=False)
    def test_memory_save_creates_persistent_record(self, tmp_path):
        memory_path = tmp_path / "memory.jsonl"

        with patch.dict(
            os.environ,
            {"PERSISTENT_MEMORY_PATH": str(memory_path)},
            clear=False,
        ):
            saved = save_run_memory(_build_state("quantum memory"))

        assert saved is True
        assert memory_path.exists()

        lines = memory_path.read_text(encoding="utf-8").splitlines()
        assert len(lines) == 1

        record = json.loads(lines[0])
        assert record.get("goal") == "quantum memory"
        assert record.get("final_report")
        assert record.get("created_at")
        assert isinstance(record.get("task_descriptions"), list)
        assert isinstance(record.get("tasks"), list)
        assert record["tasks"][0].get("approval_status") == "approved"
        assert record["tasks"][0].get("factcheck_verdict") == "PASS"

    @patch.dict(os.environ, {"ENABLE_PERSISTENT_MEMORY": "true"}, clear=False)
    def test_memory_search_returns_relevant_records(self, tmp_path):
        memory_path = tmp_path / "memory.jsonl"

        with patch.dict(
            os.environ,
            {"PERSISTENT_MEMORY_PATH": str(memory_path)},
            clear=False,
        ):
            save_run_memory(_build_state("quantum computing trends"))
            save_run_memory(_build_state("urban gardening guide"))

            results = search_memory("quantum", limit=5)
            recent = load_recent_memories(limit=2)

        assert results
        assert "quantum" in results[0].get("goal", "").lower()
        assert len(recent) == 2


class TestWriterMemoryIntegration:
    @patch("agents.writer.synthesize_final_report", side_effect=lambda _goal, combined: combined)
    @patch("agents.writer.save_run_memory", return_value=True)
    @patch("agents.writer.memory_enabled", return_value=True)
    def test_writer_triggers_memory_save(self, _mock_enabled, mock_save, _mock_synth):
        state = {
            "goal": "goal",
            "todos": [
                {
                    "id": 1,
                    "description": "Task 1",
                    "status": "done",
                    "approval_status": "approved",
                }
            ],
            "files": {
                "research_task_1.md": "APPROVED CONTENT",
                "factcheck_task_1.md": "# Fact Check Report\n\n## Verdict\nPASS",
            },
        }

        result = writer_agent(state)

        assert "final_report.txt" in result["files"]
        mock_save.assert_called_once_with(result)