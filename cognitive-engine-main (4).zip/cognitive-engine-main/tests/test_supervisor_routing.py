"""
Unit tests for tools/agent_selector.py and nodes/supervisor.py.

Run with:
    pytest tests/test_supervisor_routing.py -v
"""

from unittest.mock import MagicMock, patch

from nodes.supervisor import supervisor_node
from tools.agent_selector import select_agent


class TestAgentSelector:
    @patch("tools.agent_selector._get_llm")
    def test_llm_valid_selection(self, mock_get_llm):
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content="comparison")
        mock_get_llm.return_value = mock_llm

        selected = select_agent("Compare AWS vs Azure pricing models")

        assert selected == "comparison"

    @patch("tools.agent_selector._get_llm")
    def test_llm_alias_selection(self, mock_get_llm):
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content="analyst")
        mock_get_llm.return_value = mock_llm

        selected = select_agent("Analyze cloud risk and trend signals")

        assert selected == "analysis"

    @patch("tools.agent_selector._get_llm")
    def test_invalid_llm_output_falls_back_to_keywords(self, mock_get_llm):
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content="writer")
        mock_get_llm.return_value = mock_llm

        selected = select_agent("Analyze long-term security risks")

        assert selected == "analysis"

    @patch("tools.agent_selector._get_llm", return_value=None)
    def test_llm_unavailable_falls_back_to_keywords(self, _):
        selected = select_agent("Compare distributed tracing platforms")

        assert selected == "comparison"

    def test_empty_task_uses_first_allowed_agent(self):
        selected = select_agent("   ", allowed_agents=("research", "analysis"))

        assert selected == "research"


class TestSupervisorNode:
    @patch("nodes.supervisor.select_agent", return_value="analysis")
    def test_research_stage_uses_selector(self, mock_select_agent):
        state = {
            "todos": [
                {
                    "id": 1,
                    "description": "Analyze LLM observability trade-offs",
                    "status": "pending",
                    "stage": "research",
                }
            ],
            "execution_log": [],
        }

        result = supervisor_node(state)

        assert result["active_agent"] == "analysis"
        assert result["current_task"] == "Analyze LLM observability trade-offs"
        mock_select_agent.assert_called_once_with(
            "Analyze LLM observability trade-offs",
            allowed_agents=("research", "comparison", "analysis"),
        )
        assert any(
            item.get("task_id") == 1 and item.get("agent") == "analysis"
            for item in result["execution_log"]
            if isinstance(item, dict)
        )

    def test_factcheck_stage_routes_to_factcheck_agent(self):
        state = {
            "todos": [
                {
                    "id": 2,
                    "description": "Validate claim coverage",
                    "status": "pending",
                    "stage": "factcheck",
                }
            ],
            "execution_log": [],
        }

        result = supervisor_node(state)

        assert result["active_agent"] == "factcheck"
        assert any(
            item.get("agent") == "factcheck" and "factcheck" in item.get("observation", "")
            for item in result["execution_log"]
            if isinstance(item, dict)
        )

    def test_approval_stage_routes_to_approval_agent(self):
        state = {
            "todos": [
                {
                    "id": 3,
                    "description": "Wait for approval",
                    "status": "pending",
                    "stage": "approval",
                }
            ],
            "execution_log": [],
        }

        result = supervisor_node(state)

        assert result["active_agent"] == "approval"
        assert any(
            item.get("agent") == "approval" and "approval" in item.get("observation", "")
            for item in result["execution_log"]
            if isinstance(item, dict)
        )

    def test_unknown_stage_falls_back_to_writer(self):
        state = {
            "todos": [
                {
                    "id": 4,
                    "description": "Unexpected stage",
                    "status": "pending",
                    "stage": "custom_stage",
                }
            ],
            "execution_log": [],
        }

        result = supervisor_node(state)

        assert result["active_agent"] == "writer"

    def test_no_pending_tasks_routes_to_writer(self):
        state = {
            "todos": [
                {
                    "id": 9,
                    "description": "Completed task",
                    "status": "done",
                    "stage": "research",
                }
            ],
            "execution_log": [],
        }

        result = supervisor_node(state)

        assert result["active_agent"] == "writer"
