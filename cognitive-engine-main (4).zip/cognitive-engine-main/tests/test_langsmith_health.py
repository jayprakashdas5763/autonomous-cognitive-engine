"""
Unit tests for tools/langsmith_health.py.
"""

from unittest.mock import patch

from tools.langsmith_health import collect_langsmith_health


class TestLangSmithHealth:
    @patch("tools.langsmith_health.importlib.util.find_spec", return_value=object())
    @patch.dict("os.environ", {}, clear=True)
    def test_disabled_when_not_requested(self, _mock_find_spec):
        health = collect_langsmith_health()

        assert health["status"] == "disabled"
        assert health["tracing_requested"] is False
        assert health["runtime_enabled"] is False

    @patch("tools.langsmith_health.importlib.util.find_spec", return_value=object())
    @patch.dict(
        "os.environ",
        {
            "LANGSMITH_TRACING": "true",
            "LANGSMITH_API_KEY": "x",
            "LANGCHAIN_TRACING_V2": "true",
            "LANGCHAIN_API_KEY": "y",
            "LANGSMITH_PROJECT": "proj-a",
        },
        clear=True,
    )
    def test_enabled_when_requested_and_runtime_is_ready(self, _mock_find_spec):
        health = collect_langsmith_health()

        assert health["status"] == "enabled"
        assert health["tracing_requested"] is True
        assert health["runtime_enabled"] is True
        assert health["project"] == "proj-a"
        assert health["issues"] == []

    @patch("tools.langsmith_health.importlib.util.find_spec", return_value=None)
    @patch.dict(
        "os.environ",
        {
            "LANGSMITH_TRACING": "true",
            "LANGSMITH_API_KEY": "x",
            "LANGCHAIN_TRACING_V2": "true",
            "LANGCHAIN_API_KEY": "y",
        },
        clear=True,
    )
    def test_misconfigured_when_package_missing(self, _mock_find_spec):
        health = collect_langsmith_health()

        assert health["status"] == "misconfigured"
        assert any("langsmith package" in issue for issue in health["issues"])

    @patch("tools.langsmith_health.importlib.util.find_spec", return_value=object())
    @patch.dict(
        "os.environ",
        {
            "LANGSMITH_TRACING": "true",
            "LANGSMITH_PROJECT": "alpha",
            "LANGSMITH_ENDPOINT": "https://custom.smith.endpoint",
        },
        clear=True,
    )
    def test_reports_missing_runtime_vars(self, _mock_find_spec):
        health = collect_langsmith_health()

        assert health["status"] == "misconfigured"
        assert health["project"] == "alpha"
        assert health["endpoint"] == "https://custom.smith.endpoint"
        assert any("LANGCHAIN_TRACING_V2" in issue for issue in health["issues"])
        assert any("LANGCHAIN_API_KEY" in issue for issue in health["issues"])
