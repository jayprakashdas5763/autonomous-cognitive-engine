"""
Unit tests for human approval gate behavior.
"""

import os
from unittest.mock import patch

from agents.writer import writer_agent
from nodes.executor import executor_node


def _pass_report() -> str:
    return "# Fact Check Report\n\n## Verdict\nPASS"


def _fail_report() -> str:
    return "# Fact Check Report\n\n## Verdict\nFAIL"


class TestHumanApprovalExecutor:
    @patch("nodes.executor.task", side_effect=lambda state, _agent: state)
    @patch.dict(os.environ, {"ENABLE_HUMAN_APPROVAL": "false"}, clear=False)
    def test_approval_disabled_keeps_old_behavior(self, _mock_task):
        state = {
            "todos": [
                {
                    "id": 1,
                    "description": "Task 1",
                    "status": "pending",
                    "stage": "factcheck",
                }
            ],
            "current_task": "Task 1",
            "active_agent": "factcheck",
            "agent_results": {"Task 1_factcheck": _pass_report()},
            "files": {},
            "results": [],
            "execution_log": [],
        }

        result = executor_node(state)
        task = result["todos"][0]

        assert task["status"] == "done"
        assert task.get("approval_status") == "approved"

    @patch("nodes.executor.task", side_effect=lambda state, _agent: state)
    @patch.dict(os.environ, {"ENABLE_HUMAN_APPROVAL": "true"}, clear=False)
    def test_pass_factcheck_moves_to_pending_approval_when_enabled(self, _mock_task):
        state = {
            "todos": [
                {
                    "id": 1,
                    "description": "Task 1",
                    "status": "pending",
                    "stage": "factcheck",
                }
            ],
            "current_task": "Task 1",
            "active_agent": "factcheck",
            "agent_results": {"Task 1_factcheck": _pass_report()},
            "files": {},
            "results": [],
            "execution_log": [],
            "auto_approve_on_missing_approval": False,
        }

        result = executor_node(state)
        task = result["todos"][0]

        assert task["status"] == "pending"
        assert task["stage"] == "approval"
        assert task.get("approval_status") == "pending_approval"

    @patch.dict(os.environ, {"ENABLE_HUMAN_APPROVAL": "true"}, clear=False)
    def test_approved_task_proceeds(self):
        state = {
            "todos": [
                {
                    "id": 1,
                    "description": "Task 1",
                    "status": "pending",
                    "stage": "approval",
                    "approval_status": "pending_approval",
                }
            ],
            "current_task": "Task 1",
            "active_agent": "approval",
            "approval_decisions": {"1": "approved"},
            "files": {},
            "results": [],
            "execution_log": [],
        }

        result = executor_node(state)
        task = result["todos"][0]

        assert task["status"] == "done"
        assert task.get("approval_status") == "approved"


class TestHumanApprovalWriter:
    @patch.dict(os.environ, {"ENABLE_HUMAN_APPROVAL": "true"}, clear=False)
    @patch("agents.writer.synthesize_final_report", side_effect=lambda _goal, combined: combined)
    def test_rejected_task_is_excluded_from_writer(self, _mock_synth):
        state = {
            "goal": "goal",
            "todos": [
                {
                    "id": 1,
                    "description": "Task 1",
                    "status": "done",
                    "approval_status": "approved",
                },
                {
                    "id": 2,
                    "description": "Task 2",
                    "status": "failed",
                    "approval_status": "rejected",
                },
            ],
            "files": {
                "research_task_1.md": "APPROVED CONTENT",
                "factcheck_task_1.md": _pass_report(),
                "research_task_2.md": "REJECTED CONTENT",
                "factcheck_task_2.md": _pass_report(),
            },
        }

        result = writer_agent(state)
        final_report = result["files"]["final_report.txt"]

        assert "APPROVED CONTENT" in final_report
        assert "REJECTED CONTENT" not in final_report

    @patch.dict(os.environ, {"ENABLE_HUMAN_APPROVAL": "true"}, clear=False)
    @patch("agents.writer.synthesize_final_report", side_effect=lambda _goal, combined: combined)
    def test_writer_includes_only_approved_and_pass(self, _mock_synth):
        state = {
            "goal": "goal",
            "todos": [
                {
                    "id": 1,
                    "description": "Task 1",
                    "status": "done",
                    "approval_status": "approved",
                },
                {
                    "id": 2,
                    "description": "Task 2",
                    "status": "done",
                    "approval_status": "approved",
                },
                {
                    "id": 3,
                    "description": "Task 3",
                    "status": "failed",
                    "approval_status": "rejected",
                },
            ],
            "files": {
                "research_task_1.md": "TASK1_OK",
                "factcheck_task_1.md": _pass_report(),
                "research_task_2.md": "TASK2_FAIL_FACTCHECK",
                "factcheck_task_2.md": _fail_report(),
                "research_task_3.md": "TASK3_REJECTED",
                "factcheck_task_3.md": _pass_report(),
            },
        }

        result = writer_agent(state)
        final_report = result["files"]["final_report.txt"]

        assert "TASK1_OK" in final_report
        assert "TASK2_FAIL_FACTCHECK" not in final_report
        assert "TASK3_REJECTED" not in final_report
