"""
Unit tests for sequential/parallel graph mode selection.
"""

import os
from unittest.mock import patch

from graph import build_graph


class TestGraphModes:
    def test_sequential_graph_builds_when_flag_missing(self):
        with patch.dict(os.environ, {}, clear=False):
            graph_obj = build_graph()

        assert callable(getattr(graph_obj, "invoke", None))

    def test_parallel_graph_builds_when_flag_true(self):
        with patch.dict(os.environ, {"ENABLE_PARALLEL_EXECUTION": "true"}, clear=False):
            graph_obj = build_graph()

        assert callable(getattr(graph_obj, "invoke", None))

    def test_sequential_graph_selected_by_default(self):
        with patch("graph.build_sequential_graph", return_value="SEQ") as seq_builder:
            with patch("graph.build_parallel_graph", return_value="PAR") as par_builder:
                with patch.dict(os.environ, {}, clear=False):
                    result = build_graph()

        assert result == "SEQ"
        seq_builder.assert_called_once()
        par_builder.assert_not_called()

    def test_parallel_graph_selected_when_feature_flag_true(self):
        with patch("graph.build_sequential_graph", return_value="SEQ") as seq_builder:
            with patch("graph.build_parallel_graph", return_value="PAR") as par_builder:
                with patch.dict(os.environ, {"ENABLE_PARALLEL_EXECUTION": "true"}, clear=False):
                    result = build_graph()

        assert result == "PAR"
        par_builder.assert_called_once()
        seq_builder.assert_not_called()

    def test_sequential_graph_selected_when_feature_flag_false(self):
        with patch("graph.build_sequential_graph", return_value="SEQ") as seq_builder:
            with patch("graph.build_parallel_graph", return_value="PAR") as par_builder:
                with patch.dict(os.environ, {"ENABLE_PARALLEL_EXECUTION": "false"}, clear=False):
                    result = build_graph()

        assert result == "SEQ"
        seq_builder.assert_called_once()
        par_builder.assert_not_called()

    def test_persistent_memory_flag_keeps_sequential_default(self):
        with patch("graph.build_sequential_graph", return_value="SEQ") as seq_builder:
            with patch("graph.build_parallel_graph", return_value="PAR") as par_builder:
                with patch.dict(
                    os.environ,
                    {
                        "ENABLE_PARALLEL_EXECUTION": "false",
                        "ENABLE_PERSISTENT_MEMORY": "true",
                    },
                    clear=False,
                ):
                    result = build_graph()

        assert result == "SEQ"
        seq_builder.assert_called_once()
        par_builder.assert_not_called()

    def test_parallel_graph_selected_with_parallel_and_memory_flags_true(self):
        with patch("graph.build_sequential_graph", return_value="SEQ") as seq_builder:
            with patch("graph.build_parallel_graph", return_value="PAR") as par_builder:
                with patch.dict(
                    os.environ,
                    {
                        "ENABLE_PARALLEL_EXECUTION": "true",
                        "ENABLE_PERSISTENT_MEMORY": "true",
                    },
                    clear=False,
                ):
                    result = build_graph()

        assert result == "PAR"
        par_builder.assert_called_once()
        seq_builder.assert_not_called()
