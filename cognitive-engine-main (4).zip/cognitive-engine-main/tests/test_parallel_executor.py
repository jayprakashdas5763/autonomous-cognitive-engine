"""
Unit tests for tools/parallel_executor.py.
"""

import os
from unittest.mock import patch

from tools.parallel_executor import parallel_executor_node


def _task_id(local_state):
    description = local_state["current_task"]
    return next(
        t["id"] for t in local_state.get("todos", []) if t.get("description") == description
    )


def _make_base_state():
    return {
        "messages": ["goal"],
        "goal": "goal",
        "todos": [
            {"id": 1, "description": "Task A", "status": "pending", "stage": "research"},
            {"id": 2, "description": "Task B", "status": "pending", "stage": "research"},
        ],
        "current_task": "",
        "files": {},
        "results": [],
        "active_agent": "",
        "agent_results": {},
        "raw_sources": {},
        "execution_log": [],
    }


class TestParallelExecutor:
    @patch("tools.parallel_executor.select_agent", return_value="research")
    @patch("tools.parallel_executor._parallel_workers", return_value=2)
    @patch("tools.parallel_executor.task")
    def test_multiple_pending_tasks_processed_in_parallel_mode(
        self,
        mock_task,
        _mock_workers,
        _mock_selector,
    ):
        def fake_task(local_state, agent_name):
            tid = _task_id(local_state)
            task_name = local_state["current_task"]

            if agent_name in ("research", "comparison", "analysis"):
                local_state["files"][f"research_task_{tid}.md"] = f"research for {task_name}"
                local_state["agent_results"][task_name] = "research-done"
            elif agent_name == "factcheck":
                report = "# Fact Check Report\n\n## Verdict\nPASS"
                local_state["files"][f"factcheck_task_{tid}.md"] = report
                local_state["agent_results"][f"{task_name}_factcheck"] = report

            return local_state

        mock_task.side_effect = fake_task

        state = _make_base_state()
        result = parallel_executor_node(state)

        statuses = [todo["status"] for todo in result["todos"]]
        assert statuses == ["done", "done"]
        assert "research_task_1.md" in result["files"]
        assert "research_task_2.md" in result["files"]
        assert "factcheck_task_1.md" in result["files"]
        assert "factcheck_task_2.md" in result["files"]

    @patch("tools.parallel_executor.select_agent", return_value="research")
    @patch("tools.parallel_executor._parallel_workers", return_value=2)
    @patch("tools.parallel_executor.task")
    def test_failed_factcheck_retries_are_task_local(
        self,
        mock_task,
        _mock_workers,
        _mock_selector,
    ):
        def fake_task(local_state, agent_name):
            tid = _task_id(local_state)
            task_name = local_state["current_task"]

            if agent_name in ("research", "comparison", "analysis"):
                local_state["files"][f"research_task_{tid}.md"] = f"research for {task_name}"
                local_state["agent_results"][task_name] = "research-done"
            elif agent_name == "factcheck":
                if task_name == "Task A":
                    verdict = "FAIL"
                else:
                    verdict = "PASS"
                report = f"# Fact Check Report\n\n## Verdict\n{verdict}"
                local_state["files"][f"factcheck_task_{tid}.md"] = report
                local_state["agent_results"][f"{task_name}_factcheck"] = report

            return local_state

        mock_task.side_effect = fake_task

        state = _make_base_state()
        result = parallel_executor_node(state)

        task_a = next(todo for todo in result["todos"] if todo["id"] == 1)
        task_b = next(todo for todo in result["todos"] if todo["id"] == 2)

        assert task_a["status"] == "failed"
        assert task_a.get("retries", 0) == 2
        assert task_b["status"] == "done"
        assert task_b.get("retries", 0) == 0

    @patch("tools.parallel_executor.select_agent", return_value="research")
    @patch("tools.parallel_executor._parallel_workers", return_value=2)
    @patch("tools.parallel_executor.task")
    def test_writer_precondition_all_tasks_terminal_before_fan_in_return(
        self,
        mock_task,
        _mock_workers,
        _mock_selector,
    ):
        def fake_task(local_state, agent_name):
            tid = _task_id(local_state)
            task_name = local_state["current_task"]

            if agent_name in ("research", "comparison", "analysis"):
                local_state["files"][f"research_task_{tid}.md"] = f"research for {task_name}"
            elif agent_name == "factcheck":
                report = "# Fact Check Report\n\n## Verdict\nPASS"
                local_state["files"][f"factcheck_task_{tid}.md"] = report
                local_state["agent_results"][f"{task_name}_factcheck"] = report

            return local_state

        mock_task.side_effect = fake_task

        state = _make_base_state()
        result = parallel_executor_node(state)

        assert all(todo.get("status") in ("done", "failed") for todo in result["todos"])

    @patch("tools.parallel_executor.select_agent", return_value="research")
    @patch("tools.parallel_executor._parallel_workers", return_value=2)
    @patch("tools.parallel_executor.task")
    def test_react_style_execution_log_entries_created(
        self,
        mock_task,
        _mock_workers,
        _mock_selector,
    ):
        def fake_task(local_state, agent_name):
            tid = _task_id(local_state)
            task_name = local_state["current_task"]

            if agent_name in ("research", "comparison", "analysis"):
                local_state["files"][f"research_task_{tid}.md"] = f"research for {task_name}"
                local_state["agent_results"][task_name] = "research-done"
            elif agent_name == "factcheck":
                report = "# Fact Check Report\n\n## Verdict\nPASS"
                local_state["files"][f"factcheck_task_{tid}.md"] = report
                local_state["agent_results"][f"{task_name}_factcheck"] = report

            return local_state

        mock_task.side_effect = fake_task

        state = _make_base_state()
        result = parallel_executor_node(state)

        assert len(result["execution_log"]) >= 2

        first = result["execution_log"][0]
        assert isinstance(first, dict)
        assert "task_id" in first
        assert "reason" in first
        assert "action" in first
        assert "agent" in first
        assert "observation" in first

    @patch.dict(os.environ, {"ENABLE_HUMAN_APPROVAL": "true"}, clear=False)
    @patch("tools.parallel_executor.select_agent", return_value="research")
    @patch("tools.parallel_executor._parallel_workers", return_value=2)
    @patch("tools.parallel_executor.task")
    def test_parallel_mode_still_works_with_human_approval_enabled(
        self,
        mock_task,
        _mock_workers,
        _mock_selector,
    ):
        def fake_task(local_state, agent_name):
            tid = _task_id(local_state)
            task_name = local_state["current_task"]

            if agent_name in ("research", "comparison", "analysis"):
                local_state["files"][f"research_task_{tid}.md"] = f"research for {task_name}"
                local_state["agent_results"][task_name] = "research-done"
            elif agent_name == "factcheck":
                report = "# Fact Check Report\n\n## Verdict\nPASS"
                local_state["files"][f"factcheck_task_{tid}.md"] = report
                local_state["agent_results"][f"{task_name}_factcheck"] = report

            return local_state

        mock_task.side_effect = fake_task

        state = _make_base_state()
        state["auto_approve_on_missing_approval"] = True

        result = parallel_executor_node(state)

        assert all(todo.get("status") == "done" for todo in result["todos"])
        assert all(todo.get("approval_status") == "approved" for todo in result["todos"])
