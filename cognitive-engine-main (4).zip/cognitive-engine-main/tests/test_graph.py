"""
Unit tests for graph.py and state.py.

Run with:  pytest tests/ -v
"""
from unittest.mock import patch, MagicMock

from graph import build_graph, MAX_EXECUTOR_ITERATIONS
from state import AgentState


class TestBuildGraph:
    def test_build_graph_returns_object(self):
        graph = build_graph()
        assert graph is not None

    def test_graph_has_invoke_method(self):
        graph = build_graph()
        assert callable(getattr(graph, "invoke", None))


class TestMaxIterations:
    def test_max_iterations_is_positive_int(self):
        assert isinstance(MAX_EXECUTOR_ITERATIONS, int)
        assert MAX_EXECUTOR_ITERATIONS > 0

    def test_max_iterations_reasonable_bound(self):
        # Sanity check: shouldn't be so low it breaks normal runs
        # or so high it allows runaway loops for minutes.
        assert 5 <= MAX_EXECUTOR_ITERATIONS <= 200


class TestAgentState:
    def test_valid_state_dict(self):
        """AgentState is a TypedDict — verify all keys are present including goal."""
        state: AgentState = {
            "messages": ["hello"],
            "todos": [],
            "current_task": "",
            "files": {},
            "results": [],
            "goal": "hello",
        }
        assert state["messages"] == ["hello"]
        assert state["todos"] == []
        assert state["files"] == {}
        assert state["results"] == []
        assert state["goal"] == "hello"


class TestPlannerQuality:
    """Test that planner creates 3-5 meaningful tasks."""

    @patch("tools.planning._get_llm")
    def test_planner_creates_3_to_5_tasks(self, mock_get_llm):
        """Verify planner output has 3-5 tasks."""
        from tools.planning import write_todos

        # Mock successful LLM response
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(
            content='[{"id": 1, "description": "Research quantum computing breakthroughs", "status": "pending"}, '
            '{"id": 2, "description": "Find enterprise quantum applications", "status": "pending"}, '
            '{"id": 3, "description": "Summarize findings into a report", "status": "pending"}]'
        )
        mock_get_llm.return_value = mock_llm

        goal = "Research quantum computing breakthroughs"
        result = write_todos(goal)

        # Verify result is a list
        assert isinstance(result, list), "write_todos should return a list"

        # Verify task count is between 3 and 5
        assert 3 <= len(result) <= 5, f"Expected 3-5 tasks, got {len(result)}"

        # Verify each task has required fields
        for task in result:
            assert "id" in task, "Task missing 'id' field"
            assert "description" in task, "Task missing 'description' field"
            assert "status" in task, "Task missing 'status' field"
            assert task["description"], "Task description should not be empty"

    @patch("tools.planning._get_llm")
    def test_planner_fallback_returns_3_to_5_tasks(self, mock_get_llm):
        """Verify fallback also returns 3-5 tasks (not just 1)."""
        from tools.planning import write_todos

        # Mock failed response — LLM unavailable
        mock_get_llm.return_value = None

        goal = "Test goal"
        result = write_todos(goal)

        assert isinstance(result, list), "Fallback should return a list"
        assert 3 <= len(result) <= 5, f"Fallback should create 3-5 tasks, got {len(result)}"

    @patch("tools.planning._get_llm")
    def test_planner_tasks_are_distinct(self, mock_get_llm):
        """Verify tasks are not duplicates of the goal."""
        from tools.planning import write_todos

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(
            content='[{"id": 1, "description": "Search for AI developments in 2024", "status": "pending"}, '
            '{"id": 2, "description": "Find enterprise AI applications", "status": "pending"}, '
            '{"id": 3, "description": "Analyze AI risks and limitations", "status": "pending"}]'
        )
        mock_get_llm.return_value = mock_llm

        goal = "Research AI and write a report"
        result = write_todos(goal)

        # Verify we got tasks
        assert isinstance(result, list), "Should return a list"
        assert len(result) > 0, "Should have at least one task"


# ---------------------------------------------------------------------------
# Final report quality tests
# ---------------------------------------------------------------------------

class TestFinalReportQuality:
    """Tests verifying the synthesized final report is clean and well-structured."""

    # --- Static report structure checks ---

    def test_report_has_exactly_one_research_report_heading(self):
        report = (
            "# Research Report\n\n## Executive Summary\nSome text.\n\n"
            "## Key Findings\n- Finding one\n\n## Sources\n- No sources"
        )
        assert report.count("# Research Report") == 1

    def test_report_does_not_contain_generic_guideline_text(self):
        report = (
            "# Research Report\n\n## Executive Summary\nSome text.\n\n"
            "## Sources\n- [Example](https://example.com)"
        )
        assert "Guidelines for Gathering" not in report
        assert "Structured Report Compilation" not in report
        assert "Gathering Supporting Evidence" not in report

    def test_report_includes_sources_section(self):
        report = (
            "# Research Report\n\n## Executive Summary\nSome text.\n\n"
            "## Sources\n- [Example](https://example.com)"
        )
        assert "## Sources" in report

    def test_sources_deduplication(self):
        raw_sources = [
            "https://example.com",
            "https://foo.com",
            "https://example.com",  # duplicate
        ]
        unique = list(dict.fromkeys(raw_sources))
        assert len(unique) == 2
        assert "https://example.com" in unique
        assert "https://foo.com" in unique

    # --- Synthesizer node behaviour ---

    @patch("agents.summarizer._get_llm")
    def test_synthesizer_node_skips_generic_content(self, mock_get_llm):
        """Synthesizer must filter out generic/template task outputs."""
        from nodes.synthesizer import synthesizer_node

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(
            content="# Research Report\n\n## Executive Summary\nClean report.\n\n## Sources\n- None"
        )
        mock_get_llm.return_value = mock_llm

        state = {
            "messages": ["Research LangGraph"],
            "goal": "Research LangGraph",
            "files": {
                "task_1.txt": "# Research Report\n## Key Findings\n- LangGraph is a framework",
                "task_2.txt": "Guidelines for Gathering Supporting Evidence: always cite sources...",
            },
            "todos": [],
            "results": [],
            "current_task": "",
        }
        result_state = synthesizer_node(state)
        assert "final_report.txt" in result_state["files"]
        # Generic content task_2 should have been filtered; LLM still called once
        mock_llm.invoke.assert_called_once()

    @patch("agents.summarizer._get_llm")
    def test_synthesizer_node_produces_single_heading(self, mock_get_llm):
        """Final report must not contain multiple # Research Report headings."""
        from nodes.synthesizer import synthesizer_node

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(
            content=(
                "# Research Report\n\n## Executive Summary\nSummary.\n\n"
                "## Key Findings\n- Finding\n\n## Sources\n- [X](http://x.com)"
            )
        )
        mock_get_llm.return_value = mock_llm

        state = {
            "messages": ["Research LangGraph"],
            "goal": "Research LangGraph",
            "files": {
                "task_1.txt": "# Research Report\nReport on LangGraph.",
                "task_2.txt": "# Research Report\nReport on LangSmith.",
            },
            "todos": [],
            "results": [],
            "current_task": "",
        }
        result_state = synthesizer_node(state)
        final = result_state["files"]["final_report.txt"]
        assert final.count("# Research Report") == 1

    @patch("agents.summarizer._get_llm")
    def test_synthesizer_node_uses_goal_for_synthesis(self, mock_get_llm):
        """Synthesizer must pass the stored goal to synthesize_final_report."""
        from nodes.synthesizer import synthesizer_node

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(
            content="# Research Report\n\n## Sources\n- None"
        )
        mock_get_llm.return_value = mock_llm

        goal = "Research Tavily web search API"
        state = {
            "messages": [goal],
            "goal": goal,
            "files": {"task_1.txt": "Tavily is a search API for LLM agents."},
            "todos": [],
            "results": [],
            "current_task": "",
        }
        synthesizer_node(state)
        # The prompt sent to LLM should reference the goal
        prompt_text = str(mock_llm.invoke.call_args)
        assert goal in prompt_text

    @patch("agents.summarizer._get_llm")
    def test_synthesizer_fallback_when_no_task_files(self, mock_get_llm):
        """When there are no task files, synthesizer should return a fallback message."""
        from nodes.synthesizer import synthesizer_node

        mock_get_llm.return_value = MagicMock()

        state = {
            "messages": ["Research something"],
            "goal": "Research something",
            "files": {},
            "todos": [],
            "results": [],
            "current_task": "",
        }
        result_state = synthesizer_node(state)
        assert "final_report.txt" in result_state["files"]
        assert "No results" in result_state["files"]["final_report.txt"]
