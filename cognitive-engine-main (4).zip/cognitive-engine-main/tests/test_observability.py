"""
Unit tests for tools/observability.py.
"""

from tools.observability import (
    RUN_ID_KEY,
    build_graph_invoke_config,
    extract_graph_run_id,
    get_current_factcheck_verdict,
    get_task_context,
    parse_factcheck_verdict,
)


class TestObservabilityConfig:
    def test_build_config_contains_run_id_and_recursion_limit(self):
        config = build_graph_invoke_config(recursion_limit=77, graph_run_id="run123")

        assert config["recursion_limit"] == 77
        assert config["configurable"][RUN_ID_KEY] == "run123"

    def test_extract_graph_run_id_from_configurable(self):
        config = {"configurable": {RUN_ID_KEY: "abc"}}

        assert extract_graph_run_id(config) == "abc"

    def test_extract_graph_run_id_defaults_to_unknown(self):
        assert extract_graph_run_id({}) == "unknown"
        assert extract_graph_run_id(None) == "unknown"


class TestTaskContext:
    def test_get_task_context_matches_current_task(self):
        state = {
            "current_task": "Task B",
            "todos": [
                {"id": 1, "description": "Task A", "status": "done", "retries": 0},
                {"id": 2, "description": "Task B", "status": "pending", "retries": 1},
            ],
        }

        task_id, retries = get_task_context(state)

        assert task_id == "2"
        assert retries == 1

    def test_get_task_context_falls_back_to_pending_task(self):
        state = {
            "current_task": "",
            "todos": [
                {"id": 3, "description": "Task C", "status": "pending", "retries": 2},
            ],
        }

        task_id, retries = get_task_context(state)

        assert task_id == "3"
        assert retries == 2


class TestFactcheckVerdict:
    def test_parse_factcheck_verdict(self):
        report = "# Fact Check Report\n\n## Verdict\nPASS"

        assert parse_factcheck_verdict(report) == "PASS"

    def test_get_current_factcheck_verdict(self):
        state = {
            "current_task": "Task A",
            "agent_results": {
                "Task A_factcheck": "# Fact Check Report\n\n## Verdict\nFAIL",
            },
        }

        assert get_current_factcheck_verdict(state) == "FAIL"
