"""
Unit tests for tools/file_system.py edit_file behavior.
"""

from tools.file_system import edit_file, read_file, write_file


class TestEditFile:
    def test_edit_existing_file(self):
        state = {"files": {"a.txt": "old"}}

        result = edit_file(state, "a.txt", "new")

        assert result["ok"] is True
        assert result["created"] is False
        assert read_file(state, "a.txt") == "new"

    def test_edit_missing_file_returns_clear_error(self):
        state = {"files": {}}

        result = edit_file(state, "missing.txt", "value")

        assert result["ok"] is False
        assert result["created"] is False
        assert "Cannot edit missing file" in result["message"]
        assert "missing.txt" not in state["files"]

    def test_edit_preserves_other_files(self):
        state = {"files": {"a.txt": "A", "b.txt": "B"}}

        result = edit_file(state, "a.txt", "A2")

        assert result["ok"] is True
        assert state["files"]["a.txt"] == "A2"
        assert state["files"]["b.txt"] == "B"

    def test_edit_missing_can_create_when_allowed(self):
        state = {"files": {}}

        result = edit_file(state, "new.txt", "hello", allow_create=True)

        assert result["ok"] is True
        assert result["created"] is True
        assert read_file(state, "new.txt") == "hello"

    def test_write_file_still_works(self):
        state = {"files": {}}
        write_file(state, "x.txt", "X")
        assert read_file(state, "x.txt") == "X"
