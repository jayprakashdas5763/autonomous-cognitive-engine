﻿import time
from tools.planning import write_todos
from logging_config import get_logger
from tools.memory_store import (
    load_recent_memories,
    memory_enabled,
    search_memory,
)

logger = get_logger(__name__)

_MAX_MEMORY_CONTEXT_CHARS = 1200


def _truncate(value: str, limit: int) -> str:
    text = str(value or "").strip()
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)] + "..."


def _build_memory_context(memories: list[dict]) -> str:
    if not memories:
        return ""

    lines = [
        "Prior run memory (summarized):",
        "Use this only as context; still plan fresh tasks for the current goal.",
    ]

    for index, memory in enumerate(memories, start=1):
        goal = _truncate(memory.get("goal", ""), 160)
        created = _truncate(memory.get("created_at", ""), 40)
        final_excerpt = _truncate(memory.get("final_report_excerpt", ""), 240)

        task_descriptions = []
        for task in memory.get("tasks", [])[:3]:
            if isinstance(task, dict):
                task_descriptions.append(_truncate(task.get("description", ""), 80))

        task_summary = "; ".join(item for item in task_descriptions if item)

        lines.append(f"{index}. goal={goal}")
        if created:
            lines.append(f"   created_at={created}")
        if task_summary:
            lines.append(f"   related_tasks={task_summary}")
        if final_excerpt:
            lines.append(f"   outcome={final_excerpt}")

    context = "\n".join(lines).strip()
    return _truncate(context, _MAX_MEMORY_CONTEXT_CHARS)


def planner_node(state):
    goal = state["messages"][-1]

    logger.info("Planning tasks for goal: %.80s", goal)

    t_start = time.perf_counter()

    prior_memory_context = ""
    if memory_enabled():
        logger.info("[OBS] memory_enabled stage=planning")
        memory_hits = search_memory(goal, limit=3)
        if not memory_hits:
            memory_hits = load_recent_memories(limit=2)
        logger.info("[OBS] memory_retrieval_count=%d stage=planning", len(memory_hits))
        prior_memory_context = _build_memory_context(memory_hits)
        if prior_memory_context:
            logger.info("[OBS] memory_reused stage=planning count=%d", len(memory_hits))
    else:
        logger.info("[OBS] memory_disabled stage=planning")

    todos = write_todos(goal, prior_memory_context=prior_memory_context)

    for task in todos:
        task.setdefault("stage", "research")

    elapsed = time.perf_counter() - t_start

    state["todos"] = todos
    state["goal"] = goal

    logger.info(
        "[TIMING] Planning step took %.2fs - created %d task(s).", elapsed, len(todos)
    )

    return state

