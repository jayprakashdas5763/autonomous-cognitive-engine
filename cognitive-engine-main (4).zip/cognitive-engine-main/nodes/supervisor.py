﻿from logging_config import get_logger
from tools.agent_selector import select_agent

logger = get_logger(__name__)


def supervisor_node(state):

    pending_tasks = [t for t in state["todos"] if t.get("status") == "pending"]

    if not pending_tasks:

        state["active_agent"] = "writer"

        return state

    current = pending_tasks[0]

    state["current_task"] = current["description"]

    stage = current.get("stage", "research")

    description = current["description"]

    if stage == "research":

        state["active_agent"] = select_agent(
            description,
            allowed_agents=(
                "research",
                "comparison",
                "analysis",
            ),
        )

    elif stage == "factcheck":

        state["active_agent"] = "factcheck"

    elif stage == "approval":

        state["active_agent"] = "approval"

    else:

        state["active_agent"] = "writer"

        logger.warning(
            "Unknown stage='%s' for task='%s'. Falling back to writer.",
            stage,
            current["description"],
        )

    state.setdefault("execution_log", []).append(
        {
            "task_id": current.get("id", "?"),
            "reason": "Select specialist handler for task stage",
            "action": "route",
            "agent": state["active_agent"],
            "observation": "Routed stage {stage} to {agent}".format(
                stage=stage,
                agent=state["active_agent"],
            ),
            "retry_count": int(current.get("retries", 0) or 0),
            "factcheck_verdict": "N/A",
            "mode": "supervisor",
        }
    )

    logger.info(
        "Supervisor selected agent=%s for task='%s' stage=%s",
        state["active_agent"],
        current["description"],
        stage,
    )

    return state
