﻿import time

from logging_config import get_logger
from tools.human_approval import (
    APPROVAL_APPROVED,
    APPROVAL_PENDING,
    APPROVAL_REJECTED,
    human_approval_enabled,
    mark_pending_approval,
    resolve_task_approval,
)
from tools.task import task

logger = get_logger(__name__)


_MAX_RETRIES = 2


def _parse_verdict(factcheck_text: str) -> str:
    verdict = "UNKNOWN"

    if "## Verdict" not in factcheck_text:
        return verdict

    verdict_section = factcheck_text.split("## Verdict", 1)[1]
    lines = [line.strip() for line in verdict_section.splitlines() if line.strip()]

    if lines:
        verdict = lines[0].upper()

    return verdict


def executor_node(state):

    for todo in state["todos"]:

        if todo.get("status") != "pending":
            continue

        task_id = todo.get("id", "?")

        logger.info(
            "Executing task %s via %s",
            task_id,
            state.get("active_agent"),
        )

        t_start = time.perf_counter()

        try:

            current_stage = todo.get("stage")

            # ------------------------------------
            # Human approval stage
            # ------------------------------------

            if current_stage == "approval":

                approval_state = resolve_task_approval(
                    todo,
                    state,
                )

                if approval_state == APPROVAL_APPROVED:
                    logger.info("[OBS] task_approved task_id=%s", task_id)
                elif approval_state == APPROVAL_REJECTED:
                    logger.warning("[OBS] task_rejected task_id=%s", task_id)
                else:
                    logger.info("[OBS] task_pending_approval task_id=%s", task_id)

                elapsed = time.perf_counter() - t_start

                logger.info(
                    "[TIMING] Task %s completed in %.2fs",
                    task_id,
                    elapsed,
                )

                break

            # ------------------------------------
            # Delegate task to selected agent
            # ------------------------------------

            state = task(
                state,
                state["active_agent"],
            )

            elapsed = time.perf_counter() - t_start

            # ------------------------------------
            # Research completed
            # ------------------------------------

            if current_stage == "research":

                todo["stage"] = "factcheck"

                logger.info(
                    "Task %s research completed; moved to factcheck",
                    task_id,
                )

            # ------------------------------------
            # Factcheck completed
            # ------------------------------------

            elif current_stage == "factcheck":

                factcheck_key = f"{todo['description']}_factcheck"

                factcheck = state.get("agent_results", {}).get(factcheck_key, "")

                if not factcheck:

                    logger.warning(
                        "No factcheck report found for task %s",
                        task_id,
                    )

                logger.info(
                    "Factcheck result for task %s:\n%s",
                    task_id,
                    factcheck[:1000],
                )

                retries = int(todo.get("retries", 0) or 0)

                verdict = _parse_verdict(factcheck)

                logger.info(
                    "Parsed verdict for task %s: %s",
                    task_id,
                    verdict,
                )

                # ------------------------------------
                # Retry on FAIL
                # ------------------------------------

                if verdict == "FAIL":

                    if retries < _MAX_RETRIES:

                        todo["stage"] = "research"
                        todo["retries"] = retries + 1

                        logger.warning(
                            "Task %s failed factcheck. Retry %d/%d",
                            task_id,
                            todo["retries"],
                            _MAX_RETRIES,
                        )

                    else:

                        todo["status"] = "failed"

                        logger.error(
                            "Task %s exceeded maximum retries.",
                            task_id,
                        )

                else:

                    if human_approval_enabled():

                        mark_pending_approval(todo)

                        logger.info(
                            "[OBS] approval_required task_id=%s selected_agent=factcheck",
                            task_id,
                        )
                        logger.info(
                            "[OBS] task_pending_approval task_id=%s approval_state=%s",
                            task_id,
                            APPROVAL_PENDING,
                        )

                    else:

                        todo["status"] = "done"
                        todo["approval_status"] = APPROVAL_APPROVED

                        logger.info(
                            "[OBS] approval_bypassed task_id=%s reason=feature_flag_disabled",
                            task_id,
                        )

                        logger.info(
                            "Task %s fully completed",
                            task_id,
                        )

            logger.info(
                "[TIMING] Task %s completed in %.2fs",
                task_id,
                elapsed,
            )

        except Exception:

            elapsed = time.perf_counter() - t_start

            todo["status"] = "failed"

            logger.exception(
                "Task %s failed after %.2fs",
                task_id,
                elapsed,
            )

        # Execute one task per graph iteration
        break

    return state
