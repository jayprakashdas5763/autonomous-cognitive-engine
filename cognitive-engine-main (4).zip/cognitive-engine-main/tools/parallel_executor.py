import copy
import os
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

from logging_config import get_logger
from tools.agent_selector import select_agent
from tools.human_approval import (
    APPROVAL_APPROVED,
    APPROVAL_PENDING,
    APPROVAL_REJECTED,
    human_approval_enabled,
    mark_pending_approval,
    resolve_task_approval,
)
from tools.observability import parse_factcheck_verdict
from tools.task import task

logger = get_logger(__name__)

_MAX_RETRIES = 2
_DEFAULT_PARALLEL_WORKERS = 4


def _parallel_workers() -> int:
    raw = os.getenv("PARALLEL_MAX_WORKERS", str(_DEFAULT_PARALLEL_WORKERS)).strip()
    try:
        parsed = int(raw)
    except ValueError:
        return _DEFAULT_PARALLEL_WORKERS
    return max(1, parsed)


def _dict_delta(before: dict, after: dict) -> dict:
    return {
        key: value
        for key, value in after.items()
        if key not in before or before.get(key) != value
    }


def _snapshot_state(state: dict) -> dict:
    return {
        "messages": list(state.get("messages", [])),
        "todos": [dict(item) for item in state.get("todos", [])],
        "files": dict(state.get("files", {})),
        "results": list(state.get("results", [])),
        "goal": state.get("goal", ""),
        "agent_results": dict(state.get("agent_results", {})),
        "raw_sources": dict(state.get("raw_sources", {})),
    }


def _run_task_worker(snapshot: dict, todo: dict, agent_name: str) -> dict:
    current_task = todo.get("description", "")

    worker_state = {
        "messages": list(snapshot.get("messages", [])),
        "todos": [dict(item) for item in snapshot.get("todos", [])],
        "current_task": current_task,
        "files": dict(snapshot.get("files", {})),
        "results": [],
        "goal": snapshot.get("goal", ""),
        "active_agent": agent_name,
        "agent_results": dict(snapshot.get("agent_results", {})),
        "raw_sources": dict(snapshot.get("raw_sources", {})),
        "execution_log": [],
    }

    before_files = copy.deepcopy(worker_state["files"])
    before_agent_results = copy.deepcopy(worker_state["agent_results"])
    before_raw_sources = copy.deepcopy(worker_state["raw_sources"])

    try:
        updated_state = task(worker_state, agent_name)
    except (
        ValueError,
        TypeError,
        RuntimeError,
        ConnectionError,
        TimeoutError,
        OSError,
        AttributeError,
    ) as exc:
        return {
            "ok": False,
            "error": str(exc),
            "task_id": todo.get("id", "?"),
            "task_description": current_task,
            "agent": agent_name,
            "files_delta": {},
            "agent_results_delta": {},
            "raw_sources_delta": {},
            "results_new": [],
            "factcheck_report": "",
        }

    after_files = updated_state.get("files", {})
    after_agent_results = updated_state.get("agent_results", {})
    after_raw_sources = updated_state.get("raw_sources", {})

    factcheck_report = ""
    if isinstance(after_agent_results, dict):
        factcheck_report = after_agent_results.get(f"{current_task}_factcheck", "")

    return {
        "ok": True,
        "task_id": todo.get("id", "?"),
        "task_description": current_task,
        "agent": agent_name,
        "files_delta": _dict_delta(before_files, after_files),
        "agent_results_delta": _dict_delta(before_agent_results, after_agent_results),
        "raw_sources_delta": _dict_delta(before_raw_sources, after_raw_sources),
        "results_new": list(updated_state.get("results", [])),
        "factcheck_report": factcheck_report,
    }


def _merge_worker_output(state: dict, output: dict) -> None:
    state.setdefault("files", {}).update(output.get("files_delta", {}))
    state.setdefault("agent_results", {}).update(output.get("agent_results_delta", {}))
    state.setdefault("raw_sources", {}).update(output.get("raw_sources_delta", {}))
    state.setdefault("results", []).extend(output.get("results_new", []))


def _append_execution_log(
    state: dict,
    task_id,
    reason: str,
    action: str,
    agent: str,
    observation: str,
    retry_count: int,
    verdict: str,
):
    state.setdefault("execution_log", []).append(
        {
            "task_id": task_id,
            "reason": reason,
            "action": action,
            "agent": agent,
            "observation": observation,
            "retry_count": retry_count,
            "factcheck_verdict": verdict or "N/A",
            "mode": "parallel",
        }
    )


def _pending_todos(state: dict) -> list:
    return [todo for todo in state.get("todos", []) if todo.get("status") == "pending"]


def _execute_research_batch(state: dict, todos: list) -> None:
    if not todos:
        return

    snapshot = _snapshot_state(state)
    workers = min(_parallel_workers(), len(todos))

    logger.info(
        "[OBS] parallel_batch_start stage=research size=%d workers=%d",
        len(todos),
        workers,
    )

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {}

        for todo in todos:
            task_id = todo.get("id", "?")
            description = todo.get("description", "")
            selected_agent = select_agent(
                description,
                allowed_agents=("research", "comparison", "analysis"),
            )

            logger.info(
                "[OBS] parallel_task_dispatch stage=research task_id=%s selected_agent=%s retry_count=%d",
                task_id,
                selected_agent,
                int(todo.get("retries", 0) or 0),
            )

            future = executor.submit(_run_task_worker, snapshot, todo, selected_agent)
            future_map[future] = (todo, selected_agent)

        for future in as_completed(future_map):
            todo, selected_agent = future_map[future]
            task_id = todo.get("id", "?")

            output = future.result()
            if not output.get("ok"):
                todo["status"] = "failed"
                logger.error(
                    "[OBS] parallel_task_failed stage=research task_id=%s selected_agent=%s error=%s",
                    task_id,
                    selected_agent,
                    output.get("error", "unknown"),
                )
                _append_execution_log(
                    state,
                    task_id=task_id,
                    reason="Task requires web research",
                    action="delegate",
                    agent=selected_agent,
                    observation=f"Delegation failed: {output.get('error', 'unknown error')}",
                    retry_count=int(todo.get("retries", 0) or 0),
                    verdict="N/A",
                )
                continue

            _merge_worker_output(state, output)
            todo["stage"] = "factcheck"

            created_files = sorted(output.get("files_delta", {}).keys())
            observation = "research output stored"
            if created_files:
                observation = f"created {', '.join(created_files)}"

            logger.info(
                "[OBS] parallel_task_completed stage=research task_id=%s selected_agent=%s observation=%s",
                task_id,
                selected_agent,
                observation,
            )

            _append_execution_log(
                state,
                task_id=task_id,
                reason="Task requires web research",
                action="delegate",
                agent=selected_agent,
                observation=observation,
                retry_count=int(todo.get("retries", 0) or 0),
                verdict="N/A",
            )


def _execute_factcheck_batch(state: dict, todos: list) -> None:
    if not todos:
        return

    snapshot = _snapshot_state(state)
    workers = min(_parallel_workers(), len(todos))

    logger.info(
        "[OBS] parallel_batch_start stage=factcheck size=%d workers=%d",
        len(todos),
        workers,
    )

    with ThreadPoolExecutor(max_workers=workers) as executor:
        future_map = {}

        for todo in todos:
            task_id = todo.get("id", "?")
            retry_count = int(todo.get("retries", 0) or 0)
            logger.info(
                "[OBS] parallel_task_dispatch stage=factcheck task_id=%s selected_agent=factcheck retry_count=%d",
                task_id,
                retry_count,
            )
            future = executor.submit(_run_task_worker, snapshot, todo, "factcheck")
            future_map[future] = todo

        for future in as_completed(future_map):
            todo = future_map[future]
            task_id = todo.get("id", "?")
            retries = int(todo.get("retries", 0) or 0)

            output = future.result()
            if not output.get("ok"):
                todo["status"] = "failed"
                logger.error(
                    "[OBS] parallel_task_failed stage=factcheck task_id=%s error=%s",
                    task_id,
                    output.get("error", "unknown"),
                )
                _append_execution_log(
                    state,
                    task_id=task_id,
                    reason="Research output must be validated",
                    action="delegate",
                    agent="factcheck",
                    observation=f"Factcheck delegation failed: {output.get('error', 'unknown error')}",
                    retry_count=retries,
                    verdict="UNKNOWN",
                )
                continue

            _merge_worker_output(state, output)

            verdict = parse_factcheck_verdict(output.get("factcheck_report", "")) or "UNKNOWN"
            logger.info(
                "[OBS] factcheck_verdict task_id=%s selected_agent=factcheck retry_count=%d verdict=%s",
                task_id,
                retries,
                verdict,
            )

            if verdict == "FAIL":
                if retries < _MAX_RETRIES:
                    todo["stage"] = "research"
                    todo["retries"] = retries + 1
                    observation = f"Factcheck FAIL; retry scheduled {todo['retries']}/{_MAX_RETRIES}"
                else:
                    todo["status"] = "failed"
                    observation = "Factcheck FAIL; max retries exceeded"
            else:
                if human_approval_enabled():
                    mark_pending_approval(todo)
                    observation = "Factcheck PASS; task pending approval"
                    logger.info(
                        "[OBS] approval_required task_id=%s selected_agent=factcheck",
                        task_id,
                    )
                    logger.info(
                        "[OBS] task_pending_approval task_id=%s approval_state=%s",
                        task_id,
                        APPROVAL_PENDING,
                    )
                else:
                    todo["status"] = "done"
                    todo["approval_status"] = APPROVAL_APPROVED
                    observation = "Factcheck PASS; task completed"
                    logger.info(
                        "[OBS] approval_bypassed task_id=%s reason=feature_flag_disabled",
                        task_id,
                    )

            _append_execution_log(
                state,
                task_id=task_id,
                reason="Research output must be validated",
                action="delegate",
                agent="factcheck",
                observation=observation,
                retry_count=int(todo.get("retries", 0) or 0),
                verdict=verdict,
            )


def _execute_approval_batch(state: dict, todos: list) -> None:
    if not todos:
        return

    logger.info(
        "[OBS] parallel_batch_start stage=approval size=%d workers=1",
        len(todos),
    )

    for todo in todos:
        task_id = todo.get("id", "?")
        retries = int(todo.get("retries", 0) or 0)

        approval_state = resolve_task_approval(todo, state)

        if approval_state == APPROVAL_APPROVED:
            logger.info("[OBS] task_approved task_id=%s", task_id)
            observation = "Human approval granted"
        elif approval_state == APPROVAL_REJECTED:
            logger.warning("[OBS] task_rejected task_id=%s", task_id)
            observation = "Human approval rejected"
        else:
            logger.info("[OBS] task_pending_approval task_id=%s", task_id)
            observation = "Awaiting human approval"

        _append_execution_log(
            state,
            task_id=task_id,
            reason="Task requires human approval after factcheck",
            action="human_approval",
            agent="human",
            observation=observation,
            retry_count=retries,
            verdict="N/A",
        )


def parallel_executor_node(state: dict):
    """Parallel-capable executor for independent tasks with task-local retries."""
    t_start = time.perf_counter()

    state.setdefault("files", {})
    state.setdefault("agent_results", {})
    state.setdefault("raw_sources", {})
    state.setdefault("results", [])
    state.setdefault("execution_log", [])

    todos = state.get("todos", [])
    if not todos:
        logger.warning("[OBS] parallel_executor_no_todos")
        return state

    logger.info(
        "[OBS] parallel_executor_start total_todos=%d pending=%d workers=%d",
        len(todos),
        len(_pending_todos(state)),
        _parallel_workers(),
    )

    max_cycles = max(1, len(todos) * (_MAX_RETRIES + 3))

    for _ in range(max_cycles):
        pending = _pending_todos(state)
        if not pending:
            break

        research_batch = [todo for todo in pending if todo.get("stage", "research") == "research"]
        if research_batch:
            _execute_research_batch(state, research_batch)

        pending = _pending_todos(state)
        factcheck_batch = [todo for todo in pending if todo.get("stage") == "factcheck"]
        if factcheck_batch:
            _execute_factcheck_batch(state, factcheck_batch)

        if human_approval_enabled():
            pending = _pending_todos(state)
            approval_batch = [todo for todo in pending if todo.get("stage") == "approval"]
            if approval_batch:
                _execute_approval_batch(state, approval_batch)

        pending = _pending_todos(state)
        known_stages = ("research", "factcheck", "approval")
        unknown_stage = [todo for todo in pending if todo.get("stage") not in known_stages]
        for todo in unknown_stage:
            todo["status"] = "failed"
            task_id = todo.get("id", "?")
            stage = todo.get("stage")
            logger.error(
                "[OBS] parallel_task_failed stage=%s task_id=%s reason=unknown_stage",
                stage,
                task_id,
            )
            _append_execution_log(
                state,
                task_id=task_id,
                reason="Unsupported stage in parallel executor",
                action="mark_failed",
                agent="N/A",
                observation=f"Unknown stage: {stage}",
                retry_count=int(todo.get("retries", 0) or 0),
                verdict="UNKNOWN",
            )

    remaining = _pending_todos(state)
    if remaining:
        logger.error(
            "[OBS] parallel_executor_guard_triggered pending_remaining=%d",
            len(remaining),
        )
        for todo in remaining:
            todo["status"] = "failed"

    elapsed = time.perf_counter() - t_start
    done = sum(1 for todo in state.get("todos", []) if todo.get("status") == "done")
    failed = sum(1 for todo in state.get("todos", []) if todo.get("status") == "failed")

    logger.info(
        "[OBS] parallel_fan_in_complete done=%d failed=%d elapsed=%.2fs",
        done,
        failed,
        elapsed,
    )

    return state
