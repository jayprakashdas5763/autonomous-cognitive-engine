from logging_config import get_logger

logger = get_logger(__name__)


def write_file(state, name, content):
    state.setdefault("files", {})[name] = content
    logger.info("[OBS] file_written name=%s size=%d", name, len(content or ""))


def read_file(state, name):
    return state.get("files", {}).get(name, "")


def list_files(state):
    return list(state.get("files", {}).keys())


def edit_file(state, name, content, allow_create=False):
    """Edit an existing virtual file. If allow_create is True, create when missing."""
    files = state.setdefault("files", {})

    if name not in files:
        if allow_create:
            files[name] = content
            logger.info(
                "[OBS] file_edited name=%s mode=created size=%d",
                name,
                len(content or ""),
            )
            return {
                "ok": True,
                "created": True,
                "message": f"Created missing file: {name}",
            }

        return {
            "ok": False,
            "created": False,
            "message": f"Cannot edit missing file: {name}",
        }

    files[name] = content
    logger.info(
        "[OBS] file_edited name=%s mode=updated size=%d",
        name,
        len(content or ""),
    )
    return {
        "ok": True,
        "created": False,
        "message": f"Updated file: {name}",
    }