import os
import re
from typing import Iterable, Tuple

from dotenv import load_dotenv
from langchain_mistralai.chat_models import ChatMistralAI

from logging_config import get_logger

load_dotenv()
logger = get_logger(__name__)

_DEFAULT_SUPERVISOR_MODEL = "mistral-small"
_DEFAULT_ALLOWED_AGENTS: Tuple[str, ...] = (
    "research",
    "comparison",
    "analysis",
)


def _get_llm():
    model = os.getenv("SUPERVISOR_MODEL", _DEFAULT_SUPERVISOR_MODEL)
    try:
        return ChatMistralAI(model=model, temperature=0)
    except (ValueError, TypeError, RuntimeError, OSError) as exc:
        logger.error("Failed to initialize supervisor LLM (%s): %s", model, exc)
        return None


def _normalize_allowed_agents(allowed_agents: Iterable[str]) -> Tuple[str, ...]:
    normalized = tuple(
        dict.fromkeys(
            agent.strip().lower()
            for agent in allowed_agents
            if isinstance(agent, str) and agent.strip()
        )
    )
    if not normalized:
        raise ValueError("allowed_agents must contain at least one valid agent name")
    return normalized


def _keyword_fallback(task: str, allowed_agents: Tuple[str, ...]) -> str:
    text = (task or "").lower()

    comparison_words = ("compare", "comparison", "versus", "vs", "difference")
    analysis_words = (
        "analyze",
        "analysis",
        "trend",
        "trends",
        "risk",
        "risks",
        "opportunity",
        "opportunities",
    )

    if "comparison" in allowed_agents and any(word in text for word in comparison_words):
        return "comparison"

    if "analysis" in allowed_agents and any(word in text for word in analysis_words):
        return "analysis"

    if "research" in allowed_agents:
        return "research"

    return allowed_agents[0]


def _parse_llm_selection(raw: str, allowed_agents: Tuple[str, ...]) -> str:
    if not raw:
        return ""

    alias_map = {
        "researcher": "research",
        "compare": "comparison",
        "comparator": "comparison",
        "analyst": "analysis",
        "analyze": "analysis",
    }

    tokens = re.findall(r"[a-z_]+", raw.lower())
    for token in tokens:
        candidate = alias_map.get(token, token)
        if candidate in allowed_agents:
            return candidate

    normalized = raw.strip().lower()
    if normalized in allowed_agents:
        return normalized

    return ""


def select_agent(task: str, allowed_agents: Iterable[str] = _DEFAULT_ALLOWED_AGENTS) -> str:
    """Choose the best specialist agent for a task using LLM routing with safe fallback."""
    normalized_agents = _normalize_allowed_agents(allowed_agents)

    if not task or not task.strip():
        logger.warning("Empty task supplied to supervisor selector. Using default agent.")
        return normalized_agents[0]

    fallback_agent = _keyword_fallback(task, normalized_agents)
    llm = _get_llm()

    if llm is None:
        logger.warning(
            "Supervisor LLM unavailable. Falling back to keyword routing -> %s",
            fallback_agent,
        )
        return fallback_agent

    options = "\n".join(f"- {agent}" for agent in normalized_agents)
    prompt = f"""
You are a supervisor that routes tasks to one specialist.

Available agents:
{options}

Task:
{task}

Rules:
- Choose exactly one agent from the list above.
- Return only the agent name.
- Do not return explanations, JSON, or extra text.
"""

    try:
        raw = llm.invoke(prompt).content.strip()
        selected = _parse_llm_selection(raw, normalized_agents)

        if selected:
            logger.debug("Supervisor LLM routing selected '%s' for task: %.80s", selected, task)
            return selected

        logger.warning(
            "Supervisor LLM returned invalid agent '%s'. Falling back to %s",
            raw,
            fallback_agent,
        )
        return fallback_agent
    except (
        ValueError,
        TypeError,
        RuntimeError,
        ConnectionError,
        TimeoutError,
        OSError,
        AttributeError,
    ) as exc:
        logger.error("Supervisor LLM invocation failed. Using fallback '%s': %s", fallback_agent, exc)
        return fallback_agent
