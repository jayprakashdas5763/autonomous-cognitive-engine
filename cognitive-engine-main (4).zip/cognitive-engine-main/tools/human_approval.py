import os
from typing import Dict

APPROVAL_PENDING = "pending_approval"
APPROVAL_APPROVED = "approved"
APPROVAL_REJECTED = "rejected"

_APPROVAL_FLAG = "ENABLE_HUMAN_APPROVAL"


def human_approval_enabled() -> bool:
    return os.getenv(_APPROVAL_FLAG, "false").strip().lower() == "true"


def _normalize_decision(value: str) -> str:
    normalized = (value or "").strip().lower()
    if normalized in (APPROVAL_PENDING, APPROVAL_APPROVED, APPROVAL_REJECTED):
        return normalized
    return ""


def _approval_decisions(state: dict) -> Dict[str, str]:
    raw = state.get("approval_decisions", {})
    if isinstance(raw, dict):
        return {str(k): str(v) for k, v in raw.items()}
    return {}


def _lookup_task_decision(state: dict, todo: dict) -> str:
    decisions = _approval_decisions(state)

    task_id = str(todo.get("id", ""))
    if task_id in decisions:
        decision = _normalize_decision(decisions[task_id])
        if decision:
            return decision

    description = str(todo.get("description", ""))
    if description in decisions:
        decision = _normalize_decision(decisions[description])
        if decision:
            return decision

    return ""


def mark_pending_approval(todo: dict) -> None:
    todo["stage"] = "approval"
    todo["status"] = "pending"
    todo["approval_status"] = APPROVAL_PENDING


def resolve_task_approval(todo: dict, state: dict) -> str:
    """Resolve approval state for a task and mutate todo accordingly."""
    decision = _lookup_task_decision(state, todo)

    if not decision and bool(state.get("auto_approve_on_missing_approval", False)):
        decision = APPROVAL_APPROVED

    if decision == APPROVAL_APPROVED:
        todo["approval_status"] = APPROVAL_APPROVED
        todo["status"] = "done"
        todo["stage"] = "approval"
        return APPROVAL_APPROVED

    if decision == APPROVAL_REJECTED:
        todo["approval_status"] = APPROVAL_REJECTED
        todo["status"] = "failed"
        todo["stage"] = "approval"
        return APPROVAL_REJECTED

    todo["approval_status"] = APPROVAL_PENDING
    todo["status"] = "pending"
    todo["stage"] = "approval"
    return APPROVAL_PENDING
