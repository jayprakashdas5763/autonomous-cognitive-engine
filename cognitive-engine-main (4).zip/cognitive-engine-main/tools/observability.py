import uuid
from typing import Any, Mapping, MutableMapping, Optional, Tuple

RUN_ID_KEY = "graph_run_id"


def create_graph_run_id() -> str:
    """Return a unique id used to correlate logs for one graph invocation."""
    return uuid.uuid4().hex


def build_graph_invoke_config(
    recursion_limit: int,
    graph_run_id: Optional[str] = None,
    base_config: Optional[MutableMapping[str, Any]] = None,
) -> dict:
    """Build a LangGraph invoke config that always carries a graph run id."""
    config: dict = dict(base_config or {})
    config["recursion_limit"] = recursion_limit

    configurable = dict(config.get("configurable", {}))
    configurable[RUN_ID_KEY] = graph_run_id or create_graph_run_id()
    config["configurable"] = configurable

    return config


def extract_graph_run_id(config: Optional[Mapping[str, Any]]) -> str:
    """Extract graph run id from LangGraph config if present."""
    if not config:
        return "unknown"

    configurable = config.get("configurable", {})
    if isinstance(configurable, Mapping):
        run_id = configurable.get(RUN_ID_KEY)
        if run_id:
            return str(run_id)

    run_id = config.get(RUN_ID_KEY)
    if run_id:
        return str(run_id)

    return "unknown"


def get_task_context(state: Mapping[str, Any]) -> Tuple[str, int]:
    """Return current task id and retry count for structured observability logs."""
    current_task = state.get("current_task", "")
    todos = state.get("todos", [])

    if isinstance(todos, list):
        for todo in todos:
            if not isinstance(todo, Mapping):
                continue
            if current_task and todo.get("description") == current_task:
                return str(todo.get("id", "?")), int(todo.get("retries", 0) or 0)

        for todo in todos:
            if isinstance(todo, Mapping) and todo.get("status") == "pending":
                return str(todo.get("id", "?")), int(todo.get("retries", 0) or 0)

    return "?", 0


def parse_factcheck_verdict(report: str) -> str:
    """Parse PASS/FAIL/UNKNOWN from a factcheck markdown report."""
    if not report:
        return ""

    if "## Verdict" not in report:
        return ""

    verdict_section = report.split("## Verdict", 1)[1]
    lines = [line.strip() for line in verdict_section.splitlines() if line.strip()]
    if not lines:
        return ""

    verdict = lines[0].upper()
    if verdict in ("PASS", "FAIL", "UNKNOWN"):
        return verdict

    return verdict


def get_current_factcheck_verdict(state: Mapping[str, Any]) -> str:
    """Return latest verdict for the current task if available."""
    current_task = state.get("current_task", "")
    if not current_task:
        return ""

    agent_results = state.get("agent_results", {})
    if not isinstance(agent_results, Mapping):
        return ""

    report = agent_results.get(f"{current_task}_factcheck", "")
    if not isinstance(report, str):
        return ""

    return parse_factcheck_verdict(report)
