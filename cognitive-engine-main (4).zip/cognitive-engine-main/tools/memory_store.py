import json
import os
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

from logging_config import get_logger
from tools.observability import parse_factcheck_verdict

logger = get_logger(__name__)

_MEMORY_FLAG = "ENABLE_PERSISTENT_MEMORY"
_MEMORY_PATH_ENV = "PERSISTENT_MEMORY_PATH"
_DEFAULT_MEMORY_PATH = ".memory/run_memory.jsonl"


def memory_enabled() -> bool:
    return os.getenv(_MEMORY_FLAG, "false").strip().lower() == "true"


def _memory_path() -> Path:
    configured = os.getenv(_MEMORY_PATH_ENV, _DEFAULT_MEMORY_PATH).strip()
    return Path(configured or _DEFAULT_MEMORY_PATH)


def _truncate(value: str, limit: int) -> str:
    text = str(value or "").strip()
    if len(text) <= limit:
        return text
    return text[: max(0, limit - 3)] + "..."


def _iter_memory_records(path: Path) -> list[dict[str, Any]]:
    if not path.exists():
        return []

    records: list[dict[str, Any]] = []
    with path.open("r", encoding="utf-8") as handle:
        for raw_line in handle:
            line = raw_line.strip()
            if not line:
                continue
            try:
                data = json.loads(line)
            except json.JSONDecodeError:
                logger.warning("Skipping malformed memory record line")
                continue
            if isinstance(data, dict):
                records.append(data)

    return records


def _build_task_payload(state: dict, todo: dict) -> dict[str, Any]:
    files = state.get("files", {})
    if not isinstance(files, dict):
        files = {}

    task_id = todo.get("id", "")
    task_key = str(task_id)

    research_report = str(files.get(f"research_task_{task_key}.md", ""))
    factcheck_report = str(files.get(f"factcheck_task_{task_key}.md", ""))
    factcheck_verdict = parse_factcheck_verdict(factcheck_report)

    payload: dict[str, Any] = {
        "id": task_id,
        "description": str(todo.get("description", "")),
        "status": str(todo.get("status", "")),
        "research_report": research_report,
        "factcheck_report": factcheck_report,
    }

    approval_state = str(todo.get("approval_status", "")).strip()
    if approval_state:
        payload["approval_status"] = approval_state

    if factcheck_verdict:
        payload["factcheck_verdict"] = factcheck_verdict

    return payload


def _build_run_record(state: dict) -> dict[str, Any]:
    todos = state.get("todos", [])
    if not isinstance(todos, list):
        todos = []

    tasks = [_build_task_payload(state, todo) for todo in todos if isinstance(todo, dict)]

    files = state.get("files", {})
    if not isinstance(files, dict):
        files = {}

    return {
        "created_at": datetime.now(timezone.utc).isoformat(),
        "goal": str(state.get("goal", "")),
        "task_descriptions": [
            task.get("description", "")
            for task in tasks
            if str(task.get("description", "")).strip()
        ],
        "tasks": tasks,
        "final_report": str(files.get("final_report.txt", "")),
    }


def _summarize_record(record: dict[str, Any]) -> dict[str, Any]:
    summarized_tasks: list[dict[str, Any]] = []

    for raw_task in record.get("tasks", []):
        if not isinstance(raw_task, dict):
            continue

        task_summary: dict[str, Any] = {
            "id": raw_task.get("id", ""),
            "description": _truncate(str(raw_task.get("description", "")), 180),
            "status": str(raw_task.get("status", "")),
            "approval_status": str(raw_task.get("approval_status", "")),
            "factcheck_verdict": str(raw_task.get("factcheck_verdict", "")),
            "research_excerpt": _truncate(str(raw_task.get("research_report", "")), 220),
            "factcheck_excerpt": _truncate(str(raw_task.get("factcheck_report", "")), 180),
        }
        summarized_tasks.append(task_summary)

    return {
        "created_at": str(record.get("created_at", "")),
        "goal": _truncate(str(record.get("goal", "")), 220),
        "final_report_excerpt": _truncate(str(record.get("final_report", "")), 500),
        "tasks": summarized_tasks,
    }


def save_run_memory(state: dict) -> bool:
    if not memory_enabled():
        logger.info("[OBS] memory_disabled stage=save")
        return False

    path = _memory_path()
    path.parent.mkdir(parents=True, exist_ok=True)

    record = _build_run_record(state)

    try:
        with path.open("a", encoding="utf-8") as handle:
            handle.write(json.dumps(record, ensure_ascii=True) + "\n")
    except OSError as exc:
        logger.exception("[OBS] memory_save_failure path=%s error=%s", path, exc)
        return False

    logger.info("[OBS] memory_save_success path=%s tasks=%d", path, len(record.get("tasks", [])))
    return True


def load_recent_memories(limit: int = 5) -> list[dict[str, Any]]:
    if limit <= 0:
        return []

    if not memory_enabled():
        logger.info("[OBS] memory_disabled stage=load_recent")
        return []

    records = _iter_memory_records(_memory_path())
    if not records:
        logger.info("[OBS] memory_retrieval_count=0 mode=recent")
        return []

    recent = records[-limit:]
    recent.reverse()
    summarized = [_summarize_record(record) for record in recent]
    logger.info("[OBS] memory_retrieval_count=%d mode=recent", len(summarized))
    return summarized


def _search_text(record: dict[str, Any]) -> str:
    parts = [
        str(record.get("goal", "")),
        str(record.get("final_report", "")),
    ]

    for raw_task in record.get("tasks", []):
        if not isinstance(raw_task, dict):
            continue
        parts.extend(
            [
                str(raw_task.get("description", "")),
                str(raw_task.get("research_report", "")),
                str(raw_task.get("factcheck_report", "")),
            ]
        )

    return "\n".join(parts).lower()


def search_memory(query: str, limit: int = 5) -> list[dict[str, Any]]:
    if limit <= 0:
        return []

    if not memory_enabled():
        logger.info("[OBS] memory_disabled stage=search")
        return []

    search_query = str(query or "").strip().lower()
    if not search_query:
        return load_recent_memories(limit=limit)

    records = _iter_memory_records(_memory_path())
    if not records:
        logger.info("[OBS] memory_retrieval_count=0 mode=search")
        return []

    tokens = [token for token in search_query.split() if token]
    ranked: list[tuple[int, int, dict[str, Any]]] = []

    for index, record in enumerate(records):
        haystack = _search_text(record)
        score = 0

        if search_query in haystack:
            score += 5

        for token in tokens:
            if token in haystack:
                score += 1

        if score > 0:
            ranked.append((score, index, record))

    ranked.sort(key=lambda item: (item[0], item[1]), reverse=True)
    selected = [_summarize_record(item[2]) for item in ranked[:limit]]
    logger.info(
        "[OBS] memory_retrieval_count=%d mode=search query=%.80s",
        len(selected),
        search_query,
    )
    return selected