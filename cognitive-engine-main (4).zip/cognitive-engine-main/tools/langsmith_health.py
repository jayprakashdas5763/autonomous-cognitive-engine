import importlib.util
import os
from typing import Dict, List


def _is_true(value: str) -> bool:
    return (value or "").strip().lower() == "true"


def collect_langsmith_health() -> Dict[str, object]:
    """Collect runtime LangSmith/LangChain tracing health without exposing secrets."""
    tracing_requested = _is_true(os.getenv("LANGSMITH_TRACING", "false"))

    has_langsmith_api_key = bool(os.getenv("LANGSMITH_API_KEY", "").strip())
    has_langchain_api_key = bool(os.getenv("LANGCHAIN_API_KEY", "").strip())

    langchain_tracing_enabled = _is_true(os.getenv("LANGCHAIN_TRACING_V2", "false"))

    project = (
        os.getenv("LANGCHAIN_PROJECT", "").strip()
        or os.getenv("LANGSMITH_PROJECT", "").strip()
        or "cognitive-engine"
    )

    endpoint = (
        os.getenv("LANGSMITH_ENDPOINT", "").strip()
        or "https://api.smith.langchain.com"
    )

    runtime_enabled = langchain_tracing_enabled and has_langchain_api_key
    package_available = importlib.util.find_spec("langsmith") is not None

    issues: List[str] = []

    if tracing_requested and not has_langsmith_api_key:
        issues.append("LANGSMITH_TRACING=true but LANGSMITH_API_KEY is missing")

    if tracing_requested and not langchain_tracing_enabled:
        issues.append("LANGCHAIN_TRACING_V2 is not true at runtime")

    if tracing_requested and not has_langchain_api_key:
        issues.append("LANGCHAIN_API_KEY is not set at runtime")

    if tracing_requested and not package_available:
        issues.append("langsmith package is not installed in the active environment")

    status = "enabled" if tracing_requested and runtime_enabled else "disabled"
    if tracing_requested and issues:
        status = "misconfigured"

    return {
        "status": status,
        "tracing_requested": tracing_requested,
        "runtime_enabled": runtime_enabled,
        "langchain_tracing_enabled": langchain_tracing_enabled,
        "has_langsmith_api_key": has_langsmith_api_key,
        "has_langchain_api_key": has_langchain_api_key,
        "project": project,
        "endpoint": endpoint,
        "package_available": package_available,
        "issues": issues,
    }


def log_langsmith_health(logger, context: str = "startup") -> Dict[str, object]:
    """Log concise health details and return the collected status dict."""
    health = collect_langsmith_health()

    logger.info(
        "[LangSmith] context=%s status=%s requested=%s runtime_enabled=%s project=%s endpoint=%s",
        context,
        health["status"],
        health["tracing_requested"],
        health["runtime_enabled"],
        health["project"],
        health["endpoint"],
    )

    issues = health.get("issues", [])
    if issues:
        logger.warning("[LangSmith] context=%s issues=%s", context, "; ".join(issues))

    return health
