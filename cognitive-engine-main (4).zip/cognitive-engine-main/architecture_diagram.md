# Updated Cognitive Engine Architecture

```mermaid
flowchart TD
    A[User Goal Input] --> B[Planner]

    B --> C{Execution Mode}

    C -->|ENABLE_PARALLEL_EXECUTION=false| D[Supervisor]
    D --> E[Executor Loop]

    E --> F{Task Stage}
    F -->|research| G[Research Family Agents<br/>research, comparison, analysis]
    G --> H[Fact Checker]
    F -->|factcheck| H

    H --> I{ENABLE_HUMAN_APPROVAL}
    I -->|true| J[Human Approval<br/>pending_approval to approved or rejected]
    I -->|false| K[Auto-approve]

    J --> E
    K --> E

    E --> L{All tasks terminal}
    L -->|no| D
    L -->|yes| M[Writer]

    C -->|ENABLE_PARALLEL_EXECUTION=true| P[Parallel Executor]
    P --> Q[Research and Factcheck Batches]
    Q --> R{ENABLE_HUMAN_APPROVAL}
    R -->|true| S[Approval Batch]
    R -->|false| T[Auto-approve]

    S --> U{All tasks terminal}
    T --> U
    U -->|no| P
    U -->|yes| M

    M --> V[final_report.txt]
    M --> W[Virtual File System<br/>research_task_X.md<br/>factcheck_task_X.md]

    M --> X{ENABLE_PERSISTENT_MEMORY}
    X -->|true| Y[Memory Store JSONL]
    X -->|false| Z[No persistent save]

    B --> AA{Memory Retrieval}
    AA -->|ENABLE_PERSISTENT_MEMORY=true| AB[Search or Load summarized prior runs]
    AA -->|false| AC[No memory context]
    AB --> B

    subgraph OBS[Observability]
      AD[LangSmith optional tracing]
    end

    B -. logs .-> AD
    D -. logs .-> AD
    E -. logs .-> AD
    P -. logs .-> AD
    M -. logs .-> AD
```
