from agents.summarizer import synthesize_final_report
from logging_config import get_logger
from tools.human_approval import APPROVAL_APPROVED, human_approval_enabled
from tools.memory_store import memory_enabled, save_run_memory

from tools.file_system import (
    read_file,
    write_file,
    list_files,
)

logger = get_logger(__name__)


def _find_todo_by_task_id(state, task_id_text):
    for todo in state.get("todos", []):
        if str(todo.get("id", "")) == str(task_id_text):
            return todo
    return None


def _persist_run_memory_if_enabled(state):
    if not memory_enabled():
        logger.info("[OBS] memory_disabled stage=writer")
        return

    logger.info("[OBS] memory_enabled stage=writer")
    saved = save_run_memory(state)
    if not saved:
        logger.warning("[OBS] memory_save_not_completed stage=writer")


def writer_agent(state):

    logger.info("[OBS] writer_start")

    goal = state["goal"]

    files = list_files(state)

    combined = []

    for filename in files:

        if not filename.startswith("research_task_"):
            continue

        task_id = filename.replace("research_task_", "").replace(".md", "")

        todo = _find_todo_by_task_id(state, task_id)
        if todo and todo.get("status") == "failed":
            logger.warning("Skipping %s because task status is failed.", filename)
            continue

        if human_approval_enabled():
            approval_state = ""
            if todo:
                approval_state = str(todo.get("approval_status", "")).strip().lower()
            if approval_state != APPROVAL_APPROVED:
                logger.warning(
                    "Skipping %s because approval_status=%s.",
                    filename,
                    approval_state or "missing",
                )
                continue

        factcheck_file = f"factcheck_task_{task_id}.md"

        factcheck = read_file(
            state,
            factcheck_file,
        )

        # Skip failed research outputs
        if (
            "## Verdict" in factcheck
            and "FAIL" in factcheck.split("## Verdict")[-1].upper()
        ):
            logger.warning(
                "Skipping %s because fact check failed.",
                filename,
            )
            continue

        content = read_file(
            state,
            filename,
        )

        if content:
            combined.append(content)

    # No valid reports survived fact checking
    if not combined:

        final_report = "# Research Report\n\nAll research outputs failed fact checking."

        logger.warning("No verified research files available for synthesis.")

        write_file(
            state,
            "final_report.txt",
            final_report,
        )

        _persist_run_memory_if_enabled(state)

        logger.info("Final report saved to final_report.txt")

        return state

    # Generate final report
    final_report = synthesize_final_report(
        goal,
        "\n\n".join(combined),
    )

    logger.info(
        "Writer synthesized final report from %d verified research file(s)",
        len(combined),
    )

    write_file(
        state,
        "final_report.txt",
        final_report,
    )

    _persist_run_memory_if_enabled(state)

    logger.info("Final report saved to final_report.txt")

    return state
