import time

from tools.search_tool import web_search
from tools.file_system import write_file
from tools.task_utils import get_task_id

from agents.summarizer import summarize_research

from logging_config import get_logger

logger = get_logger(__name__)


def _parse_sources(raw_result):
    sources = []

    for block in [part.strip() for part in raw_result.split("\n\n") if part.strip()]:
        title = "Untitled source"
        url = ""
        snippet = ""

        for line in block.splitlines():

            line = line.strip()

            if line.startswith("Title:"):
                title = line.replace("Title:", "", 1).strip()

            elif line.startswith("URL:"):
                url = line.replace("URL:", "", 1).strip()

            elif line.startswith("Snippet:"):
                snippet = line.replace("Snippet:", "", 1).strip()

        if snippet:
            sources.append(
                {
                    "title": title,
                    "url": url,
                    "snippet": snippet,
                }
            )

    return sources


def _fallback_markdown_report(task, raw_result):

    sources = _parse_sources(raw_result)

    key_points = sources[:5]

    report_lines = [
        "# Research Report",
        "",
        "## Goal",
        task,
        "",
        "## Key Findings",
    ]

    if key_points:

        for item in key_points:

            report_lines.append(f"- {item['snippet']}")

    else:

        report_lines.append(
            "- No concise highlights were extracted from search results."
        )

    report_lines.extend(
        [
            "",
            "## Sources",
        ]
    )

    if sources:

        for item in sources:

            if item["url"] and item["url"] != "N/A":

                report_lines.append(f"- [{item['title']}]({item['url']})")

            else:

                report_lines.append(f"- {item['title']}")

    else:

        report_lines.append("- No sources found.")

    return "\n".join(report_lines)


def researcher_agent(state):

    task = state["current_task"]

    t_start = time.perf_counter()

    raw_result = web_search(task)

    state.setdefault("raw_sources", {})
    state.setdefault("agent_results", {})
    state.setdefault("files", {})
    state.setdefault("results", [])

    # Store original search evidence
    state["raw_sources"][task] = raw_result

    if raw_result.startswith("Error during web search"):

        state["results"].append(raw_result)

        return state

    formatted_report = summarize_research(task, raw_result)

    if formatted_report.startswith("Error during research report synthesis"):

        result = _fallback_markdown_report(task, raw_result)

    else:

        result = formatted_report

    elapsed = time.perf_counter() - t_start

    logger.info("[TIMING] Full researcher pipeline took %.2fs", elapsed)

    state["results"].append(result)

    state["agent_results"][task] = result

    # --------------------------------------------------
    # PDF Architecture: Save research to virtual FS
    # --------------------------------------------------

    task_id = get_task_id(state, task)

    filename = f"research_task_{task_id}.md"

    write_file(state, filename, result)

    logger.info("Research saved to virtual file: %s", filename)

    return state


def researcher(state):
    """Backward-compatible entrypoint.

    Accepts either:
    - graph state dict (new flow) -> returns updated state
    - plain task string (legacy flow) -> returns markdown/text output
    """
    if isinstance(state, dict):
        return researcher_agent(state)

    task = str(state or "").strip()
    if not task:
        return "No task provided."

    raw_result = web_search(task)
    if raw_result.startswith("Error during web search"):
        return raw_result

    formatted_report = summarize_research(task, raw_result)
    if formatted_report.startswith("Error during research report synthesis"):
        return _fallback_markdown_report(task, raw_result)

    return formatted_report
