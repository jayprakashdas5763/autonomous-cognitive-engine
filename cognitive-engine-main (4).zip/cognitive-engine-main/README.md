# Autonomous Cognitive Engine

A multi-agent autonomous system powered by LangGraph that breaks down complex goals into manageable tasks and executes them using specialized AI agents.

## 🎯 Overview

This application uses intelligent task planning and execution to help you accomplish complex goals. It:
- **Plans** your goal into 3-5 concrete, actionable subtasks using Mistral AI
- **Executes** tasks with specialized agents (web search, research, summarization)
- **Synthesizes** results into a professional, structured report

## ✨ Features

- **Intelligent Planning** — Mistral AI breaks goals into meaningful subtasks (not just copies)
- **Web Search** — Tavily API integration for real-time information
- **Multi-Agent Execution** — Research, summarization, and datetime lookup agents
- **Structured Reports** — Professional markdown with Executive Summary, Key Findings, Sources
- **Infinite Loop Protection** — Configurable recursion limits prevent runaway execution
- **Configurable Models** — Use different Mistral models via environment variables
- **Structured Logging** — Debug-friendly console output with timing information
- **Input Validation** — Safe goal length limits (500 chars)
- **PDF Export** — Download reports as professional PDF documents
- **Deduplication** — Automatic source deduplication to avoid repetition
- **Error Handling** — User-friendly error messages with troubleshooting guidance
- **Human Approval Gate (Optional)** — Task-level `pending_approval` / `approved` / `rejected` flow
- **Persistent Memory (Optional)** — Reuse prior run context via local JSONL sidecar storage

## 🚀 Quick Start

### Prerequisites

- Python 3.8+
- Mistral API key (free) → https://console.mistral.ai/
- Tavily API key (free) → https://app.tavily.com/

### 1. Clone & Install

```bash
git clone <repo-url>
cd cognitive-engine
pip install -r requirements.txt
```

### 2. Configure `.env` (CRITICAL)

Create a file named `.env` in the project root with **exactly** this format:

```env
# ============================================
# REQUIRED: API Keys (keep these private!)
# ============================================
MISTRAL_API_KEY=your_mistral_api_key_here
TAVILY_API_KEY=your_tavily_api_key_here

# ============================================
# OPTIONAL: Model Configuration
# (Only change if you want different models)
# ============================================

# Mistral model for planning (default: mistral-small for speed)
# Options: mistral-small, mistral-medium, mistral-large-latest
PLANNING_MODEL=mistral-small

# Mistral model for summarization (default: mistral-small for speed)
# Options: mistral-small, mistral-medium, mistral-large-latest
SUMMARIZER_MODEL=mistral-small

# ============================================
# OPTIONAL: Logging & Debug
# ============================================

# Log level (default: INFO)
# Options: DEBUG, INFO, WARNING, ERROR
LOG_LEVEL=INFO

# ============================================
# OPTIONAL: LangSmith Tracing
# (Leave these out entirely to disable tracing)
# ============================================

# Set to "true" to enable LangSmith tracing
LANGSMITH_TRACING=true

# Your LangSmith API key from https://smith.langchain.com/
LANGSMITH_API_KEY=your_langsmith_api_key_here

# Project name shown in LangSmith UI (default: cognitive-engine)
LANGSMITH_PROJECT=cognitive-engine

# ============================================
# OPTIONAL: Execution Modes
# ============================================

# Enable parallel research/factcheck execution
ENABLE_PARALLEL_EXECUTION=false

# Max worker threads when parallel execution is enabled
PARALLEL_MAX_WORKERS=4

# Enable human approval stage after factcheck
ENABLE_HUMAN_APPROVAL=false

# Enable persistent cross-run memory sidecar
ENABLE_PERSISTENT_MEMORY=false

# JSONL file path for persistent memory records
PERSISTENT_MEMORY_PATH=.memory/run_memory.jsonl
```

**⚠️ IMPORTANT:**
- `MISTRAL_API_KEY`, `TAVILY_API_KEY`, and `LANGSMITH_API_KEY` are **secret credentials**. Never commit `.env` to git.
- `PLANNING_MODEL` and `SUMMARIZER_MODEL` are **model names**, not API keys.
- Keep API keys and model names completely separate.

### 3. Run the Application

#### Option A: Streamlit UI (Recommended)

```bash
python -m streamlit run app.py
```

Open http://localhost:8501 in your browser. Type a goal and click **Execute**.

#### Option B: Command-Line Interface

```bash
python main.py
```

Follow the prompts to enter your goal.

## 📊 Example Usage

**Goal:** "Research the latest breakthroughs in quantum computing and write a summary"

**What happens:**
1. **Planning** — Engine breaks this into 3-5 tasks:
   - Task 1: Search for latest quantum computing breakthroughs (2024-2025)
   - Task 2: Find information about quantum error correction advances
   - Task 3: Research commercial quantum computing applications
   - Task 4: Summarize findings into a professional report

2. **Execution** — Each task runs in sequence:
   - Web search for current information
   - LLM-based analysis and summarization
   - Source tracking and deduplication

3. **Report** — Final report includes:
   - Executive Summary (2-3 sentences)
   - Key Findings (4-6 bullet points)
   - Detailed Analysis (multiple paragraphs)
   - Sources (with URLs and relevance notes)

## 📥 Download Options

After execution, download your report as:
- **Markdown** (`.md`) — For editing and sharing with formatting intact
- **PDF** (`.pdf`) — For printing and professional distribution
- **Raw Text** — For copying/pasting into other tools

## 🧪 Testing

Run the full test suite:

```bash
pytest tests/ -v
```

Tests use mocking—no real API calls are made.

**Expected output:** 35+ tests passing in ~2 seconds

## 📁 Project Structure

```
cognitive-engine-main/
├── app.py                    ← Streamlit web UI entry point
├── main.py                   ← CLI entry point
├── graph.py                  ← LangGraph orchestration engine
├── state.py                  ← Shared data structures (AgentState)
├── logging_config.py         ← Centralized logging setup
├── requirements.txt          ← Python dependencies
├── .env                      ← API keys & config (never commit!)
├── .env.example              ← Template (safe to commit)
├── nodes/
│   ├── planner.py            ← Breaks goal into 3-5 tasks
│   ├── executor.py           ← Runs one task per iteration
│   └── synthesizer.py        ← Merges results into final report
├── agents/
│   ├── researcher.py         ← Web search + analysis
│   └── summarizer.py         ← LLM-based text synthesis
├── tools/
│   ├── planning.py           ← LLM call for task generation
│   ├── delegation.py         ← Route tasks to correct agent
│   ├── search_tool.py        ← Tavily API wrapper
│   ├── file_system.py        ← File I/O utilities
│   └── datetime_tool.py      ← Current time lookup
├── tests/
│   ├── test_tools.py         ← Tool unit tests
│   ├── test_agents.py        ← Agent unit tests
│   ├── test_graph.py         ← Graph integration tests
│   └── conftest.py           ← Pytest configuration
└── README.md                 ← This file
```

## 🔧 Configuration Details

### Environment Variables

| Variable | Required | Purpose | Example |
|----------|----------|---------|---------|
| `MISTRAL_API_KEY` | ✅ Yes | Mistral API authentication | `sk_abc123...` |
| `TAVILY_API_KEY` | ✅ Yes | Tavily search authentication | `tvly_xyz789...` |
| `PLANNING_MODEL` | ❌ No | Model for task planning | `mistral-small` |
| `SUMMARIZER_MODEL` | ❌ No | Model for report synthesis | `mistral-small` |
| `LOG_LEVEL` | ❌ No | Console logging verbosity | `INFO` |
| `LANGSMITH_TRACING` | ❌ No | Enable LangSmith tracing | `true` |
| `LANGSMITH_API_KEY` | ❌ No | LangSmith API key | `lsv2_...` |
| `LANGSMITH_PROJECT` | ❌ No | LangSmith project name | `cognitive-engine` |
| `ENABLE_PARALLEL_EXECUTION` | ❌ No | Enable parallel graph execution mode | `true` |
| `PARALLEL_MAX_WORKERS` | ❌ No | Worker count for parallel executor | `4` |
| `ENABLE_HUMAN_APPROVAL` | ❌ No | Enable post-factcheck human approval stage | `true` |
| `ENABLE_PERSISTENT_MEMORY` | ❌ No | Enable cross-run memory sidecar | `true` |
| `PERSISTENT_MEMORY_PATH` | ❌ No | JSONL file path for memory sidecar | `.memory/run_memory.jsonl` |

### Default Behavior (if env vars not set)

```python
PLANNING_MODEL = "mistral-small"       # Fast, efficient planning
SUMMARIZER_MODEL = "mistral-small"     # Fast, efficient summarization
LOG_LEVEL = "INFO"                     # Standard verbosity
# LangSmith tracing is DISABLED unless LANGSMITH_TRACING=true
```

## 🔭 LangSmith Tracing (Optional)

LangSmith lets you inspect every LLM call, token count, latency, and chain trace in a visual UI. It is **fully optional** — the app runs normally without it.

### Setup

1. Create a free account at https://smith.langchain.com/
2. Go to **Settings → API Keys** and generate a new key
3. Add to `.env`:

```env
LANGSMITH_TRACING=true
LANGSMITH_API_KEY=lsv2_your_key_here
LANGSMITH_PROJECT=cognitive-engine
```

4. Restart the app. You will see this log line on startup:
   ```
   INFO logging_config: LangSmith tracing enabled (project: cognitive-engine).
   ```

5. Open https://smith.langchain.com/ → select **cognitive-engine** project → watch traces appear in real time.

### What gets traced

Each goal execution creates one trace containing:
- Planner LLM call (task breakdown)
- Each executor task (researcher + summarizer LLM calls)
- Tavily search tool calls
- Synthesizer LLM call (final report)

### Disabling tracing

Remove the three `LANGSMITH_*` lines from `.env` (or set `LANGSMITH_TRACING=false`). No code changes needed.

## 🧑‍⚖️ Human Approval Behavior (Optional)

Enable with:

```env
ENABLE_HUMAN_APPROVAL=true
```

Behavior:
- After a task passes factcheck, it enters `pending_approval`.
- A decision can move it to `approved` (task completed) or `rejected` (task failed/excluded).
- In both CLI and Streamlit modes, undecided tasks are auto-approved by default for safety and continuity.
- In Streamlit mode, you can provide `approval_decisions` via task-id overrides (approve/reject inputs).

## 🧠 Persistent Memory (Optional)

Enable with:

```env
ENABLE_PERSISTENT_MEMORY=true
PERSISTENT_MEMORY_PATH=.memory/run_memory.jsonl
```

When enabled:
- Writer saves a persistent run snapshot after generating `final_report.txt`.
- Planner retrieves summarized prior memories (relevant search first, then recent fallback) to improve planning continuity.
- Retrieved memory is truncated before prompt injection to avoid oversized prompts.

Saved artifacts include:
- goal
- task descriptions
- `research_task_X.md` outputs
- `factcheck_task_X.md` outputs
- `final_report.txt`
- created timestamp
- approval status (if present)
- factcheck verdict (if present)

Storage backend choice:
- JSONL is used as a safer/simple append-only local store.
- It has no external service dependency, is human-inspectable, easy to back up, and low-risk for single-process local runs.

## ⚠️ Troubleshooting

### "MISTRAL_API_KEY is missing"

**Solution:**
1. Get a key from https://console.mistral.ai/
2. Add to `.env`: `MISTRAL_API_KEY=your_key_here`
3. Restart the application

### "TAVILY_API_KEY is missing"

**Solution:**
1. Get a key from https://app.tavily.com/
2. Add to `.env`: `TAVILY_API_KEY=your_key_here`
3. Restart the application

### "Execution exceeded maximum steps"

**Cause:** Goal is too complex or ambiguous.

**Solution:** Try a simpler, more focused goal:
- ❌ "Research everything about AI"
- ✅ "Find 2024 breakthroughs in generative AI"

### "No research results found"

**Cause:** Search query returned no results.

**Solution:** Try different keywords or a more specific topic.

### Tests failing locally

**Check:**
1. Are API keys set in `.env`? (Tests use mocking, but env vars must exist)
2. Is Python 3.8+ installed? Run `python --version`
3. Is `.env` in the project root? Not in a subdirectory.

## 🏗️ Architecture

### State Machine (LangGraph)

The current runtime supports two modes:

- Sequential (default):
   - `Planner` creates 3-5 tasks
   - `Supervisor` routes each pending task by stage
   - `Executor` runs one task step per loop (`research` → `factcheck` → optional `approval`)
   - `Writer` synthesizes verified outputs to `final_report.txt`
- Parallel (optional):
   - `Planner` creates tasks
   - `Parallel Executor` batches `research` and `factcheck` where safe
   - optional `approval` handling
   - `Writer` produces final report

### Specialized Agents

- Research family: `research`, `comparison`, `analysis` agents write `research_task_X.md`
- `factcheck` agent validates evidence and writes `factcheck_task_X.md`
- Human approval gate (optional) applies `pending_approval` / `approved` / `rejected`
- `writer` includes only valid task outputs and writes `final_report.txt`

### Storage and Observability

- Virtual File System (in-state): stores task artifacts and final report during execution
- Persistent Memory (optional): JSONL sidecar stores cross-run summaries and artifacts
- LangSmith (optional): traces planner/supervisor/executor/writer activity with run-level correlation

## 🤝 Contributing

Contributions welcome! Please:
1. Create a feature branch
2. Add tests for new functionality
3. Ensure all tests pass: `pytest tests/ -v`
4. Submit a pull request

## 📝 License

MIT License — See LICENSE file

## 🙋 Support

For issues, questions, or suggestions:
1. Check the Troubleshooting section above
2. Review existing GitHub issues
3. Create a new issue with:
   - Your goal (what you were trying to do)
   - Your Python version
   - Full error message
   - Steps to reproduce

## 🎓 Learning Resources

- **LangGraph Docs:** https://langchain-ai.github.io/langgraph/
- **Mistral AI:** https://docs.mistral.ai/
- **Tavily Search:** https://tavily.com/
- **Streamlit:** https://docs.streamlit.io/
