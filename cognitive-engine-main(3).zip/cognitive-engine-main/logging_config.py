import logging
import os


def setup_langsmith() -> bool:
    """
    Activate LangSmith tracing if the required environment variables are set.

    Reads from .env (loaded by the caller via dotenv):
        LANGSMITH_TRACING=true          — must be "true" to enable
        LANGSMITH_API_KEY=<secret>      — LangSmith API key
        LANGSMITH_PROJECT=<name>        — project name in LangSmith UI (optional)

    Translates these into the env vars that LangChain checks at call time:
        LANGCHAIN_TRACING_V2, LANGCHAIN_API_KEY, LANGCHAIN_PROJECT

    Returns True if tracing was enabled, False otherwise.
    API keys are never logged.
    """
    logger = logging.getLogger(__name__)

    tracing_flag = os.getenv("LANGSMITH_TRACING", "false").strip().lower()
    if tracing_flag != "true":
        return False

    api_key = os.getenv("LANGSMITH_API_KEY", "").strip()
    if not api_key:
        logger.warning(
            "LANGSMITH_TRACING=true but LANGSMITH_API_KEY is missing — tracing disabled."
        )
        return False

    # Set the env vars LangChain reads internally for tracing.
    # These must be set before any LangChain/LangGraph calls are made.
    os.environ["LANGCHAIN_TRACING_V2"] = "true"
    os.environ["LANGCHAIN_API_KEY"] = api_key

    project = os.getenv("LANGSMITH_PROJECT", "cognitive-engine").strip()
    if project:
        os.environ["LANGCHAIN_PROJECT"] = project

    logger.info("LangSmith tracing enabled (project: %s).", project or "default")
    return True


def get_logger(name: str) -> logging.Logger:
    """
    Return a named logger with a consistent format.

    The log level can be controlled via the LOG_LEVEL environment variable.
    Defaults to INFO.  Valid values: DEBUG, INFO, WARNING, ERROR, CRITICAL.
    """
    logger = logging.getLogger(name)

    # Only configure handlers once per logger (avoid duplicate messages on re-import)
    if not logger.handlers:
        level_name = os.getenv("LOG_LEVEL", "INFO").upper()
        level = getattr(logging, level_name, logging.INFO)
        logger.setLevel(level)

        handler = logging.StreamHandler()
        handler.setFormatter(
            logging.Formatter(
                "%(asctime)s [%(levelname)s] %(name)s: %(message)s",
                datefmt="%Y-%m-%d %H:%M:%S",
            )
        )
        logger.addHandler(handler)

    return logger
