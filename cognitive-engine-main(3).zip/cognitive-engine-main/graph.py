from langgraph.graph import StateGraph, END
from agents.writer import writer_agent
from nodes.supervisor import supervisor_node
from state import AgentState
from nodes.planner import planner_node
from nodes.executor import executor_node
from logging_config import get_logger

logger = get_logger(__name__)

# Maximum number of executor loop iterations before LangGraph stops.
# Import this constant in app.py / main.py to keep the limit consistent.
MAX_EXECUTOR_ITERATIONS = 150


def build_graph():
    graph = StateGraph(AgentState)

    graph.add_node("planner", planner_node)
    graph.add_node("supervisor", supervisor_node)
    graph.add_node("executor", executor_node)
    graph.add_node("writer", writer_agent)

    graph.set_entry_point("planner")
    graph.add_edge("planner", "supervisor")
    graph.add_edge("supervisor", "executor")

    def check_done(state):
        todos = state.get("todos", [])

        if not todos:
            logger.warning("No todos in state; routing directly to writer.")
            return True

        done = all(task.get("status") in ("done", "failed") for task in todos)

        pending = sum(1 for t in todos if t.get("status") not in ("done", "failed"))

        if done:
            logger.info("All %d task(s) completed. Moving to writer.", len(todos))
        else:
            logger.debug("%d task(s) still pending.", pending)

        return done

    graph.add_conditional_edges(
        "executor",
        check_done,
        {
            True: "writer",
            False: "supervisor",
        },
    )

    graph.add_edge("writer", END)

    return graph.compile()
