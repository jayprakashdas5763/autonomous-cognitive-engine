from dotenv import load_dotenv
load_dotenv()  # Must run before setup_langsmith so .env vars are available
from logging_config import get_logger, setup_langsmith
setup_langsmith()
from graph import build_graph, MAX_EXECUTOR_ITERATIONS

logger = get_logger(__name__)

MAX_GOAL_LENGTH = 500


def main():
    graph = build_graph()
    user_goal = input("Enter your goal: ").strip()

    # --- Input validation ---
    if not user_goal:
        print("Error: Please enter a goal.")
        return
    if len(user_goal) > MAX_GOAL_LENGTH:
        print(
            f"Error: Goal is too long ({len(user_goal)} characters). "
            f"Please keep it under {MAX_GOAL_LENGTH} characters."
        )
        return

    state = {
        "messages": [user_goal],
        "todos": [],
        "current_task": "",
        "files": {},
        "results": []
    }

    try:
        logger.info("Starting graph execution for goal: %.80s", user_goal)
        result = graph.invoke(
            state,
            config={"recursion_limit": MAX_EXECUTOR_ITERATIONS}
        )
        print("\n===== FINAL REPORT =====\n")
        print(result["files"].get("final_report.txt", "No report generated."))
    except Exception as e:
        error_str = str(e).lower()
        if "api_key" in error_str or "mistral" in error_str:
            print(
                "\n❌ API Configuration Issue\n"
                "The application cannot connect to Mistral AI. Please ensure:\n"
                "  1. You have a valid Mistral API key from https://console.mistral.ai/\n"
                "  2. It is set in `.env` as: MISTRAL_API_KEY=your_key_here\n"
                "  3. The `.env` file is in the project root directory\n"
            )
        elif "tavily" in error_str:
            print(
                "\n❌ Search Service Issue\n"
                "The application cannot connect to Tavily search. Please ensure:\n"
                "  1. You have a valid Tavily API key from https://app.tavily.com/\n"
                "  2. It is set in `.env` as: TAVILY_API_KEY=your_key_here\n"
                "  3. Your API key has not exceeded rate limits\n"
            )
        elif "recursion" in error_str:
            print(
                "\n❌ Task Execution Limit Reached\n"
                "The engine couldn't complete your goal within the maximum number of steps.\n"
                "Try simplifying your request or breaking it into smaller goals.\n"
            )
        else:
            print(
                f"\n❌ Unexpected Error\n"
                f"Something went wrong. Try again or simplify your goal.\n"
                f"Error details: {str(e)[:100]}\n"
            )
        logger.error("Graph execution error: %s", e)


if __name__ == "__main__":
    main()
