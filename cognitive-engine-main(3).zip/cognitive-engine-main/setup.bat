@echo off
REM Autonomous Cognitive Engine - Quick Start Script (Windows, Streamlit-first)

setlocal enabledelayedexpansion

echo.
echo 🚀 Autonomous Cognitive Engine - Setup
echo ======================================
echo.

REM Check prerequisites
echo 📋 Checking prerequisites...

python --version >nul 2>&1
if errorlevel 1 (
    echo ❌ Python is not installed. Please install Python 3.8 or higher.
    pause
    exit /b 1
)

echo ✅ Python:
python --version

echo.

REM Create .env if it doesn't exist
if not exist .env (
    echo 📝 Creating .env file...
    (
        echo MISTRAL_API_KEY=your_mistral_api_key_here
        echo TAVILY_API_KEY=your_tavily_api_key_here
    ) > .env
    echo ⚠️  Please edit .env and add your API keys
    echo.
)

REM Install Python dependencies
echo 📦 Installing Python dependencies...
pip install -r requirements.txt >nul 2>&1
if errorlevel 1 (
    echo ❌ Failed to install requirements.txt
    pause
    exit /b 1
)
echo ✅ Python dependencies installed
echo.

echo ✅ Setup complete!
echo.
echo 🎯 Next steps:
echo.
echo 1. Edit .env and add your API keys:
echo    MISTRAL_API_KEY=your_key_here
echo    TAVILY_API_KEY=your_key_here
echo.
echo 2. Start Streamlit (Terminal 1):
echo    python -m streamlit run app.py --server.port 8501 --server.headless true
echo.
echo 3. Open in browser:
echo    Streamlit: http://localhost:8501
echo.
pause
