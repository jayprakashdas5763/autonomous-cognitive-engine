"""
Unit tests for agents/researcher.py and agents/summarizer.py.

Run with:  pytest tests/ -v
"""
import pytest
from unittest.mock import patch

from unittest.mock import MagicMock
from agents.researcher import _parse_sources, _fallback_markdown_report, researcher
from agents.summarizer import summarizer, summarize_research, synthesize_final_report


# ---------------------------------------------------------------------------
# researcher helpers
# ---------------------------------------------------------------------------

class TestParseSourcesHelper:
    def test_empty_input_returns_empty_list(self):
        assert _parse_sources("") == []

    def test_whitespace_only_returns_empty_list(self):
        assert _parse_sources("   \n  ") == []

    def test_valid_block_parsed_correctly(self):
        raw = "Title: My Title\nURL: https://example.com\nSnippet: Some useful text"
        result = _parse_sources(raw)
        assert len(result) == 1
        assert result[0]["title"] == "My Title"
        assert result[0]["url"] == "https://example.com"
        assert result[0]["snippet"] == "Some useful text"

    def test_block_without_snippet_excluded(self):
        """Blocks without a snippet should not appear in the output."""
        raw = "Title: No Snippet\nURL: https://example.com"
        result = _parse_sources(raw)
        assert result == []

    def test_multiple_blocks_parsed(self):
        raw = (
            "Title: A\nURL: https://a.com\nSnippet: A snippet\n\n"
            "Title: B\nURL: https://b.com\nSnippet: B snippet"
        )
        result = _parse_sources(raw)
        assert len(result) == 2


class TestFallbackMarkdownReport:
    def test_report_starts_with_heading(self):
        report = _fallback_markdown_report("My goal", "")
        assert report.startswith("#")

    def test_report_contains_goal(self):
        report = _fallback_markdown_report("AI research goal", "")
        assert "AI research goal" in report

    def test_report_has_sources_section(self):
        report = _fallback_markdown_report("goal", "")
        assert "## Sources" in report

    def test_report_with_no_sources_says_none_found(self):
        report = _fallback_markdown_report("goal", "")
        assert "No sources found" in report


class TestResearcher:
    def test_returns_error_message_on_search_failure(self):
        with patch("agents.researcher.web_search", return_value="Error during web search: timeout"):
            result = researcher("some research task")
        assert "Error" in result

    def test_uses_fallback_when_summarize_fails(self):
        with patch("agents.researcher.web_search", return_value="Title: T\nURL: http://t.com\nSnippet: good stuff"):
            with patch("agents.researcher.summarize_research", return_value="Error during research report synthesis: api error"):
                result = researcher("some task")
        # Should fall back to markdown report (starts with a heading)
        assert result.startswith("#")


# ---------------------------------------------------------------------------
# summarizer
# ---------------------------------------------------------------------------

class TestSummarizer:
    def test_returns_error_when_llm_missing(self):
        with patch("agents.summarizer._get_llm", return_value=None):
            result = summarizer("test input")
        assert "MISTRAL_API_KEY" in result or "Error" in result

    def test_summarize_research_returns_error_when_llm_missing(self):
        with patch("agents.summarizer._get_llm", return_value=None):
            result = summarize_research("goal", "raw notes")
        assert "MISTRAL_API_KEY" in result or "Error" in result


# ---------------------------------------------------------------------------
# synthesize_final_report
# ---------------------------------------------------------------------------

class TestSynthesizeFinalReport:
    def test_returns_error_when_llm_missing(self):
        with patch("agents.summarizer._get_llm", return_value=None):
            result = synthesize_final_report("Research LangGraph", "raw notes")
        assert "Error" in result

    def test_calls_llm_once(self):
        mock_llm = MagicMock()
        expected = "# Research Report\n\n## Executive Summary\nLangGraph summary.\n\n## Sources\n- None"
        mock_llm.invoke.return_value = MagicMock(content=expected)
        with patch("agents.summarizer._get_llm", return_value=mock_llm):
            result = synthesize_final_report("Research LangGraph", "LangGraph is a framework...")
        mock_llm.invoke.assert_called_once()
        assert result == expected

    def test_goal_is_passed_to_prompt(self):
        """The synthesis prompt must include the original goal."""
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content="# Research Report\n\n## Sources\n- None")
        with patch("agents.summarizer._get_llm", return_value=mock_llm):
            synthesize_final_report("Understand LangSmith observability", "raw output")
        call_args = mock_llm.invoke.call_args
        # The prompt string is passed as the first positional argument
        prompt_text = str(call_args)
        assert "Understand LangSmith observability" in prompt_text

    def test_result_contains_research_report_heading(self):
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(
            content="# Research Report\n\n## Executive Summary\nText.\n\n## Sources\n- [X](http://x.com)"
        )
        with patch("agents.summarizer._get_llm", return_value=mock_llm):
            result = synthesize_final_report("goal", "data")
        assert "# Research Report" in result
        assert result.count("# Research Report") == 1
