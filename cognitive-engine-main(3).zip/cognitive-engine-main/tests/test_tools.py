"""
Unit tests for tools/datetime_tool.py, tools/file_system.py, and tools/delegation.py.

Run with:  pytest tests/ -v
"""
import pytest
from unittest.mock import patch

from tools.datetime_tool import get_current_datetime
from tools.file_system import write_file, read_file, list_files
from tools.delegation import delegate


# ---------------------------------------------------------------------------
# datetime_tool
# ---------------------------------------------------------------------------

class TestDatetimeTool:
    def test_returns_string(self):
        result = get_current_datetime()
        assert isinstance(result, str)

    def test_contains_label(self):
        result = get_current_datetime()
        assert "Current date and time:" in result

    def test_format_looks_like_datetime(self):
        result = get_current_datetime()
        # Expect something like "2026-06-24 14:30:00"
        import re
        assert re.search(r"\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}", result)


# ---------------------------------------------------------------------------
# file_system
# ---------------------------------------------------------------------------

class TestFileSystem:
    def _make_state(self):
        return {"files": {}}

    def test_write_and_read_file(self):
        state = self._make_state()
        write_file(state, "test.txt", "hello world")
        assert read_file(state, "test.txt") == "hello world"

    def test_read_missing_file_returns_empty_string(self):
        state = self._make_state()
        assert read_file(state, "does_not_exist.txt") == ""

    def test_list_files_returns_all_keys(self):
        state = self._make_state()
        write_file(state, "a.txt", "A")
        write_file(state, "b.txt", "B")
        files = list_files(state)
        assert "a.txt" in files
        assert "b.txt" in files

    def test_overwrite_file(self):
        state = self._make_state()
        write_file(state, "f.txt", "old")
        write_file(state, "f.txt", "new")
        assert read_file(state, "f.txt") == "new"


# ---------------------------------------------------------------------------
# delegation  — unit tests using mocks so no real API calls are made
# ---------------------------------------------------------------------------

class TestDelegation:
    def test_empty_task_returns_message(self):
        result = delegate("")
        assert "No task provided" in result

    def test_whitespace_only_task_returns_message(self):
        result = delegate("   ")
        assert "No task provided" in result

    def test_datetime_routing_for_date_keyword(self):
        with patch("tools.delegation.get_current_datetime", return_value="2026-06-24") as mock_dt:
            delegate("What is the current date?")
        mock_dt.assert_called_once()

    def test_datetime_routing_for_time_keyword(self):
        with patch("tools.delegation.get_current_datetime", return_value="14:00") as mock_dt:
            delegate("Tell me the current time")
        mock_dt.assert_called_once()

    def test_research_routing_for_research_keyword(self):
        with patch("tools.delegation.researcher", return_value="Research result") as mock_r:
            delegate("Research the latest AI news")
        mock_r.assert_called_once()

    def test_research_routing_for_search_keyword(self):
        with patch("tools.delegation.researcher", return_value="Search result") as mock_r:
            delegate("Search for Python tutorials")
        mock_r.assert_called_once()

    def test_research_routing_for_latest_keyword(self):
        with patch("tools.delegation.researcher", return_value="Latest result") as mock_r:
            delegate("Find the latest news on LLMs")
        mock_r.assert_called_once()

    def test_summarizer_routing_as_default(self):
        with patch("tools.delegation.summarizer", return_value="Summary") as mock_s:
            delegate("Write a professional email")
        mock_s.assert_called_once()

    def test_holiday_does_not_route_to_datetime(self):
        """'holiday' contains 'day' as a substring but NOT as a whole word."""
        with patch("tools.delegation.researcher", return_value="Research result") as mock_r:
            delegate("Research holiday marketing trends")
        # Must route to researcher (via "research" keyword), NOT datetime
        mock_r.assert_called_once()

    def test_update_does_not_route_to_datetime(self):
        """'update' contains 'date' as a substring but NOT as a whole word."""
        with patch("tools.delegation.summarizer", return_value="Summary") as mock_s:
            delegate("Update the project documentation")
        mock_s.assert_called_once()


# ---------------------------------------------------------------------------
# planning — fallback quality tests
# ---------------------------------------------------------------------------

class TestPlanningFallback:
    def test_fallback_returns_3_to_5_tasks(self):
        """_generate_fallback_tasks must always return 3-5 tasks."""
        from tools.planning import _generate_fallback_tasks

        tasks = _generate_fallback_tasks("Research AI breakthroughs")
        assert isinstance(tasks, list)
        assert 3 <= len(tasks) <= 5, f"Expected 3-5 tasks, got {len(tasks)}"

    def test_fallback_does_not_copy_goal_verbatim(self):
        """No fallback task description should be an exact copy of the raw goal."""
        from tools.planning import _generate_fallback_tasks

        goal = "Research AI breakthroughs"
        tasks = _generate_fallback_tasks(goal)
        for task in tasks:
            assert task.get("description", "").strip() != goal.strip(), (
                "Fallback must not echo the raw goal as a task description"
            )

    def test_fallback_tasks_have_required_fields(self):
        """Each fallback task must have id, description, and status."""
        from tools.planning import _generate_fallback_tasks

        tasks = _generate_fallback_tasks("Some goal")
        for task in tasks:
            assert "id" in task
            assert "description" in task
            assert "status" in task
            assert task["description"]  # not empty

    def test_write_todos_fallback_on_llm_unavailable(self):
        """write_todos fallback (LLM None) must return 3-5 tasks."""
        from tools.planning import write_todos

        with patch("tools.planning._get_llm", return_value=None):
            tasks = write_todos("Prepare a research report on LangGraph")
        assert 3 <= len(tasks) <= 5, f"Expected 3-5 tasks, got {len(tasks)}"

    def test_write_todos_fallback_on_bad_json(self):
        """write_todos must fall back gracefully when LLM returns invalid JSON."""
        from unittest.mock import MagicMock
        from tools.planning import write_todos

        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content="not valid json at all")
        with patch("tools.planning._get_llm", return_value=mock_llm):
            tasks = write_todos("Any goal")
        assert 3 <= len(tasks) <= 5

    def test_write_todos_fallback_when_llm_returns_single_goal_task(self):
        """write_todos must reject a single-task response that echoes the user goal."""
        from unittest.mock import MagicMock
        from tools.planning import write_todos

        goal = "Research quantum computing"
        single_task_json = (
            f'[{{"id": 1, "description": "{goal}", "status": "pending"}}]'
        )
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content=single_task_json)
        with patch("tools.planning._get_llm", return_value=mock_llm):
            tasks = write_todos(goal)
        # Should have triggered the fallback, giving 3-5 tasks
        assert 3 <= len(tasks) <= 5

    def test_write_todos_fallback_when_llm_returns_too_few_tasks(self):
        """write_todos must use fallback when LLM returns fewer than 3 tasks."""
        from unittest.mock import MagicMock
        from tools.planning import write_todos

        two_tasks_json = (
            '[{"id": 1, "description": "Task one", "status": "pending"}, '
            '{"id": 2, "description": "Task two", "status": "pending"}]'
        )
        mock_llm = MagicMock()
        mock_llm.invoke.return_value = MagicMock(content=two_tasks_json)
        with patch("tools.planning._get_llm", return_value=mock_llm):
            tasks = write_todos("Some goal")
        assert 3 <= len(tasks) <= 5


# ---------------------------------------------------------------------------
# Task stats calculation — sidebar safety tests
# ---------------------------------------------------------------------------

class TestTaskStatsCalculation:
    def _stats(self, todos):
        total = len(todos)
        done = len([t for t in todos if t.get("status") == "done"])
        pending = len([t for t in todos if t.get("status") == "pending"])
        failed = len([t for t in todos if t.get("status") == "failed"])
        return total, done, pending, failed

    def test_empty_todos(self):
        total, done, pending, failed = self._stats([])
        assert total == 0
        assert done == 0
        assert pending == 0
        assert failed == 0

    def test_all_done(self):
        todos = [{"id": i, "description": f"Task {i}", "status": "done"} for i in range(1, 4)]
        total, done, pending, failed = self._stats(todos)
        assert total == 3
        assert done == 3
        assert pending == 0
        assert failed == 0

    def test_mixed_statuses(self):
        todos = [
            {"id": 1, "description": "T1", "status": "done"},
            {"id": 2, "description": "T2", "status": "pending"},
            {"id": 3, "description": "T3", "status": "failed"},
            {"id": 4, "description": "T4", "status": "done"},
        ]
        total, done, pending, failed = self._stats(todos)
        assert total == 4
        assert done == 2
        assert pending == 1
        assert failed == 1

    def test_missing_status_key_counts_as_zero(self):
        todos = [{"id": 1, "description": "T1"}]  # no 'status' key
        total, done, pending, failed = self._stats(todos)
        assert total == 1
        assert done == 0
        assert pending == 0
        assert failed == 0
