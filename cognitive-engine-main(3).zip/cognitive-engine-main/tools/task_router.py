from agents.registry import AGENTS
from logging_config import get_logger

logger = get_logger(__name__)


def task_router(state):

    agent_name = state.get("active_agent")

    if not agent_name:

        logger.error("No active agent specified.")

        return state

    agent = AGENTS.get(agent_name)

    if not agent:

        logger.error("Unknown agent: %s", agent_name)

        return state

    logger.info("Delegating task to agent: %s", agent_name)

    logger.info("Agent lookup: %s -> %s", agent_name, type(agent))

    return agent(state)
