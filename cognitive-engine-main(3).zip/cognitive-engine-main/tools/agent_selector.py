from langchain_mistralai.chat_models import ChatMistralAI

llm = ChatMistralAI(
    model="mistral-small",
    temperature=0,
)


def select_agent(task):

    prompt = f"""
Choose exactly one agent:

research
comparison
analysis

Task:
{task}

Return only agent name.
"""

    return llm.invoke(prompt).content.strip().lower()
