def get_task_id(state, task_description):

    return next(
        (
            t["id"]
            for t in state["todos"]
            if t["description"] == task_description
        ),
        "unknown",
    )