from tavily import TavilyClient
from dotenv import load_dotenv
import os
import re
import time
from logging_config import get_logger

load_dotenv()
logger = get_logger(__name__)

# Tavily works best with concise queries; truncate anything longer.
MAX_QUERY_LENGTH = 300

# Fewer results = faster response and less tokens sent to the summarizer.
MAX_SEARCH_RESULTS = 3


def _get_client():
    api_key = os.getenv("TAVILY_API_KEY")
    if not api_key:
        logger.error("TAVILY_API_KEY is not set in environment.")
        return None
    return TavilyClient(api_key=api_key)


def _normalize_snippet(content, max_length=450):
    """Return a compact single-line snippet for downstream summarization."""
    if not content:
        return "No preview available."

    compact = re.sub(r"\s+", " ", content).strip()
    if len(compact) > max_length:
        return compact[: max_length - 3].rstrip() + "..."
    return compact

def web_search(query: str) -> str:
    """Search the web using Tavily API."""
    if not query or not query.strip():
        return "Error during web search: query is empty."

    # Truncate to avoid Tavily API limits
    query = query.strip()[:MAX_QUERY_LENGTH]

    try:
        client = _get_client()
        if client is None:
            return "Error during web search: TAVILY_API_KEY is missing in .env"

        logger.info("Searching Tavily for: %.80s", query)
        t_start = time.perf_counter()
        response = client.search(query=query, max_results=MAX_SEARCH_RESULTS)
        elapsed = time.perf_counter() - t_start
        logger.info("[TIMING] Tavily search took %.2fs", elapsed)
        results = []
        seen_urls = set()

        for idx, r in enumerate(response.get("results", []), start=1):
            title = r.get("title", "Untitled source")
            url = r.get("url", "N/A")
            
            # Skip duplicate URLs
            if url in seen_urls or url == "N/A":
                continue
            seen_urls.add(url)
            
            snippet = _normalize_snippet(r.get("content", ""))
            results.append(
                f"Source {idx}\n"
                f"Title: {title}\n"
                f"URL: {url}\n"
                f"Snippet: {snippet}"
            )

        if not results:
            logger.warning("No results returned by Tavily for: %.80s", query)
            return "No research results found for this query."

        logger.info("Found %d unique result(s).", len(results))
        return "\n\n".join(results)
    except Exception as exc:
        logger.error("Web search failed: %s", exc)
        return f"Error during web search: {str(exc)}"
