import json
import os
import time
from langchain_mistralai.chat_models import ChatMistralAI
from dotenv import load_dotenv
from logging_config import get_logger

load_dotenv()
logger = get_logger(__name__)

# Default model used for planning. Override via PLANNING_MODEL in .env.
# mistral-small is faster and cheaper; sufficient for structured task planning.
_DEFAULT_PLANNING_MODEL = "mistral-small"


def _generate_fallback_tasks(goal: str) -> list:
    """Return 5 research-focused fallback tasks when the LLM is unavailable
    or returns output that cannot be parsed / does not meet quality thresholds.
    Every task uses research routing keywords so delegate() sends them to
    researcher() rather than summarizer().  None copy the raw goal verbatim.
    """
    short_goal = goal[:80].rstrip()
    return [
        {"id": 1, "description": f"Research background information and overview of: {short_goal}", "status": "pending"},
        {"id": 2, "description": f"Search for recent developments, key facts, and statistics about: {short_goal}", "status": "pending"},
        {"id": 3, "description": f"Find real-world use cases, examples, and applications of: {short_goal}", "status": "pending"},
        {"id": 4, "description": f"Investigate limitations, challenges, and future outlook for: {short_goal}", "status": "pending"},
        {"id": 5, "description": f"Search for expert analysis, comparisons, and key sources on: {short_goal}", "status": "pending"},
    ]


def _get_llm():
    model = os.getenv("PLANNING_MODEL", _DEFAULT_PLANNING_MODEL)
    try:
        return ChatMistralAI(model=model, temperature=0)
    except Exception as exc:
        logger.error("Failed to initialize planning LLM (%s): %s", model, exc)
        return None


def write_todos(goal: str):
    """Ask the LLM to break a goal into a JSON list of TODO tasks."""
    prompt = f"""
You are an expert project manager. Break the following goal into 3 to 5 concrete, distinct, and actionable research subtasks.

IMPORTANT RULES:
1. Create EXACTLY 3 to 5 tasks (not fewer, not more).
2. Each task must be SPECIFIC and ACTIONABLE—not vague or a copy of the goal.
3. Tasks should be DISTINCT—no duplicates or overlapping work.
4. Every task must be a research or investigation task (search, find, research, investigate, compare, analyze, explore).
5. Do NOT create generic tasks like "compile findings", "gather evidence", or "create a report"—the final report is handled automatically.
6. Return ONLY a valid JSON array, with no other text.

Example for goal "Research LangGraph, LangSmith, and Tavily":
[
  {{"id": 1, "description": "Research LangGraph: what it is, its architecture, and core features", "status": "pending"}},
  {{"id": 2, "description": "Research LangSmith: its observability features and how it helps debug LLM applications", "status": "pending"}},
  {{"id": 3, "description": "Research Tavily: its web search API and how it integrates with LLM agents", "status": "pending"}},
  {{"id": 4, "description": "Compare how LangGraph, LangSmith, and Tavily work together in an AI agent pipeline", "status": "pending"}}
]

Goal:
{goal}

Return ONLY the JSON array, no explanations.
"""

    llm = _get_llm()
    if llm is None:
        logger.warning("Planning LLM unavailable. Returning fallback tasks.")
        return _generate_fallback_tasks(goal)

    t_start = time.perf_counter()
    try:
        response = llm.invoke(prompt).content
        elapsed = time.perf_counter() - t_start
        logger.info("[TIMING] Planning LLM call took %.2fs", elapsed)
        logger.debug("Raw planning response: %.200s", response)
    except Exception as exc:
        elapsed = time.perf_counter() - t_start
        logger.error("LLM invocation failed during planning (%.2fs): %s", elapsed, exc)
        return _generate_fallback_tasks(goal)

    try:
        response = response.strip()

        if response.startswith("```json"):
            response = response.replace("```json", "", 1)

        if response.endswith("```"):
            response = response[:-3]

        response = response.strip()
        todos = json.loads(response)
        # Enforce the 3–5 task cap in case the LLM ignores the instruction
        todos = todos[:5]
        # Reject outputs that are just a single copy of the user goal
        if len(todos) < 3:
            logger.warning(
                "Planner returned only %d task(s) (minimum 3 required). Using fallback.",
                len(todos),
            )
            return _generate_fallback_tasks(goal)
        if len(todos) == 1 and todos[0].get("description", "").strip().lower() == goal.strip().lower():
            logger.warning("Planner echoed goal as single task. Using fallback.")
            return _generate_fallback_tasks(goal)
        logger.info("Planned %d task(s) for goal.", len(todos))
        return todos
    except json.JSONDecodeError as exc:
        logger.error("Failed to parse TODO JSON (%s). Raw: %.200s", exc, response)
        return _generate_fallback_tasks(goal)
