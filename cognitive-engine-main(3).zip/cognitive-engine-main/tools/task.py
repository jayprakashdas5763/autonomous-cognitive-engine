from tools.task_router import task_router
from logging_config import get_logger

logger = get_logger(__name__)


def task(state, agent_name):

    logger.info(
        "Delegating task to %s",
        agent_name,
    )

    state["active_agent"] = agent_name

    return task_router(state)
