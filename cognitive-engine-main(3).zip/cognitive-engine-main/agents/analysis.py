import time

from tools.search_tool import web_search
from agents.summarizer import summarize_research
from tools.file_system import write_file
from tools.task_utils import get_task_id
from logging_config import get_logger

logger = get_logger(__name__)


def analysis_agent(state):

    task = state["current_task"]

    t_start = time.perf_counter()

    raw_result = web_search(task)

    state.setdefault("raw_sources", {})
    state.setdefault("agent_results", {})
    state.setdefault("files", {})
    state.setdefault("results", [])

    # Store original search evidence
    state["raw_sources"][task] = raw_result

    if raw_result.startswith("Error during web search"):

        state["results"].append(raw_result)

        return state

    analysis_task = f"""
You are an expert analyst.

Task:
{task}

Using the research below, prepare a detailed analytical report.

Research:
{raw_result}

Return the report in Markdown using the following structure:

# Analysis Report

## Executive Summary

## Key Findings

## Trends

## Strengths

## Weaknesses

## Risks

## Opportunities

## Conclusions

Support important observations using the provided research.
"""

    result = summarize_research(
        analysis_task,
        raw_result,
    )

    elapsed = time.perf_counter() - t_start

    logger.info(
        "[TIMING] Full analysis pipeline took %.2fs",
        elapsed,
    )

    state["results"].append(result)

    state["agent_results"][task] = result

    task_id = get_task_id(
        state,
        task,
    )

    filename = f"research_task_{task_id}.md"

    write_file(
        state,
        filename,
        result,
    )

    logger.info(
        "Analysis saved to virtual file: %s",
        filename,
    )

    return state
