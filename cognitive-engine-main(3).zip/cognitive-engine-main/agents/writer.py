from agents.summarizer import synthesize_final_report
from logging_config import get_logger

from tools.file_system import (
    read_file,
    write_file,
    list_files,
)

logger = get_logger(__name__)


def writer_agent(state):

    goal = state["goal"]

    files = list_files(state)

    combined = []

    for filename in files:

        if not filename.startswith("research_task_"):
            continue

        task_id = filename.replace("research_task_", "").replace(".md", "")

        factcheck_file = f"factcheck_task_{task_id}.md"

        factcheck = read_file(
            state,
            factcheck_file,
        )

        # Skip failed research outputs
        if (
            "## Verdict" in factcheck
            and "FAIL" in factcheck.split("## Verdict")[-1].upper()
        ):
            logger.warning(
                "Skipping %s because fact check failed.",
                filename,
            )
            continue

        content = read_file(
            state,
            filename,
        )

        if content:
            combined.append(content)

    # No valid reports survived fact checking
    if not combined:

        final_report = (
            "# Research Report\n\n" "All research outputs failed fact checking."
        )

        logger.warning("No verified research files available for synthesis.")

        write_file(
            state,
            "final_report.txt",
            final_report,
        )

        logger.info("Final report saved to final_report.txt")

        return state

    # Generate final report
    final_report = synthesize_final_report(
        goal,
        "\n\n".join(combined),
    )

    logger.info(
        "Writer synthesized final report from %d verified research file(s)",
        len(combined),
    )

    write_file(
        state,
        "final_report.txt",
        final_report,
    )

    logger.info("Final report saved to final_report.txt")

    return state
