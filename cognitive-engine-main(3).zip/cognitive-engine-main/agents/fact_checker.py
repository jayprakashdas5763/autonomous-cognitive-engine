from agents.summarizer import summarizer
from tools.file_system import read_file, write_file
from logging_config import get_logger
from tools.task_utils import get_task_id

logger = get_logger(__name__)


def fact_checker_agent(state):

    task = state["current_task"]

    task_id = get_task_id(state, task)

    report = read_file(state, f"research_task_{task_id}.md")

    sources = state.get("raw_sources", {}).get(task, "")

    prompt = f"""
You are a professional fact checker.

Your job is to verify the research report
against the original source material.

Research Report:
{report}

Original Sources:
{sources}

Return the following structure exactly:

# Fact Check Report

## Verified Claims
- claims supported by sources

## Unsupported Claims
- claims not found in sources

## Contradictions
- statements conflicting with sources

## Missing Citations
- claims requiring evidence

## Verdict
PASS or FAIL

Rules:
- PASS only if major claims are supported.
- FAIL if important claims are unsupported.
- Use the original sources as the ground truth.
- Do not invent facts.
"""

    review = summarizer(prompt)

    state.setdefault("agent_results", {})
    state.setdefault("results", [])
    state.setdefault("files", {})

    state["agent_results"][f"{task}_factcheck"] = review

    # Save factcheck report to virtual file system
    write_file(state, f"factcheck_task_{task_id}.md", review)

    if "## Verdict" in review and "FAIL" in review.split("## Verdict")[-1].upper():
        state["results"].append(f"Fact check failed for: {task}")

    logger.info("Factcheck saved to factcheck_task_%s.md", task_id)

    logger.info("Factcheck result for task '%s':\n%s", task, review[:1000])

    return state
