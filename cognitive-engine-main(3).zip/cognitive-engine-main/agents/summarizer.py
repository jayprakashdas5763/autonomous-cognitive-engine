import os
import time
from langchain_mistralai.chat_models import ChatMistralAI
from dotenv import load_dotenv
from logging_config import get_logger

load_dotenv()
logger = get_logger(__name__)

# Default model used for summarization. Override via SUMMARIZER_MODEL in .env.
_DEFAULT_SUMMARIZER_MODEL = "mistral-small"


def _get_llm():
    model = os.getenv("SUMMARIZER_MODEL", _DEFAULT_SUMMARIZER_MODEL)
    try:
        return ChatMistralAI(model=model, temperature=0.2)
    except Exception as exc:
        logger.error("Failed to initialize summarizer LLM (%s): %s", model, exc)
        return None


def _invoke(prompt: str, error_prefix: str) -> str:
    llm = _get_llm()
    if llm is None:
        return f"{error_prefix}: MISTRAL_API_KEY is missing or invalid"

    t_start = time.perf_counter()
    try:
        response = llm.invoke(prompt)
        elapsed = time.perf_counter() - t_start
        logger.info("[TIMING] %s LLM call took %.2fs", error_prefix.split()[0], elapsed)
        return response.content.strip()
    except Exception as exc:
        elapsed = time.perf_counter() - t_start
        logger.error("%s (%.2fs): %s", error_prefix, elapsed, exc)
        return f"{error_prefix}: {str(exc)}"

def summarizer(text):
    prompt = f"""
You are an expert assistant.

Rewrite the user input into a concise, professional markdown response.

Rules:
- Keep it factual and practical.
- Use clear section headings when useful.
- Use bullets or numbered steps for readability.
- Keep response concise unless the user asks for depth.
- Do not invent facts.

User input:
{text}

Return markdown only.
"""

    return _invoke(prompt, "Error during summarization")


def summarize_research(goal, raw_research):
    prompt = f"""
You are a research analyst creating a professional, executive-ready report.

Goal:
{goal}

Raw research notes:
{raw_research}

Create a polished markdown report with this EXACT structure (do not skip any section):

# Research Report

## Executive Summary
<2-3 sentence overview of the research findings>

## Key Findings
- 4 to 6 bullets highlighting the most important discoveries
- Each bullet should include what was found and why it matters

## Detailed Explanation
<2-3 paragraphs of clear, readable explanation covering the research findings>

## Use Cases
- List 3 to 5 practical real-world use cases

## Benefits
- List 3 to 5 clear benefits

## Limitations
- List 2 to 4 honest limitations or challenges

## Conclusion
<1-2 paragraph conclusion summarising what was found and why it matters>

## Sources
- [Source Title](URL) — brief relevance note
(List all sources found in raw research notes with their URLs)

STRICT RULES:
1. Keep response between 300 and 500 words (excluding sources list).
2. Only include URLs that actually appear in the raw notes.
3. Remove marketing copy, duplicates, and irrelevant content.
4. Make every section always present and clearly formatted.
5. Return markdown only—no extra commentary.
"""

    return _invoke(prompt, "Error during research report synthesis")


def synthesize_final_report(goal: str, combined_task_outputs: str) -> str:
    """Combine multiple task research outputs into one clean, goal-focused final report."""
    prompt = f"""
You are a senior research analyst creating one clean, professional final report.

Original goal:
{goal}

Raw task outputs (multiple research results combined):
{combined_task_outputs}

INSTRUCTIONS:
1. Extract ONLY information directly relevant to the original goal above.
2. IGNORE any of the following:
   - Generic templates or instructional text
   - Text starting with "Guidelines for..." or "Structured Report..."
   - Content clearly unrelated to the original goal
   - Duplicate information already covered by another section
3. Combine all relevant findings into ONE unified report with this EXACT structure:

# Research Report

## Executive Summary
<2-3 sentence overview of findings relevant to the original goal>

## Key Findings
- <4 to 6 specific, factual bullet points derived from the research>

## Detailed Explanation
<2-3 paragraphs of coherent, readable explanation>

## Use Cases
- <3 to 5 practical real-world use cases>

## Benefits
- <3 to 5 clear benefits>

## Limitations
- <2 to 4 honest limitations or challenges>

## Conclusion
<1-2 paragraph conclusion>

## Sources
- [Source Title](URL)
(List each unique source once only. Only include URLs that appear in the raw task outputs.)

STRICT RULES:
- Do NOT include: generic report templates, instructional text, unrelated reports, or filler content.
- Do NOT repeat the same source more than once.
- Do NOT invent facts or URLs not present in the raw task outputs.
- Return markdown only—no preamble or extra commentary.
"""

    return _invoke(prompt, "Error during final report synthesis")
