from agents.researcher import researcher_agent
from agents.comparison import comparison_agent
from agents.analysis import analysis_agent
from agents.fact_checker import fact_checker_agent
from agents.writer import writer_agent

AGENTS = {
    "research": researcher_agent,
    "comparison": comparison_agent,
    "analysis": analysis_agent,
    "factcheck": fact_checker_agent,
    "writer": writer_agent,
}