from typing import TypedDict, List, Dict


class AgentState(TypedDict):

    messages: List[str]

    todos: List[dict]

    current_task: str

    files: Dict[str, str]

    results: List[str]

    goal: str

    active_agent: str

    agent_results: Dict[str, str]

    raw_sources: Dict[str, str]
    
    execution_log: List[str]
