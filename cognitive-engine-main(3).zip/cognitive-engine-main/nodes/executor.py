﻿import time

from logging_config import get_logger
from tools.task import task

logger = get_logger(__name__)


def executor_node(state):

    for todo in state["todos"]:

        if todo.get("status") != "pending":
            continue

        task_id = todo.get("id", "?")

        logger.info(
            "Executing task %s via %s",
            task_id,
            state.get("active_agent"),
        )

        t_start = time.perf_counter()

        try:

            current_stage = todo.get("stage")

            # ------------------------------------
            # Delegate task to selected agent
            # ------------------------------------

            state = task(
                state,
                state["active_agent"],
            )

            elapsed = time.perf_counter() - t_start

            # ------------------------------------
            # Research completed
            # ------------------------------------

            if current_stage == "research":

                todo["stage"] = "factcheck"

                logger.info(
                    "Task %s research completed; moved to factcheck",
                    task_id,
                )

            # ------------------------------------
            # Factcheck completed
            # ------------------------------------

            elif current_stage == "factcheck":

                factcheck_key = f"{todo['description']}_factcheck"

                factcheck = state.get("agent_results", {}).get(factcheck_key, "")

                if not factcheck:

                    logger.warning(
                        "No factcheck report found for task %s",
                        task_id,
                    )

                logger.info(
                    "Factcheck result for task %s:\n%s",
                    task_id,
                    factcheck[:1000],
                )

                retries = todo.get("retries", 0)

                # ------------------------------------
                # Parse verdict safely
                # ------------------------------------

                verdict = "UNKNOWN"

                if "## Verdict" in factcheck:

                    verdict_section = factcheck.split(
                        "## Verdict",
                        1,
                    )[1]

                    lines = [
                        line.strip()
                        for line in verdict_section.splitlines()
                        if line.strip()
                    ]

                    if lines:
                        verdict = lines[0].upper()

                logger.info(
                    "Parsed verdict for task %s: %s",
                    task_id,
                    verdict,
                )

                # ------------------------------------
                # Retry on FAIL
                # ------------------------------------

                if verdict == "FAIL":

                    if retries < 2:

                        todo["stage"] = "research"
                        todo["retries"] = retries + 1

                        logger.warning(
                            "Task %s failed factcheck. Retry %d/2",
                            task_id,
                            todo["retries"],
                        )

                    else:

                        todo["status"] = "failed"

                        logger.error(
                            "Task %s exceeded maximum retries.",
                            task_id,
                        )

                else:

                    todo["status"] = "done"

                    logger.info(
                        "Task %s fully completed",
                        task_id,
                    )

            logger.info(
                "[TIMING] Task %s completed in %.2fs",
                task_id,
                elapsed,
            )

        except Exception:

            elapsed = time.perf_counter() - t_start

            todo["status"] = "failed"

            logger.exception(
                "Task %s failed after %.2fs",
                task_id,
                elapsed,
            )

        # Execute one task per graph iteration
        break

    return state
