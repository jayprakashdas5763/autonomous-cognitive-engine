﻿import time
from tools.file_system import read_file
from agents.summarizer import synthesize_final_report
from logging_config import get_logger

logger = get_logger(__name__)

# Patterns that indicate a task output is generic template / instructional text.
# These are filtered out before passing content to the synthesis LLM.
_GENERIC_PATTERNS = [
    "guidelines for gathering",
    "structured report compilation",
    "this task will be handled",
    "gathering supporting evidence",
    "compile all findings into",
    "compile all the findings",
]


def _is_generic_content(text: str) -> bool:
    """Return True if text looks like a generic template or instructional filler."""
    lower = text.lower()
    return any(pattern in lower for pattern in _GENERIC_PATTERNS)


def synthesizer_node(state):
    goal = state.get("goal") or (state["messages"][-1] if state.get("messages") else "")
    task_files = [f for f in state.get("files", {}) if f != "final_report.txt"]

    if not task_files:
        logger.warning("No task files found to synthesize.")
        state["files"]["final_report.txt"] = "No results were generated."
        return state

    t_start = time.perf_counter()

    # Collect task outputs, skipping empty or clearly generic-template content
    task_outputs = []
    for file_name in sorted(task_files):
        content = read_file(state, file_name)
        if not content or not content.strip():
            continue
        if _is_generic_content(content):
            logger.info("Skipping generic/template content in %s", file_name)
            continue
        task_outputs.append(content)

    if not task_outputs:
        logger.warning("All task outputs were empty or generic. Using fallback report.")
        state["files"]["final_report.txt"] = (
            "# Research Report\n\nNo meaningful results were generated for this goal.\n\n"
            "## Sources\n\n- No sources found."
        )
        return state

    # Combine raw task outputs and run a single LLM synthesis step to produce
    # ONE clean, goal-focused final report instead of naively concatenating.
    combined_raw = "\n\n---\n\n".join(task_outputs)
    final_report = synthesize_final_report(goal, combined_raw)

    # Fallback: if synthesis LLM call fails, use the best-looking individual output
    if final_report.startswith("Error during final report synthesis"):
        logger.warning("LLM synthesis failed; falling back to best individual task output.")
        final_report = next(
            (o for o in task_outputs if "# Research Report" in o or "## Executive Summary" in o),
            task_outputs[0],
        )

    state["files"]["final_report.txt"] = final_report
    elapsed = time.perf_counter() - t_start
    logger.info("[TIMING] Synthesis of %d file(s) took %.2fs.", len(task_files), elapsed)
    return state
