﻿import time
from tools.planning import write_todos
from logging_config import get_logger

logger = get_logger(__name__)


def planner_node(state):
    goal = state["messages"][-1]

    logger.info("Planning tasks for goal: %.80s", goal)

    t_start = time.perf_counter()

    todos = write_todos(goal)

    for task in todos:
        task.setdefault("stage", "research")

    elapsed = time.perf_counter() - t_start

    state["todos"] = todos
    state["goal"] = goal

    logger.info(
        "[TIMING] Planning step took %.2fs — created %d task(s).", elapsed, len(todos)
    )

    return state
