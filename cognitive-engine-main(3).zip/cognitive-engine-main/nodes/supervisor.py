from logging_config import get_logger

logger = get_logger(__name__)


def supervisor_node(state):

    pending_tasks = [t for t in state["todos"] if t.get("status") == "pending"]

    if not pending_tasks:

        state["active_agent"] = "writer"

        return state

    current = pending_tasks[0]

    state["current_task"] = current["description"]

    stage = current.get("stage", "research")

    description = current["description"].lower()

    if stage == "research":

        if any(
            word in description
            for word in [
                "compare",
                "comparison",
                "versus",
                "vs",
            ]
        ):

            state["active_agent"] = "comparison"

        elif any(
            word in description
            for word in [
                "analyze",
                "analysis",
                "trend",
                "trends",
                "risk",
                "risks",
                "opportunity",
                "opportunities",
            ]
        ):

            state["active_agent"] = "analysis"

        else:

            state["active_agent"] = "research"

    elif stage == "factcheck":

        state["active_agent"] = "factcheck"

    else:

        state["active_agent"] = "writer"

    logger.info(
        "Supervisor selected agent=%s for task='%s' stage=%s",
        state["active_agent"],
        current["description"],
        stage,
    )

    return state
