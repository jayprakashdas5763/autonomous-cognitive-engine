#!/bin/bash

# Autonomous Cognitive Engine - Quick Start Script (Streamlit-first)

set -e

echo "🚀 Autonomous Cognitive Engine - Setup"
echo "======================================="
echo ""

# Check prerequisites
echo "📋 Checking prerequisites..."

if ! command -v python3 &> /dev/null; then
    echo "❌ Python 3 is not installed. Please install Python 3.8 or higher."
    exit 1
fi

echo "✅ Python: $(python3 --version)"
echo ""

# Create .env if it doesn't exist
if [ ! -f .env ]; then
    echo "📝 Creating .env file..."
    cat > .env << 'EOF'
MISTRAL_API_KEY=your_mistral_api_key_here
TAVILY_API_KEY=your_tavily_api_key_here
EOF
    echo "⚠️  Please edit .env and add your API keys"
    echo ""
fi

# Install Python dependencies
echo "📦 Installing Python dependencies..."
pip install -r requirements.txt > /dev/null 2>&1 || {
    echo "❌ Failed to install requirements.txt"
    exit 1
}
echo "✅ Python dependencies installed"
echo ""

echo "✅ Setup complete!"
echo ""
echo "🎯 Next steps:"
echo ""
echo "1. Edit .env and add your API keys:"
echo "   MISTRAL_API_KEY=your_key_here"
echo "   TAVILY_API_KEY=your_key_here"
echo ""
echo "2. Start Streamlit (Terminal 1):"
echo "   python3 -m streamlit run app.py --server.port 8501 --server.headless true"
echo ""
echo "3. Open in browser:"
echo "   Streamlit: http://localhost:8501"
echo ""
