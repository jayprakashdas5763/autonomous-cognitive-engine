#!/usr/bin/env python3
"""
LoadRunner Report Generator - Desktop Application
Simple GUI for generating LoadRunner performance reports.
Supports both local folders and Confluence URLs.
"""

import os
import sys
import tempfile
import shutil
import zipfile
import threading
import tkinter as tk
from tkinter import ttk, filedialog, messagebox, simpledialog
from datetime import datetime, timedelta
from urllib.parse import urlparse, urljoin, unquote, quote
import re

# Debug flag - set to False for production to improve performance
DEBUG = False

def debug_print(*args, **kwargs):
    """Print only when DEBUG is True."""
    if DEBUG:
        print(*args, **kwargs)

try:
    import requests
    from urllib3.exceptions import InsecureRequestWarning
    # Suppress SSL warnings for internal servers
    requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    REQUESTS_AVAILABLE = True
except ImportError:
    REQUESTS_AVAILABLE = False
    print("Warning: requests not installed. Confluence URL support will not be available.")
    print("Install with: pip install requests")

# Try to import NTLM auth for Windows corporate networks
NTLM_AVAILABLE = False
try:
    from requests_ntlm import HttpNtlmAuth
    NTLM_AVAILABLE = True
except ImportError:
    pass  # NTLM not available, will use basic auth

# Try to import matplotlib for VUsers graph
MATPLOTLIB_AVAILABLE = False
FuncFormatter = None
MaxNLocator = None
try:
    import matplotlib
    matplotlib.use('TkAgg')
    from matplotlib.backends.backend_tkagg import FigureCanvasTkAgg
    from matplotlib.figure import Figure
    from matplotlib.lines import Line2D
    from matplotlib.ticker import FuncFormatter, MaxNLocator
    MATPLOTLIB_AVAILABLE = True
except Exception as e:
    print(f"Warning: matplotlib not available - VUsers graph disabled")

# Import parser
from lrr_parser import LRRParser, EXCEL_AVAILABLE


class LoadRunnerReportApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Income Tax PT Team Tool for Report Generation")
        # Set window size to fit screen
        screen_width = root.winfo_screenwidth()
        screen_height = root.winfo_screenheight()
        window_width = min(1350, screen_width - 50)
        window_height = min(900, screen_height - 80)
        x_pos = (screen_width - window_width) // 2
        y_pos = max(10, (screen_height - window_height) // 2 - 30)
        self.root.geometry(f"{window_width}x{window_height}+{x_pos}+{y_pos}")
        self.root.minsize(1100, 850)  # Minimum size to show graph
        self.root.resizable(True, True)
        
        # Start maximized
        self.root.state('zoomed')
        
        # Set icon if available
        try:
            self.root.iconbitmap(default='')
        except:
            pass
        
        # Variables - 4 input paths
        self.input_path1 = tk.StringVar()
        self.input_path2 = tk.StringVar()
        self.input_path3 = tk.StringVar()
        self.input_path4 = tk.StringVar()
        self.output_path = tk.StringVar()
        self.report_type = tk.StringVar(value='all')  # Keep for backward compatibility
        self.script_folder = tk.StringVar(value='')  # Path to Scripts parent folder (optional, for API details)
        self.script_name = tk.StringVar(value='')
        
        # Report type checkboxes (can select multiple)
        self.report_all = tk.BooleanVar(value=True)  # All Reports (exclusive)
        self.report_trans_summary = tk.BooleanVar(value=False)
        self.report_tps = tk.BooleanVar(value=False)
        self.report_tps_main = tk.BooleanVar(value=False)
        self.report_errors = tk.BooleanVar(value=False)
        
        # Steady state mode: 'absolute' (wall clock HH:MM:SS) or 'relative' (seconds from test start)
        self.ss_mode = tk.StringVar(value='absolute')
        self._previous_ss_mode = 'absolute'  # Track previous mode for conversion
        
        # Steady state variables for each controller (From and To in HH:MM:SS or seconds format)
        self.ss_from1 = tk.StringVar(value='')
        self.ss_to1 = tk.StringVar(value='')
        self.ss_from2 = tk.StringVar(value='')
        self.ss_to2 = tk.StringVar(value='')
        self.ss_from3 = tk.StringVar(value='')
        self.ss_to3 = tk.StringVar(value='')
        self.ss_from4 = tk.StringVar(value='')
        self.ss_to4 = tk.StringVar(value='')
        
        # User count variables for each controller (displayed after report generation)
        self.user_count1 = tk.StringVar(value='-')
        self.user_count2 = tk.StringVar(value='-')
        self.user_count3 = tk.StringVar(value='-')
        self.user_count4 = tk.StringVar(value='-')
        self.total_user_count = tk.StringVar(value='-')
        
        # Trace user count changes to update total
        def update_total_users(*args):
            total = 0
            for uc in [self.user_count1, self.user_count2, self.user_count3, self.user_count4]:
                val = uc.get().strip()
                if val.isdigit():
                    total += int(val)
            self.total_user_count.set(str(total) if total > 0 else '-')
        
        self.user_count1.trace_add('write', update_total_users)
        self.user_count2.trace_add('write', update_total_users)
        self.user_count3.trace_add('write', update_total_users)
        self.user_count4.trace_add('write', update_total_users)
        
        # ZIP file path or Confluence URL variables for each controller
        self.conf_url1 = tk.StringVar(value='')
        self.conf_url2 = tk.StringVar(value='')
        self.conf_url3 = tk.StringVar(value='')
        self.conf_url4 = tk.StringVar(value='')
        
        # Extracted folder path variables (populated after Unzip)
        self.extracted_path1 = tk.StringVar(value='')
        self.extracted_path2 = tk.StringVar(value='')
        self.extracted_path3 = tk.StringVar(value='')
        self.extracted_path4 = tk.StringVar(value='')
        
        # Confluence credentials
        self.confluence_user = tk.StringVar(value='')
        self.confluence_token = tk.StringVar(value='')  # API token or password
        self.confluence_session = None  # Reusable session for downloads
        self.local_extract_folder = tk.StringVar(value='')  # Where to save extracted files
        
        # Confluence upload
        self.upload_to_confluence = tk.BooleanVar(value=False)
        self.confluence_page_url = tk.StringVar(value='')
        
        # Temp directories for downloaded Confluence files
        self.temp_dirs = []
        
        # Track progress popups by controller number (to avoid closing wrong popup)
        self.progress_popups = {}
        
        # Use D: drive for temp operations (more space than C:)
        self.temp_base_dir = "D:\\temp\\lrr_temp"
        try:
            os.makedirs(self.temp_base_dir, exist_ok=True)
        except:
            # Fallback to system temp if D: not available
            self.temp_base_dir = None
        
        # Custom Target TPS values (user-defined overrides)
        self.custom_target_tps = {}
        self.custom_script_categories = {}  # Track BO/FO category for user-added scripts
        self._load_custom_target_tps()  # Load saved values from file
        
        # Track previous paths to detect actual changes (for clearing cached data)
        # Use a single tracking per controller for the EFFECTIVE data source
        self._prev_effective_paths = {1: '', 2: '', 3: '', 4: ''}
        
        # Default output to Desktop
        desktop = os.path.join(os.path.expanduser('~'), 'Desktop')
        self.output_path.set(desktop)
        
        # Bind window close event for cleanup
        self.root.protocol("WM_DELETE_WINDOW", self._on_closing)
        
        self.create_widgets()
    
    def _on_closing(self):
        """Handle window close - cleanup temp directories and properly exit."""
        try:
            # Cleanup temp directories
            import shutil
            for temp_dir in self.temp_dirs:
                try:
                    if os.path.exists(temp_dir):
                        shutil.rmtree(temp_dir, ignore_errors=True)
                except:
                    pass
            
            # Close any matplotlib figures
            try:
                import matplotlib.pyplot as plt
                plt.close('all')
            except:
                pass
            
            # Close Confluence session if open
            try:
                if self.confluence_session:
                    self.confluence_session.close()
            except:
                pass
        except:
            pass
        
        # Destroy the window and exit
        try:
            self.root.destroy()
        except:
            pass
        
        # Force exit to ensure process terminates
        import sys
        sys.exit(0)
    
    def _get_custom_tps_file_path(self):
        """Get path to the custom Target TPS config file."""
        # Store in the same folder as the script/exe
        app_dir = os.path.dirname(os.path.abspath(__file__))
        return os.path.join(app_dir, 'custom_target_tps.json')
    
    def _load_custom_target_tps(self):
        """Load custom Target TPS values from persistent file."""
        try:
            config_file = self._get_custom_tps_file_path()
            if os.path.exists(config_file):
                import json
                with open(config_file, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    # Support both old format (just TPS values) and new format (with categories)
                    if isinstance(data, dict) and 'tps_values' in data:
                        self.custom_target_tps = data.get('tps_values', {})
                        self.custom_script_categories = data.get('categories', {})
                    else:
                        # Old format - just TPS values
                        self.custom_target_tps = data
                        self.custom_script_categories = {}
                print(f"Loaded {len(self.custom_target_tps)} custom Target TPS values")
        except Exception as e:
            print(f"Could not load custom Target TPS: {e}")
            self.custom_target_tps = {}
            self.custom_script_categories = {}
    
    def _save_custom_target_tps(self):
        """Save custom Target TPS values to persistent file."""
        try:
            config_file = self._get_custom_tps_file_path()
            import json
            # Save both TPS values and categories
            data = {
                'tps_values': self.custom_target_tps,
                'categories': getattr(self, 'custom_script_categories', {})
            }
            with open(config_file, 'w', encoding='utf-8') as f:
                json.dump(data, f, indent=2)
            print(f"Saved {len(self.custom_target_tps)} custom Target TPS values to {config_file}")
        except Exception as e:
            print(f"Could not save custom Target TPS: {e}")
        
    def create_widgets(self):
        # Main frame with padding
        main_frame = ttk.Frame(self.root, padding="5")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Title - centered and highlighted
        title_label = tk.Label(main_frame, text="Income Tax PT Team Tool for Report Generation", 
                               font=('Segoe UI', 13, 'bold'), fg='white', bg='#2E86AB')
        title_label.pack(fill=tk.X, pady=(0, 8), ipady=5)
        
        # Confluence credentials row
        top_row = ttk.Frame(main_frame)
        top_row.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(top_row, text="Confluence User:", font=('Segoe UI', 10)).pack(side=tk.LEFT, padx=(0, 3))
        ttk.Entry(top_row, textvariable=self.confluence_user, width=18, font=('Segoe UI', 10)).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(top_row, text="Password:", font=('Segoe UI', 10)).pack(side=tk.LEFT, padx=(0, 3))
        self.password_entry = ttk.Entry(top_row, textvariable=self.confluence_token, width=18, show='*', font=('Segoe UI', 10))
        self.password_entry.pack(side=tk.LEFT, padx=(0, 5))
        
        self.show_password = tk.BooleanVar(value=False)
        def toggle_password():
            self.password_entry.config(show='' if self.show_password.get() else '*')
        ttk.Checkbutton(top_row, text="Show", variable=self.show_password, command=toggle_password).pack(side=tk.LEFT, padx=(0, 5))
        
        # Login button to establish Confluence session
        self.login_btn = ttk.Button(top_row, text="Login", width=7, command=self._confluence_login)
        self.login_btn.pack(side=tk.LEFT, padx=(0, 10))
        self.login_status = tk.StringVar(value='')
        ttk.Label(top_row, textvariable=self.login_status, foreground='gray', font=('Segoe UI', 9)).pack(side=tk.LEFT, padx=(0, 10))
        
        # Note for Confluence usage
        note_text = "Note: For Confluence, first login with your MSP Credentials, then paste the confluence link and click FetchDetails"
        ttk.Label(main_frame, text=note_text, foreground='blue', font=('Segoe UI', 9, 'italic')).pack(anchor=tk.W, pady=(0, 5))
        
        # Input folders section - 4 controllers (single line each)
        input_frame = ttk.LabelFrame(main_frame, text="LoadRunner Results", padding="3")
        input_frame.pack(fill=tk.X, pady=(0, 5))
        
        # Steady State Mode selector row
        ss_mode_row = ttk.Frame(input_frame)
        ss_mode_row.pack(fill=tk.X, pady=(0, 3))
        ttk.Label(ss_mode_row, text="Steady State:", font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Radiobutton(ss_mode_row, text="Absolute Steady State", variable=self.ss_mode, value='absolute',
                       command=self._update_ss_labels).pack(side=tk.LEFT, padx=(0, 10))
        ttk.Radiobutton(ss_mode_row, text="Relative Steady State", variable=self.ss_mode, value='relative',
                       command=self._update_ss_labels).pack(side=tk.LEFT)
        
        # Store references to SS labels for dynamic update
        self._ss_labels = []
        
        # Initialize graph variables for 4 controllers (before creating rows)
        self.figs = [None, None, None, None]
        self.axes = [None, None, None, None]
        self.canvases = [None, None, None, None]
        self.vuser_info_labels = [None, None, None, None]
        self.graph_tooltip_labels = [None, None, None, None]
        self.graph_data_x = [[], [], [], []]  # Time in minutes for each graph
        self.graph_data_y = [[], [], [], []]  # VUser counts for each graph
        self.graph_start_timestamps = [0, 0, 0, 0]  # Start timestamps for each graph (first data point)
        self.test_start_times = [None, None, None, None]  # Actual test start datetime from parser
        self.graph_ramp_info = [{}, {}, {}, {}]  # Ramp timing info for each controller
        self.cached_parsers = {}  # Cache parsers per controller to speed up Info button
        
        # Create single-line controller rows with graphs
        self._create_controller_row(input_frame, 1, self.input_path1, self.ss_from1, self.ss_to1, self.user_count1, self.conf_url1, self.extracted_path1, required=True)
        self._create_controller_row(input_frame, 2, self.input_path2, self.ss_from2, self.ss_to2, self.user_count2, self.conf_url2, self.extracted_path2)
        self._create_controller_row(input_frame, 3, self.input_path3, self.ss_from3, self.ss_to3, self.user_count3, self.conf_url3, self.extracted_path3)
        self._create_controller_row(input_frame, 4, self.input_path4, self.ss_from4, self.ss_to4, self.user_count4, self.conf_url4, self.extracted_path4)
        
        # Total User Count row
        total_row = ttk.Frame(input_frame)
        total_row.pack(fill=tk.X, pady=(5, 2))
        ttk.Entry(total_row, textvariable=self.total_user_count, width=6, state='readonly', font=('Segoe UI', 10, 'bold')).pack(side=tk.RIGHT)
        ttk.Label(total_row, text="Total Usercount =", font=('Segoe UI', 10, 'bold'), foreground='blue').pack(side=tk.RIGHT, padx=(0, 5))
        
        # Hint (dynamic based on mode)
        self._ss_hint_var = tk.StringVar(value="Absolute Steady State: Enter wall clock time (e.g., 13:38:56 to 13:49:34)")
        self._ss_hint_label = ttk.Label(input_frame, textvariable=self._ss_hint_var, foreground='gray', font=('Segoe UI', 8))
        self._ss_hint_label.pack(anchor=tk.W)
        
        # Horizontal container: Controls on left, Graphs on right
        middle_container = ttk.Frame(main_frame)
        middle_container.pack(fill=tk.BOTH, expand=True, pady=(0, 5))
        
        # Left side - controls
        left_controls = ttk.Frame(middle_container)
        left_controls.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
        
        # Right side - VUsers Graphs (2x2 grid)
        if MATPLOTLIB_AVAILABLE:
            graphs_frame = ttk.LabelFrame(middle_container, text="Running VUsers", padding="5")
            graphs_frame.pack(side=tk.RIGHT, fill=tk.Y, padx=(10, 0))
            
            # 2x2 grid for 4 graphs - fixed size
            for row_idx in range(2):
                row_frame = ttk.Frame(graphs_frame)
                row_frame.pack(fill=tk.X, pady=5)
                
                for col_idx in range(2):
                    ctrl_idx = row_idx * 2 + col_idx  # 0,1 on top, 2,3 on bottom
                    
                    # Container for label + graph
                    graph_container = ttk.Frame(row_frame)
                    graph_container.pack(side=tk.LEFT, padx=5)
                    
                    # Top row with label and maximize button
                    top_row = ttk.Frame(graph_container)
                    top_row.pack(fill=tk.X)
                    
                    # Label
                    ttk.Label(top_row, text=f"C{ctrl_idx+1}:", font=('Segoe UI', 8, 'bold')).pack(side=tk.LEFT)
                    
                    # Maximize button (small icon) with hand cursor
                    max_btn = ttk.Button(top_row, text="⬜", width=2, 
                                        command=lambda i=ctrl_idx: self._maximize_graph(i),
                                        cursor='hand2')
                    max_btn.pack(side=tk.RIGHT, padx=(2, 0))
                    
                    # Create figure - fixed equal size for all 4 graphs
                    fig = Figure(figsize=(2.0, 1.2), dpi=80, facecolor='white')
                    ax = fig.add_subplot(111, facecolor='white')
                    ax.tick_params(axis='both', labelsize=5, length=2, pad=1)
                    ax.text(0.5, 0.5, 'No data', ha='center', va='center', 
                           transform=ax.transAxes, fontsize=7, color='gray')
                    fig.subplots_adjust(left=0.12, right=0.98, top=0.92, bottom=0.18)
                    
                    canvas = FigureCanvasTkAgg(fig, master=graph_container)
                    canvas.draw()
                    canvas_widget = canvas.get_tk_widget()
                    canvas_widget.config(width=160, height=96, cursor='hand2')
                    canvas_widget.pack(side=tk.LEFT, padx=(2, 3))
                    
                    # Connect mouse motion event for tooltip
                    canvas.mpl_connect('motion_notify_event', lambda event, i=ctrl_idx: self._on_graph_hover_multi(event, i))
                    
                    # Double-click to maximize
                    canvas_widget.bind('<Double-Button-1>', lambda e, i=ctrl_idx: self._maximize_graph(i))
                    
                    # Info label (Max/Avg)
                    info_label = ttk.Label(graph_container, text="M:-\nA:-", font=('Segoe UI', 6))
                    info_label.pack(side=tk.LEFT)
                    
                    # Tooltip label (hidden by default)
                    tooltip_label = ttk.Label(graph_container, text="", font=('Segoe UI', 6),
                                             background='#FFFFCC', relief='solid', borderwidth=1)
                    
                    # Store references
                    self.figs[ctrl_idx] = fig
                    self.axes[ctrl_idx] = ax
                    self.canvases[ctrl_idx] = canvas
                    self.vuser_info_labels[ctrl_idx] = info_label
                    self.graph_tooltip_labels[ctrl_idx] = tooltip_label
        
        # Output folder and Report Name in one row
        output_frame = ttk.LabelFrame(left_controls, text="Save Report To", padding="3")
        output_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Label(output_frame, text="Folder:").pack(side=tk.LEFT, padx=(0, 2))
        output_entry = ttk.Entry(output_frame, textvariable=self.output_path, width=35)
        output_entry.pack(side=tk.LEFT, padx=(0, 3))
        
        browse_output_btn = ttk.Button(output_frame, text="...", width=3, command=self.browse_output)
        browse_output_btn.pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(output_frame, text="Report Name*:", font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=(0, 3))
        ttk.Entry(output_frame, textvariable=self.script_name, width=25).pack(side=tk.LEFT)
        
        # Scripts Folder section (optional - for API details in Slow Transactions)
        scripts_frame = ttk.LabelFrame(left_controls, text="Scripts (Optional - for API details)", padding="3")
        scripts_frame.pack(fill=tk.X, pady=(0, 5))
        ttk.Label(scripts_frame, text="ZIP/Folder:", font=('Segoe UI', 9)).pack(side=tk.LEFT, padx=(0, 3))
        ttk.Entry(scripts_frame, textvariable=self.script_folder, width=50, font=('Segoe UI', 9)).pack(side=tk.LEFT, padx=(0, 3))
        ttk.Button(scripts_frame, text="+ ZIP", width=5, command=self._browse_script_zip).pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(scripts_frame, text="+ Folder", width=6, command=self._browse_script_folder).pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(scripts_frame, text="+ Confluence", width=10, command=self._add_script_from_confluence).pack(side=tk.LEFT, padx=(0, 2))
        ttk.Button(scripts_frame, text="Clear", width=5, command=lambda: self.script_folder.set('')).pack(side=tk.LEFT, padx=(0, 5))
        self.script_progress_var = tk.StringVar(value="")
        self.script_progress_label = ttk.Label(scripts_frame, textvariable=self.script_progress_var, font=('Segoe UI', 8), foreground='blue')
        self.script_progress_label.pack(side=tk.LEFT, padx=(5, 0))
        
        # Report type section
        type_frame = ttk.LabelFrame(left_controls, text="Report Type", padding="3")
        type_frame.pack(fill=tk.X, pady=(0, 5))
        
        # All Reports radio button (exclusive - when selected, others are disabled)
        self.rb_all = ttk.Radiobutton(type_frame, text='All Reports', value='all', 
                                       variable=self.report_type, command=self._on_report_type_change)
        self.rb_all.pack(side=tk.LEFT, padx=8)
        
        # Separator
        ttk.Label(type_frame, text="|", font=('Segoe UI', 9)).pack(side=tk.LEFT, padx=2)
        
        # Individual report type checkboxes (can be combined)
        self.cb_trans = ttk.Checkbutton(type_frame, text='Transaction Summary', 
                                         variable=self.report_trans_summary, command=self._on_checkbox_change)
        self.cb_trans.pack(side=tk.LEFT, padx=8)
        
        self.cb_tps = ttk.Checkbutton(type_frame, text='TPS', 
                                       variable=self.report_tps, command=self._on_checkbox_change)
        self.cb_tps.pack(side=tk.LEFT, padx=8)
        
        self.cb_tps_main = ttk.Checkbutton(type_frame, text='TPS_Main', 
                                            variable=self.report_tps_main, command=self._on_checkbox_change)
        self.cb_tps_main.pack(side=tk.LEFT, padx=8)
        
        self.cb_errors = ttk.Checkbutton(type_frame, text='Errors', 
                                          variable=self.report_errors, command=self._on_checkbox_change)
        self.cb_errors.pack(side=tk.LEFT, padx=8)
        
        # Confluence Upload section
        upload_frame = ttk.LabelFrame(left_controls, text="Upload to Confluence", padding="3")
        upload_frame.pack(fill=tk.X, pady=(0, 5))
        
        ttk.Checkbutton(upload_frame, text="Upload to Confluence", variable=self.upload_to_confluence).pack(side=tk.LEFT, padx=(0, 10))
        
        ttk.Label(upload_frame, text="Page URL:", font=('Segoe UI', 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Entry(upload_frame, textvariable=self.confluence_page_url, width=60, font=('Segoe UI', 9)).pack(side=tk.LEFT, padx=(0, 5))
        ttk.Label(upload_frame, text="(Use same MSP credentials)", font=('Segoe UI', 8), foreground='gray').pack(side=tk.LEFT)
        
        # Button frame for horizontal layout
        btn_frame = ttk.Frame(left_controls)
        btn_frame.pack(pady=8, fill=tk.X)
        
        # Generate Report button - styled with attractive design
        generate_btn = tk.Button(btn_frame, text="🚀 Generate Report", 
                                 command=self.generate_report,
                                 font=('Segoe UI', 10, 'bold'),
                                 bg='#2E7D32',  # Dark green background
                                 fg='white',     # White text
                                 activebackground='#1B5E20',  # Darker green on click
                                 activeforeground='white',
                                 relief='raised',
                                 bd=2,
                                 padx=10,
                                 pady=4,
                                 cursor='hand2')
        generate_btn.pack(side=tk.LEFT, padx=3)
        
        # Add hover effects
        def on_enter(e):
            generate_btn['bg'] = '#43A047'  # Lighter green on hover
        def on_leave(e):
            generate_btn['bg'] = '#2E7D32'  # Back to original
        generate_btn.bind("<Enter>", on_enter)
        generate_btn.bind("<Leave>", on_leave)
        
        # PDF Report button - styled attractively
        pdf_btn = tk.Button(btn_frame, text="📄 PDF Report", 
                            command=self.generate_pdf_report,
                            font=('Segoe UI', 10, 'bold'),
                            bg='#1565C0',  # Blue background
                            fg='white',     # White text
                            activebackground='#0D47A1',  # Darker blue on click
                            activeforeground='white',
                            relief='raised',
                            bd=2,
                            padx=10,
                            pady=4,
                            cursor='hand2')
        pdf_btn.pack(side=tk.LEFT, padx=3)
        
        # Add hover effects for PDF button
        def on_enter_pdf(e):
            pdf_btn['bg'] = '#1976D2'  # Lighter blue on hover
        def on_leave_pdf(e):
            pdf_btn['bg'] = '#1565C0'  # Back to original
        pdf_btn.bind("<Enter>", on_enter_pdf)
        pdf_btn.bind("<Leave>", on_leave_pdf)
        
        # Edit Target TPS button - styled attractively (orange)
        target_tps_btn = tk.Button(btn_frame, text="🎯 Target TPS", 
                              command=self.show_target_tps_editor,
                              font=('Segoe UI', 10, 'bold'),
                              bg='#E65100',  # Deep orange background
                              fg='white',     # White text
                              activebackground='#BF360C',  # Darker orange on click
                              activeforeground='white',
                              relief='raised',
                              bd=2,
                              padx=10,
                              pady=4,
                              cursor='hand2')
        target_tps_btn.pack(side=tk.LEFT, padx=3)
        
        # Add hover effects for Target TPS button
        def on_enter_tps(e):
            target_tps_btn['bg'] = '#FF6D00'  # Lighter orange on hover
        def on_leave_tps(e):
            target_tps_btn['bg'] = '#E65100'  # Back to original
        target_tps_btn.bind("<Enter>", on_enter_tps)
        target_tps_btn.bind("<Leave>", on_leave_tps)
        
        # Results display frame - shows user count and SS duration after report generation
        results_frame = ttk.LabelFrame(left_controls, text="Results Summary", padding="5")
        results_frame.pack(fill=tk.X, pady=(0, 5))
        
        # User count label - prominent display
        self.user_count_label = ttk.Label(results_frame, text="Virtual Users: - ", 
                                          font=('Segoe UI', 10, 'bold'), foreground='blue')
        self.user_count_label.pack(side=tk.LEFT, padx=(0, 20))
        
        # SS Duration label
        self.ss_duration_label = ttk.Label(results_frame, text="SS Duration: - ", 
                                           font=('Segoe UI', 9))
        self.ss_duration_label.pack(side=tk.LEFT, padx=(0, 20))
        
        # Transaction count label
        self.trans_count_label = ttk.Label(results_frame, text="Transactions: - ", 
                                           font=('Segoe UI', 9))
        self.trans_count_label.pack(side=tk.LEFT)
        
        # FinalReport Status section - shows PDF generation progress
        finalreport_frame = ttk.LabelFrame(left_controls, text="FinalReport Status", padding="5")
        finalreport_frame.pack(fill=tk.X, pady=(0, 5))
        
        # Progress bar
        self.pdf_progress_var = tk.DoubleVar(value=0)
        self.pdf_progress_bar = ttk.Progressbar(finalreport_frame, variable=self.pdf_progress_var, 
                                                 maximum=100, length=200, mode='determinate')
        self.pdf_progress_bar.pack(side=tk.LEFT, padx=(0, 10))
        
        # Progress percentage label
        self.pdf_progress_pct = tk.StringVar(value="0%")
        self.pdf_progress_pct_label = ttk.Label(finalreport_frame, textvariable=self.pdf_progress_pct,
                                                 font=('Segoe UI', 9, 'bold'), foreground='#1565C0')
        self.pdf_progress_pct_label.pack(side=tk.LEFT, padx=(0, 10))
        
        # Current step label
        self.pdf_progress_step = tk.StringVar(value="Ready")
        self.pdf_progress_step_label = ttk.Label(finalreport_frame, textvariable=self.pdf_progress_step,
                                                  font=('Segoe UI', 9), foreground='gray')
        self.pdf_progress_step_label.pack(side=tk.LEFT)
        
        # Status/Log section
        log_frame = ttk.LabelFrame(left_controls, text="Status", padding="5")
        log_frame.pack(fill=tk.BOTH, expand=True)
        
        self.log_text = tk.Text(log_frame, height=6, wrap=tk.WORD, state=tk.DISABLED,
                                font=('Consolas', 8))
        self.log_text.pack(fill=tk.BOTH, expand=True)
        
        # Scrollbar for log
        scrollbar = ttk.Scrollbar(self.log_text, command=self.log_text.yview)
        scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
        self.log_text.config(yscrollcommand=scrollbar.set)
        
        # Initial log message
        self.log("Ready. Select a LoadRunner results folder to generate report.")
        if EXCEL_AVAILABLE:
            self.log("Excel export: Available")
        else:
            self.log("Excel export: Not available (install openpyxl)")
    
    def log(self, message):
        """Add message to log."""
        self.log_text.config(state=tk.NORMAL)
        timestamp = datetime.now().strftime('%H:%M:%S')
        self.log_text.insert(tk.END, f"[{timestamp}] {message}\n")
        self.log_text.see(tk.END)
        self.log_text.config(state=tk.DISABLED)
        self.root.update()
    
    def update_vusers_graph(self, parser, ss_from_min=None, ss_to_min=None, ctrl_index=0):
        """Update the VUsers graph for a specific controller.
        ctrl_index: 0-3 for C1-C4
        If ss_from_min and ss_to_min are provided, show only the steady state period."""
        if not MATPLOTLIB_AVAILABLE:
            return
        
        if ctrl_index < 0 or ctrl_index > 3:
            return
            
        fig = self.figs[ctrl_index]
        ax = self.axes[ctrl_index]
        canvas = self.canvases[ctrl_index]
        info_label = self.vuser_info_labels[ctrl_index]
        
        if fig is None or ax is None or canvas is None:
            return
        
        try:
            # Get VUsers data
            all_vusers = getattr(parser, 'all_running_vusers', None)
            running_vusers = getattr(parser, 'running_vusers', None)
            all_timestamps = getattr(parser, 'all_vuser_timestamps', None)
            
            # Extract ramp timing info from parser for accurate max period calculation
            ramp_info = {}
            ramp_info['ramp_up_min'] = getattr(parser, 'ramp_up_seconds', 0) / 60.0
            ramp_info['ramp_down_min'] = getattr(parser, 'ramp_down_seconds', 0) / 60.0
            ramp_info['steady_state_duration_min'] = getattr(parser, 'steady_state_duration', 0) / 60.0
            ramp_info['steady_state_from_rel'] = getattr(parser, 'steady_state_from_rel', 0) / 60.0
            ramp_info['steady_state_to_rel'] = getattr(parser, 'steady_state_to_rel', 0) / 60.0
            self.graph_ramp_info[ctrl_index] = ramp_info
            
            # DEBUG: Print ramp timing info (disabled by default for performance)
            debug_print(f"\n=== RAMP TIMING for Controller {ctrl_index+1} ===")
            debug_print(f"  Ramp Up: {ramp_info['ramp_up_min']:.2f} min ({getattr(parser, 'ramp_up_seconds', 0)} sec)")
            debug_print(f"  Steady State Duration: {ramp_info['steady_state_duration_min']:.2f} min")
            debug_print(f"  Ramp Down: {ramp_info['ramp_down_min']:.2f} min ({getattr(parser, 'ramp_down_seconds', 0)} sec)")
            debug_print(f"  SS From (rel): {ramp_info['steady_state_from_rel']:.2f} min")
            debug_print(f"  SS To (rel): {ramp_info['steady_state_to_rel']:.2f} min")
            debug_print(f"========================================\n")
            
            # Completely clear and reset
            ax.cla()
            ax.set_facecolor('white')
            
            # Use whichever data is available
            vusers_data = all_vusers if all_vusers else running_vusers
            
            if vusers_data and len(vusers_data) > 0:
                # Create time axis in minutes
                if all_timestamps and len(all_timestamps) == len(vusers_data):
                    start_time = min(all_timestamps)
                    times_min = [(t - start_time) / 60.0 for t in all_timestamps]
                    # Store start timestamp for absolute time display
                    self.graph_start_timestamps[ctrl_index] = start_time
                else:
                    times_min = [i * 5 / 60.0 for i in range(len(vusers_data))]
                    self.graph_start_timestamps[ctrl_index] = 0
                
                # Convert to list of floats
                y_data = [float(v) for v in vusers_data]
                
                # AGGREGATE data: For duplicate timestamps, take MAX value
                time_to_max = {}
                for x, y in zip(times_min, y_data):
                    if x not in time_to_max:
                        time_to_max[x] = y
                    else:
                        time_to_max[x] = max(time_to_max[x], y)
                
                # Sort by time
                sorted_times = sorted(time_to_max.keys())
                times_min = sorted_times
                y_data = [time_to_max[t] for t in sorted_times]
                
                # Calculate key timing points for simplified graph
                max_v = int(max(y_data)) if y_data else 0
                avg_v = int(sum(y_data) / len(y_data)) if y_data else 0
                test_start = min(times_min) if times_min else 0
                test_end = max(times_min) if times_min else 0
                
                # Max Period Start = First time VUsers reaches max
                ramp_up_end = test_start
                for i, y in enumerate(y_data):
                    if int(y) == max_v:
                        ramp_up_end = times_min[i]
                        break
                
                # Max Period End = First time VUsers drops by 1 from max (after reaching max)
                ramp_down_start = test_end  # Default to end if never drops
                found_max = False
                for i, y in enumerate(y_data):
                    if int(y) == max_v:
                        found_max = True
                    elif found_max and int(y) < max_v:
                        # VUsers dropped by at least 1 from max
                        ramp_down_start = times_min[i-1] if i > 0 else times_min[i]
                        break
                
                # Store original data for tooltip (so hover shows actual values)
                self.graph_data_x[ctrl_index] = times_min
                self.graph_data_y[ctrl_index] = y_data
                
                # Use actual data points for the graph (shows real shape)
                sampled_x = times_min
                sampled_y = y_data
                
                # Clear and set white background
                ax.clear()
                ax.set_facecolor('#FFFFFF')
                fig.set_facecolor('#FFFFFF')
                
                # Get SS times for this controller to determine coloring
                ss_from_vars = [self.ss_from1, self.ss_from2, self.ss_from3, self.ss_from4]
                ss_to_vars = [self.ss_to1, self.ss_to2, self.ss_to3, self.ss_to4]
                ss_from_val = ss_from_vars[ctrl_index].get().strip()
                ss_to_val = ss_to_vars[ctrl_index].get().strip()
                
                # If SS times are set, show SS-filtered view
                if ss_from_val and ss_to_val and ss_from_min is not None and ss_to_min is not None:
                    # Draw full shape in faded blue as background
                    ax.fill_between(sampled_x, sampled_y, alpha=0.15, color='#4169E1')
                    ax.plot(sampled_x, sampled_y, color='#228B22', linewidth=0.5, alpha=0.3)
                    
                    # Draw SS region prominently - horizontal line at max
                    ss_plot_x = [ss_from_min, ss_to_min]
                    ss_plot_y = [max_v, max_v]
                    ax.fill_between(ss_plot_x, ss_plot_y, alpha=0.5, color='#32CD32', zorder=3)
                    ax.plot(ss_plot_x, ss_plot_y, color='darkgreen', linewidth=1.5, marker='s', markersize=2, zorder=4)
                else:
                    # No SS filter - draw full shape
                    ax.fill_between(sampled_x, sampled_y, alpha=0.3, color='#4169E1')  # Blue fill
                    ax.plot(sampled_x, sampled_y, color='#228B22', linewidth=1.5, marker='s', markersize=3)  # Green line
                
                # Set limits - zoom to SS period if SS times provided
                x_min = min(times_min) if times_min else 0
                x_max = max(times_min) if times_min else 1
                
                # If SS times are provided, zoom to that period
                if ss_from_min is not None and ss_to_min is not None:
                    x_min = max(0, ss_from_min - 0.5)  # Small margin before SS start
                    x_max = ss_to_min + 0.5  # Small margin after SS end
                
                ax.set_xlim(x_min, x_max)
                ax.set_ylim(0, max_v + 10)
                
                # Minimal labels for small graph - very compact
                ax.tick_params(axis='both', labelsize=4, length=2, pad=1)
                
                # Format x-axis
                def fmt(x, pos):
                    m = int(x)
                    return f"{m}"
                
                ax.xaxis.set_major_formatter(FuncFormatter(fmt))
                ax.xaxis.set_major_locator(MaxNLocator(3))
                ax.yaxis.set_major_locator(MaxNLocator(3))
                
                # Info label
                if info_label:
                    info_label.config(text=f"M:{max_v} A:{avg_v}")
                
                # Auto-populate steady state fields with max period if empty
                ss_from_vars = [self.ss_from1, self.ss_from2, self.ss_from3, self.ss_from4]
                ss_to_vars = [self.ss_to1, self.ss_to2, self.ss_to3, self.ss_to4]
                current_ss_from = ss_from_vars[ctrl_index].get().strip()
                current_ss_to = ss_to_vars[ctrl_index].get().strip()
                
                # Only auto-populate if both fields are empty
                if not current_ss_from and not current_ss_to:
                    is_absolute = (self.ss_mode.get() == 'absolute')
                    
                    if is_absolute:
                        # For absolute mode, use actual test start time and add max period
                        test_start_dt = self.test_start_times[ctrl_index] if ctrl_index < len(self.test_start_times) else None
                        if test_start_dt and isinstance(test_start_dt, datetime):
                            from datetime import timedelta
                            from_dt = test_start_dt + timedelta(minutes=ramp_up_end)
                            to_dt = test_start_dt + timedelta(minutes=ramp_down_start)
                            ss_from_str = from_dt.strftime('%H:%M:%S')
                            ss_to_str = to_dt.strftime('%H:%M:%S')
                        else:
                            # Fallback to using data timestamps if test start not available
                            start_ts = self.graph_start_timestamps[ctrl_index] if ctrl_index < len(self.graph_start_timestamps) else 0
                            if start_ts and start_ts > 0:
                                from_ts = start_ts + (ramp_up_end * 60)
                                to_ts = start_ts + (ramp_down_start * 60)
                                from_dt = datetime.fromtimestamp(from_ts)
                                to_dt = datetime.fromtimestamp(to_ts)
                                ss_from_str = from_dt.strftime('%H:%M:%S')
                                ss_to_str = to_dt.strftime('%H:%M:%S')
                            else:
                                # Fallback to relative if no timestamp available
                                total_secs_from = int(ramp_up_end * 60)
                                total_secs_to = int(ramp_down_start * 60)
                                ss_from_str = f"{total_secs_from//3600:02d}:{(total_secs_from%3600)//60:02d}:{total_secs_from%60:02d}"
                                ss_to_str = f"{total_secs_to//3600:02d}:{(total_secs_to%3600)//60:02d}:{total_secs_to%60:02d}"
                    else:
                        # Relative mode - minutes from test start
                        total_secs_from = int(ramp_up_end * 60)
                        total_secs_to = int(ramp_down_start * 60)
                        ss_from_str = f"{total_secs_from//3600:02d}:{(total_secs_from%3600)//60:02d}:{total_secs_from%60:02d}"
                        ss_to_str = f"{total_secs_to//3600:02d}:{(total_secs_to%3600)//60:02d}:{total_secs_to%60:02d}"
                    
                    ss_from_vars[ctrl_index].set(ss_from_str)
                    ss_to_vars[ctrl_index].set(ss_to_str)
                    mode_str = "Absolute" if is_absolute else "Relative"
                    self.log(f"C{ctrl_index+1}: Auto-filled SS ({mode_str}): {ss_from_str} to {ss_to_str}")
            else:
                self.graph_data_x[ctrl_index] = []
                self.graph_data_y[ctrl_index] = []
                ax.text(0.5, 0.5, 'No data', ha='center', va='center', 
                       transform=ax.transAxes, fontsize=5, color='gray')
                if info_label:
                    info_label.config(text="M:- A:-")
            
            fig.tight_layout(pad=0.2)
            canvas.draw()
        except Exception as e:
            self.log(f"Error updating C{ctrl_index+1} graph: {e}")
    
    def _maximize_graph(self, ctrl_index):
        """Open a maximized popup window for the specified graph - smooth linear style like LR."""
        data_x = self.graph_data_x[ctrl_index]
        data_y = self.graph_data_y[ctrl_index]
        
        if not data_x or not data_y:
            messagebox.showinfo("No Data", f"No data available for Controller {ctrl_index+1} graph.", parent=self.root)
            return
        
        # Create popup window
        popup = tk.Toplevel(self.root)
        popup.title(f"Controller {ctrl_index+1} - Running VUsers Graph")
        popup.geometry("1200x650")
        popup.transient(self.root)
        
        # Create larger figure
        fig = Figure(figsize=(12, 6), dpi=100, facecolor='white')
        ax = fig.add_subplot(111, facecolor='white')
        
        # AGGREGATE data: For duplicate timestamps, take MAX value
        # This handles cases where multiple readings exist for same time
        time_to_max = {}
        for x, y in zip(data_x, data_y):
            if x not in time_to_max:
                time_to_max[x] = y
            else:
                time_to_max[x] = max(time_to_max[x], y)
        
        # Sort by time
        sorted_times = sorted(time_to_max.keys())
        raw_x = sorted_times
        raw_y = [time_to_max[t] for t in sorted_times]
        
        # Get max and avg
        max_v = int(max(raw_y)) if raw_y else 0
        avg_v = int(sum(raw_y) / len(raw_y)) if raw_y else 0
        test_start = min(raw_x) if raw_x else 0
        test_end = max(raw_x) if raw_x else 0
        
        # Max Period Start = First time VUsers reaches max
        ramp_up_end = test_start
        for i, y in enumerate(raw_y):
            if int(y) == max_v:
                ramp_up_end = raw_x[i]
                break
        
        # Max Period End = First time VUsers drops by 1 from max (after reaching max)
        ramp_down_start = test_end  # Default to end if never drops
        found_max = False
        for i, y in enumerate(raw_y):
            if int(y) == max_v:
                found_max = True
            elif found_max and int(y) < max_v:
                # VUsers dropped by at least 1 from max
                ramp_down_start = raw_x[i-1] if i > 0 else raw_x[i]
                break
        
        # Create SIMPLIFIED /___\ shape
        plot_x = [test_start, ramp_up_end, ramp_down_start, test_end]
        plot_y = [0, max_v, max_v, 0]
        
        # Store key times for display
        max_start_time = ramp_up_end
        max_end_time = ramp_down_start
        test_start_time = test_start
        test_end_time = test_end
        
        # Get SS times from user input
        ss_from_vars = [self.ss_from1, self.ss_from2, self.ss_from3, self.ss_from4]
        ss_to_vars = [self.ss_to1, self.ss_to2, self.ss_to3, self.ss_to4]
        ss_from_val = ss_from_vars[ctrl_index].get().strip()
        ss_to_val = ss_to_vars[ctrl_index].get().strip()
        
        # Calculate SS region in minutes if provided
        ss_from_min = None
        ss_to_min = None
        if ss_from_val and ss_to_val:
            try:
                # Get test duration for smart parsing
                test_dur_sec = (test_end_time - test_start_time) * 60  # Convert min to sec
                
                def smart_parse_time(time_str, is_rel, test_dur):
                    """Parse time, smart about HH:MM:SS vs MM:SS in relative mode."""
                    parts = time_str.split(':')
                    if len(parts) == 3:
                        h, m, s = int(parts[0]), int(parts[1]), int(parts[2])
                        hms_seconds = h * 3600 + m * 60 + s
                        mms_seconds = h * 60 + m  # Treat as MM:SS
                        if is_rel and test_dur:
                            if hms_seconds > test_dur and mms_seconds <= test_dur:
                                return mms_seconds
                        return hms_seconds
                    elif len(parts) == 2:
                        m, s = int(parts[0]), int(parts[1])
                        return m * 60 + s
                    return int(time_str)
                
                is_absolute = (self.ss_mode.get() == 'absolute')
                from_secs = smart_parse_time(ss_from_val, not is_absolute, test_dur_sec)
                to_secs = smart_parse_time(ss_to_val, not is_absolute, test_dur_sec)
                
                if is_absolute and self.graph_start_timestamps[ctrl_index] > 0:
                    from datetime import datetime as dt
                    base_ts = self.graph_start_timestamps[ctrl_index]
                    base_dt = dt.fromtimestamp(base_ts)
                    base_secs = base_dt.hour * 3600 + base_dt.minute * 60 + base_dt.second
                    ss_from_min = (from_secs - base_secs) / 60.0
                    ss_to_min = (to_secs - base_secs) / 60.0
                else:
                    ss_from_min = from_secs / 60.0
                    ss_to_min = to_secs / 60.0
            except Exception as e:
                print(f"Error parsing SS times: {e}")
                pass
        
        # Format time strings
        mode = self.ss_mode.get()
        total_duration = test_end_time - test_start_time
        
        # Max duration for display
        max_duration = max_end_time - max_start_time
        
        if mode == 'absolute' and self.graph_start_timestamps[ctrl_index] > 0:
            from datetime import datetime as dt
            base_timestamp = self.graph_start_timestamps[ctrl_index]
            
            def to_abs_str(min_val):
                return dt.fromtimestamp(base_timestamp + min_val * 60).strftime('%H:%M:%S')
            
            test_start_str = to_abs_str(test_start_time)
            test_end_str = to_abs_str(test_end_time)
            max_start_str = to_abs_str(max_start_time)
            max_end_str = to_abs_str(max_end_time)
            time_mode_str = "ABSOLUTE"
        else:
            def fmt_rel(minutes):
                total_secs = int(minutes * 60)
                h = total_secs // 3600
                m = (total_secs % 3600) // 60
                s = total_secs % 60
                return f"{h:02d}:{m:02d}:{s:02d}"
            
            test_start_str = fmt_rel(test_start_time)
            test_end_str = fmt_rel(test_end_time)
            max_start_str = fmt_rel(max_start_time)
            max_end_str = fmt_rel(max_end_time)
            time_mode_str = "RELATIVE"
        
        # PLOT: Simplified /___\ graph like LoadRunner Running VUsers
        # If SS times are set, clip the plot to only show the SS period
        if ss_from_min is not None and ss_to_min is not None:
            # Create SS-filtered plot data - just a horizontal line at max VUsers
            ss_plot_x = [ss_from_min, ss_to_min]
            ss_plot_y = [max_v, max_v]
            
            # Draw full shape in light blue as background
            ax.fill_between(plot_x, plot_y, alpha=0.15, color='#4169E1')  # Light blue fill
            ax.plot(plot_x, plot_y, color='#228B22', linewidth=0.8, alpha=0.3)  # Faded green line
            
            # Draw SS region prominently in green
            ax.fill_between(ss_plot_x, ss_plot_y, alpha=0.5, color='#32CD32', zorder=3)  # Lime green fill
            ax.plot(ss_plot_x, ss_plot_y, color='darkgreen', linewidth=2, marker='s', markersize=4, zorder=4)
        else:
            # No SS filter - draw full shape
            ax.fill_between(plot_x, plot_y, alpha=0.3, color='#4169E1')  # Blue fill
            ax.plot(plot_x, plot_y, color='#228B22', linewidth=1.5, marker='s', markersize=4)  # Green line with markers
        
        # Add horizontal line at max VUsers
        ax.axhline(y=max_v, color='red', linestyle='--', linewidth=1.5, alpha=0.8)
        
        # Grid and labels
        ax.set_xlabel('Time (HH:MM:SS)', fontsize=11)
        ax.set_ylabel('Running VUsers', fontsize=11)
        ax.grid(True, linestyle='--', alpha=0.5)
        
        # X-axis formatting
        from matplotlib.ticker import FuncFormatter
        if mode == 'absolute' and self.graph_start_timestamps[ctrl_index] > 0:
            base_ts = self.graph_start_timestamps[ctrl_index]
            def fmt_x(x, pos):
                from datetime import datetime as dt
                return dt.fromtimestamp(base_ts + x * 60).strftime('%H:%M:%S')
            ax.xaxis.set_major_formatter(FuncFormatter(fmt_x))
        else:
            def fmt_x(x, pos):
                total_secs = int(x * 60)
                h = total_secs // 3600
                m = (total_secs % 3600) // 60
                s = total_secs % 60
                return f"{h:02d}:{m:02d}:{s:02d}"
            ax.xaxis.set_major_formatter(FuncFormatter(fmt_x))
        
        # Set limits - zoom to SS period if SS times provided
        if ss_from_min is not None and ss_to_min is not None:
            ax.set_xlim(max(0, ss_from_min - 0.5), ss_to_min + 0.5)
        else:
            ax.set_xlim(test_start_time - 0.5, test_end_time + 0.5)
        ax.set_ylim(0, max_v * 1.1)
        
        # Title - split into multiple lines for readability
        ss_str = ""
        if ss_from_val and ss_to_val:
            ss_dur = (ss_to_min - ss_from_min) if ss_to_min is not None and ss_from_min is not None else 0
            ss_str = f"\nSS: {ss_from_val} to {ss_to_val} ({ss_dur:.1f} min)"
        
        title = f"Controller {ctrl_index+1} - Running VUsers [{time_mode_str}]\n"
        title += f"Test: {test_start_str} to {test_end_str} ({total_duration:.1f} min)  |  "
        title += f"Max: {max_v} VUsers ({max_start_str} to {max_end_str}){ss_str}"
        ax.set_title(title, fontsize=10, fontweight='bold')
        
        fig.tight_layout(pad=1.5)
        
        # Canvas
        canvas = FigureCanvasTkAgg(fig, master=popup)
        canvas.draw()
        canvas_widget = canvas.get_tk_widget()
        canvas_widget.pack(fill=tk.BOTH, expand=True, padx=10, pady=10)
        canvas_widget.config(cursor='crosshair')
        
        # Tooltip
        tooltip_label = ttk.Label(popup, text="", font=('Segoe UI', 9),
                                 background='#FFFFCC', relief='solid', borderwidth=1)
        
        def on_hover(event):
            if event.inaxes != ax:
                tooltip_label.place_forget()
                return
            
            x_mouse = event.xdata
            if x_mouse is None:
                tooltip_label.place_forget()
                return
            
            # Linear interpolation to find VUsers at mouse position
            vuser_count = 0
            if len(plot_x) > 0:
                if x_mouse <= plot_x[0]:
                    vuser_count = int(plot_y[0])
                elif x_mouse >= plot_x[-1]:
                    vuser_count = int(plot_y[-1])
                else:
                    # Find surrounding points and interpolate
                    for i in range(len(plot_x) - 1):
                        if plot_x[i] <= x_mouse <= plot_x[i + 1]:
                            # Linear interpolation
                            ratio = (x_mouse - plot_x[i]) / (plot_x[i + 1] - plot_x[i]) if plot_x[i + 1] != plot_x[i] else 0
                            vuser_count = int(plot_y[i] + ratio * (plot_y[i + 1] - plot_y[i]))
                            break
            
            # Format time
            if mode == 'absolute' and self.graph_start_timestamps[ctrl_index] > 0:
                from datetime import datetime as dt
                abs_seconds = self.graph_start_timestamps[ctrl_index] + (x_mouse * 60)
                time_str = dt.fromtimestamp(abs_seconds).strftime('%H:%M:%S')
            else:
                mins = int(x_mouse)
                secs = int((x_mouse % 1) * 60)
                time_str = f"{mins:02d}:{secs:02d}"
            
            # Tooltip text
            if vuser_count >= max_v * 0.99:
                tooltip_text = f"Time: {time_str}  |  VUsers: {vuser_count}  ★ MAX"
            else:
                tooltip_text = f"Time: {time_str}  |  VUsers: {vuser_count}"
            tooltip_label.config(text=tooltip_text)
            
            # Position tooltip
            canvas_x, canvas_y = event.x, event.y
            canvas_w = canvas_widget.winfo_width()
            canvas_h = canvas_widget.winfo_height()
            tip_w = len(tooltip_text) * 7 + 20
            tip_h = 25
            
            tip_x = canvas_x - tip_w - 10 if canvas_x + tip_w + 25 > canvas_w else canvas_x + 15
            tip_y = canvas_y - tip_h - 10 if canvas_y + tip_h + 35 > canvas_h else canvas_y + 20
            tip_x = max(5, tip_x)
            tip_y = max(5, tip_y)
            
            tooltip_label.place(x=tip_x, y=tip_y)
        
        def on_leave(event):
            tooltip_label.place_forget()
        
        canvas.mpl_connect('motion_notify_event', on_hover)
        canvas_widget.bind('<Leave>', on_leave)
        
        # Info frame
        info_frame = ttk.Frame(popup)
        info_frame.pack(fill=tk.X, padx=10, pady=(0, 5))
        
        # Legend labels
        ttk.Label(info_frame, text="■ Full Test", font=('Segoe UI', 10), 
                  foreground='#0066CC').pack(side=tk.LEFT, padx=(0, 15))
        
        if ss_from_val and ss_to_val:
            ttk.Label(info_frame, text="■ Steady State", font=('Segoe UI', 10, 'bold'), 
                      foreground='#228B22').pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(info_frame, text=f"--- Max: {max_v}", font=('Segoe UI', 10), 
                  foreground='red').pack(side=tk.LEFT, padx=(0, 15))
        
        ttk.Label(info_frame, text=f"Avg: {avg_v}", font=('Segoe UI', 10), 
                  foreground='#666666').pack(side=tk.LEFT)
        
        # Button frame
        btn_frame = ttk.Frame(popup)
        btn_frame.pack(fill=tk.X, padx=10, pady=(0, 10))
        
        # Close button with hand cursor
        close_btn = ttk.Button(btn_frame, text="Close", command=popup.destroy)
        close_btn.pack(side=tk.RIGHT)
        close_btn.configure(cursor='hand2')
        
        # General info label
        ttk.Label(btn_frame, text=f"Avg VUsers: {avg_v}  |  Total Duration: {total_duration:.1f} min",
                 font=('Segoe UI', 10)).pack(side=tk.LEFT)
        
        # Center popup on screen
        popup.update_idletasks()
        width = popup.winfo_width()
        height = popup.winfo_height()
        x = (popup.winfo_screenwidth() // 2) - (width // 2)
        y = (popup.winfo_screenheight() // 2) - (height // 2)
        popup.geometry(f'{width}x{height}+{x}+{y}')
        
        # Focus on popup
        popup.focus_set()
        popup.grab_set()
    
    def _on_graph_hover_multi(self, event, ctrl_index):
        """Handle mouse hover on VUsers graph to show tooltip for specific controller."""
        tooltip_label = self.graph_tooltip_labels[ctrl_index]
        if not tooltip_label:
            return
        
        ax = self.axes[ctrl_index]
        data_x = self.graph_data_x[ctrl_index]
        data_y = self.graph_data_y[ctrl_index]
        canvas = self.canvases[ctrl_index]
        
        # Hide tooltip if outside axes or no data
        if event.inaxes != ax or not data_x or not data_y:
            tooltip_label.place_forget()
            return
        
        try:
            x_mouse = event.xdata  # Time in minutes
            y_mouse = event.ydata
            
            if x_mouse is None or y_mouse is None:
                tooltip_label.place_forget()
                return
            
            # Find closest data point
            min_dist = float('inf')
            closest_idx = 0
            for i, (x, y) in enumerate(zip(data_x, data_y)):
                dist = abs(x - x_mouse)
                if dist < min_dist:
                    min_dist = dist
                    closest_idx = i
            
            # Get the VUser count at this point
            vuser_count = int(data_y[closest_idx])
            time_min = data_x[closest_idx]
            
            # Check if at EXACT max VUsers
            max_v = int(max(data_y)) if data_y else 0
            is_at_max = vuser_count == max_v
            
            # Format time based on Absolute/Relative mode
            mode = self.ss_mode.get()
            if mode == 'absolute' and self.graph_start_timestamps[ctrl_index] > 0:
                # Convert to absolute wall clock time
                abs_seconds = self.graph_start_timestamps[ctrl_index] + (time_min * 60)
                from datetime import datetime as dt
                abs_time = dt.fromtimestamp(abs_seconds)
                time_str = abs_time.strftime('%H:%M:%S')
                if is_at_max:
                    tooltip_text = f"{time_str}\nVU:{vuser_count}★"
                else:
                    tooltip_text = f"{time_str}\nVU:{vuser_count}"
            else:
                # Relative time format mm:ss
                mins = int(time_min)
                secs = int((time_min - mins) * 60)
                time_str = f"{mins:02d}:{secs:02d}"
                if is_at_max:
                    tooltip_text = f"{time_str}\nVU:{vuser_count}★"
                else:
                    tooltip_text = f"{time_str}\nVU:{vuser_count}"
            
            # Update and show tooltip near the mouse position
            tooltip_label.config(text=tooltip_text)
            
            # Position tooltip - offset from mouse
            canvas_widget = canvas.get_tk_widget()
            canvas_width = canvas_widget.winfo_width()
            canvas_height = canvas_widget.winfo_height()
            
            tooltip_x = event.x + 5
            tooltip_y = canvas_height - event.y - 30
            
            # Keep tooltip within canvas bounds
            if tooltip_x > canvas_width - 60:
                tooltip_x = event.x - 60
            if tooltip_y < 5:
                tooltip_y = 5
            
            tooltip_label.place(in_=canvas_widget, x=tooltip_x, y=tooltip_y)
            
        except Exception:
            tooltip_label.place_forget()
    
    def _update_ss_labels(self):
        """Update SS labels and hint based on mode selection, and convert SS times if needed."""
        new_mode = self.ss_mode.get()
        old_mode = getattr(self, '_previous_ss_mode', new_mode)
        
        if new_mode == 'absolute':
            self._ss_hint_var.set("Absolute Steady State: Enter wall clock time (e.g., 13:38:56 to 13:49:34)")
        else:
            self._ss_hint_var.set("Relative Steady State: Enter time from test start (e.g., 00:00:08 to 00:10:08 or seconds like 8 to 608)")
        
        # Convert SS times when mode changes
        if old_mode != new_mode:
            self._convert_ss_times(old_mode, new_mode)
        
        self._previous_ss_mode = new_mode
        # Note: Don't auto-update graphs here - user should click Enter after changing SS times
    
    def _convert_ss_times(self, from_mode, to_mode):
        """Convert steady state times between absolute and relative modes for all controllers."""
        ss_from_vars = [self.ss_from1, self.ss_from2, self.ss_from3, self.ss_from4]
        ss_to_vars = [self.ss_to1, self.ss_to2, self.ss_to3, self.ss_to4]
        
        for ctrl_index in range(4):
            ss_from_str = ss_from_vars[ctrl_index].get().strip()
            ss_to_str = ss_to_vars[ctrl_index].get().strip()
            
            # Skip if no SS times set
            if not ss_from_str or not ss_to_str:
                continue
            
            # Get actual test start time for this controller
            test_start_dt = self.test_start_times[ctrl_index] if ctrl_index < len(self.test_start_times) else None
            
            # Skip if no test data loaded
            if not test_start_dt or not isinstance(test_start_dt, datetime):
                continue
            
            try:
                # Parse current times
                def parse_hhmmss(time_str):
                    parts = time_str.split(':')
                    if len(parts) == 3:
                        return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
                    elif len(parts) == 2:
                        return int(parts[0]) * 60 + int(parts[1])
                    return int(time_str)
                
                def to_hhmmss(seconds):
                    h = int(seconds) // 3600
                    m = (int(seconds) % 3600) // 60
                    s = int(seconds) % 60
                    return f"{h:02d}:{m:02d}:{s:02d}"
                
                from_secs = parse_hhmmss(ss_from_str)
                to_secs = parse_hhmmss(ss_to_str)
                
                # Get test start time in seconds from midnight
                test_start_secs = test_start_dt.hour * 3600 + test_start_dt.minute * 60 + test_start_dt.second
                
                if from_mode == 'absolute' and to_mode == 'relative':
                    # Absolute -> Relative: subtract test start time
                    new_from = from_secs - test_start_secs
                    new_to = to_secs - test_start_secs
                    
                    # Handle day rollover (if test crosses midnight)
                    if new_from < 0:
                        new_from += 86400
                    if new_to < 0:
                        new_to += 86400
                    
                    ss_from_vars[ctrl_index].set(to_hhmmss(new_from))
                    ss_to_vars[ctrl_index].set(to_hhmmss(new_to))
                    self.log(f"C{ctrl_index+1}: Converted SS to Relative: {to_hhmmss(new_from)} - {to_hhmmss(new_to)}")
                    
                elif from_mode == 'relative' and to_mode == 'absolute':
                    # Relative -> Absolute: add test start time
                    new_from = from_secs + test_start_secs
                    new_to = to_secs + test_start_secs
                    
                    # Handle day rollover
                    if new_from >= 86400:
                        new_from -= 86400
                    if new_to >= 86400:
                        new_to -= 86400
                    
                    ss_from_vars[ctrl_index].set(to_hhmmss(new_from))
                    ss_to_vars[ctrl_index].set(to_hhmmss(new_to))
                    self.log(f"C{ctrl_index+1}: Converted SS to Absolute: {to_hhmmss(new_from)} - {to_hhmmss(new_to)}")
                    
            except Exception as e:
                self.log(f"C{ctrl_index+1}: Could not convert SS times: {e}")
    
    def _create_controller_row(self, parent, num, path_var, ss_from_var, ss_to_var, user_count_var, zip_url_var, extracted_path_var, required=False):
        """Create a single-line controller with all fields."""
        row = ttk.Frame(parent)
        row.pack(fill=tk.X, pady=2)
        
        # Controller label
        label_text = f"C{num}*:" if required else f"C{num}:"
        ttk.Label(row, text=label_text, width=4, font=('Segoe UI', 10, 'bold')).pack(side=tk.LEFT)
        
        # Path entry (local folder or extracted) - wider for full path visibility
        path_entry = ttk.Entry(row, textvariable=path_var, width=30, font=('Segoe UI', 9))
        path_entry.pack(side=tk.LEFT, padx=(0, 2))
        path_browse_btn = ttk.Button(row, text="...", width=3, command=lambda: self.browse_input(num))
        path_browse_btn.pack(side=tk.LEFT, padx=(0, 2))
        path_info_btn = ttk.Button(row, text="i", width=2, command=lambda: self.load_test_info(num))
        path_info_btn.pack(side=tk.LEFT, padx=(0, 5))
        
        # OR separator
        ttk.Label(row, text="OR", foreground='red', font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT, padx=(3, 3))
        
        # Confluence Link section
        ttk.Label(row, text="Confluence:", foreground='darkgreen', font=('Segoe UI', 9, 'bold')).pack(side=tk.LEFT)
        conf_entry = ttk.Entry(row, textvariable=zip_url_var, width=28, font=('Segoe UI', 9))
        conf_entry.pack(side=tk.LEFT, padx=(0, 2))
        conf_browse_btn = ttk.Button(row, text="...", width=3, command=lambda: self._browse_zip(num))
        conf_browse_btn.pack(side=tk.LEFT, padx=(0, 2))
        conf_unzip_btn = ttk.Button(row, text="Fetch", width=5, command=lambda: self._unzip_to_local(num))
        conf_unzip_btn.pack(side=tk.LEFT, padx=(0, 2))
        
        # ClearPath button to reset all fields for this controller - right after FetchDetails
        def clear_controller():
            """Clear all fields for this controller."""
            # Re-enable both path and confluence fields FIRST for quick UI response
            path_entry.config(state='normal')
            path_browse_btn.config(state='normal')
            path_info_btn.config(state='normal')
            conf_entry.config(state='normal')
            conf_browse_btn.config(state='normal')
            conf_unzip_btn.config(state='normal')
            conf_info_btn.config(state='normal')
            
            # Clear path fields
            path_var.set('')
            zip_url_var.set('')
            extracted_path_var.set('')
            
            # Clear steady state fields
            ss_from_var.set('')
            ss_to_var.set('')
            
            # Clear user count
            user_count_var.set('-')
            
            # Clear the graph
            self._clear_graph(num - 1)
            
            # Clear cached parser
            self.cached_parsers = {k: v for k, v in self.cached_parsers.items() if k[0] != num}
            
            # Clear tracking for this controller
            if num in self._prev_effective_paths:
                del self._prev_effective_paths[num]
            
            self.log(f"C{num}: Cleared")
            
            # Clear temp directory in background thread (can be slow for large files)
            def cleanup_temp():
                if self.temp_base_dir and os.path.exists(self.temp_base_dir):
                    temp_dir = os.path.join(self.temp_base_dir, f"lrr_c{num}_{os.getpid()}")
                    if os.path.exists(temp_dir):
                        try:
                            import shutil
                            shutil.rmtree(temp_dir)
                        except Exception:
                            pass  # Ignore cleanup errors
            
            import threading
            threading.Thread(target=cleanup_temp, daemon=True).start()
        
        clear_btn = ttk.Button(row, text="Clear", width=5, command=clear_controller)
        clear_btn.pack(side=tk.LEFT, padx=(0, 2))
        
        # Info button for Confluence (shows test info after FetchDetails)
        conf_info_btn = ttk.Button(row, text="i", width=2, command=lambda: self.load_test_info(num))
        conf_info_btn.pack(side=tk.LEFT, padx=(0, 5))
        
        # Bidirectional mutual exclusion: Path <-> Confluence
        # Helper to get current effective path and clear if changed
        def get_effective_path():
            """Get the effective data source path (local path > extracted > conf_url)"""
            return path_var.get().strip() or extracted_path_var.get().strip() or zip_url_var.get().strip()
        
        def clear_controller_temp(ctrl_num):
            """Clear temp directory for this controller to prevent stale data"""
            if self.temp_base_dir and os.path.exists(self.temp_base_dir):
                temp_dir = os.path.join(self.temp_base_dir, f"lrr_c{ctrl_num}_{os.getpid()}")
                if os.path.exists(temp_dir):
                    try:
                        import shutil
                        shutil.rmtree(temp_dir)
                        self.log(f"C{ctrl_num}: Cleared temp directory")
                    except Exception as e:
                        pass  # Ignore cleanup errors
        
        def check_and_clear_if_source_changed():
            """Check if data source changed and clear old data if needed"""
            current_effective = get_effective_path()
            prev_effective = self._prev_effective_paths.get(num, '')
            
            # If we have a new non-empty path that's different from previous
            if current_effective and prev_effective and current_effective != prev_effective:
                ss_from_var.set('')
                ss_to_var.set('')
                user_count_var.set('-')
                self._clear_graph(num - 1)
                # NOTE: Don't delete temp folder here - it may contain the NEW extracted data
                self.log(f"C{num}: Data source changed, cleared old data")
            
            # Update tracking (only when non-empty)
            if current_effective:
                self._prev_effective_paths[num] = current_effective
        
        def on_path_change(*args):
            current_path = path_var.get().strip()
            
            if current_path:
                # Path is set - disable confluence fields
                conf_entry.config(state='disabled')
                conf_browse_btn.config(state='disabled')
                conf_unzip_btn.config(state='disabled')
                conf_info_btn.config(state='disabled')
                
                # Check if data source changed
                check_and_clear_if_source_changed()
            else:
                # Path is empty - enable confluence fields
                conf_entry.config(state='normal')
                conf_browse_btn.config(state='normal')
                conf_unzip_btn.config(state='normal')
                conf_info_btn.config(state='normal')
                # Clear SS, Users and graph if ALL path sources are empty
                if not zip_url_var.get().strip() and not extracted_path_var.get().strip():
                    ss_from_var.set('')
                    ss_to_var.set('')
                    user_count_var.set('-')
                    self._clear_graph(num - 1)
        
        def on_conf_change(*args):
            current_url = zip_url_var.get().strip()
            
            if current_url:
                # Confluence is set - disable path fields
                path_entry.config(state='disabled')
                path_browse_btn.config(state='disabled')
                path_info_btn.config(state='disabled')
                
                # Check if data source changed
                check_and_clear_if_source_changed()
            else:
                # Confluence is empty - enable path fields
                path_entry.config(state='normal')
                path_browse_btn.config(state='normal')
                path_info_btn.config(state='normal')
                # Clear extracted path when confluence URL is cleared
                if extracted_path_var.get().strip():
                    extracted_path_var.set('')
                # Clear SS, Users, graph and temp folder if path is also empty
                if not path_var.get().strip():
                    ss_from_var.set('')
                    ss_to_var.set('')
                    user_count_var.set('-')
                    self._clear_graph(num - 1)
                    clear_controller_temp(num)  # Clear temp folder too
        
        # Trace both variables
        path_var.trace_add('write', on_path_change)
        zip_url_var.trace_add('write', on_conf_change)
        
        # Trace SS fields and extracted path to clear graph when emptied
        def on_ss_change(*args):
            """Clear graph and user count when SS times are cleared."""
            ss_from = ss_from_var.get().strip()
            ss_to = ss_to_var.get().strip()
            # If both SS fields are empty, clear the graph and user count
            if not ss_from and not ss_to:
                user_count_var.set('-')
                self._clear_graph(num - 1)
        
        def on_extracted_path_change(*args):
            """Clear if data source changed or if all paths are empty."""
            current_extracted = extracted_path_var.get().strip()
            
            if current_extracted:
                # Extracted path is set - check if data source changed
                check_and_clear_if_source_changed()
            elif not path_var.get().strip():
                # Both extracted and local path are empty - clear all
                ss_from_var.set('')
                ss_to_var.set('')
                user_count_var.set('-')
                self._clear_graph(num - 1)
        
        ss_from_var.trace_add('write', on_ss_change)
        ss_to_var.trace_add('write', on_ss_change)
        extracted_path_var.trace_add('write', on_extracted_path_change)
        
        # SteadyState From/To (label text updated dynamically based on mode)
        ss_label = ttk.Label(row, text="Steady State:", font=('Segoe UI', 9))
        ss_label.pack(side=tk.LEFT)
        self._ss_labels.append(ss_label)  # Store reference for dynamic update
        ss_from_entry = ttk.Entry(row, textvariable=ss_from_var, width=9, font=('Segoe UI', 9), state='disabled')
        ss_from_entry.pack(side=tk.LEFT, padx=(0, 2))
        ttk.Label(row, text="-", font=('Segoe UI', 9)).pack(side=tk.LEFT)
        ss_to_entry = ttk.Entry(row, textvariable=ss_to_var, width=9, font=('Segoe UI', 9), state='disabled')
        ss_to_entry.pack(side=tk.LEFT, padx=(0, 2))
        
        # Bind Enter key to fetch users on steady state entries
        def on_ss_enter(event=None):
            # Only proceed if both SS times are filled
            if not ss_from_var.get().strip() or not ss_to_var.get().strip():
                return
            self._fetch_users_for_controller(num, path_var, extracted_path_var, ss_from_var, ss_to_var, user_count_var)
        ss_from_entry.bind('<Return>', on_ss_enter)
        ss_to_entry.bind('<Return>', on_ss_enter)
        
        # Enter button to fetch users - initially disabled
        enter_btn = ttk.Button(row, text="Enter", width=5, command=on_ss_enter, state='disabled')
        enter_btn.pack(side=tk.LEFT, padx=(0, 5))
        
        # Enable/disable SS fields and Enter button based on data source availability
        def update_ss_fields_state(*args):
            # Data is ready if we have local path OR extracted path (FetchDetails clicked)
            has_ready_data = path_var.get().strip() or extracted_path_var.get().strip()
            
            # Enable/disable SS fields based on ready data
            if has_ready_data:
                ss_from_entry.config(state='normal')
                ss_to_entry.config(state='normal')
            else:
                ss_from_entry.config(state='disabled')
                ss_to_entry.config(state='disabled')
            
            # Enable Enter button only if SS fields are filled AND data is ready
            ss_from = ss_from_var.get().strip()
            ss_to = ss_to_var.get().strip()
            if ss_from and ss_to and has_ready_data:
                enter_btn.config(state='normal')
            else:
                enter_btn.config(state='disabled')
        
        ss_from_var.trace_add('write', update_ss_fields_state)
        ss_to_var.trace_add('write', update_ss_fields_state)
        path_var.trace_add('write', update_ss_fields_state)
        extracted_path_var.trace_add('write', update_ss_fields_state)
        
        # Users
        ttk.Label(row, text="Users:", font=('Segoe UI', 9)).pack(side=tk.LEFT)
        ttk.Entry(row, textvariable=user_count_var, width=6, state='readonly', font=('Segoe UI', 9)).pack(side=tk.LEFT, padx=(0, 5))
    
    def _fetch_users_for_controller(self, ctrl_num, path_var, extracted_path_var, ss_from_var, ss_to_var, user_count_var):
        """Fetch and display running users for the given steady state period.
        If SS times are empty, shows full graph without filtering."""
        try:
            # Get folder path - prefer extracted path (from Confluence), else use path_var
            folder_path = extracted_path_var.get().strip() or path_var.get().strip()
            
            # ALWAYS clear old data first before loading new data
            self._clear_graph(ctrl_num - 1)
            user_count_var.set('...')
            self.root.update()
            
            # Update effective path tracking
            self._prev_effective_paths[ctrl_num] = folder_path
            
            # Debug logging
            self.log(f"C{ctrl_num}: Enter clicked, loading from: {os.path.basename(folder_path) if folder_path else 'None'}")
            
            if not folder_path:
                user_count_var.set('-')
                self.log(f"C{ctrl_num}: No folder path found")
                return
            
            if not os.path.isdir(folder_path):
                user_count_var.set('Err')
                self.log(f"C{ctrl_num}: Folder not found: {folder_path}")
                return
            
            # Find .lrr file and log it
            lrr_files = [f for f in os.listdir(folder_path) if f.endswith('.lrr')]
            if lrr_files:
                self.log(f"C{ctrl_num}: Found .lrr file: {lrr_files[0]}")
            
            # Get steady state times
            ss_from = ss_from_var.get().strip()
            ss_to = ss_to_var.get().strip()
            
            # Create NEW parser instance (no caching)
            parser = LRRParser(folder_path)
            
            # Check if SS times are provided
            if ss_from and ss_to:
                # With SS times - filter to steady state period
                self.log(f"C{ctrl_num}: SS times {ss_from} to {ss_to}")
                
                is_absolute = (self.ss_mode.get() == 'absolute')
                
                # First parse to get test timing info for validation
                parser._parse_lrr_file()
                test_start_dt = parser.scenario_info.get('start_time')
                test_duration = parser.scenario_info.get('duration_seconds', 3600)
                
                # Smart parse for relative mode - handle MM:SS:00 format
                def smart_parse_time(time_str, is_relative, test_dur):
                    """Parse time string, being smart about HH:MM:SS vs MM:SS format in relative mode."""
                    parts = time_str.split(':')
                    if len(parts) == 3:
                        h, m, s = int(parts[0]), int(parts[1]), int(parts[2])
                        # In relative mode, if parsed as HH:MM:SS exceeds test duration,
                        # user probably meant MM:SS:00 (minutes:seconds)
                        hms_seconds = h * 3600 + m * 60 + s
                        mms_seconds = h * 60 + m  # Treat as MM:SS (ignore trailing :00)
                        
                        if is_relative and test_dur:
                            # If HH:MM:SS interpretation exceeds test, use MM:SS
                            if hms_seconds > test_dur and mms_seconds <= test_dur:
                                return mms_seconds
                        return hms_seconds
                    elif len(parts) == 2:
                        m, s = int(parts[0]), int(parts[1])
                        return m * 60 + s
                    return int(time_str)
                
                from_seconds = smart_parse_time(ss_from, not is_absolute, test_duration)
                to_seconds = smart_parse_time(ss_to, not is_absolute, test_duration)
                
                # Validate SS times based on mode
                if is_absolute and test_start_dt and test_start_dt != 'N/A':
                    test_start_secs = test_start_dt.hour * 3600 + test_start_dt.minute * 60 + test_start_dt.second
                    test_end_secs = test_start_secs + (test_duration if test_duration else 3600)
                    test_end_dt = test_start_dt + timedelta(seconds=test_duration) if test_duration else None
                    
                    # Check if SS times look like relative times (starting near 0)
                    if from_seconds < 600:  # Less than 10 minutes from midnight
                        # This looks like relative time entered in Absolute mode
                        messagebox.showerror("Steady State Time Error", 
                            f"You selected 'Absolute Steady State' but entered relative times!\n\n"
                            f"Entered: {ss_from} to {ss_to}\n\n"
                            f"For Absolute mode, enter wall clock times like:\n"
                            f"{test_start_dt.strftime('%H:%M:%S')} to {test_end_dt.strftime('%H:%M:%S') if test_end_dt else 'HH:MM:SS'}\n\n"
                            f"Or switch to 'Relative Steady State' mode.", parent=self.root)
                        user_count_var.set('-')
                        return
                    
                    # Check if SS times are within test range
                    if from_seconds < test_start_secs or to_seconds > test_end_secs + 60:
                        messagebox.showerror("Steady State Time Error", 
                            f"SS times are outside test range!\n\n"
                            f"Test ran from: {test_start_dt.strftime('%H:%M:%S')} to {test_end_dt.strftime('%H:%M:%S') if test_end_dt else 'N/A'}\n"
                            f"Entered: {ss_from} to {ss_to}\n\n"
                            f"Please enter SS times within the test duration.", parent=self.root)
                        user_count_var.set('-')
                        return
                else:
                    # Relative mode validation - check if SS times exceed test duration
                    if test_duration and to_seconds > test_duration:
                        # Format test duration as HH:MM:SS
                        dur_h = int(test_duration // 3600)
                        dur_m = int((test_duration % 3600) // 60)
                        dur_s = int(test_duration % 60)
                        dur_str = f"{dur_h:02d}:{dur_m:02d}:{dur_s:02d}"
                        
                        messagebox.showerror("Steady State Time Error", 
                            f"SS 'To' time exceeds test duration!\n\n"
                            f"Test Duration: {dur_str}\n"
                            f"Entered SS To: {ss_to}\n\n"
                            f"Please enter an SS To time within the test duration.", parent=self.root)
                        user_count_var.set('-')
                        return
                    
                    # Check if from_seconds is valid
                    if from_seconds >= to_seconds:
                        messagebox.showerror("Steady State Time Error", 
                            f"SS 'From' time must be less than 'To' time!\n\n"
                            f"Entered: {ss_from} to {ss_to}", parent=self.root)
                        user_count_var.set('-')
                        return
                
                parser.set_steady_state(from_seconds, to_seconds, is_absolute=is_absolute)
                parser.parse()
                
                # Calculate SS times in minutes for graph filtering
                ss_from_min = None
                ss_to_min = None
                
                if is_absolute:
                    # For absolute mode, convert wall clock to relative minutes
                    if test_start_dt and test_start_dt != 'N/A':
                        try:
                            test_start_secs = test_start_dt.hour * 3600 + test_start_dt.minute * 60 + test_start_dt.second
                            ss_from_min = (from_seconds - test_start_secs) / 60.0
                            ss_to_min = (to_seconds - test_start_secs) / 60.0
                        except:
                            pass
                else:
                    # For relative mode, times are already from test start
                    ss_from_min = from_seconds / 60.0
                    ss_to_min = to_seconds / 60.0
                
                # Get the max vusers for the SS period
                if hasattr(parser, 'max_vusers') and parser.max_vusers > 0:
                    user_count_var.set(str(parser.max_vusers))
                    # Update VUsers graph with SS filter for this controller
                    self.update_vusers_graph(parser, ss_from_min, ss_to_min, ctrl_index=ctrl_num-1)
                else:
                    user_count_var.set('N/A')
            else:
                # No SS times - show full graph without filtering
                self.log(f"C{ctrl_num}: No SS times, showing full graph")
                parser._parse_lrr_file()
                duration = parser.scenario_info.get('duration_seconds', 3600)
                if duration:
                    parser.set_steady_state(0, int(duration), is_absolute=False)
                else:
                    parser.set_steady_state(0, 3600, is_absolute=False)
                parser.parse()
                
                # Get max vusers for full test
                if hasattr(parser, 'max_vusers') and parser.max_vusers > 0:
                    user_count_var.set(str(parser.max_vusers))
                    self.log(f"C{ctrl_num}: Max VUsers = {parser.max_vusers}")
                else:
                    user_count_var.set('-')
                
                # Update graph without SS filter (full timeline)
                self.update_vusers_graph(parser, ctrl_index=ctrl_num-1)
                self.log(f"C{ctrl_num}: Graph updated (full timeline)")
                
        except Exception as e:
            import traceback
            print(f"Error fetching users for C{ctrl_num}: {e}")
            traceback.print_exc()
            self.log(f"C{ctrl_num}: Error - {str(e)}")
            user_count_var.set('Err')
    
    def _try_update_graph_for_path(self, folder_path, ctrl_index=0):
        """Try to update the VUsers graph for a given folder path and controller.
        This shows the full VUser timeline even without steady state times."""
        if not folder_path or not os.path.isdir(folder_path):
            return
        
        try:
            self.log(f"Loading VUsers graph for C{ctrl_index+1}...")
            # Don't change cursor - it can interfere with other popups
            
            # Create parser - use optimized VUsers-only loading
            parser = LRRParser(folder_path)
            
            # Get SS times for the specific controller
            ss_from_vars = [self.ss_from1, self.ss_from2, self.ss_from3, self.ss_from4]
            ss_to_vars = [self.ss_to1, self.ss_to2, self.ss_to3, self.ss_to4]
            
            ss_from_str = ss_from_vars[ctrl_index].get().strip()
            ss_to_str = ss_to_vars[ctrl_index].get().strip()
            
            if ss_from_str and ss_to_str:
                # First parse to get test duration for smart parsing
                parser._parse_lrr_file()
                test_duration = parser.scenario_info.get('duration_seconds', 3600)
                
                # Smart parse for relative mode
                def smart_parse_time(time_str, is_rel, test_dur):
                    parts = time_str.split(':')
                    if len(parts) == 3:
                        h, m, s = int(parts[0]), int(parts[1]), int(parts[2])
                        hms_seconds = h * 3600 + m * 60 + s
                        mms_seconds = h * 60 + m  # Treat as MM:SS
                        if is_rel and test_dur:
                            if hms_seconds > test_dur and mms_seconds <= test_dur:
                                return mms_seconds
                        return hms_seconds
                    elif len(parts) == 2:
                        m, s = int(parts[0]), int(parts[1])
                        return m * 60 + s
                    return int(time_str)
                
                is_absolute = (self.ss_mode.get() == 'absolute')
                from_seconds = smart_parse_time(ss_from_str, not is_absolute, test_duration)
                to_seconds = smart_parse_time(ss_to_str, not is_absolute, test_duration)
                parser.set_steady_state(from_seconds, to_seconds, is_absolute=is_absolute)
                
                # Calculate SS times in minutes for graph filtering
                ss_from_min = None
                ss_to_min = None
                
                # Always store the test start time
                test_start_dt = parser.scenario_info.get('start_time')
                if test_start_dt and test_start_dt != 'N/A' and isinstance(test_start_dt, datetime):
                    self.test_start_times[ctrl_index] = test_start_dt
                
                if is_absolute:
                    if test_start_dt and test_start_dt != 'N/A':
                        try:
                            test_start_secs = test_start_dt.hour * 3600 + test_start_dt.minute * 60 + test_start_dt.second
                            ss_from_min = (from_seconds - test_start_secs) / 60.0
                            ss_to_min = (to_seconds - test_start_secs) / 60.0
                        except:
                            pass
                else:
                    ss_from_min = from_seconds / 60.0
                    ss_to_min = to_seconds / 60.0
            else:
                ss_from_min = None
                ss_to_min = None
                # First parse to get duration info
                parser._parse_lrr_file()
                # Use full test duration (relative 0 to end)
                duration = parser.scenario_info.get('duration_seconds', 3600)
                if duration:
                    parser.set_steady_state(0, int(duration), is_absolute=False)
                else:
                    parser.set_steady_state(0, 3600, is_absolute=False)
            
            # Store actual test start time from parser
            test_start_dt = parser.scenario_info.get('start_time')
            if test_start_dt and test_start_dt != 'N/A' and isinstance(test_start_dt, datetime):
                self.test_start_times[ctrl_index] = test_start_dt
            
            # Parse VUsers data only (skip heavy transaction parsing)
            parser.parse_vusers_only()
            
            # Check if VUsers data was loaded
            if hasattr(parser, 'all_running_vusers') and parser.all_running_vusers:
                self.log(f"VUsers data loaded: {len(parser.all_running_vusers)} points")
                self.update_vusers_graph(parser, ss_from_min, ss_to_min, ctrl_index=ctrl_index)
                self.log(f"C{ctrl_index+1} VUsers graph updated")
            elif hasattr(parser, 'running_vusers') and parser.running_vusers:
                self.log(f"VUsers data loaded (SS only): {len(parser.running_vusers)} points")
                self.update_vusers_graph(parser, ss_from_min, ss_to_min, ctrl_index=ctrl_index)
                self.log(f"C{ctrl_index+1} VUsers graph updated")
            else:
                self.log(f"No VUsers data found for C{ctrl_index+1}")
            
        except Exception as e:
            import traceback
            print(f"Error updating graph: {e}")
            traceback.print_exc()
            self.log(f"Could not load VUsers graph: {str(e)}")
    
    def _clear_graph(self, ctrl_index):
        """Clear the VUsers graph for a specific controller."""
        try:
            ax = self.axes[ctrl_index]
            canvas = self.canvases[ctrl_index]
            info_label = self.vuser_info_labels[ctrl_index]
            
            if ax and canvas:
                ax.clear()
                ax.text(0.5, 0.5, 'No data', ha='center', va='center', 
                       transform=ax.transAxes, fontsize=5, color='gray')
                ax.tick_params(axis='both', labelsize=4, length=2, pad=1)
                canvas.draw()
                
            if info_label:
                info_label.config(text="M:- A:-")
                
            # Clear stored data
            self.graph_data_x[ctrl_index] = []
            self.graph_data_y[ctrl_index] = []
            self.graph_start_timestamps[ctrl_index] = 0
            
        except Exception as e:
            pass  # Silently ignore errors during cleanup
    
    def _confluence_login(self):
        """Login to Confluence and establish session."""
        username = self.confluence_user.get().strip()
        password = self.confluence_token.get().strip()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter Confluence username and password.", parent=self.root)
            return
        
        self.login_status.set("Connecting...")
        self.root.config(cursor="wait")
        self.root.update()
        
        try:
            import requests
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            
            base_url = "http://confluence.incometax.gov.in:9080/confluence"
            
            # Create new session
            session = requests.Session()
            session.verify = False
            session.trust_env = True
            
            self.log("Logging in to Confluence...")
            
            # Try form-based login
            login_url = f"{base_url}/dologin.action"
            login_data = {
                'os_username': username,
                'os_password': password,
                'os_destination': f'{base_url}/index.action',
                'login': 'Log In'
            }
            
            resp = session.post(login_url, data=login_data, timeout=60, allow_redirects=True)
            
            # Check if login succeeded
            if resp.status_code == 200 and ('logout' in resp.text.lower() or 'os_username' not in resp.text.lower()):
                self.confluence_session = session
                self.login_status.set("✓ Logged in")
                self.log("Confluence login: SUCCESS")
                messagebox.showinfo("Success", "Logged in to Confluence!\n\nYou can now paste ZIP URLs and click 'FetchDetails'.", parent=self.root)
            else:
                # Check if we got login page back (wrong credentials)
                if 'os_username' in resp.text.lower():
                    self.login_status.set("✗ Login failed")
                    self.log("Confluence login: FAILED - Invalid credentials")
                    messagebox.showerror("Login Failed", "Invalid username or password.\n\nPlease check your credentials.", parent=self.root)
                else:
                    # Partial success - store session anyway
                    self.confluence_session = session
                    self.login_status.set("? Unverified")
                    self.log("Confluence login: Unverified - try FetchDetails")
                    messagebox.showwarning("Warning", "Could not verify login.\n\nTry pasting a ZIP URL and clicking 'FetchDetails'.", parent=self.root)
                    
        except requests.exceptions.ConnectionError as e:
            self.login_status.set("✗ No VPN?")
            self.log(f"Confluence login: Network error - {str(e)}")
            messagebox.showerror("Connection Error", 
                "Cannot connect to Confluence server.\n\n"
                "Please check:\n"
                "1. VPN is connected\n"
                "2. You can access Confluence in browser\n\n"
                f"Error: {str(e)[:100]}", parent=self.root)
        except requests.exceptions.Timeout:
            self.login_status.set("✗ Timeout")
            self.log("Confluence login: Timeout")
            messagebox.showerror("Timeout", "Connection timed out.\n\nPlease check your VPN connection.", parent=self.root)
        except Exception as e:
            self.login_status.set("✗ Error")
            self.log(f"Confluence login error: {str(e)}")
            messagebox.showerror("Error", f"Login failed:\n{str(e)}", parent=self.root)
        finally:
            self.root.config(cursor="")
    
    def _browse_extract_folder(self):
        """Browse for local extraction folder."""
        folder = filedialog.askdirectory(title="Select Folder to Save Extracted Results")
        if folder:
            self.local_extract_folder.set(folder)
            self.log(f"Extract folder set to: {folder}")
    
    def _test_confluence_connection(self):
        """Test connection to Confluence server using form-based login."""
        username = self.confluence_user.get().strip()
        password = self.confluence_token.get().strip()
        
        if not username or not password:
            messagebox.showerror("Error", "Please enter Confluence username and password.", parent=self.root)
            return
        
        try:
            import requests
            from requests_ntlm import HttpNtlmAuth
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            
            session = requests.Session()
            session.verify = False  # Disable SSL verification for internal servers
            session.trust_env = True  # Use system proxy settings
            
            base_url = "http://confluence.incometax.gov.in:9080/confluence"
            
            self.log("Testing Confluence connection (this may take up to 2 minutes)...")
            self.root.config(cursor="wait")
            self.root.update()
            
            # Try form-based login with longer timeout
            login_url = f"{base_url}/dologin.action"
            login_data = {
                'os_username': username,
                'os_password': password,
                'os_destination': f'{base_url}/index.action',
                'login': 'Log In'
            }
            
            resp = session.post(login_url, data=login_data, timeout=120, allow_redirects=True)
            
            # Check if login succeeded by looking for logout link or no login form
            if 'logout' in resp.text.lower() or 'os_username' not in resp.text.lower():
                messagebox.showinfo("Success", "Connected to Confluence successfully!\n\nYou can now paste ZIP URLs and click 'FetchDetails'.", parent=self.root)
                self.log("Confluence connection test: SUCCESS")
                # Store the session for later use
                self.confluence_session = session
            else:
                # Try NTLM auth
                session2 = requests.Session()
                session2.verify = False
                session2.trust_env = True
                session2.auth = HttpNtlmAuth(username, password)
                resp2 = session2.get(f"{base_url}/index.action", timeout=120)
                
                if resp2.status_code == 200 and 'logout' in resp2.text.lower():
                    messagebox.showinfo("Success", "Connected to Confluence (NTLM) successfully!", parent=self.root)
                    self.log("Confluence connection test: SUCCESS (NTLM)")
                    self.confluence_session = session2
                else:
                    messagebox.showwarning("Warning", 
                        "Could not verify login.\n\n"
                        "The connection might still work. Try pasting a ZIP URL and clicking 'FetchDetails'.", parent=self.root)
                    self.log("Confluence connection test: Could not verify")
                    self.confluence_session = session
            
        except Exception as e:
            messagebox.showerror("Error", f"Connection test failed:\n{str(e)}\n\nCheck if you can access Confluence in your browser.\nIf yes, try downloading the ZIP manually in browser.", parent=self.root)
            self.log(f"Confluence connection test failed: {str(e)}")
        finally:
            self.root.config(cursor="")
    
    def _download_confluence_zip(self, confluence_url):
        """Download ZIP file from Confluence URL and return local path."""
        import requests
        from requests_ntlm import HttpNtlmAuth
        import urllib3
        import re
        import time
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        username = self.confluence_user.get().strip()
        password = self.confluence_token.get().strip()
        
        if not username or not password:
            raise Exception("Please enter Confluence username and password, then click 'Login' first.")
        
        base_url = "http://confluence.incometax.gov.in:9080/confluence"
        
        # Use existing session if logged in (MUCH FASTER)
        if self.confluence_session:
            session = self.confluence_session
            self.log("Using cached session (fast)...")
        else:
            # Create new session with NTLM auth directly (skip form login - it's slow)
            self.log(f"Creating session with NTLM auth...")
            session = requests.Session()
            session.verify = False
            session.auth = HttpNtlmAuth(username, password)
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Connection': 'keep-alive',
            })
            self.confluence_session = session  # Cache for next time
        
        try:
            # If URL ends with .zip, extract filename and page URL
            if confluence_url.lower().endswith('.zip'):
                filename = confluence_url.split('/')[-1]
                page_url = confluence_url.rsplit('/', 1)[0]
            else:
                filename = None
                page_url = confluence_url
            
            self.log(f"Fetching page...")
            start_time = time.time()
            
            # Fetch the page to find attachment links (reduced timeout)
            resp = session.get(page_url, timeout=60, verify=False)
            
            self.log(f"Page loaded in {time.time() - start_time:.1f}s")
            
            if resp.status_code != 200:
                raise Exception(f"Could not access page (Status: {resp.status_code})")
            
            # Check if we got the login page instead of the actual content
            if 'os_username' in resp.text and 'os_password' in resp.text:
                raise Exception("Authentication failed - still seeing login page.\n\nPlease check your username and password.")
            
            # Find attachment download link
            download_link = None
            
            # Look for direct attachment link patterns
            patterns = [
                r'href=["\']([^"\']*?/download/attachments/[^"\']*?' + re.escape(filename or '') + r'[^"\']*?)["\']',
                r'href=["\']([^"\']*?/download/attachments/[^"\']*?\.zip[^"\']*?)["\']',
                r'href=["\']([^"\']*?attachments/[^"\']*?\.zip[^"\']*?)["\']',
            ]
            
            for pattern in patterns:
                matches = re.findall(pattern, resp.text, re.IGNORECASE)
                if matches:
                    # Find matching filename if specified
                    if filename:
                        for m in matches:
                            if filename.lower() in m.lower():
                                download_link = m
                                break
                    if not download_link and matches:
                        download_link = matches[0]
                    if download_link:
                        break
            
            if not download_link:
                # Try API approach
                # Extract space key and page title from URL
                display_match = re.search(r'/display/([^/]+)/([^/]+)', confluence_url)
                if display_match:
                    space = display_match.group(1)
                    page_title = display_match.group(2).replace('+', ' ').replace('%20', ' ')
                    
                    if filename and filename != page_title:
                        page_title = page_title  # Use actual page title
                    
                    # Try REST API to get attachments
                    api_url = f"{base_url}/rest/api/content?spaceKey={space}&title={page_title}&expand=children.attachment"
                    api_resp = session.get(api_url, timeout=30, verify=False)
                    
                    if api_resp.status_code == 200:
                        try:
                            data = api_resp.json()
                            if data.get('results'):
                                page_id = data['results'][0].get('id')
                                if page_id:
                                    attach_url = f"{base_url}/rest/api/content/{page_id}/child/attachment"
                                    attach_resp = session.get(attach_url, timeout=120, verify=False)
                                    if attach_resp.status_code == 200:
                                        attach_data = attach_resp.json()
                                        for att in attach_data.get('results', []):
                                            if filename and filename.lower() == att.get('title', '').lower():
                                                download_link = att.get('_links', {}).get('download')
                                                break
                                            elif att.get('title', '').lower().endswith('.zip'):
                                                download_link = att.get('_links', {}).get('download')
                        except:
                            pass
            
            if not download_link:
                # Last resort: try direct download (URL might be direct attachment link)
                if '.zip' in confluence_url.lower():
                    download_link = confluence_url
            
            if not download_link:
                raise Exception("Could not find ZIP attachment link on the page.\n\nPlease check the URL or download manually.")
            
            # Make URL absolute if needed
            if download_link.startswith('/'):
                download_link = f"{base_url}{download_link}"
            elif not download_link.startswith('http'):
                download_link = f"{base_url}/{download_link}"
            
            self.log(f"Starting download...")
            dl_start = time.time()
            
            # Download the file with progress
            dl_resp = session.get(download_link, stream=True, timeout=120, verify=False)
            
            if dl_resp.status_code != 200:
                raise Exception(f"Download failed (Status: {dl_resp.status_code})")
            
            # Check content type
            content_type = dl_resp.headers.get('Content-Type', '')
            if 'html' in content_type.lower():
                raise Exception("Server returned HTML instead of ZIP. Authentication may have failed.")
            
            # Get file size if available
            file_size = dl_resp.headers.get('Content-Length')
            file_size = int(file_size) if file_size else None
            
            # Save to temp file with progress updates
            temp_zip = tempfile.NamedTemporaryFile(suffix='.zip', delete=False, prefix='confluence_')
            temp_zip_path = temp_zip.name
            
            total_size = 0
            last_log_mb = 0
            chunk_size = 65536  # 64KB chunks for faster download
            
            for chunk in dl_resp.iter_content(chunk_size=chunk_size):
                if chunk:
                    temp_zip.write(chunk)
                    total_size += len(chunk)
                    
                    # Log progress every 10MB (less frequent)
                    current_mb = total_size // (10 * 1024 * 1024)
                    if current_mb > last_log_mb:
                        last_log_mb = current_mb
                        if file_size:
                            pct = (total_size * 100) // file_size
                            self.log(f"  {total_size / 1024 / 1024:.0f} MB ({pct}%)")
                        else:
                            self.log(f"  {total_size / 1024 / 1024:.0f} MB...")
            
            temp_zip.close()
            dl_time = time.time() - dl_start
            
            if total_size < 1000:
                # File too small, probably error page
                with open(temp_zip_path, 'r', errors='ignore') as f:
                    content = f.read()
                    if 'login' in content.lower() or 'error' in content.lower():
                        os.remove(temp_zip_path)
                        raise Exception("Download failed - server returned login/error page.")
            
            self.log(f"Downloaded {total_size / 1024 / 1024:.1f} MB in {dl_time:.0f}s")
            return temp_zip_path
            
        except requests.exceptions.ConnectionError as e:
            error_str = str(e).lower()
            if 'getaddrinfo failed' in error_str or 'name resolution' in error_str or 'failed to resolve' in error_str:
                raise Exception("Cannot connect to Confluence.\n\nPlease check:\n1. VPN is connected\n2. You can access Confluence in browser")
            else:
                raise Exception(f"Connection error: {str(e)[:150]}\n\nCheck VPN connection.")
        except requests.exceptions.Timeout:
            raise Exception("Connection timed out.\n\nPlease check VPN is connected and try again.")
        except requests.exceptions.RequestException as e:
            raise Exception(f"Network error: {str(e)}")
    
    def _download_confluence_zip_with_progress(self, confluence_url, progress_popup):
        """Download ZIP from Confluence with progress popup updates."""
        import requests
        from requests_ntlm import HttpNtlmAuth
        import urllib3
        import re
        import time
        urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
        
        username = self.confluence_user.get().strip()
        password = self.confluence_token.get().strip()
        base_url = "http://confluence.incometax.gov.in:9080/confluence"
        
        # Update popup
        self.root.after(0, lambda: progress_popup.status_var.set("Authenticating..."))
        
        # Use existing session if available
        if self.confluence_session:
            session = self.confluence_session
        else:
            session = requests.Session()
            session.verify = False
            session.auth = HttpNtlmAuth(username, password)
            session.headers.update({
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Connection': 'keep-alive',
            })
            self.confluence_session = session
        
        try:
            # Parse URL
            if confluence_url.lower().endswith('.zip'):
                filename = confluence_url.split('/')[-1]
                page_url = confluence_url.rsplit('/', 1)[0]
            else:
                filename = None
                page_url = confluence_url
            
            # Fetch page
            self.root.after(0, lambda: progress_popup.status_var.set("Fetching Confluence page..."))
            start_time = time.time()
            resp = session.get(page_url, timeout=60, verify=False)
            page_time = time.time() - start_time
            self.log(f"Page loaded in {page_time:.1f}s")
            
            if resp.status_code != 200:
                raise Exception(f"Could not access page (Status: {resp.status_code})")
            
            if 'os_username' in resp.text and 'os_password' in resp.text:
                raise Exception("Authentication failed - still seeing login page.")
            
            # Find download link
            self.root.after(0, lambda: progress_popup.status_var.set("Finding attachment..."))
            download_link = None
            
            patterns = [
                r'href=["\']([^"\']*?/download/attachments/[^"\']*?' + re.escape(filename or '') + r'[^"\']*?)["\']',
                r'href=["\']([^"\']*?/download/attachments/[^"\']*?\.zip[^"\']*?)["\']',
                r'href=["\']([^"\']*?attachments/[^"\']*?\.zip[^"\']*?)["\']',
            ]
            
            for pattern in patterns:
                matches = re.findall(pattern, resp.text, re.IGNORECASE)
                if matches:
                    if filename:
                        for m in matches:
                            if filename.lower() in m.lower():
                                download_link = m
                                break
                    if not download_link and matches:
                        download_link = matches[0]
                    if download_link:
                        break
            
            if not download_link:
                # Try API
                display_match = re.search(r'/display/([^/]+)/([^/]+)', confluence_url)
                if display_match:
                    space = display_match.group(1)
                    page_title = display_match.group(2).replace('+', ' ').replace('%20', ' ')
                    api_url = f"{base_url}/rest/api/content?spaceKey={space}&title={page_title}&expand=children.attachment"
                    api_resp = session.get(api_url, timeout=30, verify=False)
                    if api_resp.status_code == 200:
                        try:
                            data = api_resp.json()
                            if data.get('results'):
                                page_id = data['results'][0].get('id')
                                if page_id:
                                    attach_url = f"{base_url}/rest/api/content/{page_id}/child/attachment"
                                    attach_resp = session.get(attach_url, timeout=30, verify=False)
                                    if attach_resp.status_code == 200:
                                        attach_data = attach_resp.json()
                                        for att in attach_data.get('results', []):
                                            if filename and filename.lower() == att.get('title', '').lower():
                                                download_link = att.get('_links', {}).get('download')
                                                break
                                            elif att.get('title', '').lower().endswith('.zip'):
                                                download_link = att.get('_links', {}).get('download')
                        except:
                            pass
            
            if not download_link:
                if '.zip' in confluence_url.lower():
                    download_link = confluence_url
            
            if not download_link:
                raise Exception("Could not find ZIP attachment link on the page.")
            
            # Make URL absolute
            if download_link.startswith('/'):
                download_link = f"{base_url}{download_link}"
            elif not download_link.startswith('http'):
                download_link = f"{base_url}/{download_link}"
            
            # Download with progress
            self.root.after(0, lambda: progress_popup.status_var.set("Starting download..."))
            dl_start = time.time()
            
            dl_resp = session.get(download_link, stream=True, timeout=120, verify=False)
            
            if dl_resp.status_code != 200:
                raise Exception(f"Download failed (Status: {dl_resp.status_code})")
            
            content_type = dl_resp.headers.get('Content-Type', '')
            if 'html' in content_type.lower():
                raise Exception("Server returned HTML instead of ZIP.")
            
            file_size = dl_resp.headers.get('Content-Length')
            file_size = int(file_size) if file_size else None
            
            # Save to temp file
            temp_zip = tempfile.NamedTemporaryFile(suffix='.zip', delete=False, prefix='confluence_')
            temp_zip_path = temp_zip.name
            
            total_size = 0
            last_update_mb = 0
            chunk_size = 65536
            
            for chunk in dl_resp.iter_content(chunk_size=chunk_size):
                if chunk:
                    temp_zip.write(chunk)
                    total_size += len(chunk)
                    
                    # Update progress every 2MB
                    current_mb = total_size // (2 * 1024 * 1024)
                    if current_mb > last_update_mb:
                        last_update_mb = current_mb
                        if file_size:
                            pct = (total_size * 100) // file_size
                            status = f"Downloading: {total_size // (1024*1024)} MB ({pct}%)"
                        else:
                            status = f"Downloading: {total_size // (1024*1024)} MB..."
                        self.root.after(0, lambda s=status: progress_popup.status_var.set(s))
            
            temp_zip.close()
            dl_time = time.time() - dl_start
            
            if total_size < 1000:
                with open(temp_zip_path, 'r', errors='ignore') as f:
                    content = f.read()
                    if 'login' in content.lower() or 'error' in content.lower():
                        os.remove(temp_zip_path)
                        raise Exception("Download failed - server returned login/error page.")
            
            self.log(f"Downloaded {total_size / 1024 / 1024:.1f} MB in {dl_time:.0f}s")
            return temp_zip_path
            
        except requests.exceptions.ConnectionError as e:
            error_str = str(e).lower()
            if 'getaddrinfo failed' in error_str or 'name resolution' in error_str:
                raise Exception("Cannot connect to Confluence.\n\nCheck VPN connection.")
            else:
                raise Exception(f"Connection error: {str(e)[:100]}")
        except requests.exceptions.Timeout:
            raise Exception("Connection timed out.\n\nCheck VPN connection.")
        except requests.exceptions.RequestException as e:
            raise Exception(f"Network error: {str(e)}")
    
    def _show_load_complete_notification(self, controller_num, result_folder, start_str, end_str, elapsed_str):
        """Show a non-blocking notification that a controller loaded successfully.
        Auto-closes after 5 seconds or when clicked."""
        try:
            popup = tk.Toplevel(self.root)
            popup.title(f"C{controller_num} Loaded")
            popup.geometry("300x120")
            popup.resizable(False, False)
            popup.attributes('-topmost', True)
            
            # Position based on controller number (same grid as progress popups)
            screen_width = self.root.winfo_screenwidth()
            popup_w, popup_h = 300, 120
            margin = 10
            
            if controller_num == 1:
                x = screen_width - (popup_w * 2) - margin * 2
                y = 50
            elif controller_num == 2:
                x = screen_width - popup_w - margin
                y = 50
            elif controller_num == 3:
                x = screen_width - (popup_w * 2) - margin * 2
                y = 50 + 150 + margin
            else:  # C4
                x = screen_width - popup_w - margin
                y = 50 + 150 + margin
            
            popup.geometry(f"{popup_w}x{popup_h}+{x}+{y}")
            
            # Green background for success
            frame = tk.Frame(popup, bg='#d4edda', padx=10, pady=10)
            frame.pack(fill=tk.BOTH, expand=True)
            
            tk.Label(frame, text=f"✓ C{controller_num} Loaded", font=('Segoe UI', 11, 'bold'),
                    bg='#d4edda', fg='#155724').pack(pady=(0, 5))
            tk.Label(frame, text=os.path.basename(result_folder), font=('Segoe UI', 9),
                    bg='#d4edda', fg='#155724').pack()
            tk.Label(frame, text=f"Time: {elapsed_str}", font=('Segoe UI', 9),
                    bg='#d4edda', fg='#155724').pack()
            tk.Label(frame, text="(click to close)", font=('Segoe UI', 8),
                    bg='#d4edda', fg='#666').pack(pady=(5, 0))
            
            # Close on click - stop event propagation
            def close_popup(event=None):
                try:
                    popup.destroy()
                except:
                    pass
                return 'break'  # Stop event propagation
            
            popup.bind('<Button-1>', close_popup)
            for child in frame.winfo_children():
                child.bind('<Button-1>', close_popup)
            frame.bind('<Button-1>', close_popup)
            
            # Auto-close after 5 seconds
            popup.after(5000, close_popup)
            
        except Exception as e:
            # If notification fails, just log it
            self.log(f"C{controller_num}: Notification error - {str(e)}")
    
    def _show_error_notification(self, controller_num, error_msg):
        """Show a non-blocking error notification. Auto-closes after 8 seconds or when clicked."""
        try:
            popup = tk.Toplevel(self.root)
            popup.title(f"C{controller_num} Error")
            popup.geometry("320x100")
            popup.resizable(False, False)
            popup.attributes('-topmost', True)
            
            # Position based on controller number
            screen_width = self.root.winfo_screenwidth()
            popup_w, popup_h = 320, 100
            margin = 10
            
            if controller_num == 1:
                x = screen_width - (popup_w * 2) - margin * 2
                y = 50
            elif controller_num == 2:
                x = screen_width - popup_w - margin
                y = 50
            elif controller_num == 3:
                x = screen_width - (popup_w * 2) - margin * 2
                y = 50 + 150 + margin
            else:  # C4
                x = screen_width - popup_w - margin
                y = 50 + 150 + margin
            
            popup.geometry(f"{popup_w}x{popup_h}+{x}+{y}")
            
            # Red background for error
            frame = tk.Frame(popup, bg='#f8d7da', padx=10, pady=10)
            frame.pack(fill=tk.BOTH, expand=True)
            
            tk.Label(frame, text=f"✗ C{controller_num} Error", font=('Segoe UI', 11, 'bold'),
                    bg='#f8d7da', fg='#721c24').pack(pady=(0, 5))
            # Truncate long error messages
            short_msg = error_msg[:60] + "..." if len(error_msg) > 60 else error_msg
            tk.Label(frame, text=short_msg, font=('Segoe UI', 9),
                    bg='#f8d7da', fg='#721c24', wraplength=290).pack()
            tk.Label(frame, text="(click to close)", font=('Segoe UI', 8),
                    bg='#f8d7da', fg='#666').pack(pady=(5, 0))
            
            # Close on click - stop event propagation
            def close_popup(event=None):
                try:
                    popup.destroy()
                except:
                    pass
                return 'break'  # Stop event propagation
            
            popup.bind('<Button-1>', close_popup)
            for child in frame.winfo_children():
                child.bind('<Button-1>', close_popup)
            frame.bind('<Button-1>', close_popup)
            
            # Auto-close after 8 seconds
            popup.after(8000, close_popup)
            
        except Exception as e:
            pass  # If notification fails, just ignore
    
    def _create_progress_popup(self, controller_num, is_url):
        """Create a non-modal progress popup window with timing info."""
        popup = tk.Toplevel(self.root)
        popup.title(f"Loading C{controller_num}")
        popup.geometry("320x150")
        popup.resizable(False, False)
        # Don't use transient - allows interaction with main window
        # Don't use grab_set - keeps it non-modal
        
        # Position in a 2x2 grid on the right side of screen
        popup.update_idletasks()
        screen_width = self.root.winfo_screenwidth()
        screen_height = self.root.winfo_screenheight()
        
        # 2x2 grid positions: C1=top-left, C2=top-right, C3=bottom-left, C4=bottom-right
        popup_w, popup_h = 320, 150
        margin = 10
        
        if controller_num == 1:
            x = screen_width - (popup_w * 2) - margin * 2
            y = 50
        elif controller_num == 2:
            x = screen_width - popup_w - margin
            y = 50
        elif controller_num == 3:
            x = screen_width - (popup_w * 2) - margin * 2
            y = 50 + popup_h + margin
        else:  # C4
            x = screen_width - popup_w - margin
            y = 50 + popup_h + margin
        
        popup.geometry(f"{popup_w}x{popup_h}+{x}+{y}")
        
        # Content
        frame = ttk.Frame(popup, padding="10")
        frame.pack(fill=tk.BOTH, expand=True)
        
        # Title with controller number
        source = "Confluence" if is_url else "Local ZIP"
        ttk.Label(frame, text=f"C{controller_num} - {source}", 
                  font=('Segoe UI', 10, 'bold')).pack(pady=(0, 8))
        
        # Status label
        status_var = tk.StringVar(value="Initializing...")
        status_label = ttk.Label(frame, textvariable=status_var, font=('Segoe UI', 9))
        status_label.pack(pady=2)
        
        # Progress bar
        progress = ttk.Progressbar(frame, mode='indeterminate', length=250)
        progress.pack(pady=6)
        progress.start(10)
        
        # Time info frame
        time_frame = ttk.Frame(frame)
        time_frame.pack(fill=tk.X, pady=10)
        
        start_time = datetime.now()
        start_str = start_time.strftime("%H:%M:%S")
        
        ttk.Label(time_frame, text=f"Started: {start_str}", font=('Segoe UI', 9)).pack(side=tk.LEFT)
        
        elapsed_var = tk.StringVar(value="Elapsed: 00:00:00")
        elapsed_label = ttk.Label(time_frame, textvariable=elapsed_var, font=('Segoe UI', 9))
        elapsed_label.pack(side=tk.RIGHT)
        
        # Update elapsed time every second
        def update_elapsed():
            if popup.winfo_exists():
                elapsed = datetime.now() - start_time
                hours, remainder = divmod(int(elapsed.total_seconds()), 3600)
                minutes, seconds = divmod(remainder, 60)
                elapsed_var.set(f"Elapsed: {hours:02d}:{minutes:02d}:{seconds:02d}")
                popup.after(1000, update_elapsed)
        
        update_elapsed()
        
        # Store references
        popup.status_var = status_var
        popup.start_time = start_time
        popup.progress = progress
        popup.controller_num = controller_num
        
        # Track this popup by controller number
        self.progress_popups[controller_num] = popup
        
        # Handle manual close (X button) - only close this popup
        def on_popup_close():
            try:
                # Remove from tracking dict
                if controller_num in self.progress_popups:
                    del self.progress_popups[controller_num]
                popup.destroy()
            except:
                pass
        
        popup.protocol("WM_DELETE_WINDOW", on_popup_close)
        
        return popup
    
    def _browse_zip(self, controller_num):
        """Browse for a local ZIP file."""
        zip_vars = {1: self.conf_url1, 2: self.conf_url2, 3: self.conf_url3, 4: self.conf_url4}
        
        zip_file = filedialog.askopenfilename(
            title=f"Select LoadRunner Results ZIP (Controller {controller_num})",
            filetypes=[("ZIP Files", "*.zip"), ("All Files", "*.*")]
        )
        if zip_file:
            zip_vars[controller_num].set(zip_file)
            self.log(f"Controller {controller_num}: Selected ZIP file: {os.path.basename(zip_file)}")
    
    def _unzip_to_local(self, controller_num):
        """Extract local ZIP file or download from Confluence URL and extract.
        Runs in background thread to avoid UI freezing."""
        zip_vars = {1: self.conf_url1, 2: self.conf_url2, 3: self.conf_url3, 4: self.conf_url4}
        extracted_vars = {1: self.extracted_path1, 2: self.extracted_path2, 3: self.extracted_path3, 4: self.extracted_path4}
        
        zip_path = zip_vars[controller_num].get().strip()
        
        if not zip_path:
            messagebox.showerror("Error", f"Please enter a ZIP path or Confluence URL for Controller {controller_num}.", parent=self.root)
            return
        
        # Check credentials for Confluence URLs upfront
        is_url = zip_path.startswith('http://') or zip_path.startswith('https://')
        if is_url:
            username = self.confluence_user.get().strip()
            password = self.confluence_token.get().strip()
            
            if not username or not password:
                messagebox.showerror("Credential Error", 
                    "Please Enter Valid MSP Credentials!\n\n"
                    "1. Enter your MSP Username and Password above\n"
                    "2. Click 'Login' button first\n"
                    "3. Check your VPN Connection\n\n"
                    "Then try FetchDetails again.", parent=self.root)
                return
        else:
            # It's a local file path - validate it exists
            if not os.path.isfile(zip_path):
                messagebox.showerror("Error", f"ZIP file does not exist:\n{zip_path}\n\nUse 'Browse' to select a ZIP file.", parent=self.root)
                return
            
            if not zip_path.lower().endswith('.zip'):
                messagebox.showerror("Error", "Please select a valid .zip file.", parent=self.root)
                return
        
        # Create progress popup
        progress_popup = self._create_progress_popup(controller_num, is_url)
        
        # Run download/extract in background thread
        def background_task():
            try:
                local_zip_path = zip_path
                
                # Download from Confluence if URL
                if is_url:
                    self.root.after(0, lambda: progress_popup.status_var.set("Connecting to Confluence..."))
                    self.root.after(0, lambda: self.log(f"C{controller_num}: Downloading from Confluence..."))
                    local_zip_path = self._download_confluence_zip_with_progress(zip_path, progress_popup)
                    self.root.after(0, lambda: self.log(f"C{controller_num}: Download complete"))
                
                # Extract ZIP
                self.root.after(0, lambda: progress_popup.status_var.set("Extracting ZIP file..."))
                self.root.after(0, lambda: self.log(f"C{controller_num}: Extracting ZIP..."))
                
                # Use local extract folder if specified, otherwise use temp
                local_folder = self.local_extract_folder.get().strip()
                if local_folder and os.path.isdir(local_folder):
                    extract_dir = os.path.join(local_folder, f"C{controller_num}_results")
                    if os.path.exists(extract_dir):
                        import shutil
                        shutil.rmtree(extract_dir)
                    os.makedirs(extract_dir, exist_ok=True)
                else:
                    if self.temp_base_dir and os.path.exists(self.temp_base_dir):
                        extract_dir = os.path.join(self.temp_base_dir, f"lrr_c{controller_num}_{os.getpid()}")
                        # IMPORTANT: Clear old contents before re-extracting
                        if os.path.exists(extract_dir):
                            import shutil
                            shutil.rmtree(extract_dir)
                        os.makedirs(extract_dir, exist_ok=True)
                    else:
                        extract_dir = tempfile.mkdtemp(prefix=f"lrr_c{controller_num}_")
                    self.temp_dirs.append(extract_dir)
                
                # Extract the ZIP file - use fast extractall
                with zipfile.ZipFile(local_zip_path, 'r') as zip_ref:
                    zip_contents = zip_ref.namelist()
                    total_files = len(zip_contents)
                    self.root.after(0, lambda: progress_popup.status_var.set(f"Extracting {total_files} files..."))
                    zip_ref.extractall(extract_dir)
                
                # Find the results folder
                self.root.after(0, lambda: progress_popup.status_var.set("Searching for results..."))
                result_folder = self._find_results_folder(extract_dir)
                
                # Calculate completion time
                end_time = datetime.now()
                elapsed = end_time - progress_popup.start_time
                hours, remainder = divmod(int(elapsed.total_seconds()), 3600)
                minutes, seconds = divmod(remainder, 60)
                elapsed_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
                end_str = end_time.strftime("%H:%M:%S")
                
                # Update UI on main thread
                def update_ui():
                    # Close only this controller's progress popup
                    try:
                        if controller_num in self.progress_popups:
                            popup_to_close = self.progress_popups.pop(controller_num)
                            if popup_to_close.winfo_exists():
                                popup_to_close.destroy()
                    except:
                        pass
                    
                    if result_folder:
                        extracted_vars[controller_num].set(result_folder)
                        # Clear cached parser for this controller (new extract = new data)
                        self.cached_parsers = {k: v for k, v in self.cached_parsers.items() if k[0] != controller_num}
                        self.log(f"C{controller_num}: Loaded successfully in {elapsed_str} - {os.path.basename(result_folder)}")
                        
                        # Update VUsers graph for this controller
                        try:
                            self._try_update_graph_for_path(result_folder, ctrl_index=controller_num-1)
                        except Exception as graph_err:
                            self.log(f"C{controller_num}: Graph update error - {str(graph_err)}")
                        
                        # Show non-blocking success notification
                        self._show_load_complete_notification(controller_num, result_folder, 
                            progress_popup.start_time.strftime('%H:%M:%S'), end_str, elapsed_str)
                    else:
                        top_items = []
                        try:
                            for item in os.listdir(extract_dir)[:8]:
                                item_path = os.path.join(extract_dir, item)
                                if os.path.isdir(item_path):
                                    top_items.append(f"[{item}]")
                                else:
                                    top_items.append(item)
                        except:
                            top_items = ['(error listing)']
                        items_str = ', '.join(top_items) if top_items else '(empty)'
                        self.log(f"C{controller_num}: No LoadRunner results found in ZIP - {items_str}")
                        self._show_error_notification(controller_num, "No LoadRunner results found in ZIP")
                
                self.root.after(0, update_ui)
                
            except zipfile.BadZipFile:
                def handle_error():
                    try:
                        if controller_num in self.progress_popups:
                            popup_to_close = self.progress_popups.pop(controller_num)
                            if popup_to_close.winfo_exists():
                                popup_to_close.destroy()
                    except:
                        pass
                    self._show_error_notification(controller_num, "Invalid ZIP file")
                self.root.after(0, handle_error)
                self.root.after(0, lambda: self.log(f"C{controller_num}: Invalid ZIP file"))
            except Exception as e:
                error_msg = str(e)
                def handle_error():
                    try:
                        if controller_num in self.progress_popups:
                            popup_to_close = self.progress_popups.pop(controller_num)
                            if popup_to_close.winfo_exists():
                                popup_to_close.destroy()
                    except:
                        pass
                    if is_url:
                        self._show_error_notification(controller_num, f"Download failed: {error_msg}")
                    else:
                        self._show_error_notification(controller_num, f"Extract failed: {error_msg}")
                self.root.after(0, handle_error)
                self.root.after(0, lambda: self.log(f"C{controller_num}: Error - {error_msg}"))
        
        # Start background thread (don't block main window)
        self.log(f"Starting C{controller_num} load...")
        thread = threading.Thread(target=background_task, daemon=True)
        thread.start()
    
    def _set_status(self, text, color="black"):
        """Set status message (for progress indication)."""
        try:
            # Update the log with status
            self.log(f"[Status] {text}")
        except:
            pass
    
    def _find_results_folder(self, base_folder):
        """Find the folder containing LoadRunner results within extracted ZIP.
        Searches for various markers that indicate LoadRunner results."""
        
        # Marker files that indicate a LoadRunner results folder (case-insensitive)
        file_markers = [
            'sum_dat.ini', 'results.db', 'results.mdb', 'scenario.lrs',
            'results.xml', 'output.mdb', 'results.db3',
            # Analysis session files
            'AnalysisSession.lra', 'Session.lra',
        ]
        # Folder markers
        folder_markers = ['sum_data', 'raw_results', 'Log', 'Event_meter', 'Graphs']
        # File extension markers
        ext_markers = ['.lrr', '.lra', '.lrs', '.db3']
        
        def check_folder(folder):
            """Check if a folder contains LoadRunner results."""
            try:
                items = os.listdir(folder)
                items_lower = [i.lower() for i in items]
            except:
                return None
            
            # Check for marker folders (sum_data is the primary indicator)
            for marker_folder in folder_markers:
                if marker_folder.lower() in items_lower:
                    marker_path = os.path.join(folder, marker_folder)
                    if os.path.isdir(marker_path):
                        return folder
            
            # Check for marker files directly in folder
            for marker in file_markers:
                if marker.lower() in items_lower:
                    return folder
            
            # Check for LoadRunner file extensions
            for item in items:
                item_lower = item.lower()
                for ext in ext_markers:
                    if item_lower.endswith(ext):
                        return folder
            
            # Check inside sum_data subfolder for marker files
            sum_data = os.path.join(folder, 'sum_data')
            if os.path.isdir(sum_data):
                try:
                    sum_items = [f.lower() for f in os.listdir(sum_data)]
                    for marker in file_markers:
                        if marker.lower() in sum_items:
                            return folder
                except:
                    pass
            
            return None
        
        # Check base folder first
        self.log(f"Searching for LoadRunner results...")
        result = check_folder(base_folder)
        if result:
            self.log(f"Found results in base folder")
            return result
        
        # Recursive search with depth limit (fast, no logging per folder)
        def search_recursive(folder, depth=0, max_depth=3):
            if depth > max_depth:
                return None
            try:
                items = os.listdir(folder)
                for item in items:
                    item_path = os.path.join(folder, item)
                    if os.path.isdir(item_path):
                        result = check_folder(item_path)
                        if result:
                            self.log(f"Found results in: {item}")
                            return result
                        # Recurse deeper
                        deeper_result = search_recursive(item_path, depth + 1, max_depth)
                        if deeper_result:
                            return deeper_result
            except PermissionError:
                pass
            return None
        
        result = search_recursive(base_folder)
        if result:
            return result
        
        # Log what we actually found for debugging
        self.log(f"No LoadRunner results found. Detailed contents:")
        try:
            for item in os.listdir(base_folder)[:10]:
                item_path = os.path.join(base_folder, item)
                if os.path.isdir(item_path):
                    self.log(f"  [DIR] {item}")
                    # Show contents of first subfolder
                    try:
                        subitems = os.listdir(item_path)[:8]
                        for subitem in subitems:
                            subpath = os.path.join(item_path, subitem)
                            prefix = "    [DIR]" if os.path.isdir(subpath) else "    [FILE]"
                            self.log(f"{prefix} {subitem}")
                    except:
                        pass
                else:
                    self.log(f"  [FILE] {item}")
        except Exception as e:
            self.log(f"  Error listing: {e}")
        
        return None
    
    def _extracted_test_info(self, controller_num):
        """Show test timing info for the extracted folder."""
        extracted_vars = {1: self.extracted_path1, 2: self.extracted_path2, 3: self.extracted_path3, 4: self.extracted_path4}
        
        extracted_path = extracted_vars[controller_num].get().strip()
        
        if not extracted_path:
            messagebox.showwarning("Warning", f"No extracted folder for Controller {controller_num}.\n\nPaste a ZIP path or Confluence URL and click 'FetchDetails' first.", parent=self.root)
            return
        
        if not os.path.isdir(extracted_path):
            messagebox.showerror("Error", f"Extracted folder no longer exists:\n{extracted_path}", parent=self.root)
            return
        
        self._show_test_info_for_path(extracted_path, controller_num)
    
    def _show_test_info_for_path(self, folder_path, controller_num):
        """Show test timing info for a given folder path."""
        try:
            parser = LRRParser(folder_path)
            parser._parse_lrr_file()
            
            info = parser.scenario_info
            start_time = info.get('start_time', 'N/A')
            stop_time = info.get('stop_time', 'N/A')
            duration = info.get('duration_seconds', 0)
            
            # Get scenario configuration (ramp-up, steady state, ramp-down)
            ramp_up_config = info.get('ramp_up_config', 'N/A')
            steady_state_config = info.get('steady_state_config', 'N/A')
            ramp_down_config = info.get('ramp_down_config', 'N/A')
            
            # Format duration as HH:MM:SS
            if duration and duration != 'N/A':
                hours = int(duration) // 3600
                minutes = (int(duration) % 3600) // 60
                seconds = int(duration) % 60
                duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
            else:
                duration_str = "N/A"
            
            # Check if user selected Relative or Absolute mode
            is_relative = (self.ss_mode.get() == 'relative')
            
            if is_relative:
                # For relative mode, show 00:00:00 as start and duration as end
                start_str = "00:00:00"
                stop_str = duration_str
                start_date = ""
                mode_hint = "Enter relative time from test start"
            else:
                # For absolute mode, show actual wall clock times
                if isinstance(start_time, datetime):
                    start_str = start_time.strftime('%H:%M:%S')
                    start_date = start_time.strftime('%Y-%m-%d')
                else:
                    start_str = str(start_time)
                    start_date = ""
                    
                if isinstance(stop_time, datetime):
                    stop_str = stop_time.strftime('%H:%M:%S')
                else:
                    stop_str = str(stop_time)
                mode_hint = "Enter wall clock time (HH:MM:SS)"
            
            # Log and show simple messagebox with test timing info
            self.log(f"C{controller_num}: Start={start_str}, Stop={stop_str}, Duration={duration_str}")
            mode_text = "RELATIVE" if is_relative else "ABSOLUTE"
            
            # Build scenario config section
            config_section = f"\n--- Scenario Config ---\nRamp-Up: {ramp_up_config}\nSteady State: {steady_state_config}\nRamp-Down: {ramp_down_config}"
            
            if is_relative:
                msg = f"Mode: {mode_text}\n\nStart: {start_str}\nEnd: {stop_str}{config_section}\n\n{mode_hint}"
            else:
                msg = f"Mode: {mode_text}\n\nDate: {start_date}\nStart: {start_str}\nEnd: {stop_str}\nDuration: {duration_str}{config_section}\n\n{mode_hint}"
            
            messagebox.showinfo(f"C{controller_num} Test Info", msg, parent=self.root)
            
        except Exception as e:
            self.log(f"Error loading Controller {controller_num} info: {str(e)}")
            messagebox.showerror("Error", f"Failed to load test info:\n{str(e)}", parent=self.root)
    
    def _confluence_test_info(self, controller_num):
        """Show test timing info for Confluence URL - downloads if needed and shows Info dialog."""
        conf_url_vars = {1: self.conf_url1, 2: self.conf_url2, 3: self.conf_url3, 4: self.conf_url4}
        path_vars = {1: self.input_path1, 2: self.input_path2, 3: self.input_path3, 4: self.input_path4}
        
        # Check if local path is already populated (already downloaded)
        local_path = path_vars[controller_num].get().strip()
        if local_path and os.path.isdir(local_path):
            # Already downloaded, use load_test_info
            self.load_test_info(controller_num)
            return
        
        # Need to download from Confluence first
        url = conf_url_vars[controller_num].get().strip()
        
        if not url:
            messagebox.showerror("Error", f"Please enter Confluence ZIP URL for Controller {controller_num}.", parent=self.root)
            return
        
        if not self._is_confluence_url(url):
            messagebox.showerror("Error", "Invalid Confluence URL!", parent=self.root)
            return
        
        # Download from Confluence (credentials will be validated during download)
        self.log(f"Downloading from Confluence to get test info for Controller {controller_num}...")
        folder = self._download_from_confluence(url, controller_num)
        
        if folder:
            # Set downloaded folder to local path field
            path_vars[controller_num].set(folder)
            # Now show the test info
            self.load_test_info(controller_num)
        else:
            self.log(f"Failed to download from Confluence")

    def _fetch_confluence(self, controller_num):
        """Fetch from Confluence URL and populate the local path field with downloaded folder."""
        conf_url_vars = {1: self.conf_url1, 2: self.conf_url2, 3: self.conf_url3, 4: self.conf_url4}
        path_vars = {1: self.input_path1, 2: self.input_path2, 3: self.input_path3, 4: self.input_path4}
        
        url = conf_url_vars[controller_num].get().strip()
        
        if not url:
            messagebox.showerror("Error", f"Please enter Confluence ZIP URL for Controller {controller_num}.\n\nExample:\nhttp://confluence.incometax.gov.in:9080/confluence/download/attachments/.../result.zip?api=v2", parent=self.root)
            return
        
        if not self._is_confluence_url(url):
            messagebox.showerror("Error", "Invalid Confluence URL!\n\nPlease enter a valid URL starting with http:// or https://\n\nExample:\nhttp://confluence.incometax.gov.in:9080/confluence/download/attachments/.../result.zip?api=v2", parent=self.root)
            return
        
        # Download from Confluence (credentials will be validated during download)
        self.log(f"Fetching from Confluence for Controller {controller_num}...")
        folder = self._download_from_confluence(url, controller_num)
        
        if folder:
            # Set downloaded folder to local path field
            path_vars[controller_num].set(folder)
            # Clear the Confluence URL field to show it's been processed
            conf_url_vars[controller_num].set("")
            self.log(f"Downloaded and extracted to: {folder}")
            # Auto-load test info
            self.load_test_info(controller_num)
            # Update VUsers graph for this controller
            self._try_update_graph_for_path(folder, ctrl_index=controller_num-1)
        else:
            self.log(f"Failed to download from Confluence")
    
    def _fetch_and_populate(self, controller_num):
        """Fetch from Confluence URL and populate the path field with downloaded folder."""
        path_vars = {1: self.input_path1, 2: self.input_path2, 3: self.input_path3, 4: self.input_path4}
        url = path_vars[controller_num].get().strip()
        
        if not url:
            messagebox.showerror("Error", f"Please enter a Confluence ZIP URL for Controller {controller_num}.\n\nExample:\nhttp://confluence.incometax.gov.in:9080/confluence/download/attachments/.../result.zip?api=v2", parent=self.root)
            return
        
        if not self._is_confluence_url(url):
            messagebox.showerror("Error", "The entered path is not a Confluence URL.\n\nFor local folders, use 'Browse' button.\nFor Confluence, paste the ZIP URL and click 'Fetch'.\n\nExample URL:\nhttp://confluence.incometax.gov.in:9080/confluence/download/attachments/.../result.zip?api=v2", parent=self.root)
            return
        
        # Download from Confluence (credentials will be validated during download)
        self.log(f"Fetching from Confluence for Controller {controller_num}...")
        folder = self._download_from_confluence(url, controller_num)
        
        if folder:
            # Replace URL with downloaded folder path
            path_vars[controller_num].set(folder)
            self.log(f"Downloaded to: {folder}")
            # Auto-load test info
            self.load_test_info(controller_num)
            # Update VUsers graph for this controller
            self._try_update_graph_for_path(folder, ctrl_index=controller_num-1)
        else:
            self.log(f"Failed to download from Confluence")
    
    def load_test_info(self, controller_num):
        """Load and display test timing info from controller folder (local or extracted from Confluence)."""
        path_vars = {1: self.input_path1, 2: self.input_path2, 3: self.input_path3, 4: self.input_path4}
        extracted_vars = {1: self.extracted_path1, 2: self.extracted_path2, 3: self.extracted_path3, 4: self.extracted_path4}
        
        # Check extracted path first (from Confluence), then local path
        source = extracted_vars[controller_num].get().strip()
        if not source:
            source = path_vars[controller_num].get().strip()
        
        if not source:
            messagebox.showwarning("Warning", f"No data for Controller {controller_num}.\n\nEither:\n- Use 'Browse' to select a folder\n- Or paste Confluence URL and click 'FetchDetails'", parent=self.root)
            return
        
        try:
            folder = source
            
            # Check if it's a ZIP file reference - tell user to unzip first
            if source.lower().endswith('.zip'):
                messagebox.showerror("Error", 
                    f"The path contains a ZIP file.\n\n"
                    "Click 'FetchDetails' to extract the ZIP first.", parent=self.root)
                return
            
            # Check if folder exists
            if not os.path.isdir(source):
                messagebox.showerror("Error", f"Folder does not exist:\n{source}", parent=self.root)
                return
            
            # Use cached parser if available (much faster for repeated Info clicks)
            cache_key = (controller_num, folder)
            if cache_key in self.cached_parsers:
                parser = self.cached_parsers[cache_key]
                debug_print(f"Using cached parser for C{controller_num}")
            else:
                parser = LRRParser(folder)
                parser._parse_lrr_file()  # Get scenario info
                parser.parse()  # Parse full data including VUsers
                self.cached_parsers[cache_key] = parser
                debug_print(f"Created and cached parser for C{controller_num}")
            
            info = parser.scenario_info
            start_time = info.get('start_time', 'N/A')
            stop_time = info.get('stop_time', 'N/A')
            duration = info.get('duration_seconds', 0)
            
            # Get ramp timing info from parser
            ramp_up_sec = getattr(parser, 'ramp_up_seconds', 0)
            ramp_down_sec = getattr(parser, 'ramp_down_seconds', 0)
            ss_duration_sec = getattr(parser, 'steady_state_duration', 0)
            ss_from_rel_sec = getattr(parser, 'steady_state_from_rel', 0)
            ss_to_rel_sec = getattr(parser, 'steady_state_to_rel', 0)
            
            # Format duration as HH:MM:SS
            if duration and duration != 'N/A':
                hours = int(duration) // 3600
                minutes = (int(duration) % 3600) // 60
                seconds = int(duration) % 60
                duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
            else:
                duration_str = "N/A"
            
            # Check if user selected Relative or Absolute mode
            is_relative = (self.ss_mode.get() == 'relative')
            
            if is_relative:
                # For relative mode, show 00:00:00 as start and duration as end
                start_str = "00:00:00"
                stop_str = duration_str
                start_date = ""
                mode_hint = "Enter relative time from test start"
            else:
                # For absolute mode, show actual wall clock times
                if isinstance(start_time, datetime):
                    start_str = start_time.strftime('%H:%M:%S')
                    start_date = start_time.strftime('%Y-%m-%d')
                else:
                    start_str = str(start_time)
                    start_date = ""
                    
                if isinstance(stop_time, datetime):
                    stop_str = stop_time.strftime('%H:%M:%S')
                else:
                    stop_str = str(stop_time)
                mode_hint = "Enter wall clock time (HH:MM:SS)"
            
            # Log info
            self.log(f"C{controller_num}: Start={start_str}, Stop={stop_str}, Duration={duration_str}")
            
            # Get max VUsers info - first try graph data, then fallback to parser
            ctrl_index = controller_num - 1
            data_y = self.graph_data_y[ctrl_index] if ctrl_index < len(self.graph_data_y) else []
            data_x = self.graph_data_x[ctrl_index] if ctrl_index < len(self.graph_data_x) else []
            
            # If graph data not available, get it from parser directly
            if not data_y or len(data_y) == 0:
                all_vusers = getattr(parser, 'all_running_vusers', None)
                running_vusers = getattr(parser, 'running_vusers', None)
                all_timestamps = getattr(parser, 'all_vuser_timestamps', None)
                
                vusers_data = all_vusers if all_vusers else running_vusers
                if vusers_data and len(vusers_data) > 0:
                    raw_y = [float(v) for v in vusers_data]
                    if all_timestamps and len(all_timestamps) == len(vusers_data):
                        start_ts = min(all_timestamps)
                        raw_x = [(t - start_ts) / 60.0 for t in all_timestamps]
                    else:
                        raw_x = [i * 5 / 60.0 for i in range(len(vusers_data))]
                    
                    # AGGREGATE: For duplicate timestamps, take MAX value and sort
                    time_to_max = {}
                    for x, y in zip(raw_x, raw_y):
                        if x not in time_to_max:
                            time_to_max[x] = y
                        else:
                            time_to_max[x] = max(time_to_max[x], y)
                    sorted_times = sorted(time_to_max.keys())
                    data_x = sorted_times
                    data_y = [time_to_max[t] for t in sorted_times]
            
            # Get SS times for this controller
            ss_from_vars = [self.ss_from1, self.ss_from2, self.ss_from3, self.ss_from4]
            ss_to_vars = [self.ss_to1, self.ss_to2, self.ss_to3, self.ss_to4]
            ss_from_val = ss_from_vars[ctrl_index].get().strip()
            ss_to_val = ss_to_vars[ctrl_index].get().strip()
            
            max_vusers_info = ""
            ss_vusers_info = ""
            
            if data_y and len(data_y) > 0:
                max_v = int(max(data_y))
                avg_v = int(sum(data_y) / len(data_y))
                
                # Max Period: First time VUsers reaches max to first time it drops
                first_max_idx = None
                drop_from_max_idx = None
                
                for i, y in enumerate(data_y):
                    if int(y) == max_v:
                        if first_max_idx is None:
                            first_max_idx = i
                    elif first_max_idx is not None and drop_from_max_idx is None:
                        # First drop after reaching max
                        drop_from_max_idx = i - 1  # Last point at max
                        break
                
                # If never dropped, use last point
                if first_max_idx is not None and drop_from_max_idx is None:
                    drop_from_max_idx = len(data_y) - 1
                
                if first_max_idx is not None and drop_from_max_idx is not None and first_max_idx < len(data_x) and drop_from_max_idx < len(data_x):
                    max_start_min = data_x[first_max_idx]
                    max_end_min = data_x[drop_from_max_idx]
                    max_dur = max_end_min - max_start_min
                    
                    if is_relative:
                        # Convert minutes to HH:MM:SS format
                        total_secs1 = int(max_start_min * 60)
                        h1 = total_secs1 // 3600
                        m1 = (total_secs1 % 3600) // 60
                        s1 = total_secs1 % 60
                        
                        total_secs2 = int(max_end_min * 60)
                        h2 = total_secs2 // 3600
                        m2 = (total_secs2 % 3600) // 60
                        s2 = total_secs2 % 60
                        
                        max_vusers_info = f"\n\nMax VUsers: {max_v} ({avg_v} avg)\nMax Period: {h1:02d}:{m1:02d}:{s1:02d} to {h2:02d}:{m2:02d}:{s2:02d} ({max_dur:.1f} min)"
                    else:
                        # Convert to absolute time
                        if isinstance(start_time, datetime):
                            from datetime import timedelta
                            abs_start = start_time + timedelta(minutes=max_start_min)
                            abs_end = start_time + timedelta(minutes=max_end_min)
                            max_vusers_info = f"\n\nMax VUsers: {max_v} ({avg_v} avg)\nMax Period: {abs_start.strftime('%H:%M:%S')} to {abs_end.strftime('%H:%M:%S')} ({max_dur:.1f} min)"
                        else:
                            max_vusers_info = f"\n\nMax VUsers: {max_v} ({avg_v} avg)"
                else:
                    max_vusers_info = f"\n\nMax VUsers: {max_v} ({avg_v} avg)"
                
                # Calculate SS max VUsers if SS times are set
                if ss_from_val and ss_to_val and data_x:
                    try:
                        from lrr_parser import parse_time
                        from_secs = parse_time(ss_from_val)
                        to_secs = parse_time(ss_to_val)
                        
                        # Convert SS times to relative minutes for filtering
                        if not is_relative and isinstance(start_time, datetime):
                            # Absolute mode - convert wall clock to relative
                            test_start_secs = start_time.hour * 3600 + start_time.minute * 60 + start_time.second
                            ss_from_min = (from_secs - test_start_secs) / 60.0
                            ss_to_min = (to_secs - test_start_secs) / 60.0
                        else:
                            # Relative mode - already in seconds from test start
                            ss_from_min = from_secs / 60.0
                            ss_to_min = to_secs / 60.0
                        
                        # Filter data to SS period
                        ss_y = []
                        for x, y in zip(data_x, data_y):
                            if ss_from_min <= x <= ss_to_min:
                                ss_y.append(y)
                        
                        if ss_y:
                            ss_max = int(max(ss_y))
                            ss_avg = int(sum(ss_y) / len(ss_y))
                            ss_dur = ss_to_min - ss_from_min
                            ss_vusers_info = f"\n\n--- Steady State ---\nSS Period: {ss_from_val} to {ss_to_val} ({ss_dur:.1f} min)\nSS Max VUsers: {ss_max}\nSS Avg VUsers: {ss_avg}"
                    except Exception as e:
                        self.log(f"SS calc error: {e}")
            
            # Build ramp timing info from ACTUAL data (scenario config calculation is unreliable)
            ramp_info_str = ""
            ramp_up_config = info.get('ramp_up_config', 'N/A')
            ramp_down_config = info.get('ramp_down_config', 'N/A')
            ss_config = info.get('steady_state_config', 'N/A')
            
            if ramp_up_config != 'N/A' or ss_config != 'N/A':
                ramp_info_str = "\n\n--- Scenario Config ---"
                ramp_info_str += f"\nRamp-Up: {ramp_up_config}"
                ramp_info_str += f"\nSteady State: {ss_config}"
                ramp_info_str += f"\nRamp-Down: {ramp_down_config}"
            
            # Show simple messagebox with test timing info
            mode_text = "RELATIVE" if is_relative else "ABSOLUTE"
            if is_relative:
                msg = f"Mode: {mode_text}\n\nStart: {start_str}\nEnd: {stop_str}{max_vusers_info}{ss_vusers_info}{ramp_info_str}\n\n{mode_hint}"
            else:
                msg = f"Mode: {mode_text}\n\nDate: {start_date}\nStart: {start_str}\nEnd: {stop_str}\nDuration: {duration_str}{max_vusers_info}{ss_vusers_info}{ramp_info_str}\n\n{mode_hint}"
            
            messagebox.showinfo(f"C{controller_num} Test Info", msg, parent=self.root)
            
        except Exception as e:
            self.log(f"Error loading Controller {controller_num} info: {str(e)}")
            messagebox.showerror("Error", f"Failed to load test info:\n{str(e)}", parent=self.root)
    
    def browse_input(self, controller_num):
        """Browse for input folder."""
        folder = filedialog.askdirectory(title=f"Select LoadRunner Results Folder (Controller {controller_num})")
        if folder:
            # Clear any cached parser for this controller (new folder = new data)
            self.cached_parsers = {k: v for k, v in self.cached_parsers.items() if k[0] != controller_num}
            
            if controller_num == 1:
                self.input_path1.set(folder)
            elif controller_num == 2:
                self.input_path2.set(folder)
            elif controller_num == 3:
                self.input_path3.set(folder)
            elif controller_num == 4:
                self.input_path4.set(folder)
            self.log(f"Selected Controller {controller_num}: {folder}")
            # Auto-load test info after selecting folder
            self.load_test_info(controller_num)
            # Update VUsers graph for this controller
            self._try_update_graph_for_path(folder, ctrl_index=controller_num-1)
    
    def browse_output(self):
        """Browse for output folder."""
        folder = filedialog.askdirectory(title="Select Output Folder")
        if folder:
            self.output_path.set(folder)
            self.log(f"Selected output: {folder}")
    
    def _on_report_type_change(self):
        """Handle when All Reports radio button is selected."""
        if self.report_type.get() == 'all':
            # Clear all checkboxes when All Reports is selected
            self.report_trans_summary.set(False)
            self.report_tps.set(False)
            self.report_tps_main.set(False)
            self.report_errors.set(False)
    
    def _on_checkbox_change(self):
        """Handle when any individual report checkbox is changed."""
        # If any checkbox is selected, deselect All Reports
        if (self.report_trans_summary.get() or self.report_tps.get() or 
            self.report_tps_main.get() or self.report_errors.get()):
            self.report_type.set('')  # Deselect All Reports radio
        else:
            # If no checkboxes selected, re-select All Reports
            self.report_type.set('all')
    
    def _get_selected_report_types(self):
        """Get list of selected report types."""
        if self.report_type.get() == 'all':
            return ['all']
        
        selected = []
        if self.report_trans_summary.get():
            selected.append('transaction_summary')
        if self.report_tps.get():
            selected.append('tps')
        if self.report_tps_main.get():
            selected.append('tps_main')
        if self.report_errors.get():
            selected.append('errors')
        
        return selected if selected else ['all']  # Default to all if nothing selected
    
    def _browse_script_folder(self):
        """Browse for parent folder containing LoadRunner scripts."""
        folder = filedialog.askdirectory(title="Select Scripts Parent Folder (containing all script subfolders)")
        if folder:
            # Append to existing paths (separated by ;)
            existing = self.script_folder.get().strip()
            if existing:
                self.script_folder.set(f"{existing}; {folder}")
            else:
                self.script_folder.set(folder)
            # Count Action.c files in the folder
            action_c_count = 0
            for root, dirs, files in os.walk(folder):
                for f in files:
                    if f.lower() == 'action.c':
                        action_c_count += 1
            if action_c_count > 0:
                self.log(f"Added scripts folder: {folder}")
                self.log(f"  Found {action_c_count} Action.c file(s)")
            else:
                self.log(f"Added scripts folder: {folder}")
                self.log(f"  WARNING: No Action.c files found in this folder or subfolders")
    
    def _extract_nested_zips(self, folder_path):
        """Extract any nested ZIP files found within a folder (ZIP of ZIPs support).
        
        Recursively extracts .zip files found in the folder, creating subfolders
        for each extracted ZIP content.
        """
        try:
            for root, dirs, files in os.walk(folder_path):
                for f in files:
                    if f.lower().endswith('.zip'):
                        zip_path = os.path.join(root, f)
                        # Extract to a folder with same name as ZIP (without .zip extension)
                        extract_dir = os.path.join(root, f[:-4])
                        try:
                            with zipfile.ZipFile(zip_path, 'r') as zf:
                                zf.extractall(extract_dir)
                            self.log(f"    Extracted nested ZIP: {f}")
                            # Remove the nested ZIP after extraction
                            os.remove(zip_path)
                            # Recursively check for more nested ZIPs
                            self._extract_nested_zips(extract_dir)
                        except zipfile.BadZipFile:
                            self.log(f"    WARNING: Invalid nested ZIP: {f}")
                        except Exception as e:
                            self.log(f"    WARNING: Could not extract {f}: {e}")
        except Exception as e:
            self.log(f"  WARNING: Error during nested ZIP extraction: {e}")
    
    def _browse_script_zip(self):
        """Browse for ZIP file containing LoadRunner scripts."""
        zip_path = filedialog.askopenfilename(
            title="Select Scripts ZIP File",
            filetypes=[("ZIP files", "*.zip"), ("All files", "*.*")]
        )
        if zip_path:
            # Check ZIP size
            try:
                zip_size_mb = os.path.getsize(zip_path) / (1024 * 1024)
            except:
                zip_size_mb = 0
            
            self.log(f"Added scripts ZIP: {os.path.basename(zip_path)} ({zip_size_mb:.1f} MB)")
            
            # Just add the path - NO extraction needed!
            # We read directly from ZIP during report generation (fast!)
            existing = self.script_folder.get().strip()
            if existing:
                self.script_folder.set(f"{existing}; {zip_path}")
            else:
                self.script_folder.set(zip_path)
            
            # Quick count of .c files in ZIP
            try:
                with zipfile.ZipFile(zip_path, 'r') as zf:
                    c_file_count = sum(1 for n in zf.namelist() if n.lower().endswith('.c'))
                    action_c_count = sum(1 for n in zf.namelist() if n.lower().endswith('action.c'))
                    self.log(f"  Contains {c_file_count} .c files ({action_c_count} Action.c)")
                    self.log(f"  Will read directly from ZIP (no extraction)")
            except Exception as e:
                self.log(f"  WARNING: Could not read ZIP: {e}")
    
    def _extract_zip_with_progress(self, zip_path):
        """Extract a large ZIP file with a progress dialog."""
        # Create progress window
        progress_win = tk.Toplevel(self.root)
        progress_win.title("Extracting Scripts")
        progress_win.geometry("400x150")
        progress_win.transient(self.root)
        progress_win.grab_set()
        
        # Center the window
        progress_win.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - 400) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 150) // 2
        progress_win.geometry(f"+{x}+{y}")
        
        # Add widgets
        ttk.Label(progress_win, text=f"Extracting: {os.path.basename(zip_path)}", 
                  font=('Segoe UI', 10, 'bold')).pack(pady=(20, 10))
        
        progress_var = tk.DoubleVar(value=0)
        progress_bar = ttk.Progressbar(progress_win, variable=progress_var, 
                                        maximum=100, length=350)
        progress_bar.pack(pady=10, padx=20)
        
        status_var = tk.StringVar(value="Starting extraction...")
        status_label = ttk.Label(progress_win, textvariable=status_var)
        status_label.pack(pady=10)
        
        # Shared state for thread communication
        extraction_state = {
            'completed': False,
            'error': None,
            'extracted_path': None,
            'progress': 0,
            'status': 'Starting...'
        }
        
        def extract_in_thread():
            try:
                script_temp_dir = tempfile.mkdtemp(prefix='lrr_scripts_')
                self.temp_dirs.append(script_temp_dir)
                
                with zipfile.ZipFile(zip_path, 'r') as zf:
                    file_list = zf.namelist()
                    total_files = len(file_list)
                    
                    for i, file_name in enumerate(file_list):
                        zf.extract(file_name, script_temp_dir)
                        
                        # Update progress
                        progress = int((i + 1) * 100 / total_files)
                        extraction_state['progress'] = progress
                        extraction_state['status'] = f"Extracting: {i + 1}/{total_files} files ({progress}%)"
                
                # Count Action.c files
                action_c_count = 0
                for root, dirs, files in os.walk(script_temp_dir):
                    for f in files:
                        if f.lower() == 'action.c':
                            action_c_count += 1
                
                extraction_state['extracted_path'] = script_temp_dir
                extraction_state['action_c_count'] = action_c_count
                extraction_state['completed'] = True
                
            except Exception as e:
                extraction_state['error'] = str(e)
                extraction_state['completed'] = True
        
        def check_progress():
            # Update UI from main thread
            progress_var.set(extraction_state['progress'])
            status_var.set(extraction_state['status'])
            
            if extraction_state['completed']:
                progress_win.destroy()
                
                if extraction_state['error']:
                    self.log(f"  ERROR extracting ZIP: {extraction_state['error']}")
                    messagebox.showerror("Extraction Failed", 
                                        f"Failed to extract ZIP:\n{extraction_state['error']}", parent=self.root)
                else:
                    extracted_path = extraction_state['extracted_path']
                    action_c_count = extraction_state.get('action_c_count', 0)
                    
                    # Add extracted folder path
                    existing = self.script_folder.get().strip()
                    if existing:
                        self.script_folder.set(f"{existing}; {extracted_path}")
                    else:
                        self.script_folder.set(extracted_path)
                    
                    self.log(f"  Extraction complete!")
                    self.log(f"  Found {action_c_count} Action.c file(s)")
            else:
                # Check again in 100ms
                self.root.after(100, check_progress)
        
        # Start extraction thread
        thread = threading.Thread(target=extract_in_thread, daemon=True)
        thread.start()
        
        # Start checking progress
        self.root.after(100, check_progress)
    
    def _add_script_from_confluence(self):
        """Add Script ZIP from Confluence URL."""
        # Validate credentials first
        username = self.confluence_user.get().strip()
        token = self.confluence_token.get().strip()
        
        if not username or not token:
            messagebox.showerror("Credentials Required", 
                "Please enter Confluence credentials (Username and Password) at the top of the app first.", parent=self.root)
            return
        
        # Prompt for Confluence URL
        url = simpledialog.askstring("Confluence Script ZIP", 
            "Enter Confluence URL for Script ZIP file:\n\n"
            "Examples:\n"
            "• http://confluence.../download/attachments/.../Scripts.zip\n"
            "• http://confluence.../display/SPACE/PAGE/Scripts.zip",
            parent=self.root)
        
        if not url or not url.strip():
            return
        
        url = url.strip()
        
        if not (url.startswith('http://') or url.startswith('https://')):
            messagebox.showerror("Invalid URL", "Please enter a valid Confluence URL starting with http:// or https://", parent=self.root)
            return
        
        self.log(f"Downloading scripts from Confluence: {url}")
        
        # Download using existing confluence download method
        # Use controller_num=99 to create a separate temp folder for scripts
        extracted_folder = self._download_from_confluence(url, 99)
        
        if extracted_folder and os.path.exists(extracted_folder):
            # Count Action.c files
            action_c_count = 0
            for root, dirs, files in os.walk(extracted_folder):
                for f in files:
                    if f.lower() == 'action.c':
                        action_c_count += 1
            
            # Append to existing paths
            existing = self.script_folder.get().strip()
            if existing:
                self.script_folder.set(f"{existing}; {extracted_folder}")
            else:
                self.script_folder.set(extracted_folder)
            
            self.log(f"  Downloaded and extracted scripts")
            self.log(f"  Found {action_c_count} Action.c file(s)")
        else:
            messagebox.showerror("Download Failed", 
                "Failed to download scripts from Confluence.\n\n"
                "Please check:\n"
                "• Confluence credentials are correct\n"
                "• URL is valid and accessible\n"
                "• You have permission to access the attachment", parent=self.root)
    
    def _is_confluence_url(self, path):
        """Check if the path is a Confluence URL."""
        if not path:
            return False
        path = path.strip()
        return path.startswith('http://') or path.startswith('https://')
    
    def _download_from_confluence(self, confluence_url, controller_num):
        """Download ZIP file from Confluence.
        
        Handles multiple URL formats:
        1. Direct download: http://confluence.../download/attachments/12345/file.zip
        2. Page with filename: http://confluence.../display/SPACE/PAGE/file.zip
        3. Page URL: http://confluence.../display/SPACE/PAGE
        
        Returns path to extracted folder, or None on failure.
        """
        if not REQUESTS_AVAILABLE:
            self.log("ERROR: requests library not installed.")
            messagebox.showerror("Error", "requests library not installed.\nInstall with: pip install requests", parent=self.root)
            return None
        
        username = self.confluence_user.get().strip()
        token = self.confluence_token.get().strip()
        
        if not username or not token:
            messagebox.showerror("Error", "Please enter Confluence credentials (Username and Password).", parent=self.root)
            return None
        
        self.log(f"Downloading from Confluence: {confluence_url}")
        
        try:
            # Create temp directory on D: drive (more space)
            if self.temp_base_dir and os.path.exists(self.temp_base_dir):
                temp_dir = os.path.join(self.temp_base_dir, f"lrr_c{controller_num}_{os.getpid()}")
                # IMPORTANT: Clear old contents before re-downloading
                if os.path.exists(temp_dir):
                    import shutil
                    shutil.rmtree(temp_dir)
                os.makedirs(temp_dir, exist_ok=True)
            else:
                temp_dir = tempfile.mkdtemp(prefix=f"lrr_c{controller_num}_")
            self.temp_dirs.append(temp_dir)
            
            # Parse URL
            parsed = urlparse(confluence_url)
            base_url = f"{parsed.scheme}://{parsed.netloc}"
            
            # Detect context path (e.g., /confluence, /wiki)
            path_parts = parsed.path.split('/')
            context_path = ""
            for part in path_parts:
                if part in ['confluence', 'wiki']:
                    context_path = '/' + part
                    break
            
            # Create session with authentication
            # PREFER existing confluence_session (has form-based login cookies)
            if self.confluence_session:
                self.log("  Using existing Confluence session")
                session = self.confluence_session
            else:
                session = requests.Session()
                # Try NTLM auth first if available (common in corporate Windows environments)
                if NTLM_AVAILABLE:
                    self.log("  Using NTLM authentication")
                    session.auth = HttpNtlmAuth(username, token)
                else:
                    self.log("  Using Basic authentication")
                    session.auth = (username, token)
            
            import urllib3
            urllib3.disable_warnings(urllib3.exceptions.InsecureRequestWarning)
            
            url_lower = confluence_url.lower()
            
            # CASE 1: Direct download URL (contains /download/attachments/)
            if '/download/attachments/' in url_lower:
                self.log("  Direct download URL detected")
                return self._download_attachment(session, confluence_url, temp_dir)
            
            # CASE 2: URL ends with .zip - likely a page URL with filename appended
            # Example: /display/SPACE/PAGE_TITLE/filename.zip
            if url_lower.endswith('.zip'):
                self.log("  URL ends with .zip - parsing for page and filename")
                
                # Extract filename from URL
                url_path = parsed.path
                filename = url_path.rsplit('/', 1)[-1]  # Get last part (filename.zip)
                
                # Construct the page URL (without filename)
                page_path = url_path.rsplit('/', 1)[0]  # Remove filename
                page_url = f"{base_url}{page_path}"
                
                self.log(f"  Filename to find: {filename}")
                self.log(f"  Page URL: {page_url}")
                
                # Fetch the page HTML and look for the attachment link
                result = self._find_attachment_in_page(session, page_url, base_url, filename, temp_dir)
                if result:
                    return result
                
                # If that fails, try the full URL as a direct download (some servers may redirect)
                self.log("  Trying URL as direct download...")
                try:
                    result = self._download_attachment(session, confluence_url, temp_dir)
                    if result:
                        return result
                except:
                    pass
            
            # CASE 3: Just a page URL - look for any .zip attachments
            if '/display/' in url_lower:
                self.log("  Page URL detected - will look for attachments")
                result = self._find_attachment_in_page(session, confluence_url, base_url, None, temp_dir)
                if result:
                    return result
            
            # All approaches failed
            self.log("  ERROR: Could not download file from Confluence")
            messagebox.showerror("Error", 
                "Could not download from Confluence.\n\n"
                "Please use the direct attachment download URL:\n"
                "1. Open Confluence page in browser\n"
                "2. Right-click on the ZIP file\n"
                "3. Select 'Copy link address'\n"
                "4. Paste that URL here\n\n"
                "Expected format:\n"
                "http://confluence.../download/attachments/12345/file.zip", parent=self.root)
            return None
            
        except requests.exceptions.RequestException as e:
            self.log(f"ERROR: Network error: {str(e)}")
            messagebox.showerror("Error", f"Failed to connect to Confluence:\n{str(e)}", parent=self.root)
            return None
        except Exception as e:
            self.log(f"ERROR: {str(e)}")
            messagebox.showerror("Error", f"Failed to download:\n{str(e)}", parent=self.root)
            return None
    
    def _find_attachment_in_page(self, session, page_url, base_url, target_filename, temp_dir):
        """Fetch a Confluence page and look for attachment download links.
        
        Args:
            session: requests Session with auth
            page_url: URL of the Confluence page
            base_url: Base URL (scheme + host)
            target_filename: Specific filename to find, or None to find any .zip
            temp_dir: Temp directory to extract to
            
        Returns: Extracted folder path, or None
        """
        self.log(f"  Fetching page: {page_url}")
        
        try:
            # Add headers to mimic browser request
            headers = {
                'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36',
                'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            }
            resp = session.get(page_url, verify=False, timeout=120, headers=headers)
            self.log(f"  Page status: {resp.status_code}")
            
            if resp.status_code == 401:
                self.log("  Authentication failed - check username/password")
                messagebox.showerror("Error", "Authentication failed.\n\nPlease check your Username and Password.", parent=self.root)
                return None
            
            if resp.status_code == 403:
                self.log("  Access forbidden - you may not have permission")
                messagebox.showerror("Error", "Access forbidden.\n\nYou may not have permission to access this page.", parent=self.root)
                return None
                
            if resp.status_code != 200:
                self.log(f"  Failed to fetch page: HTTP {resp.status_code}")
                return None
            
            html_content = resp.text
            self.log(f"  HTML length: {len(html_content)} chars")
            
            # Check if we got a login page instead of the actual content
            html_lower = html_content.lower()
            if 'login' in html_lower and ('password' in html_lower or 'username' in html_lower):
                if 'os_username' in html_lower or 'os_password' in html_lower:
                    self.log("  WARNING: Got login page - credentials not accepted")
                    self.log("  Try using your network/Windows password")
                    messagebox.showerror("Error", 
                        "Got login page instead of content.\n\n"
                        "Your credentials were not accepted.\n"
                        "Try using your network/Windows password.", parent=self.root)
                    return None
            
            # Look for download links - multiple patterns
            all_zip_links = []
            
            # Pattern 1: /download/attachments/ID/filename.zip
            pattern1 = re.findall(
                r'href=["\']([^"\']*download/attachments/[^"\']*\.zip[^"\']*)["\']',
                html_content, re.IGNORECASE
            )
            all_zip_links.extend(pattern1)
            
            # Pattern 2: /plugins/servlet/attachments/download/ID
            pattern2 = re.findall(
                r'href=["\']([^"\']*servlet/attachments[^"\']*\.zip[^"\']*)["\']',
                html_content, re.IGNORECASE
            )
            all_zip_links.extend(pattern2)
            
            # Pattern 3: Any href ending with .zip
            pattern3 = re.findall(
                r'href=["\']([^"\']+\.zip(?:\?[^"\']*)?)["\']',
                html_content, re.IGNORECASE
            )
            # Filter to only include attachment-like URLs
            for link in pattern3:
                if 'attachment' in link.lower() or 'download' in link.lower():
                    if link not in all_zip_links:
                        all_zip_links.append(link)
            
            self.log(f"  Found {len(all_zip_links)} ZIP link(s)")
            
            if not all_zip_links:
                self.log("  No ZIP attachment links found in page HTML")
                # Show first 500 chars of HTML for debugging
                self.log(f"  HTML preview: {html_content[:500]}...")
                return None
            
            # Log found links
            for i, link in enumerate(all_zip_links[:5]):
                self.log(f"    [{i+1}] {link[:80]}...")
            
            # If we have a target filename, look for it
            if target_filename:
                target_base = target_filename.lower().replace('.zip', '')
                self.log(f"  Searching for: {target_filename}")
                
                for link in all_zip_links:
                    link_lower = link.lower()
                    if target_filename.lower() in link_lower or target_base in link_lower:
                        download_url = link if link.startswith('http') else base_url + link
                        self.log(f"  Found matching link: {download_url}")
                        return self._download_attachment(session, download_url, temp_dir)
                
                self.log(f"  No exact match for '{target_filename}'")
            
            # Use first ZIP link found
            first_link = all_zip_links[0]
            download_url = first_link if first_link.startswith('http') else base_url + first_link
            self.log(f"  Using first ZIP found: {download_url}")
            return self._download_attachment(session, download_url, temp_dir)
            
        except Exception as e:
            self.log(f"  Error fetching page: {e}")
            return None
    
    def _download_attachment(self, session, url, temp_dir):
        """Download a single attachment and extract if zip.
        
        Handles URLs like:
        http://confluence.incometax.gov.in:9080/confluence/download/attachments/249102393/RUN65_ITR_80PER_C122_Mixload_11032026_HTML.zip?api=v2
        
        Returns the extracted folder path, or None if download fails.
        """
        self.log(f"  Downloading from: {url}")
        
        try:
            response = session.get(url, stream=True, verify=False, timeout=120)
            response.raise_for_status()
        except requests.exceptions.HTTPError as e:
            self.log(f"  HTTP Error: {e}")
            if e.response.status_code == 404:
                self.log("  File not found (404)")
            raise  # Re-raise so caller can handle
        except Exception as e:
            self.log(f"  Download error: {e}")
            raise
        
        # Get filename from content-disposition header first
        filename = None
        if 'content-disposition' in response.headers:
            cd = response.headers['content-disposition']
            match = re.search(r'filename[*]?=["\']?(?:UTF-8\'\')?([^"\';\n]+)', cd, re.IGNORECASE)
            if match:
                filename = match.group(1).strip()
        
        # Fallback: extract from URL path (ignore query params)
        if not filename:
            url_path = urlparse(url).path
            filename = os.path.basename(url_path)
            # Remove any remaining query params if present
            if '?' in filename:
                filename = filename.split('?')[0]
        
        if not filename or filename == '':
            filename = "attachment.zip"
        
        self.log(f"  Filename: {filename}")
        
        filepath = os.path.join(temp_dir, filename)
        
        # Download file with progress
        total_size = int(response.headers.get('content-length', 0))
        downloaded = 0
        
        with open(filepath, 'wb') as f:
            for chunk in response.iter_content(chunk_size=8192):
                f.write(chunk)
                downloaded += len(chunk)
        
        file_size_mb = downloaded / (1024 * 1024)
        self.log(f"  Downloaded: {filename} ({file_size_mb:.1f} MB)")
        
        # If it's a zip file, extract it
        if filename.lower().endswith('.zip'):
            self.log("  Extracting zip file...")
            extract_dir = os.path.join(temp_dir, 'extracted')
            
            try:
                with zipfile.ZipFile(filepath, 'r') as zf:
                    zf.extractall(extract_dir)
                self.log(f"  Extracted to: {extract_dir}")
            except zipfile.BadZipFile:
                self.log("  ERROR: Invalid or corrupted zip file")
                # Check if it's actually an HTML page (login redirect)
                try:
                    with open(filepath, 'r', encoding='utf-8', errors='ignore') as f:
                        content_start = f.read(500)
                    if '<html' in content_start.lower() or '<!doctype' in content_start.lower():
                        self.log("  Downloaded file is HTML (likely login page). Session may have expired.")
                        messagebox.showerror("Error", 
                            "Downloaded file is not a ZIP - got HTML page instead.\n\n"
                            "Your session may have expired. Please:\n"
                            "1. Click Login again to refresh session\n"
                            "2. Then click FetchDetails or Generate Report", parent=self.root)
                    else:
                        messagebox.showerror("Error", "Downloaded file is not a valid ZIP file or is corrupted.", parent=self.root)
                except:
                    messagebox.showerror("Error", "Downloaded file is not a valid ZIP file or is corrupted.", parent=self.root)
                return None
            
            # Find the folder with .lrr file (search recursively)
            lrr_found = None
            for root, dirs, files in os.walk(extract_dir):
                for f in files:
                    if f.lower().endswith('.lrr'):
                        lrr_found = os.path.join(root, f)
                        self.log(f"  Found .lrr file: {f}")
                        self.log(f"  LRR folder: {root}")
                        return root
            
            if not lrr_found:
                self.log("  WARNING: No .lrr file found in zip. Listing contents...")
                for root, dirs, files in os.walk(extract_dir):
                    for f in files:
                        self.log(f"    {os.path.join(root, f)}")
                # Return extract_dir anyway, maybe sum_data folder exists
                return extract_dir
        
        elif filename.lower().endswith('.lrr'):
            return temp_dir
        else:
            self.log(f"  WARNING: Unexpected file type: {filename}")
            return temp_dir
    
    def _download_from_page(self, session, page_url, base_url, temp_dir):
        """Download attachments from a Confluence page."""
        # Try to get page ID from URL
        page_id = None
        
        # Detect context path from URL (e.g., /confluence, /wiki, or none)
        parsed_url = urlparse(page_url)
        path_parts = parsed_url.path.split('/')
        context_path = ""
        for i, part in enumerate(path_parts):
            if part in ['confluence', 'wiki']:
                context_path = '/' + part
                break
        
        self.log(f"  Context path: {context_path or '(none)'}")
        
        # Pattern for /pages/viewpage.action?pageId=12345
        match = re.search(r'pageId=(\d+)', page_url)
        if match:
            page_id = match.group(1)
        
        # Pattern for /wiki/spaces/SPACE/pages/12345/Title or /confluence/spaces/...
        if not page_id:
            match = re.search(r'/pages/(\d+)', page_url)
            if match:
                page_id = match.group(1)
        
        # Pattern for /display/SPACE/Title (need to look up by title)
        # Handle cases like /display/AV/PAGE_TITLE or /display/AV/PAGE_TITLE/FILENAME.zip
        if not page_id:
            match = re.search(r'/display/([^/]+)/(.+)', page_url)
            if match:
                space_key = match.group(1)
                full_path = unquote(match.group(2).replace('+', ' '))
                
                # Remove query string if present
                if '?' in full_path:
                    full_path = full_path.split('?')[0]
                
                # Try multiple title candidates:
                # 1. Full path without .zip extension
                # 2. Just the first segment (page title)
                title_candidates = []
                
                # Remove .zip or .lrr extension if present
                clean_path = full_path
                if clean_path.lower().endswith('.zip') or clean_path.lower().endswith('.lrr'):
                    clean_path = clean_path.rsplit('.', 1)[0]
                
                # If there are slashes, the page title is likely the first part
                # and the rest is filename or subpage
                if '/' in clean_path:
                    parts = clean_path.split('/')
                    # First part is likely the page title
                    title_candidates.append(parts[0])
                    # Also try the full path (in case page title has /)
                    title_candidates.append(clean_path)
                else:
                    title_candidates.append(clean_path)
                
                self.log(f"  Space: {space_key}")
                self.log(f"  Title candidates: {title_candidates}")
                
                # Try multiple REST API paths (different Confluence versions/configs)
                api_paths = [
                    f"{base_url}{context_path}/rest/api/content",
                    f"{base_url}/rest/api/content",
                    f"{base_url}{context_path}/wiki/rest/api/content",
                    f"{base_url}/wiki/rest/api/content"
                ]
                
                # URL-encode the title for the API request
                
                # Try each title candidate with each API path
                for title in title_candidates:
                    if page_id:
                        break
                    self.log(f"  Trying title: {title}")
                    encoded_title = quote(title, safe='')
                    for api_base in api_paths:
                        # Try both encoded and non-encoded
                        for t in [title, encoded_title]:
                            api_url = f"{api_base}?spaceKey={space_key}&title={t}"
                            self.log(f"    API: {api_url}")
                            try:
                                resp = session.get(api_url, verify=False, timeout=120)
                                if resp.status_code == 200:
                                    data = resp.json()
                                    if data.get('results'):
                                        page_id = data['results'][0]['id']
                                        self.log(f"  Found page ID: {page_id}")
                                        break
                            except Exception as e:
                                self.log(f"    API error: {e}")
                                continue
                        if page_id:
                            break
                
                # Fallback: Try to fetch the page HTML and extract page ID or attachment link from it
                if not page_id:
                    self.log("  REST API lookup failed, trying HTML page fetch...")
                    # Construct a proper page URL (without the filename)
                    page_title = title_candidates[0] if title_candidates else ""
                    
                    # Target filename to look for in attachments
                    target_filename = None
                    if full_path.lower().endswith('.zip') or full_path.lower().endswith('.lrr'):
                        target_filename = full_path.rsplit('/', 1)[-1]  # Last part of path
                        self.log(f"  Looking for attachment: {target_filename}")
                    
                    # Try both encoded and non-encoded page URLs
                    page_urls_to_try = [
                        f"{base_url}{context_path}/display/{space_key}/{page_title}",
                        f"{base_url}{context_path}/display/{space_key}/{quote(page_title)}",
                    ]
                    
                    for page_html_url in page_urls_to_try:
                        self.log(f"  Fetching page: {page_html_url}")
                        try:
                            resp = session.get(page_html_url, verify=False, timeout=120)
                            self.log(f"  Page fetch status: {resp.status_code}")
                            
                            if resp.status_code != 200:
                                self.log(f"  Page not found or access denied")
                                continue
                            
                            html_content = resp.text
                            self.log(f"  Page HTML length: {len(html_content)} chars")
                            
                            # First, try to find direct download link for the target file
                            if target_filename:
                                # Pattern: href="/confluence/download/attachments/12345/filename.zip"
                                escaped_filename = re.escape(target_filename)
                                match = re.search(
                                    rf'href=["\']([^"\']*download/attachments/\d+/{escaped_filename}[^"\']*)["\']',
                                    html_content, re.IGNORECASE
                                )
                                if match:
                                    download_link = match.group(1)
                                    if not download_link.startswith('http'):
                                        download_link = base_url + download_link
                                    self.log(f"  Found direct download link in HTML: {download_link}")
                                    return self._download_attachment(session, download_link, temp_dir)
                                else:
                                    self.log(f"  No direct link found for: {target_filename}")
                                    # Try a broader search
                                    zip_links = re.findall(r'href=["\']([^"\']*\.zip[^"\']*)["\']', html_content, re.IGNORECASE)
                                    if zip_links:
                                        self.log(f"  Found {len(zip_links)} ZIP links in page:")
                                        for link in zip_links[:5]:
                                            self.log(f"    - {link}")
                                        # Try partial match
                                        for link in zip_links:
                                            # Check if target filename (without .zip) is in the link
                                            target_base = target_filename.rsplit('.', 1)[0].lower()
                                            if target_base in link.lower() and 'download/attachments/' in link.lower():
                                                download_link = link if link.startswith('http') else base_url + link
                                                self.log(f"  Using partial match: {download_link}")
                                                return self._download_attachment(session, download_link, temp_dir)
                            
                            # Try to find page ID in various places in the HTML
                            # Pattern 1: meta name="ajs-page-id" content="12345"
                            match = re.search(r'ajs-page-id["\'][^>]*content=["\'](\d+)["\']', html_content)
                            if match:
                                page_id = match.group(1)
                                self.log(f"  Found page ID from HTML meta: {page_id}")
                            # Pattern 2: pageId=12345
                            if not page_id:
                                match = re.search(r'pageId[=:][\s"\']*(\d+)', html_content)
                                if match:
                                    page_id = match.group(1)
                                    self.log(f"  Found page ID from HTML: {page_id}")
                            # Pattern 3: data-content-id="12345"
                            if not page_id:
                                match = re.search(r'data-content-id=["\'](\d+)["\']', html_content)
                                if match:
                                    page_id = match.group(1)
                                    self.log(f"  Found page ID from data-content-id: {page_id}")
                                    
                            # Also try to find ANY download link for .zip files
                            if not page_id and target_filename:
                                matches = re.findall(
                                    r'href=["\']([^"\']*download/attachments/[^"\']+\.zip[^"\']*)["\']',
                                    html_content, re.IGNORECASE
                                )
                                if matches:
                                    self.log(f"  Found {len(matches)} ZIP attachment(s) in HTML:")
                                    for link in matches[:5]:  # Show first 5
                                        self.log(f"    {link}")
                                    # Try to find one matching target filename
                                    for link in matches:
                                        if target_filename.lower() in link.lower():
                                            download_link = link if link.startswith('http') else base_url + link
                                            self.log(f"  Using matching link: {download_link}")
                                            return self._download_attachment(session, download_link, temp_dir)
                            
                            # If we found page_id from HTML, break out of the URL loop
                            if page_id:
                                break
                                
                        except Exception as e:
                            self.log(f"  HTML fetch error: {e}")
                            continue
        
        if not page_id:
            self.log("  ERROR: Could not determine page ID from URL")
            self.log("  Please use the direct attachment download URL instead.")
            self.log("  To get it: Right-click the ZIP file on Confluence page > Copy link address")
            messagebox.showerror("Error", 
                "Could not find the Confluence page.\\n\\n"
                "Please use the direct attachment download URL instead:\\n"
                "1. Open the Confluence page in browser\\n"
                "2. Right-click on the ZIP file attachment\\n"
                "3. Select 'Copy link address'\\n"
                "4. Paste that URL here\\n\\n"
                "Example URL format:\\n"
                "http://confluence.../download/attachments/12345/file.zip", parent=self.root)
            return None
        
        self.log(f"  Page ID: {page_id}")
        
        # Get attachments via REST API - try multiple paths
        api_paths = [
            f"{base_url}{context_path}/rest/api/content/{page_id}/child/attachment",
            f"{base_url}/rest/api/content/{page_id}/child/attachment",
            f"{base_url}{context_path}/wiki/rest/api/content/{page_id}/child/attachment",
            f"{base_url}/wiki/rest/api/content/{page_id}/child/attachment"
        ]
        
        attachments = None
        for api_url in api_paths:
            self.log(f"  Trying attachments API: {api_url}")
            try:
                resp = session.get(api_url, verify=False)
                if resp.status_code == 200:
                    attachments = resp.json().get('results', [])
                    self.log(f"  Found {len(attachments)} attachment(s)")
                    break
            except Exception as e:
                self.log(f"  API error: {e}")
                continue
        
        if attachments is None:
            self.log(f"  ERROR: Failed to get attachments from all API paths")
            messagebox.showerror("Error", 
                "Failed to get attachments from Confluence.\\n\\n"
                "Please use the direct attachment download URL instead:\\n"
                "Right-click on the ZIP file > Copy link address", parent=self.root)
            return None
        
        # Try to extract filename from URL (if present)
        target_filename = None
        url_path = urlparse(page_url).path
        if url_path.lower().endswith('.zip') or url_path.lower().endswith('.lrr'):
            target_filename = unquote(os.path.basename(url_path))
            self.log(f"  Looking for specific file: {target_filename}")
        
        # Look for .lrr or .zip files
        lrr_attachment = None
        zip_attachment = None
        matching_attachment = None
        
        for att in attachments:
            title = att.get('title', '')
            self.log(f"    Attachment: {title}")
            
            # Check for exact filename match first
            if target_filename and title == target_filename:
                matching_attachment = att
                self.log(f"    -> Exact match found!")
                break
            
            if title.lower().endswith('.lrr'):
                lrr_attachment = att
            elif title.lower().endswith('.zip'):
                zip_attachment = att
        
        # Priority: exact match > .lrr > .zip
        target = matching_attachment or lrr_attachment or zip_attachment
        
        if not target:
            self.log("  ERROR: No .lrr or .zip attachment found on page")
            messagebox.showerror("Error", "No .lrr or .zip attachment found on the Confluence page.", parent=self.root)
            return None
        
        self.log(f"  Downloading: {target.get('title', 'unknown')}")
        
        # Download the attachment
        download_link = target.get('_links', {}).get('download', '')
        if download_link:
            self.log(f"  Download link from API: {download_link}")
            
            # The download_link may or may not include the context path
            # Make sure we construct the full URL properly
            if download_link.startswith('http'):
                # Already a full URL
                download_url = download_link
            elif download_link.startswith(context_path):
                # Already includes context path (e.g., /confluence/download/...)
                download_url = base_url + download_link
            elif context_path and not download_link.startswith(context_path):
                # Need to add context path (e.g., /download/... -> /confluence/download/...)
                download_url = base_url + context_path + download_link
            else:
                download_url = base_url + download_link
            
            self.log(f"  Full download URL: {download_url}")
            return self._download_attachment(session, download_url, temp_dir)
        
        return None
    
    def _upload_to_confluence(self, excel_path, report_name):
        """Upload the report to a Confluence page as an attachment."""
        page_url = self.confluence_page_url.get().strip()
        username = self.confluence_user.get().strip()
        password = self.confluence_token.get().strip()
        
        if not page_url:
            self.log("Confluence Upload: No page URL provided, skipping.")
            return
        
        if not username or not password:
            self.log("Confluence Upload: MSP credentials required. Please login first.")
            messagebox.showwarning("Confluence Upload", 
                "Please enter MSP credentials and Login before uploading to Confluence.", parent=self.root)
            return
        
        try:
            import requests
            import re
            from urllib.parse import urlparse, parse_qs
            
            self.log("Uploading report to Confluence...")
            
            # Extract page ID from URL
            # URL formats:
            # .../pages/viewpage.action?pageId=123456
            # .../display/SPACE/Page+Title
            # .../pages/123456
            
            # Get base URL first (needed for API calls)
            parsed = urlparse(page_url)
            base_url = f"{parsed.scheme}://{parsed.netloc}/confluence"
            
            page_id = None
            
            # Try to extract pageId from query string
            if 'pageId=' in page_url:
                match = re.search(r'pageId=(\d+)', page_url)
                if match:
                    page_id = match.group(1)
            
            # Try to extract from /pages/123456 format
            if not page_id:
                match = re.search(r'/pages/(\d+)', page_url)
                if match:
                    page_id = match.group(1)
            
            # Try to extract from /display/SPACE/PAGE_TITLE format
            if not page_id:
                match = re.search(r'/display/([^/]+)/(.+?)(?:\?|$)', page_url)
                if match:
                    space_key = match.group(1)
                    page_title = unquote(match.group(2).replace('+', ' '))
                    self.log(f"Looking up page ID for space={space_key}, title={page_title}")
                    
                    # Use existing session or create new one for lookup
                    lookup_session = self.confluence_session
                    if not lookup_session:
                        lookup_session = requests.Session()
                        login_url = f"{base_url}/dologin.action"
                        login_data = {
                            'os_username': username,
                            'os_password': password,
                            'login': 'Log in',
                            'os_destination': ''
                        }
                        lookup_session.post(login_url, data=login_data, verify=False, timeout=30)
                    
                    # Look up page ID via REST API
                    lookup_url = f"{base_url}/rest/api/content"
                    params = {
                        'title': page_title,
                        'spaceKey': space_key,
                        'limit': 1
                    }
                    lookup_resp = lookup_session.get(lookup_url, params=params, verify=False, timeout=30)
                    
                    if lookup_resp.status_code == 200:
                        data = lookup_resp.json()
                        if data.get('results') and len(data['results']) > 0:
                            page_id = str(data['results'][0]['id'])
                            self.log(f"Found page ID: {page_id}")
                        else:
                            self.log(f"No page found for space={space_key}, title={page_title}")
                    else:
                        self.log(f"Failed to look up page: {lookup_resp.status_code}")
            
            if not page_id:
                self.log("Confluence Upload: Could not extract page ID from URL.")
                self.log("  Try a URL with pageId=XXXXX or /pages/XXXXX or /display/SPACE/PAGE_TITLE")
                messagebox.showerror("Confluence Upload", 
                    "Could not extract page ID from URL.\n\n"
                    "Supported URL formats:\n"
                    "  .../pages/viewpage.action?pageId=123456\n"
                    "  .../pages/123456\n"
                    "  .../display/SPACE/PageTitle", parent=self.root)
                return
            
            # parsed already set above
            base_url = f"{parsed.scheme}://{parsed.netloc}/confluence"
            
            # Use existing session or create new one
            session = self.confluence_session
            if not session:
                session = requests.Session()
                # Login to Confluence
                login_url = f"{base_url}/dologin.action"
                login_data = {
                    'os_username': username,
                    'os_password': password,
                    'login': 'Log in',
                    'os_destination': ''
                }
                session.post(login_url, data=login_data, verify=False, timeout=30)
            
            # Upload attachment using REST API
            attachment_url = f"{base_url}/rest/api/content/{page_id}/child/attachment"
            
            file_name = os.path.basename(excel_path)
            
            # Determine MIME type based on file extension
            if file_name.lower().endswith('.pdf'):
                mime_type = 'application/pdf'
            elif file_name.lower().endswith('.xlsx'):
                mime_type = 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet'
            elif file_name.lower().endswith('.xls'):
                mime_type = 'application/vnd.ms-excel'
            else:
                mime_type = 'application/octet-stream'
            
            with open(excel_path, 'rb') as f:
                files = {
                    'file': (file_name, f, mime_type)
                }
                headers = {
                    'X-Atlassian-Token': 'nocheck'  # Required for Confluence API
                }
                
                response = session.post(
                    attachment_url,
                    files=files,
                    headers=headers,
                    verify=False,
                    timeout=60
                )
            
            if response.status_code in [200, 201]:
                self.log(f"Confluence Upload: SUCCESS! File uploaded to page {page_id}")
                messagebox.showinfo("Confluence Upload", 
                    f"Report uploaded successfully!\n\nFile: {file_name}\nPage ID: {page_id}", parent=self.root)
            else:
                self.log(f"Confluence Upload: Failed - Status {response.status_code}")
                self.log(f"  Response: {response.text[:200]}...")
                messagebox.showerror("Confluence Upload", 
                    f"Upload failed with status {response.status_code}\n\n{response.text[:200]}", parent=self.root)
                
        except Exception as e:
            self.log(f"Confluence Upload: Error - {str(e)}")
            messagebox.showerror("Confluence Upload", f"Error uploading to Confluence:\n\n{str(e)}", parent=self.root)
    
    def _prompt_confluence_upload(self, excel_path, report_name):
        """Prompt user for Confluence page URL and upload the report."""
        # Check if credentials are available
        username = self.confluence_user.get().strip()
        password = self.confluence_token.get().strip()
        
        if not username or not password:
            messagebox.showwarning("Confluence Upload", 
                "Please enter MSP credentials at the top of the app and Login first.\n\n"
                "Then generate the report again or use the pre-configured upload option.", parent=self.root)
            return
        
        # Ask for page URL
        page_url = simpledialog.askstring("Confluence Upload", 
            "Enter the Confluence page URL where you want to upload:\n\n"
            "Supported formats:\n"
            "  .../display/SPACE/PageTitle\n"
            "  .../pages/viewpage.action?pageId=123456",
            parent=self.root)
        
        if page_url and page_url.strip():
            # Set the URL and upload
            self.confluence_page_url.set(page_url.strip())
            self._upload_to_confluence(excel_path, report_name)
    
    def _cleanup_temp_dirs(self, clear_ui=True):
        """Clean up temporary directories created for Confluence downloads.
        
        Args:
            clear_ui: If True, also clear extracted paths and graphs. Set False when cleaning on success.
        """
        for temp_dir in self.temp_dirs:
            try:
                if os.path.exists(temp_dir):
                    shutil.rmtree(temp_dir)
                    self.log(f"Cleaned up temp folder: {temp_dir}")
            except Exception as e:
                self.log(f"Warning: Could not clean up {temp_dir}: {e}")
        self.temp_dirs = []
        
        # Only clear UI elements if explicitly requested (e.g., on app close)
        if clear_ui:
            self.extracted_path1.set('')
            self.extracted_path2.set('')
            self.extracted_path3.set('')
            self.extracted_path4.set('')
    
    def _resolve_input_path(self, path, controller_num):
        """Resolve input path - download from Confluence if URL, else return as-is.
        
        Returns:
            Tuple (resolved_path, is_confluence)
        """
        if not path:
            return (None, False)
        
        path = path.strip()
        
        if self._is_confluence_url(path):
            # Download from Confluence
            resolved = self._download_from_confluence(path, controller_num)
            return (resolved, True)
        else:
            return (path, False)
    
    def _parse_time_to_seconds(self, time_str):
        """Parse time input to seconds based on current SS mode.
        
        For Absolute mode (wall clock time):
        - HH:MM:SS format (e.g., 13:38:56)
        - Returns seconds since midnight (13:38:56 = 49136)
        
        For Relative mode (from test start):
        - HH:MM:SS format (e.g., 00:10:00) or just seconds (600)
        - Returns seconds from test start (600)
        """
        if not time_str or not time_str.strip():
            return None
        
        time_str = time_str.strip()
        
        try:
            # Check if it's just a number (seconds)
            if time_str.isdigit():
                return int(time_str)
            
            # Parse HH:MM:SS or MM:SS format
            parts = time_str.split(':')
            if len(parts) == 3:
                return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
            elif len(parts) == 2:
                return int(parts[0]) * 60 + int(parts[1])
            else:
                return int(parts[0])
        except:
            return None
    
    def generate_report(self):
        """Generate the report."""
        # Reset user count displays
        self.user_count1.set('-')
        self.user_count2.set('-')
        self.user_count3.set('-')
        self.user_count4.set('-')
        
        # NOTE: Do NOT cleanup temp dirs here - they may be needed for the report
        # Cleanup happens on app close or after successful report generation
        
        # Get all input paths - prefer local path, then extracted path, finally Confluence URL
        # (extracted_path is set when user clicks FetchDetails)
        raw_inputs = [
            self.input_path1.get().strip() or self.extracted_path1.get().strip() or self.conf_url1.get().strip(),
            self.input_path2.get().strip() or self.extracted_path2.get().strip() or self.conf_url2.get().strip(),
            self.input_path3.get().strip() or self.extracted_path3.get().strip() or self.conf_url3.get().strip(),
            self.input_path4.get().strip() or self.extracted_path4.get().strip() or self.conf_url4.get().strip()
        ]
        
        # Get steady state timings for each controller
        ss_timings = [
            (self._parse_time_to_seconds(self.ss_from1.get()), self._parse_time_to_seconds(self.ss_to1.get())),
            (self._parse_time_to_seconds(self.ss_from2.get()), self._parse_time_to_seconds(self.ss_to2.get())),
            (self._parse_time_to_seconds(self.ss_from3.get()), self._parse_time_to_seconds(self.ss_to3.get())),
            (self._parse_time_to_seconds(self.ss_from4.get()), self._parse_time_to_seconds(self.ss_to4.get())),
        ]
        
        output_folder = self.output_path.get().strip()
        report_types = self._get_selected_report_types()  # Returns list of selected types
        script_name = self.script_name.get().strip()
        
        # Validate - Report Name is mandatory
        if not script_name:
            messagebox.showerror("Error", "Please enter a Report Name.", parent=self.root)
            return
        
        # Validate - at least Controller 1 is required
        if not raw_inputs[0]:
            messagebox.showerror("Error", "Please select at least Controller 1 results folder or enter Confluence URL.", parent=self.root)
            return
        
        # Resolve input paths (download from Confluence if URLs)
        input_folders = []
        for i, raw_path in enumerate(raw_inputs, start=1):
            if not raw_path:
                continue
            
            resolved_path, is_confluence = self._resolve_input_path(raw_path, i)
            
            if is_confluence:
                if not resolved_path:
                    # Download failed - error already shown
                    return
                self.log(f"Controller {i}: Downloaded from Confluence to {resolved_path}")
            else:
                # Local folder - validate it exists
                if not os.path.isdir(resolved_path):
                    messagebox.showerror("Error", f"Controller {i} folder does not exist:\n{resolved_path}\n\nClick 'FetchDetails' to re-extract the data.", parent=self.root)
                    return
            
            # Validate Steady State is required for this controller
            ss_from, ss_to = ss_timings[i-1]
            if ss_from is None or ss_to is None:
                required_text = " (REQUIRED)" if i == 1 else ""
                mode = self.ss_mode.get()
                if mode == 'absolute':
                    format_hint = "Absolute Steady State: HH:MM:SS (e.g., 13:38:56 to 13:49:34)"
                else:
                    format_hint = "Relative Steady State: HH:MM:SS from test start (e.g., 00:00:08 to 00:10:08)"
                messagebox.showerror("Error", f"Please enter Steady State From and To times for Controller {i}{required_text}.\\n\\n{format_hint}", parent=self.root)
                return
            
            if ss_from >= ss_to:
                messagebox.showerror("Error", f"Steady State 'From' time must be less than 'To' time for Controller {i}.", parent=self.root)
                return
            
            input_folders.append((resolved_path, i))
        
        if not output_folder:
            messagebox.showerror("Error", "Please select an output folder.", parent=self.root)
            return
        
        if not os.path.isdir(output_folder):
            messagebox.showerror("Error", f"Output folder does not exist:\\n{output_folder}", parent=self.root)
            return
        
        if not EXCEL_AVAILABLE:
            messagebox.showerror("Error", "Excel export not available.\\nPlease install openpyxl: pip install openpyxl", parent=self.root)
            return
        
        # Record start time
        from datetime import datetime
        start_time = datetime.now()
        
        # Create progress window
        progress_win = tk.Toplevel(self.root)
        progress_win.title("Generating Report")
        progress_win.geometry("450x220")
        progress_win.transient(self.root)
        progress_win.grab_set()
        progress_win.resizable(False, False)
        
        # Center the window
        progress_win.update_idletasks()
        x = self.root.winfo_x() + (self.root.winfo_width() - 450) // 2
        y = self.root.winfo_y() + (self.root.winfo_height() - 220) // 2
        progress_win.geometry(f"+{x}+{y}")
        
        # Add widgets
        title_label = ttk.Label(progress_win, text="Generating Report...", 
                  font=('Segoe UI', 11, 'bold'))
        title_label.pack(pady=(15, 5))
        
        # Start time label
        start_time_str = start_time.strftime("%H:%M:%S")
        time_frame = ttk.Frame(progress_win)
        time_frame.pack(pady=(0, 5))
        ttk.Label(time_frame, text=f"Started: {start_time_str}", font=('Segoe UI', 9), foreground='gray').pack(side=tk.LEFT, padx=10)
        elapsed_var = tk.StringVar(value="Elapsed: 0s")
        ttk.Label(time_frame, textvariable=elapsed_var, font=('Segoe UI', 9), foreground='gray').pack(side=tk.LEFT, padx=10)
        
        # Progress bar with percentage
        progress_frame = ttk.Frame(progress_win)
        progress_frame.pack(pady=5, padx=30, fill=tk.X)
        
        progress_var = tk.DoubleVar(value=0)
        progress_bar = ttk.Progressbar(progress_frame, variable=progress_var, 
                                        maximum=100, length=340, mode='determinate')
        progress_bar.pack(side=tk.LEFT)
        
        pct_var = tk.StringVar(value="0%")
        pct_label = ttk.Label(progress_frame, textvariable=pct_var, font=('Segoe UI', 9, 'bold'), width=5)
        pct_label.pack(side=tk.LEFT, padx=(5, 0))
        
        status_var = tk.StringVar(value="Starting...")
        status_label = ttk.Label(progress_win, textvariable=status_var, font=('Segoe UI', 9))
        status_label.pack(pady=5)
        
        controller_var = tk.StringVar(value="")
        controller_label = ttk.Label(progress_win, textvariable=controller_var, font=('Segoe UI', 9), foreground='gray')
        controller_label.pack(pady=5)
        
        def update_progress(step, pct, controller_info=""):
            progress_var.set(pct)
            pct_var.set(f"{int(pct)}%")
            status_var.set(step)
            if controller_info:
                controller_var.set(controller_info)
            # Update elapsed time
            elapsed = (datetime.now() - start_time).total_seconds()
            if elapsed < 60:
                elapsed_var.set(f"Elapsed: {int(elapsed)}s")
            else:
                mins = int(elapsed // 60)
                secs = int(elapsed % 60)
                elapsed_var.set(f"Elapsed: {mins}m {secs}s")
            progress_win.update()
        
        try:
            self.log("=" * 50)
            self.log(f"Processing {len(input_folders)} controller(s)...")
            self.log(f"Report type: {', '.join(report_types)}")
            self.log("Target TPS: Using built-in lookup table (edit in Excel Target_TPS sheet)")
            if script_name:
                self.log(f"Report Name: {script_name}")
            
            # Parse all folders and aggregate data
            all_parsers = []
            total_controllers = len(input_folders)
            for idx, (folder, ctrl_num) in enumerate(input_folders):
                self.log(f"Parsing Controller {ctrl_num}: {os.path.basename(folder)}")
                parser = LRRParser(folder)
                
                # Apply user-specified steady state timings if provided
                ss_from, ss_to = ss_timings[ctrl_num-1]
                is_absolute = (self.ss_mode.get() == 'absolute')
                if ss_from is not None and ss_to is not None:
                    mode_text = "absolute" if is_absolute else "relative"
                    self.log(f"  Using {mode_text} steady state: {ss_from}s to {ss_to}s (duration: {ss_to - ss_from}s)")
                    parser.set_steady_state(ss_from, ss_to, is_absolute=is_absolute)
                
                # Progress callback for this controller
                base_pct = int((idx / total_controllers) * 70)  # 0-70% for parsing
                def make_callback(base, ctrl, total):
                    def callback(step, pct):
                        # Scale pct (0-100) to this controller's portion
                        portion = 70 / total  # Each controller gets equal portion of 70%
                        actual_pct = base + (pct / 100 * portion)
                        update_progress(step, actual_pct, f"Controller {ctrl} of {total}")
                    return callback
                
                parser.parse(progress_callback=make_callback(base_pct, idx+1, total_controllers))
                
                # Debug: show parser debug info
                if hasattr(parser, '_debug_info'):
                    for info in parser._debug_info:
                        self.log(f"  DEBUG: {info}")
                
                # Debug: show filtered time range per controller
                if parser._user_steady_state:
                    self.log(f"  Filter range: {parser.steady_state_from_rel}s to {parser.steady_state_to_rel}s")
                    self.log(f"  Response times captured: {len(parser.response_times)} transactions")
                
                # Update user count display for this controller
                user_count_vars = [self.user_count1, self.user_count2, self.user_count3, self.user_count4]
                if hasattr(parser, 'max_vusers') and parser.max_vusers > 0:
                    user_count_vars[ctrl_num-1].set(str(parser.max_vusers))
                    self.log(f"  Users for C{ctrl_num}: {parser.max_vusers}")
                else:
                    user_count_vars[ctrl_num-1].set("N/A")
                
                all_parsers.append((parser, ctrl_num))
            
            # Check for duplicate results (same file provided via different paths)
            if len(all_parsers) > 1:
                result_names = {}  # result_name -> list of controller numbers
                for parser, ctrl_num in all_parsers:
                    result_name = parser.scenario_info.get('result_name', '')
                    if result_name:
                        if result_name not in result_names:
                            result_names[result_name] = []
                        result_names[result_name].append(ctrl_num)
                
                # Find duplicates
                duplicates = {name: ctrls for name, ctrls in result_names.items() if len(ctrls) > 1}
                if duplicates:
                    dup_messages = []
                    for name, ctrls in duplicates.items():
                        ctrl_list = ', '.join([f'C{c}' for c in ctrls])
                        dup_messages.append(f"  • '{name}' in {ctrl_list}")
                    
                    dup_text = '\n'.join(dup_messages)
                    self.log(f"WARNING: Duplicate results detected!")
                    for msg in dup_messages:
                        self.log(msg)
                    
                    progress_win.destroy()  # Hide progress for dialog
                    proceed = messagebox.askyesno(
                        "Duplicate Results Detected",
                        f"The same LoadRunner result appears to be loaded in multiple controllers:\n\n"
                        f"{dup_text}\n\n"
                        f"This will cause data to be counted multiple times, resulting in incorrect totals.\n\n"
                        f"Do you want to continue anyway?",
                        icon='warning',
                        parent=self.root
                    )
                    if not proceed:
                        self.log("Report generation cancelled - duplicate results detected.")
                        return
                    else:
                        self.log("User chose to continue with duplicate results.")
                        # Re-create progress window to continue
                        progress_win = tk.Toplevel(self.root)
                        progress_win.title("Generating Report")
                        progress_win.geometry("450x220")
                        progress_win.transient(self.root)
                        progress_win.grab_set()
                        progress_win.resizable(False, False)
                        progress_win.update_idletasks()
                        x = self.root.winfo_x() + (self.root.winfo_width() - 450) // 2
                        y = self.root.winfo_y() + (self.root.winfo_height() - 220) // 2
                        progress_win.geometry(f"+{x}+{y}")
                        title_label = ttk.Label(progress_win, text="Generating Report...", font=('Segoe UI', 11, 'bold'))
                        title_label.pack(pady=(15, 5))
                        # Time info
                        time_frame = ttk.Frame(progress_win)
                        time_frame.pack(pady=(0, 5))
                        ttk.Label(time_frame, text=f"Started: {start_time_str}", font=('Segoe UI', 9), foreground='gray').pack(side=tk.LEFT, padx=10)
                        elapsed_var = tk.StringVar(value="Elapsed: 0s")
                        ttk.Label(time_frame, textvariable=elapsed_var, font=('Segoe UI', 9), foreground='gray').pack(side=tk.LEFT, padx=10)
                        # Progress bar with percentage
                        progress_frame = ttk.Frame(progress_win)
                        progress_frame.pack(pady=5, padx=30, fill=tk.X)
                        progress_var = tk.DoubleVar(value=70)
                        progress_bar = ttk.Progressbar(progress_frame, variable=progress_var, maximum=100, length=340, mode='determinate')
                        progress_bar.pack(side=tk.LEFT)
                        pct_var = tk.StringVar(value="70%")
                        pct_label = ttk.Label(progress_frame, textvariable=pct_var, font=('Segoe UI', 9, 'bold'), width=5)
                        pct_label.pack(side=tk.LEFT, padx=(5, 0))
                        status_var = tk.StringVar(value="Aggregating data...")
                        status_label = ttk.Label(progress_win, textvariable=status_var, font=('Segoe UI', 9))
                        status_label.pack(pady=5)
                        controller_var = tk.StringVar(value="")
                        controller_label = ttk.Label(progress_win, textvariable=controller_var, font=('Segoe UI', 9), foreground='gray')
                        controller_label.pack(pady=5)
            
            update_progress("Aggregating data...", 72, "")
            
            # Use first parser as base and aggregate data from others
            base_parser = all_parsers[0][0]  # Extract parser from (parser, ctrl_num) tuple
            
            # Aggregate transaction data from all parsers
            if len(all_parsers) > 1:
                self.log(f"Aggregating data from {len(all_parsers)} controllers...")
                for other_parser, _ in all_parsers[1:]:
                    base_parser.aggregate_data(other_parser)
            
            update_progress("Processing results...", 75, "")
            
            # Log scenario info and debug data
            self.log(f"Result: {base_parser.scenario_info.get('result_name', 'N/A')}")
            if hasattr(base_parser, 'steady_state_duration') and base_parser.steady_state_duration:
                ss_minutes = round(base_parser.steady_state_duration / 60, 1)
                self.log(f"Steady state duration: {base_parser.steady_state_duration}s ({ss_minutes} min)")
            
            # Log User Count for the steady state duration
            if hasattr(base_parser, 'max_vusers') and base_parser.max_vusers > 0:
                self.log(f"*** Virtual User Count for SS Duration: {base_parser.max_vusers} users (avg: {base_parser.avg_vusers}) ***")
                # Update UI label with user count
                self.user_count_label.config(text=f"Virtual User Count: {base_parser.max_vusers} users (avg: {base_parser.avg_vusers})")
            else:
                self.log("User Count: Not available (vuser graph not found)")
                self.user_count_label.config(text="Virtual User Count: N/A")
            
            # NOTE: Do not update VUsers graph here - it's already set with correct steady state
            # when user clicked "Enter" for each controller. Updating here would reset to full duration.
            
            # Update SS Duration label in UI
            if hasattr(base_parser, 'steady_state_duration') and base_parser.steady_state_duration:
                ss_minutes = round(base_parser.steady_state_duration / 60, 1)
                self.ss_duration_label.config(text=f"SS Duration: {base_parser.steady_state_duration}s ({ss_minutes} min)")
            
            # Debug: Log transaction count
            trans_count = len(base_parser.transaction_summary)
            self.log(f"Transactions found: {trans_count}")
            # Update transaction count label in UI
            self.trans_count_label.config(text=f"Transactions: {trans_count}")
            if trans_count == 0:
                self.log("WARNING: No transactions parsed! Check if graph files exist in sum_data folder.")
                self.log(f"  Steady state filter: {base_parser.steady_state_from_rel}s to {base_parser.steady_state_to_rel}s")
            
            # Parse script folder if provided (for API details in Slow Transactions)
            update_progress("Parsing scripts...", 80, "")
            script_folder_paths = self.script_folder.get().strip()
            script_temp_dirs = []  # Track temp dirs for cleanup
            if script_folder_paths:
                # Split multiple paths by semicolon
                paths = [p.strip() for p in script_folder_paths.split(';') if p.strip()]
                
                for path in paths:
                    # Check if it's a ZIP file - read directly without extraction (FAST!)
                    if path.lower().endswith('.zip') and os.path.isfile(path):
                        self.log(f"Reading scripts directly from ZIP: {os.path.basename(path)}")
                        self.log(f"  (No extraction needed - reading .c files directly)")
                        self.root.update()
                        
                        try:
                            # Use progress callback to update UI
                            def progress_update(current, total, message):
                                if current % 50 == 0 or current == total:
                                    self.log(f"  {message}")
                                    self.root.update()
                            
                            # Parse directly from ZIP - MUCH faster than extracting
                            base_parser.parse_script_zip(path, progress_callback=progress_update)
                            
                            api_call_count = sum(len(v) for v in base_parser.transaction_api_calls.values())
                            if api_call_count > 0:
                                self.log(f"  Found {api_call_count} API calls across {len(base_parser.transaction_api_calls)} transactions")
                            else:
                                self.log(f"  No API calls found (check if Action.c files exist)")
                        except Exception as e:
                            self.log(f"  ERROR reading ZIP: {e}")
                    
                    # Check if it's a folder
                    elif os.path.isdir(path):
                        self.log(f"Parsing scripts from folder: {path}")
                        self.root.update()
                        base_parser.parse_script_folder(path)
                        api_call_count = sum(len(v) for v in base_parser.transaction_api_calls.values())
                        if api_call_count > 0:
                            self.log(f"  Found {api_call_count} API calls across {len(base_parser.transaction_api_calls)} transactions")
                        else:
                            self.log(f"  No API calls found (check if Action.c files exist in subfolders)")
                    else:
                        self.log(f"WARNING: Script path not found: {path}")
            else:
                # No script folder provided
                self.log("No script folder provided - API details will use error log fallback")
            
            update_progress("Preparing Excel...", 85, "")
            
            # Generate Excel - use script_name for filename if provided, else use folder name
            if script_name:
                excel_filename = f"{script_name}_Report.xlsx"
            else:
                folder_name = os.path.basename(input_folders[0][0])  # input_folders is list of (path, ctrl_num)
                excel_filename = f"{folder_name}_Report.xlsx"
            
            excel_path = os.path.join(output_folder, excel_filename)
            
            # Check if file already exists
            if os.path.exists(excel_path):
                # First check if file is locked (open in another app)
                try:
                    with open(excel_path, 'a'):
                        pass
                except PermissionError:
                    progress_win.destroy()
                    messagebox.showerror("Error", f"The file is already open. Please close it first:\n\n{excel_path}", parent=self.root)
                    return
                
                # File exists and is not locked - ask user if they want to overwrite
                progress_win.withdraw()  # Hide progress window for dialog
                overwrite = messagebox.askyesno(
                    "Report Already Exists",
                    f"A report with this name already exists:\n\n{excel_filename}\n\n"
                    f"Do you want to overwrite it?\n\n"
                    f"Click 'No' to cancel and change the Report Name.",
                    icon='warning',
                    parent=self.root
                )
                if not overwrite:
                    progress_win.destroy()
                    self.log("Report generation cancelled - file already exists.")
                    return
                progress_win.deiconify()  # Show progress window again
            
            self.log(f"Generating Excel report...")
            
            # DEBUG: Print avg_tps values before Excel export
            self.log("DEBUG: TPS values before Excel export:")
            for name, data in sorted(base_parser.response_times.items()):
                if 'avg_tps' in data and ('Last_Trans' in name or 'Logout' in name):
                    self.log(f"  {name}: avg_tps={data['avg_tps']}")
            
            # Pass custom Target TPS values if user has set them
            custom_tps = getattr(self, 'custom_target_tps', None)
            custom_categories = getattr(self, 'custom_script_categories', None)
            
            # Default adjustment percentage is 100% - user can change in Excel cell N7
            adj_pct = 1.0  # 100%
            
            update_progress("Generating Excel report...", 90, "")
            base_parser.export_to_excel(excel_path, report_types, None, script_name, custom_tps, adj_pct, custom_categories)
            
            update_progress("Complete!", 100, "")
            self.log(f"Report saved: {excel_filename}")
            self.log("=" * 50)
            self.log("SUCCESS!")
            
            # Close progress window
            progress_win.destroy()
            
            # DO NOT clean up temp directories here - let user continue working with graphs
            # Temp dirs will be cleaned when app closes
            
            # Clean up script temp dirs if we extracted from ZIPs
            for temp_dir in script_temp_dirs:
                if temp_dir and os.path.exists(temp_dir):
                    try:
                        shutil.rmtree(temp_dir)
                    except Exception:
                        pass
            
            # Upload to Confluence if checkbox was pre-selected
            if self.upload_to_confluence.get():
                self._upload_to_confluence(excel_path, script_name or folder_name)
            
            # Ask to open
            if messagebox.askyesno("Success", f"Report generated successfully!\\n\\n{excel_path}\\n\\nOpen the file?", parent=self.root):
                os.startfile(excel_path)
            
            # Ask if user wants to upload to Confluence (if not already uploaded)
            if not self.upload_to_confluence.get():
                if messagebox.askyesno("Upload to Confluence", 
                    "Do you want to upload this report to Confluence?", parent=self.root):
                    self._prompt_confluence_upload(excel_path, script_name or folder_name)
            
            # Store the last generated report path for PDF generation
            self.last_excel_path = excel_path
            self.last_parser = base_parser
            self.last_scenario_name = script_name or folder_name
                
        except PermissionError:
            progress_win.destroy()
            self.log(f"ERROR: File is open. Please close it first.")
            messagebox.showerror("Error", f"The file is already open. Please close it and try again.", parent=self.root)
            # Don't clear UI on error - let user fix and retry
        except Exception as e:
            try:
                progress_win.destroy()
            except:
                pass
            self.log(f"ERROR: {str(e)}")
            messagebox.showerror("Error", f"Failed to generate report:\\n\\n{str(e)}", parent=self.root)
            # Don't clear UI on error - let user fix and retry
    
    def show_target_tps_editor(self):
        """Show a dialog to edit Target TPS values - loads from TARGET_TPS_LOOKUP."""
        from lrr_parser import TARGET_TPS_LOOKUP, BO_USECASES
        
        # Separate BO and FO usecases from TARGET_TPS_LOOKUP
        bo_tps = {}
        fo_tps = {}
        
        for script_name, tps_value in TARGET_TPS_LOOKUP.items():
            if script_name in BO_USECASES:
                bo_tps[script_name] = tps_value
            else:
                fo_tps[script_name] = tps_value
        
        # Apply any custom overrides
        if hasattr(self, 'custom_target_tps') and self.custom_target_tps:
            for script_name, tps_value in self.custom_target_tps.items():
                if script_name in bo_tps:
                    bo_tps[script_name] = tps_value
                elif script_name in fo_tps:
                    fo_tps[script_name] = tps_value
        
        # Show dialog
        self._show_target_tps_dialog(bo_tps, fo_tps)
    
    def _show_target_tps_dialog(self, bo_tps, fo_tps):
        """Show dialog to edit Target TPS values - separated by BO and FO tabs."""
        from lrr_parser import TARGET_TPS_LOOKUP, BO_USECASES
        
        dialog = tk.Toplevel(self.root)
        dialog.title("Edit Target TPS Values")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Calculate size based on screen - use 70% of screen height, max 700
        screen_width = dialog.winfo_screenwidth()
        screen_height = dialog.winfo_screenheight()
        dialog_width = 720  # Wider to fit delete button
        dialog_height = min(int(screen_height * 0.75), 750)
        
        # Center dialog
        x = (screen_width - dialog_width) // 2
        y = (screen_height - dialog_height) // 2
        dialog.geometry(f"{dialog_width}x{dialog_height}+{x}+{y}")
        
        # Make dialog resizable and set minimum size
        dialog.resizable(True, True)
        dialog.minsize(600, 400)
        
        # Title
        title_label = ttk.Label(dialog, text="Edit Target TPS Values", 
                               font=('Segoe UI', 14, 'bold'))
        title_label.pack(pady=(10, 5))
        
        info_label = ttk.Label(dialog, text="Edit Target TPS values below. These will be used in FinalReport generation.", 
                              font=('Segoe UI', 9), foreground='gray')
        info_label.pack(pady=(0, 10))
        
        # Storage for entry widgets and row frames
        tps_entries = {}
        row_frames = {}  # script_name -> row_frame widget
        deleted_scripts = set()  # Track deleted scripts
        
        # Undo history stack - stores (action_type, data) tuples
        undo_history = []  # List of ('delete', {script_name, tps_value, tab_name, row_index}) or ('edit', {script_name, old_value})
        
        # Mutable containers to hold current BO/FO data (so inner functions can modify)
        current_bo_tps = dict(bo_tps)
        current_fo_tps = dict(fo_tps)
        
        # Button frame - pack at BOTTOM FIRST to reserve space (ensures buttons always visible)
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(side=tk.BOTTOM, fill=tk.X, pady=10, padx=10)
        
        # Create notebook for BO/FO tabs - pack AFTER button frame so it takes remaining space
        notebook = ttk.Notebook(dialog)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Store tab references for refresh
        tab_info = {}
        
        def delete_script(script_name, row_frame, tab_name):
            """Delete a script from the list."""
            if messagebox.askyesno("Confirm Delete", f"Delete script '{script_name}'?", parent=dialog):
                # Save to undo history BEFORE deleting
                old_tps = tps_entries[script_name].get() if script_name in tps_entries else "0"
                undo_history.append(('delete', {
                    'script_name': script_name,
                    'tps_value': old_tps,
                    'tab_name': tab_name
                }))
                update_undo_btn_state()
                
                # Remove from entries
                if script_name in tps_entries:
                    del tps_entries[script_name]
                # Remove from row_frames
                if script_name in row_frames:
                    del row_frames[script_name]
                # Track as deleted
                deleted_scripts.add(script_name)
                # Remove from current data
                if tab_name == "BO" and script_name in current_bo_tps:
                    del current_bo_tps[script_name]
                elif tab_name == "FO" and script_name in current_fo_tps:
                    del current_fo_tps[script_name]
                # Hide the row (destroy it)
                row_frame.destroy()
                # Update summary
                update_summary()
        
        def update_undo_btn_state():
            """Update the undo button state based on history."""
            if undo_history:
                undo_btn.config(state='normal', bg='#FF9800')
            else:
                undo_btn.config(state='disabled', bg='#CCCCCC')
        
        def undo_last_action():
            """Undo the last delete or edit action."""
            if not undo_history:
                return
            
            action_type, data = undo_history.pop()
            
            if action_type == 'delete':
                # Restore deleted script
                script_name = data['script_name']
                tps_value = data['tps_value']
                tab_name = data['tab_name']
                
                # Remove from deleted set
                deleted_scripts.discard(script_name)
                
                # Add back to current data
                if tab_name == "BO":
                    current_bo_tps[script_name] = float(tps_value)
                else:
                    current_fo_tps[script_name] = float(tps_value)
                
                # Recreate the row in the appropriate tab
                if tab_name in tab_info:
                    info = tab_info[tab_name]
                    scrollable_frame = info['scrollable_frame']
                    on_mousewheel = info['on_mousewheel']
                    row_colors = info['row_colors']
                    
                    # Calculate row number
                    idx = len([s for s in tps_entries if (s in current_bo_tps if tab_name == "BO" else s in current_fo_tps)]) + 1
                    row_bg = row_colors[idx % 2]
                    
                    row_frame = tk.Frame(scrollable_frame, bg=row_bg)
                    row_frame.pack(fill=tk.X)
                    row_frame.bind("<MouseWheel>", on_mousewheel)
                    
                    # Serial number
                    tk.Label(row_frame, text=str(idx), width=6, bg=row_bg, anchor='center').pack(side=tk.LEFT, padx=2, pady=3)
                    
                    # Script name label
                    tk.Label(row_frame, text=script_name, width=40, bg=row_bg, anchor='w').pack(side=tk.LEFT, padx=2, pady=3)
                    
                    # TPS entry
                    tps_var = tk.StringVar(value=str(tps_value))
                    tps_entry_new = ttk.Entry(row_frame, textvariable=tps_var, width=12, justify='center')
                    tps_entry_new.pack(side=tk.LEFT, padx=2, pady=3)
                    tps_entry_new.bind("<MouseWheel>", on_mousewheel)
                    
                    # Delete button
                    del_btn = tk.Button(row_frame, text="🗑", fg='red', bg=row_bg, 
                                       font=('Segoe UI', 9), bd=0, cursor='hand2',
                                       command=lambda s=script_name, r=row_frame, t=tab_name: delete_script(s, r, t))
                    del_btn.pack(side=tk.LEFT, padx=5, pady=3)
                    
                    tps_entries[script_name] = tps_var
                    row_frames[script_name] = row_frame
                
                # Update summary
                update_summary()
            
            update_undo_btn_state()
        
        def update_summary():
            """Update the summary label."""
            bo_count = len(current_bo_tps) - len([s for s in deleted_scripts if s in bo_tps])
            fo_count = len(current_fo_tps) - len([s for s in deleted_scripts if s in fo_tps])
            # Count actual entries
            bo_count = len([s for s in tps_entries if s in current_bo_tps or (hasattr(self, 'custom_script_categories') and self.custom_script_categories.get(s) == 'BO')])
            fo_count = len([s for s in tps_entries if s in current_fo_tps or (hasattr(self, 'custom_script_categories') and self.custom_script_categories.get(s) == 'FO')])
            total = bo_count + fo_count
            summary_label.config(text=f"Total: {total} scripts ({bo_count} BO + {fo_count} FO)")
        
        def create_tps_tab(parent, tps_dict, tab_name, header_color):
            """Create a tab with script TPS entries."""
            tab_frame = ttk.Frame(parent)
            
            # Canvas with scrollbar
            canvas = tk.Canvas(tab_frame, bg='white')
            scrollbar = ttk.Scrollbar(tab_frame, orient="vertical", command=canvas.yview)
            scrollable_frame = tk.Frame(canvas, bg='white')
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )
            
            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            
            # Mouse wheel scrolling
            def on_mousewheel(event):
                canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            canvas.bind("<MouseWheel>", on_mousewheel)
            scrollable_frame.bind("<MouseWheel>", on_mousewheel)
            
            # Header row with colored background
            header_frame = tk.Frame(scrollable_frame, bg=header_color)
            header_frame.pack(fill=tk.X, pady=(0, 2))
            
            tk.Label(header_frame, text="Sl No", font=('Segoe UI', 10, 'bold'), 
                    width=6, bg=header_color, fg='white', anchor='center').pack(side=tk.LEFT, padx=2, pady=5)
            tk.Label(header_frame, text="Script_Name", font=('Segoe UI', 10, 'bold'), 
                    width=40, bg=header_color, fg='white', anchor='w').pack(side=tk.LEFT, padx=2, pady=5)
            tk.Label(header_frame, text="Target TPS", font=('Segoe UI', 10, 'bold'), 
                    width=12, bg=header_color, fg='white', anchor='center').pack(side=tk.LEFT, padx=2, pady=5)
            tk.Label(header_frame, text="Action", font=('Segoe UI', 10, 'bold'), 
                    width=8, bg=header_color, fg='white', anchor='center').pack(side=tk.LEFT, padx=2, pady=5)
            
            # Script entries with alternating row colors
            row_colors = ['#FFFFFF', '#F5F5F5']
            for idx, (script, tps_value) in enumerate(tps_dict.items(), 1):
                row_bg = row_colors[idx % 2]
                row_frame = tk.Frame(scrollable_frame, bg=row_bg)
                row_frame.pack(fill=tk.X)
                row_frame.bind("<MouseWheel>", on_mousewheel)
                
                # Serial number
                tk.Label(row_frame, text=str(idx), width=6, bg=row_bg, anchor='center').pack(side=tk.LEFT, padx=2, pady=3)
                
                # Script name label
                tk.Label(row_frame, text=script, width=40, bg=row_bg, anchor='w').pack(side=tk.LEFT, padx=2, pady=3)
                
                # Get current TPS value (custom override or default)
                current_tps = tps_value
                if hasattr(self, 'custom_target_tps') and script in self.custom_target_tps:
                    current_tps = self.custom_target_tps[script]
                
                # TPS entry
                tps_var = tk.StringVar(value=str(current_tps))
                tps_entry = ttk.Entry(row_frame, textvariable=tps_var, width=12, justify='center')
                tps_entry.pack(side=tk.LEFT, padx=2, pady=3)
                tps_entry.bind("<MouseWheel>", on_mousewheel)
                
                # Delete button
                del_btn = tk.Button(row_frame, text="🗑", fg='red', bg=row_bg, 
                                   font=('Segoe UI', 9), bd=0, cursor='hand2',
                                   command=lambda s=script, r=row_frame, t=tab_name: delete_script(s, r, t))
                del_btn.pack(side=tk.LEFT, padx=5, pady=3)
                
                tps_entries[script] = tps_var
                row_frames[script] = row_frame
            
            canvas.pack(side=tk.LEFT, fill=tk.BOTH, expand=True)
            scrollbar.pack(side=tk.RIGHT, fill=tk.Y)
            
            # Store reference to scrollable_frame for adding new scripts
            tab_info[tab_name] = {
                'scrollable_frame': scrollable_frame,
                'on_mousewheel': on_mousewheel,
                'row_colors': row_colors,
                'header_color': header_color
            }
            
            return tab_frame
        
        # Create BO tab (blue header)
        if bo_tps:
            bo_tab = create_tps_tab(notebook, bo_tps, "BO", '#4472C4')
            notebook.add(bo_tab, text=f"1 - BO ({len(bo_tps)})")
        
        # Create FO tab (green header)
        if fo_tps:
            fo_tab = create_tps_tab(notebook, fo_tps, "FO", '#70AD47')
            notebook.add(fo_tab, text=f"2 - FO ({len(fo_tps)})")
        
        def save_tps_values():
            """Save TPS values and close dialog."""
            if not hasattr(self, 'custom_target_tps'):
                self.custom_target_tps = {}
            
            # Remove deleted scripts
            for script in deleted_scripts:
                if script in self.custom_target_tps:
                    del self.custom_target_tps[script]
            
            # Save current values
            for script, tps_var in tps_entries.items():
                try:
                    tps_value = float(tps_var.get())
                    self.custom_target_tps[script] = tps_value
                except ValueError:
                    pass  # Skip invalid values
            
            self.log(f"Saved Target TPS for {len(self.custom_target_tps)} scripts")
            
            # Save to persistent file
            self._save_custom_target_tps()
            
            dialog.destroy()
            messagebox.showinfo("Success", f"Target TPS values saved for {len(self.custom_target_tps)} scripts.\n\nThese will be used in report generation.", parent=self.root)
        
        def add_new_script():
            """Open dialog to add a new script with Target TPS."""
            add_dialog = tk.Toplevel(dialog)
            add_dialog.title("Add New Script")
            add_dialog.geometry("450x200")
            add_dialog.transient(dialog)
            add_dialog.grab_set()
            
            # Center dialog
            add_dialog.update_idletasks()
            x = dialog.winfo_x() + (dialog.winfo_width() - 450) // 2
            y = dialog.winfo_y() + (dialog.winfo_height() - 200) // 2
            add_dialog.geometry(f"450x200+{x}+{y}")
            
            # Form frame
            form_frame = ttk.Frame(add_dialog, padding=15)
            form_frame.pack(fill=tk.BOTH, expand=True)
            
            # Script Name
            ttk.Label(form_frame, text="Script Name:", font=('Segoe UI', 10, 'bold')).grid(row=0, column=0, sticky='w', pady=5)
            script_name_var = tk.StringVar()
            script_entry = ttk.Entry(form_frame, textvariable=script_name_var, width=35)
            script_entry.grid(row=0, column=1, pady=5, padx=5)
            
            # Target TPS
            ttk.Label(form_frame, text="Target TPS:", font=('Segoe UI', 10, 'bold')).grid(row=1, column=0, sticky='w', pady=5)
            tps_value_var = tk.StringVar(value="0")
            tps_entry_widget = ttk.Entry(form_frame, textvariable=tps_value_var, width=15)
            tps_entry_widget.grid(row=1, column=1, sticky='w', pady=5, padx=5)
            
            # Category (BO/FO)
            ttk.Label(form_frame, text="Category:", font=('Segoe UI', 10, 'bold')).grid(row=2, column=0, sticky='w', pady=5)
            category_var = tk.StringVar(value="FO")  # Default to FO since shown screenshot is FO tab
            category_frame = ttk.Frame(form_frame)
            category_frame.grid(row=2, column=1, sticky='w', pady=5, padx=5)
            ttk.Radiobutton(category_frame, text="BO (Back Office)", variable=category_var, value="BO").pack(side=tk.LEFT)
            ttk.Radiobutton(category_frame, text="FO (Front Office)", variable=category_var, value="FO").pack(side=tk.LEFT, padx=10)
            
            def confirm_add():
                script_name = script_name_var.get().strip()
                if not script_name:
                    messagebox.showwarning("Warning", "Please enter a script name.", parent=add_dialog)
                    return
                
                if script_name in tps_entries:
                    messagebox.showwarning("Warning", f"Script '{script_name}' already exists.", parent=add_dialog)
                    return
                
                try:
                    tps_value = float(tps_value_var.get())
                except ValueError:
                    messagebox.showwarning("Warning", "Please enter a valid Target TPS value.", parent=add_dialog)
                    return
                
                category = category_var.get()
                
                # Add to custom_target_tps
                if not hasattr(self, 'custom_target_tps'):
                    self.custom_target_tps = {}
                self.custom_target_tps[script_name] = tps_value
                
                # Store category info
                if not hasattr(self, 'custom_script_categories'):
                    self.custom_script_categories = {}
                self.custom_script_categories[script_name] = category
                
                # Add to current data
                if category == "BO":
                    current_bo_tps[script_name] = tps_value
                else:
                    current_fo_tps[script_name] = tps_value
                
                # Add visual row to the appropriate tab
                if category in tab_info:
                    info = tab_info[category]
                    scrollable_frame = info['scrollable_frame']
                    on_mousewheel = info['on_mousewheel']
                    row_colors = info['row_colors']
                    
                    # Calculate row number
                    idx = len([s for s in tps_entries if (s in current_bo_tps if category == "BO" else s in current_fo_tps)]) + 1
                    row_bg = row_colors[idx % 2]
                    
                    row_frame = tk.Frame(scrollable_frame, bg=row_bg)
                    row_frame.pack(fill=tk.X)
                    row_frame.bind("<MouseWheel>", on_mousewheel)
                    
                    # Serial number
                    tk.Label(row_frame, text=str(idx), width=6, bg=row_bg, anchor='center').pack(side=tk.LEFT, padx=2, pady=3)
                    
                    # Script name label
                    tk.Label(row_frame, text=script_name, width=40, bg=row_bg, anchor='w').pack(side=tk.LEFT, padx=2, pady=3)
                    
                    # TPS entry
                    tps_var = tk.StringVar(value=str(tps_value))
                    tps_entry_new = ttk.Entry(row_frame, textvariable=tps_var, width=12, justify='center')
                    tps_entry_new.pack(side=tk.LEFT, padx=2, pady=3)
                    tps_entry_new.bind("<MouseWheel>", on_mousewheel)
                    
                    # Delete button
                    del_btn = tk.Button(row_frame, text="🗑", fg='red', bg=row_bg, 
                                       font=('Segoe UI', 9), bd=0, cursor='hand2',
                                       command=lambda s=script_name, r=row_frame, t=category: delete_script(s, r, t))
                    del_btn.pack(side=tk.LEFT, padx=5, pady=3)
                    
                    tps_entries[script_name] = tps_var
                    row_frames[script_name] = row_frame
                
                # Update summary
                update_summary()
                
                add_dialog.destroy()
                messagebox.showinfo("Success", f"Added new script:\n\n{script_name} = {tps_value} TPS ({category})", parent=dialog)
            
            # Buttons
            btn_frame2 = ttk.Frame(form_frame)
            btn_frame2.grid(row=3, column=0, columnspan=2, pady=15)
            
            add_btn = tk.Button(btn_frame2, text="➕ Add", command=confirm_add,
                               font=('Segoe UI', 10, 'bold'),
                               bg='#2196F3', fg='white',
                               activebackground='#1976D2',
                               padx=20, pady=5, cursor='hand2')
            add_btn.pack(side=tk.LEFT, padx=5)
            
            cancel_btn2 = tk.Button(btn_frame2, text="Cancel", command=add_dialog.destroy,
                                   font=('Segoe UI', 10),
                                   padx=15, pady=5, cursor='hand2')
            cancel_btn2.pack(side=tk.LEFT, padx=5)
            
            script_entry.focus()
        
        def import_from_excel():
            """Import Target TPS values from an Excel file's Target_TPS sheet."""
            from tkinter import filedialog
            
            file_path = filedialog.askopenfilename(
                title="Select Excel file with Target_TPS sheet",
                filetypes=[("Excel files", "*.xlsx"), ("All files", "*.*")],
                parent=dialog
            )
            
            if not file_path:
                return
            
            try:
                from openpyxl import load_workbook
                wb = load_workbook(file_path, read_only=True)
                
                if 'Target_TPS' not in wb.sheetnames:
                    messagebox.showerror("Error", "No 'Target_TPS' sheet found in the selected Excel file.", parent=dialog)
                    return
                
                ws = wb['Target_TPS']
                imported_count = 0
                
                # Read rows - skip header and section headers
                for row in ws.iter_rows(min_row=2, values_only=True):
                    if row[1] and row[3]:  # Script Name (col B) and Target TPS (col D)
                        script_name = str(row[1]).strip()
                        try:
                            tps_value = float(row[3])
                            
                            # Update entry if script exists
                            if script_name in tps_entries:
                                tps_entries[script_name].set(str(tps_value))
                                imported_count += 1
                            else:
                                # Add as new custom TPS
                                if not hasattr(self, 'custom_target_tps'):
                                    self.custom_target_tps = {}
                                self.custom_target_tps[script_name] = tps_value
                                imported_count += 1
                        except (ValueError, TypeError):
                            pass  # Skip invalid TPS values
                
                wb.close()
                messagebox.showinfo("Import Success", f"Imported Target TPS for {imported_count} scripts from:\n{os.path.basename(file_path)}", parent=dialog)
                
            except Exception as e:
                messagebox.showerror("Import Error", f"Failed to import from Excel:\n{str(e)}", parent=dialog)
        
        def export_to_excel():
            """Export current Target TPS values to a standalone Excel file."""
            from tkinter import filedialog
            from lrr_parser import TARGET_TPS_LOOKUP, BO_USECASES
            
            file_path = filedialog.asksaveasfilename(
                title="Save Target TPS to Excel",
                defaultextension=".xlsx",
                filetypes=[("Excel files", "*.xlsx")],
                initialfilename="Target_TPS_Values.xlsx",
                parent=dialog
            )
            
            if not file_path:
                return
            
            try:
                from openpyxl import Workbook
                from openpyxl.styles import Font, PatternFill, Border, Side, Alignment
                
                wb = Workbook()
                ws = wb.active
                ws.title = "Target_TPS"
                
                # Build combined TPS lookup from current values
                combined_tps = {}
                for script, tps_var in tps_entries.items():
                    try:
                        combined_tps[script] = float(tps_var.get())
                    except ValueError:
                        combined_tps[script] = 0.0
                
                # Headers
                border = Border(
                    left=Side(style='thin'),
                    right=Side(style='thin'),
                    top=Side(style='thin'),
                    bottom=Side(style='thin')
                )
                header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
                headers = ['SL No', 'Script Name', 'Category', 'Target TPS', 'Source']
                
                for col, header in enumerate(headers, 1):
                    cell = ws.cell(row=1, column=col, value=header)
                    cell.font = Font(bold=True, color='FFFFFF')
                    cell.fill = header_fill
                    cell.border = border
                    cell.alignment = Alignment(horizontal='center')
                
                # Separate BO and FO
                bo_scripts = [(s, t, 'BO') for s, t in combined_tps.items() if s in BO_USECASES]
                fo_scripts = [(s, t, 'FO') for s, t in combined_tps.items() if s not in BO_USECASES]
                
                current_row = 2
                
                # BO Section
                bo_fill = PatternFill(start_color='FFC000', end_color='FFC000', fill_type='solid')
                ws.merge_cells(f'A{current_row}:E{current_row}')
                bo_header = ws.cell(row=current_row, column=1, value=f'BACK OFFICE USECASES ({len(bo_scripts)} scripts)')
                bo_header.font = Font(bold=True, size=11)
                bo_header.fill = bo_fill
                current_row += 1
                
                light_bo = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')
                for idx, (script, tps, cat) in enumerate(sorted(bo_scripts), 1):
                    source = 'Custom' if hasattr(self, 'custom_target_tps') and script in self.custom_target_tps else 'Built-in'
                    for col, val in enumerate([idx, script, cat, tps, source], 1):
                        cell = ws.cell(row=current_row, column=col, value=val)
                        cell.border = border
                        cell.fill = light_bo
                        if col == 4:
                            cell.number_format = '0.00'
                    current_row += 1
                
                current_row += 1  # Empty row
                
                # FO Section
                fo_fill = PatternFill(start_color='5B9BD5', end_color='5B9BD5', fill_type='solid')
                ws.merge_cells(f'A{current_row}:E{current_row}')
                fo_header = ws.cell(row=current_row, column=1, value=f'FRONTEND USECASES ({len(fo_scripts)} scripts)')
                fo_header.font = Font(bold=True, size=11, color='FFFFFF')
                fo_header.fill = fo_fill
                current_row += 1
                
                light_fo = PatternFill(start_color='DEEBF7', end_color='DEEBF7', fill_type='solid')
                for idx, (script, tps, cat) in enumerate(sorted(fo_scripts), 1):
                    source = 'Custom' if hasattr(self, 'custom_target_tps') and script in self.custom_target_tps else 'Built-in'
                    for col, val in enumerate([idx, script, cat, tps, source], 1):
                        cell = ws.cell(row=current_row, column=col, value=val)
                        cell.border = border
                        cell.fill = light_fo
                        if col == 4:
                            cell.number_format = '0.00'
                    current_row += 1
                
                # Column widths
                ws.column_dimensions['A'].width = 8
                ws.column_dimensions['B'].width = 60
                ws.column_dimensions['C'].width = 12
                ws.column_dimensions['D'].width = 12
                ws.column_dimensions['E'].width = 12
                
                wb.save(file_path)
                messagebox.showinfo("Export Success", f"Target TPS values exported to:\n{file_path}", parent=dialog)
                
                # Ask to open file
                if messagebox.askyesno("Open File", "Open the exported file?", parent=dialog):
                    os.startfile(file_path)
                    
            except Exception as e:
                messagebox.showerror("Export Error", f"Failed to export to Excel:\n{str(e)}", parent=dialog)
        
        # Import button
        import_btn = tk.Button(btn_frame, text="📥 Import", command=import_from_excel,
                              font=('Segoe UI', 10),
                              bg='#9C27B0', fg='white',
                              activebackground='#7B1FA2',
                              padx=10, pady=5, cursor='hand2')
        import_btn.pack(side=tk.LEFT, padx=3)
        
        # Export button
        export_btn = tk.Button(btn_frame, text="📤 Export", command=export_to_excel,
                              font=('Segoe UI', 10),
                              bg='#607D8B', fg='white',
                              activebackground='#455A64',
                              padx=10, pady=5, cursor='hand2')
        export_btn.pack(side=tk.LEFT, padx=3)
        
        # Add New button
        add_new_btn = tk.Button(btn_frame, text="➕ Add New", command=add_new_script,
                               font=('Segoe UI', 10, 'bold'),
                               bg='#2196F3', fg='white',
                               activebackground='#1976D2',
                               padx=15, pady=5, cursor='hand2')
        add_new_btn.pack(side=tk.LEFT, padx=5)
        
        # Save button
        save_btn = tk.Button(btn_frame, text="💾 Save", command=save_tps_values,
                            font=('Segoe UI', 10, 'bold'),
                            bg='#4CAF50', fg='white',
                            activebackground='#388E3C',
                            padx=20, pady=5, cursor='hand2')
        save_btn.pack(side=tk.RIGHT, padx=5)
        
        # Undo button (initially disabled)
        undo_btn = tk.Button(btn_frame, text="↩ Undo", command=undo_last_action,
                             font=('Segoe UI', 10),
                             bg='#CCCCCC', fg='white',
                             activebackground='#F57C00',
                             padx=15, pady=5, cursor='hand2',
                             state='disabled')
        undo_btn.pack(side=tk.RIGHT, padx=5)
        
        # Cancel button
        cancel_btn = tk.Button(btn_frame, text="Cancel", command=dialog.destroy,
                              font=('Segoe UI', 10),
                              padx=15, pady=5, cursor='hand2')
        cancel_btn.pack(side=tk.RIGHT, padx=5)
        
        # Summary label
        total_scripts = len(bo_tps) + len(fo_tps)
        summary_label = ttk.Label(btn_frame, text=f"Total: {total_scripts} scripts ({len(bo_tps)} BO + {len(fo_tps)} FO)")
        summary_label.pack(side=tk.LEFT, padx=10)

    def show_vuser_editor(self):
        """Show a dialog to edit VUser counts for each script from ALL controllers."""
        import re
        from lrr_parser import LRRParser
        
        # Collect all input paths from all controllers
        all_paths = []
        for i, (inp_var, ext_var) in enumerate([
            (self.input_path1, self.extracted_path1),
            (self.input_path2, self.extracted_path2),
            (self.input_path3, self.extracted_path3),
            (self.input_path4, self.extracted_path4),
        ], start=1):
            # Prioritize extracted path
            path = ext_var.get().strip()
            if not path:
                path = inp_var.get().strip()
            
            # Skip zip files and empty paths
            if path and not path.lower().endswith('.zip') and os.path.isdir(path):
                all_paths.append((i, path))
        
        if not all_paths:
            messagebox.showwarning("Warning", "Please provide at least one valid input folder path.\n\nIf using ZIP files, click 'FetchDetail' first.", parent=self.root)
            return
        
        # Extract script names from transactions
        def extract_script_name(trans_name):
            match = re.search(r'_T(\d{2})', trans_name)
            if match:
                pos = match.start()
                return trans_name[:pos]
            return trans_name
        
        # Collect scripts from ALL controllers
        all_scripts = set()
        all_vuser_counts = {}
        scenario_name = None
        
        # Normalize script name to handle variations like ITR1Online vs ITR1_Online
        def normalize_script_name(name):
            """Normalize script name - add underscore before Online/Offline if missing."""
            import re
            # Generic normalization: Add underscore before Online/Offline if missing
            # Examples: ITR1Online -> ITR1_Online, BulkFetchOnline -> BulkFetch_Online
            normalized = re.sub(r'([a-zA-Z0-9])(Online|Offline)\b', r'\1_\2', name, flags=re.IGNORECASE)
            return normalized
        
        # Track normalized names to avoid duplicates
        normalized_to_original = {}
        
        self.log(f"Scanning {len(all_paths)} controller(s) for scripts...")
        
        for controller_num, input_path in all_paths:
            # Find LRR file
            lrr_files = [f for f in os.listdir(input_path) if f.endswith('.lrr')]
            if not lrr_files:
                self.log(f"  C{controller_num}: No .lrr file found, skipping")
                continue
            
            lrr_path = os.path.join(input_path, lrr_files[0])
            
            try:
                # Parse to get transaction names
                parser = LRRParser(lrr_path)
                parser.parse()
                
                # Get scenario name from first controller
                if scenario_name is None:
                    try:
                        import configparser
                        config = configparser.ConfigParser()
                        config.read(lrr_path, encoding='utf-8-sig')
                        if config.has_section('Scenario'):
                            scenario_name = config.get('Scenario', 'Subject', fallback=None)
                    except:
                        pass
                
                # Collect scripts from this controller
                controller_scripts = set()
                for trans in parser.transaction_summary:
                    name = trans.get('transaction_name', '')
                    if 'vuser_init' not in name.lower() and 'vuser_end' not in name.lower() and 'action' not in name.lower():
                        script = extract_script_name(name)
                        normalized = normalize_script_name(script)
                        # Use normalized name, keep track of original
                        if normalized not in normalized_to_original:
                            normalized_to_original[normalized] = script
                        controller_scripts.add(normalized)
                        all_scripts.add(normalized)
                
                # Merge vuser counts (prefer existing values)
                for script, count in parser.script_vuser_counts.items():
                    normalized = normalize_script_name(script)
                    if normalized not in all_vuser_counts:
                        all_vuser_counts[normalized] = count
                
                self.log(f"  C{controller_num}: Found {len(controller_scripts)} scripts")
                
            except Exception as e:
                self.log(f"  C{controller_num}: Error - {e}")
        
        if not all_scripts:
            messagebox.showinfo("Info", "No scripts found in any controller folders.", parent=self.root)
            return
        
        self.log(f"Total unique scripts found: {len(all_scripts)}")
        
        # Create editor dialog with combined scripts
        self._show_vuser_dialog(sorted(all_scripts), all_vuser_counts, scenario_name)
    
    def _show_vuser_dialog(self, scripts, current_counts, scenario_name=None):
        """Show dialog to edit vuser counts - separated by BO and FO tabs."""
        dialog = tk.Toplevel(self.root)
        dialog.title("Edit VUser Counts")
        dialog.geometry("600x600")
        dialog.transient(self.root)
        dialog.grab_set()
        
        # Center the dialog
        dialog.update_idletasks()
        x = (dialog.winfo_screenwidth() - 600) // 2
        y = (dialog.winfo_screenheight() - 600) // 2
        dialog.geometry(f"600x600+{x}+{y}")
        
        # Helper to determine if script is FO
        # FO scripts contain ITR followed by a digit (ITR1, ITR2, etc.)
        # EXCEPTION: ITR_Collection_Report is BO, not FO
        import re
        def is_fo_script(script_name):
            script_upper = script_name.upper()
            # Exception: ITR_Collection_Report is BO
            if 'ITR_COLLECTION' in script_upper or 'ITRCOLLECTION' in script_upper:
                return False  # This is BO
            # ITR followed by digit anywhere in name (ITR1, ITR2, ITR3, ITR4, ER003_ITR3, etc.)
            if re.search(r'ITR\d', script_upper):
                return True
            # Contains _FO or starts with FO_
            if '_FO' in script_upper or script_upper.startswith('FO_'):
                return True
            return False
        
        # Separate BO and FO scripts - FO scripts go to FO tab, rest to BO tab
        bo_scripts = [s for s in scripts if not is_fo_script(s)]
        fo_scripts = [s for s in scripts if is_fo_script(s)]
        
        # Title
        title_label = ttk.Label(dialog, text="Edit VUser Counts for Scripts", 
                                font=('Segoe UI', 12, 'bold'))
        title_label.pack(pady=10)
        
        # Scenario name display
        if scenario_name:
            scenario_label = ttk.Label(dialog, text=f"Scenario: {scenario_name}",
                                       font=('Segoe UI', 10, 'bold'), foreground='#1565C0')
            scenario_label.pack(pady=2)
            info_text = f"Values will be saved to: {scenario_name}_vusers.txt"
        else:
            info_text = "Values will be saved to: vuser_presets.txt"
        
        info_label = ttk.Label(dialog, text=info_text,
                               font=('Segoe UI', 9), foreground='gray')
        info_label.pack(pady=5)
        
        # Script count summary
        summary_label = ttk.Label(dialog, 
                                  text=f"BO Scripts: {len(bo_scripts)} | FO Scripts: {len(fo_scripts)} | Total: {len(scripts)}",
                                  font=('Segoe UI', 9), foreground='#666666')
        summary_label.pack(pady=2)
        
        # Create notebook for tabs
        notebook = ttk.Notebook(dialog)
        notebook.pack(fill=tk.BOTH, expand=True, padx=10, pady=5)
        
        # Store entry widgets
        entries = {}
        
        def create_scripts_page(parent, script_list, tab_name):
            """Create a scrollable page for scripts."""
            frame = ttk.Frame(parent)
            
            # Create scrollable frame
            canvas = tk.Canvas(frame, highlightthickness=0)
            scrollbar = ttk.Scrollbar(frame, orient="vertical", command=canvas.yview)
            scrollable_frame = ttk.Frame(canvas)
            
            scrollable_frame.bind(
                "<Configure>",
                lambda e: canvas.configure(scrollregion=canvas.bbox("all"))
            )
            
            canvas.create_window((0, 0), window=scrollable_frame, anchor="nw")
            canvas.configure(yscrollcommand=scrollbar.set)
            
            # Header row
            header_frame = ttk.Frame(scrollable_frame)
            header_frame.pack(fill=tk.X, padx=10, pady=5)
            ttk.Label(header_frame, text="Script Name", font=('Segoe UI', 10, 'bold'), width=35).pack(side=tk.LEFT)
            ttk.Label(header_frame, text="VUser Count", font=('Segoe UI', 10, 'bold'), width=12).pack(side=tk.LEFT)
            
            ttk.Separator(scrollable_frame, orient='horizontal').pack(fill=tk.X, padx=10, pady=2)
            
            if not script_list:
                # Show message if no scripts
                no_scripts_label = ttk.Label(scrollable_frame, 
                                             text=f"No {tab_name} scripts found.\n\nScripts will appear here automatically\nwhen you load .lrr files.", 
                                             font=('Segoe UI', 10), foreground='gray')
                no_scripts_label.pack(pady=50)
            else:
                # Add entry for each script
                for script in sorted(script_list):
                    row_frame = ttk.Frame(scrollable_frame)
                    row_frame.pack(fill=tk.X, padx=10, pady=2)
                    
                    ttk.Label(row_frame, text=script, font=('Segoe UI', 9), width=35, anchor='w').pack(side=tk.LEFT)
                    
                    entry = ttk.Entry(row_frame, width=10, font=('Segoe UI', 9))
                    entry.pack(side=tk.LEFT, padx=5)
                    
                    # Set current value
                    current_val = current_counts.get(script, 0)
                    entry.insert(0, str(current_val))
                    
                    entries[script] = entry
            
            canvas.pack(side="left", fill="both", expand=True)
            scrollbar.pack(side="right", fill="y")
            
            # Mouse wheel scrolling for this canvas
            def _on_mousewheel(event):
                canvas.yview_scroll(int(-1*(event.delta/120)), "units")
            
            canvas.bind("<Enter>", lambda e: canvas.bind_all("<MouseWheel>", _on_mousewheel))
            canvas.bind("<Leave>", lambda e: canvas.unbind_all("<MouseWheel>"))
            
            return frame
        
        # Create BO tab (Page 1)
        bo_frame = create_scripts_page(notebook, bo_scripts, "BO (Back Office)")
        notebook.add(bo_frame, text=f"  1 - BO ({len(bo_scripts)})  ")
        
        # Create FO tab (Page 2)
        fo_frame = create_scripts_page(notebook, fo_scripts, "FO (Front Office)")
        notebook.add(fo_frame, text=f"  2 - FO ({len(fo_scripts)})  ")
        
        # Buttons frame
        btn_frame = ttk.Frame(dialog)
        btn_frame.pack(pady=15)
        
        def save_and_close():
            """Save vuser counts to scenario-specific file."""
            try:
                presets_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'TargetTPS_Presets')
                
                # Use scenario-specific filename if available
                if scenario_name:
                    preset_filename = f'{scenario_name}_vusers.txt'
                else:
                    preset_filename = 'vuser_presets.txt'
                
                preset_path = os.path.join(presets_folder, preset_filename)
                
                # Ensure folder exists
                os.makedirs(presets_folder, exist_ok=True)
                
                # Write new file
                with open(preset_path, 'w', encoding='utf-8') as f:
                    # Write header comments
                    f.write(f"# VUser Presets for Scenario: {scenario_name or 'Generic'}\n")
                    f.write("# Format: script_name,vuser_count\n")
                    f.write(f"# Auto-generated from VUser Editor\n")
                    f.write("# " + "="*50 + "\n\n")
                    
                    # Write script counts
                    for script in sorted(entries.keys()):
                        entry = entries[script]
                        try:
                            count = int(entry.get().strip() or '0')
                        except ValueError:
                            count = 0
                        f.write(f"{script},{count}\n")
                
                self.log(f"VUser counts saved to: {preset_path}")
                messagebox.showinfo("Success", 
                    f"VUser counts saved!\n\n"
                    f"File: {preset_filename}\n"
                    f"Scripts: {len(entries)}\n\n"
                    f"This file will be auto-loaded when you\n"
                    f"generate reports for scenario: {scenario_name or 'any'}", parent=dialog)
                dialog.destroy()
                
            except Exception as e:
                messagebox.showerror("Error", f"Failed to save:\n{str(e)}", parent=dialog)
        
        save_btn = tk.Button(btn_frame, text="💾 Save", command=save_and_close,
                             font=('Segoe UI', 10, 'bold'),
                             bg='#2E7D32', fg='white',
                             padx=20, pady=5, cursor='hand2')
        save_btn.pack(side=tk.LEFT, padx=10)
        
        cancel_btn = tk.Button(btn_frame, text="Cancel", command=dialog.destroy,
                               font=('Segoe UI', 10),
                               padx=20, pady=5, cursor='hand2')
        cancel_btn.pack(side=tk.LEFT, padx=10)
        
        dialog.protocol("WM_DELETE_WINDOW", dialog.destroy)

    def generate_pdf_report(self):
        """Generate PDF report similar to LoadRunner Analysis PDF."""
        try:
            from pdf_report import generate_pdf_report
            
            # Get input paths - prioritize extracted paths (already unzipped folders)
            raw_inputs = []
            for i, (inp, ext) in enumerate([
                (self.input_path1.get().strip(), self.extracted_path1.get().strip()),
                (self.input_path2.get().strip(), self.extracted_path2.get().strip()),
                (self.input_path3.get().strip(), self.extracted_path3.get().strip()),
                (self.input_path4.get().strip(), self.extracted_path4.get().strip()),
            ]):
                # Prioritize extracted path, then input path
                path = ext if ext else inp
                # Skip zip files - they need to be extracted first
                if path and not path.lower().endswith('.zip'):
                    raw_inputs.append(path)
                elif not path:
                    raw_inputs.append('')
            
            # Filter non-empty paths (already validated as folders)
            input_paths = []
            for path in raw_inputs:
                if path and os.path.isdir(path):
                    input_paths.append(path)
            
            if not input_paths:
                messagebox.showwarning("Warning", "Please provide at least one valid input folder path.\n\nIf using ZIP file, click 'FetchDetail' first to extract.", parent=self.root)
                return
            
            # Get output path
            output_path = self.output_path.get().strip()
            if not output_path:
                output_path = os.path.dirname(input_paths[0]) if input_paths else os.path.expanduser("~/Documents")
            
            # Get report name (stored in script_name field) - REQUIRED
            report_name = self.script_name.get().strip()
            if not report_name:
                messagebox.showwarning("Warning", "Please enter a Report Name before generating PDF report.", parent=self.root)
                return
            
            # Get steady state timings
            ss_timings = [
                (self._parse_time_to_seconds(self.ss_from1.get()), self._parse_time_to_seconds(self.ss_to1.get())),
                (self._parse_time_to_seconds(self.ss_from2.get()), self._parse_time_to_seconds(self.ss_to2.get())),
                (self._parse_time_to_seconds(self.ss_from3.get()), self._parse_time_to_seconds(self.ss_to3.get())),
                (self._parse_time_to_seconds(self.ss_from4.get()), self._parse_time_to_seconds(self.ss_to4.get())),
            ]
            
            # Validate steady state times for C1 (REQUIRED)
            ss_from_c1, ss_to_c1 = ss_timings[0]
            if ss_from_c1 is None or ss_to_c1 is None:
                # Check if using absolute or relative mode
                if self.steady_state_mode.get() == 'absolute':
                    messagebox.showwarning("Warning", 
                        "Please enter Steady State From and To times for Controller 1 (REQUIRED).\n\n"
                        "Absolute Steady State: HH:MM:SS (e.g., 13:38:56 to 13:49:34)", parent=self.root)
                else:
                    messagebox.showwarning("Warning", 
                        "Please enter Steady State From and To times for Controller 1 (REQUIRED).\n\n"
                        "Relative Steady State: Minutes from test start (e.g., 5 to 15)", parent=self.root)
                return
            
            # Reset progress bar
            self.pdf_progress_var.set(0)
            self.pdf_progress_pct.set("0%")
            self.pdf_progress_step.set("Starting...")
            self.root.update_idletasks()
            
            # Define progress callback for UI updates
            def update_pdf_progress(percent, step):
                self.pdf_progress_var.set(percent)
                self.pdf_progress_pct.set(f"{int(percent)}%")
                self.pdf_progress_step.set(step)
                self.root.update_idletasks()
            
            self.log("Generating PDF report...")
            
            # Parse the first input
            from lrr_parser import LRRParser
            
            first_path = input_paths[0]
            lrr_files = [f for f in os.listdir(first_path) if f.endswith('.lrr')]
            
            if not lrr_files:
                messagebox.showerror("Error", f"No .lrr file found in: {first_path}", parent=self.root)
                return
            
            lrr_path = os.path.join(first_path, lrr_files[0])
            parser = LRRParser(lrr_path)
            
            # Set steady state if provided
            ss_from, ss_to = ss_timings[0]
            if ss_from is not None and ss_to is not None:
                parser.set_steady_state(ss_from, ss_to, is_absolute=True)
            
            parser.parse()
            
            # Merge other controllers if present
            for i, path in enumerate(input_paths[1:], start=1):
                if path and os.path.exists(path):
                    other_lrr_files = [f for f in os.listdir(path) if f.endswith('.lrr')]
                    if other_lrr_files:
                        other_lrr_path = os.path.join(path, other_lrr_files[0])
                        other_parser = LRRParser(other_lrr_path)
                        
                        ss_from, ss_to = ss_timings[i]
                        if ss_from is not None and ss_to is not None:
                            other_parser.set_steady_state(ss_from, ss_to, is_absolute=True)
                        
                        other_parser.parse()
                        parser.merge(other_parser)
            
            # Determine filename
            folder_name = os.path.basename(first_path.rstrip('/\\'))
            scenario_name = report_name or folder_name
            
            # Generate PDF path
            pdf_filename = f"{scenario_name}.pdf"
            pdf_path = os.path.join(output_path, pdf_filename)
            
            # Get selected report types
            report_types = self._get_selected_report_types()
            
            # Generate PDF with progress callback
            result_path = generate_pdf_report(parser, pdf_path, scenario_name, report_types, update_pdf_progress)
            
            self.log(f"PDF report generated: {result_path}")
            
            # Upload to Confluence if checkbox was pre-selected
            if self.upload_to_confluence.get():
                self._upload_to_confluence(result_path, scenario_name)
            
            # Ask to open
            if messagebox.askyesno("Success", f"PDF report generated successfully!\n\n{result_path}\n\nOpen the file?", parent=self.root):
                os.startfile(result_path)
            
            # Reset progress to ready state after completion
            self.pdf_progress_step.set("✓ Ready")
            
            # Ask if user wants to upload to Confluence (if not already uploaded)
            if not self.upload_to_confluence.get():
                if messagebox.askyesno("Upload to Confluence", 
                    "Do you want to upload this PDF report to Confluence?", parent=self.root):
                    self._prompt_confluence_upload(result_path, scenario_name)
                
        except ImportError as e:
            self.log(f"ERROR: PDF generation requires reportlab library. Run: pip install reportlab")
            self.pdf_progress_var.set(0)
            self.pdf_progress_pct.set("0%")
            self.pdf_progress_step.set("✗ Error: Missing reportlab")
            messagebox.showerror("Error", "PDF generation requires reportlab library.\n\nRun: pip install reportlab", parent=self.root)
        except Exception as e:
            self.log(f"ERROR generating PDF: {str(e)}")
            self.pdf_progress_var.set(0)
            self.pdf_progress_pct.set("0%")
            self.pdf_progress_step.set("✗ Error")
            messagebox.showerror("Error", f"Failed to generate PDF report:\n\n{str(e)}", parent=self.root)


def main():
    # Clear Python bytecode cache to ensure latest code is used
    # This prevents stale cached code from causing issues after file updates
    import shutil
    import importlib
    
    cache_dir = os.path.join(os.path.dirname(__file__), '__pycache__')
    if os.path.exists(cache_dir):
        try:
            shutil.rmtree(cache_dir)
        except Exception:
            pass  # Ignore errors (files may be locked)
    
    # Force reload lrr_parser to ensure latest code is used
    import lrr_parser
    importlib.reload(lrr_parser)
    
    root = tk.Tk()
    app = LoadRunnerReportApp(root)
    try:
        root.mainloop()
    except KeyboardInterrupt:
        # Handle Ctrl+C gracefully
        app._on_closing()


if __name__ == '__main__':
    main()
