#!/usr/bin/env python3
"""
Targeted regression test for the per-controller script-name -> vuser-count
lookup that powers Column J ("Current User Count") in FinalReport.

Reproduces the failure modes diagnosed from the LRR_LOOKUP_TRACE TSV:
  - 38.1_FO092_PaymentAPI_DoubleVerification_V1.3_1 etc. should normalize
    to the same canonical key as the FinalReport row
    `FO092_PaymentAPI_DoubleVerification`.
  - Substring fuzzy must NOT match `EVerification` (1250) to
    `FO092_PaymentAPI_DoubleVerification` (chars borrowed from
    "doubleverification").
  - `Payments_IncomeTax_*` script rows must match `Payments_*` /
    `Payment_*` LR group names (singular/plural canonicalization +
    middle-token IncomeTax strip).
  - Jaccard fallback bridges small differences like
    `FO009_VerifyYourPan_PostLogin` <-> `VerifyPan_PostLogin`.

Run:
    python test_lookup_logic.py
"""
from __future__ import annotations

import re
import sys

# We exercise the lookup by driving the public path: build a minimal stub
# that owns `all_scenario_info` + `script_vuser_counts`, then invoke the
# same `_lookup_in_one_ctrl` logic by importing the helpers from a
# scratch evaluator. The simplest robust approach is to reproduce just
# the normalization + lookup function inline using the same regex
# rules as the parser. To keep this honest (no copy/paste drift), we
# import `LRRParser` and read the *real* normalizer out of an instance
# by calling `export_to_excel` on a fully stubbed parser is heavy; so
# instead we drive a tiny replica that mirrors the parser's
# `_norm_tokens` to validate the matching contract.

# --- mirror of parser's `_norm_tokens` (kept in sync intentionally) ---


def _norm_tokens(name):
    s = str(name or '').strip()
    if not s:
        return '', set(), []
    s = re.sub(r'^[\d.]+[._]', '', s)
    s = re.sub(r'^[a-zA-Z]+\d{3,}_', '', s)
    s = re.sub(r'_IncomeTax', '', s, flags=re.IGNORECASE)
    s = re.sub(
        r'_(?:'
        r'final|finalv?\d*|modify|modified|new|ntb|'
        r'act\d+(?:_ay[_]?\d+_?\d*)?|'
        r'v\d+[\w.]*|'
        r'ay[_]?\d+_?\d*'
        r').*$',
        '', s, flags=re.IGNORECASE
    )
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s)
    s = re.sub(r'([A-Z])([A-Z][a-z])', r'\1_\2', s)
    s = s.lower()
    s = re.sub(r'[^a-z0-9_]+', '_', s)
    s = re.sub(r'_+', '_', s).strip('_')
    if not s:
        return '', set(), []
    _TOKEN_CANON = {'payments': 'payment', 'prevaliate': 'prevalidate'}
    tokens = []
    for tok in s.split('_'):
        if not tok:
            continue
        tok = _TOKEN_CANON.get(tok, tok)
        tokens.append(tok)
    if not tokens:
        return '', set(), []
    joined = ''.join(tokens)
    starts = set()
    cur = 0
    for tok in tokens:
        starts.add(cur)
        cur += len(tok)
    return joined, starts, tokens


# Mini replica of the parser's per-controller fuzzy chain. Mirrors the
# code in `_lookup_in_one_ctrl` so we can unit-test the contract
# without standing up a full Excel export.

PRE_FILTER_TAGS = [
    ('invalid', lambda s: 'invalid' in s),
    ('error', lambda s: 'error' in s or '_err' in s),
    ('csi', lambda s: 'csi' in s),
    ('history', lambda s: 'history' in s),
]
PAYMENT_TAGS = [
    ('debit', lambda s: 'debit' in s),
    ('neft', lambda s: 'neft' in s or 'rtgs' in s),
    ('cheque', lambda s: 'cheque' in s),
    ('netbank', lambda s: 'netbank' in s),
    ('26qd', lambda s: '26qd' in s),
]


def _lookup_in_one_ctrl(script_key, ctrl_counts):
    if not ctrl_counts:
        return 0
    if script_key in ctrl_counts:
        return int(float(ctrl_counts[script_key]))
    # mapping skipped in test (no SCRIPT_NAME_MAPPING needed for cases here)
    s_joined, s_starts, s_tokens = _norm_tokens(script_key)
    s_tokenset = set(s_tokens)
    # strict-norm MAX
    strict_max = 0
    for g, c in sorted(ctrl_counts.items(), key=lambda kv: str(kv[0]).lower()):
        g_joined, _gs, _gt = _norm_tokens(g)
        if g_joined and s_joined and g_joined == s_joined:
            v = int(float(c))
            if v > strict_max:
                strict_max = v
    if strict_max > 0:
        return strict_max
    # fuzzy with token-start checks
    s_lower = script_key.lower()
    best_score = -1
    best_count = 0
    for g, c in sorted(ctrl_counts.items(), key=lambda kv: str(kv[0]).lower()):
        g_lower = g.lower()
        # prefilters
        skip = False
        for _tag, fn in PRE_FILTER_TAGS:
            if fn(s_lower) != fn(g_lower):
                skip = True
                break
        if skip:
            continue
        if 'payment' in s_lower:
            for _tag, fn in PAYMENT_TAGS:
                if fn(s_lower) != fn(g_lower):
                    skip = True
                    break
            if skip:
                continue
        g_joined, g_starts, g_tokens = _norm_tokens(g)
        g_tokenset = set(g_tokens)
        score = 0
        if s_lower == g_lower:
            score = 1000
        elif s_joined and s_joined == g_joined:
            score = 900
        elif s_lower.startswith(g_lower) and g_lower:
            score = 800 + len(g_lower)
        elif g_lower.startswith(s_lower) and s_lower:
            score = 700 + len(s_lower)
        elif s_joined and g_joined and s_joined in g_joined:
            pos = g_joined.find(s_joined)
            if pos in g_starts:
                score = 600 + len(s_joined)
        elif s_joined and g_joined and g_joined in s_joined:
            pos = s_joined.find(g_joined)
            if pos in s_starts:
                score = 500 + len(g_joined)
        else:
            fm = re.search(r'form(\d+\w*)', s_joined or '')
            if fm and g_joined and f'form{fm.group(1)}' in g_joined:
                score = 400 + len(fm.group(1))
            if score == 0 and s_tokenset and g_tokenset:
                overlap = s_tokenset & g_tokenset
                smaller = min(len(s_tokenset), len(g_tokenset))
                if len(overlap) >= 2 and len(overlap) == smaller:
                    score = 300 + len(overlap) * 10
        if score > best_score:
            best_score = score
            best_count = int(float(c))
        elif score == best_score and int(float(c)) > best_count:
            best_count = int(float(c))
    if best_score > 0 and best_count > 0:
        return best_count
    return 0


# --- Test data: lifted directly from the user's LRR_LOOKUP_TRACE TSV ---

C1 = {
    '05_ITR1_ONLINE_AY26_27_Final': 3315,
    '06_ITR1_OFFLINE_AY26_27_Final': 668,
}
C2 = {
    '11_ITR4_ONLINE_AY26_27_Final': 2210,
    '12_ITR4_OFFLINE_AY26_27_Final': 900,
}
C3 = {
    '22_Form10BA_AY_25_26_Final': 195,
    '23_FORM15G_AY25_26_Final': 212,
    '24_Form15H_AY25_26_Final': 207,
    '26_Form_24Q_AY25_26_Final': 205,
    '27_Form27Q_AY25_26_Final': 200,
    '28_Form_27EQ_AY25_26_Final': 200,
    '36_FO092_PaymentAPI_Bulkchallan_Generation_V1.2': 80,
    '37_FO092_PaymentAPI_Validate_CRN_V1.2': 80,
    '38.1_FO092_PaymentAPI_DoubleVerification_V1.3_1': 10,
    '38.2_FO092_PaymentAPI_DoubleVerification_V1.3_2': 10,
    '38.3_FO092_PaymentAPI_DoubleVerification_V1.3_3': 10,
    '38.4_FO092_PaymentAPI_DoubleVerification_V1.3_4': 10,
    '38.5_FO092_PaymentAPI_DoubleVerification_V1.3_5': 10,
    '38.7_FO092_PaymentAPI_DoubleVerification_V1.3_7': 10,
    '38.8_FO092_PaymentAPI_DoubleVerification_V1.3_8': 10,
    '38.9_FO092_PaymentAPI_DoubleVerification_V1.3_9': 10,
    '39_FO092_Payment_26QDNetBanking_ACT1961_AY26': 25,
    '40_FO092_PaymentsNetBanking_ACT1961_AY26': 190,
    '41_Payments_Debitcard_ACT1961_AY26': 180,
    '42_NEFT_RTGS_ACT1961_AY26': 550,
    '43_FO092_Payment_Cheque__ACT1961_AY26_V.1': 160,
    '44_Payments_DebitCard_Error_AY26_FINAL_V.1': 30,
    '45_Payments_NEFT_RTGS_Error_AY26_Final_V.1': 26,
    '46_Payment_DownloadchallanReceipt_AY26_27_V.1': 190,
    '47_FO092_ViewChallanHistory_AY26': 310,
    '48_Payment_CSIDownload_AY26_Final': 400,
    'Form26Q_2526': 210,
}
C4 = {
    '01_LOGINHERE_AY26_27': 580,
    '02_FO013_Dashboard_AY26_27_Final': 580,
    '03_FO013_UpdateProfileDetails_AY26_27_Final': 750,
    '16_EVerification_AY26_27': 1250,
    '18_Change_Password_AY26_27': 445,
    '19_VerifyPANDetails_AY26_27': 100,
    '20_VerifyPan_PostLogin_AY26_27': 345,
    '21_Prevaliate_AY_26_27': 1380,
}

CONTROLLERS = [C1, C2, C3, C4]


def lookup_max(script_key):
    vals = []
    for ctrl in CONTROLLERS:
        v = _lookup_in_one_ctrl(script_key, ctrl)
        if v > 0:
            vals.append(v)
    return max(vals) if vals else ''


# Cases observed in EX5 (the user-provided trace). Each entry:
#   (script_key, expected_value, description)
# expected_value == '' means: must be blank (no controller matches).
CASES = [
    # Previously working - must continue
    ('FO002_LoginHere',                580, 'norm-match C4 LOGINHERE'),
    ('FO013_Dashboard',                580, 'norm-match C4 Dashboard'),
    ('Update_profile',                 750, 'fuzzy s in g (token-start)'),
    ('ITR1_Online',                   3315, 'norm-match C1 ITR1_ONLINE'),
    ('ITR1_Offline',                   668, 'norm-match C1 ITR1_OFFLINE'),
    ('ITR4_Online',                   2210, 'norm-match C2 ITR4_ONLINE'),
    ('ITR4_Offline',                   900, 'norm-match C2 ITR4_OFFLINE'),
    ('FORM26Q',                        210, 'fuzzy form26q match'),
    ('Payments_IncomeTax_NEFT_RTGS',   550, 'IncomeTax strip + fuzzy g in s'),
    # The critical wrong-match fix
    ('FO092_PaymentAPI_DoubleVerification', 10,
     'must match 38.x_FO092_…_V1.3_x (count 10), NOT 16_EVerification (1250)'),
    # Singular/plural + IncomeTax strip
    ('Payments_IncomeTax_NetBanking',         190, 'payments→payment + IncomeTax strip'),
    ('Payments_IncomeTax_26QDNetBanking',     25,  'IncomeTax strip + payments→payment'),
    ('Payments_IncomeTax_Debitcard',          180, 'payments→payment + IncomeTax strip'),
    ('Payments_IncomeTax_Cheque',             160, 'payments→payment + IncomeTax strip'),
    ('Payments_IncomeTax_Debitcard_Error',    30,  'IncomeTax strip + error prefilter ok'),
    ('Payments_IncomeTax_NEFT_RTGS_Error',    26,  'IncomeTax strip + error prefilter ok'),
    ('Payments_IncomeTax_DownloadChallanReceipt', 190, 'IncomeTax strip + payments→payment'),
    ('Payments_ViewChallanHistory',           310, 'fuzzy g in s at token-start (history prefilter)'),
    ('Payments_IncomeTax_CSIDownload',        400, 'IncomeTax strip + payments→payment (csi prefilter)'),
    # Jaccard fallback case
    ('FO009_VerifyYourPan_PostLogin',         345, 'jaccard tokens overlap'),
    # Truly no match (no controller has a PreLogin variant)
    ('VerifyYourPan_PreLogin',                '',  'no LR group exists; must be blank'),
    # ER_DUMP: prevalidate vs prevaliate typo - acceptable to be blank
    # (user must add SCRIPT_NAME_MAPPING or fix the LR group name)
    ('Prevalidate',                           1380, 'typo canonicalization prevaliate->prevalidate'),
]


def main():
    failed = []
    print('\n=== Lookup contract regression (mirrors lrr_parser._lookup_in_one_ctrl) ===')
    for script_key, expected, desc in CASES:
        got = lookup_max(script_key)
        ok = got == expected
        tag = '[ OK ]' if ok else '[FAIL]'
        print(f'  {tag} {script_key:50s} expected={expected!r:>10}  got={got!r:>10}  ({desc})')
        if not ok:
            failed.append((script_key, expected, got, desc))
    print()
    if failed:
        print(f'RESULT: {len(failed)} of {len(CASES)} cases FAILED.')
        for sk, exp, got, desc in failed:
            print(f'   - {sk}: expected {exp!r}, got {got!r}  ({desc})')
        return 1
    print(f'RESULT: All {len(CASES)} lookup cases passed.')
    return 0


if __name__ == '__main__':
    sys.exit(main())
