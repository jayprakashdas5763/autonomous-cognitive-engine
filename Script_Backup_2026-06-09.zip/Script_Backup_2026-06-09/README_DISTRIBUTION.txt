# LRR Report Generator - Quick Start Guide

## Running the Application

1. Extract the zip file to any folder
2. Double-click **`Launch_LRR_Report_Generator.bat`** or **`LRR_Report_Generator.exe`**

---

## Windows SmartScreen Warning (First Run Only)

On first run, you may see a blue "Windows protected your PC" warning:

**To bypass this warning:**
1. Click **"More info"** (small link at bottom of the blue box)
2. Click **"Run anyway"** button that appears
3. The app will start normally

This warning appears because the app is not signed with a commercial code certificate. 
It is safe to run - you received it from your trusted team member.

---

## What's New in V1.3.1

- Optimized startup time (uses folder distribution instead of single-file)
- All preset files included in the package
- Bug fixes and performance improvements

---

## Troubleshooting

**App won't start?**
- Make sure you extracted ALL files from the zip (not just the .exe)
- Keep all files together in the same folder

**Missing features?**
- Some features require network access to Confluence
- Check your VPN connection if using remote resources

---

## Support

Contact your performance testing team for assistance.
