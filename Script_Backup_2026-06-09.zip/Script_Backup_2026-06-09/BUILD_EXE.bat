@echo off
title Building LRR Report Generator
cd /d "%~dp0"

echo ============================================
echo   Building LRR Report Generator V1.3.1
echo   (Optimized --onedir mode for fast startup)
echo ============================================
echo.

REM Check if PyInstaller is installed
pip show pyinstaller >nul 2>&1
if errorlevel 1 (
    echo Installing PyInstaller...
    pip install pyinstaller -q
)

echo Cleaning previous build...
if exist "dist\LRR_Report_Generator" rmdir /s /q "dist\LRR_Report_Generator"
if exist "build\LRR_Report_Generator" rmdir /s /q "build\LRR_Report_Generator"

echo Building application...
echo.
pyinstaller --clean LRR_Report_Generator.spec

if errorlevel 1 (
    echo.
    echo BUILD FAILED! Check errors above.
    pause
    exit /b 1
)

echo.
echo Creating launcher...
(
echo @echo off
echo cd /d "%%~dp0"
echo start "" "LRR_Report_Generator.exe"
) > "dist\LRR_Report_Generator\Launch_LRR_Report_Generator.bat"

echo.
echo ============================================
echo   BUILD COMPLETE!
echo ============================================
echo.
echo Output folder: dist\LRR_Report_Generator\
echo.
echo To distribute: Zip the entire "LRR_Report_Generator" folder
echo Users run: Launch_LRR_Report_Generator.bat or LRR_Report_Generator.exe
echo.
echo NOTE: On first run, users may see SmartScreen warning.
echo       Click "More info" then "Run anyway"
echo.
pause
