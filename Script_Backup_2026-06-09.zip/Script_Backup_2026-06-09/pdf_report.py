# PDF Report Generator for LoadRunner Results
# Generates reports similar to LoadRunner Analysis PDF format

import os
import re
import io
from datetime import datetime
from reportlab.lib import colors
from reportlab.lib.pagesizes import A4, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch, cm
from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer, PageBreak
from reportlab.platypus import Image as RLImage
from reportlab.lib.enums import TA_CENTER, TA_LEFT, TA_RIGHT
from reportlab.platypus import BaseDocTemplate, PageTemplate, Frame
from reportlab.pdfgen import canvas

# Try to import matplotlib for graph generation
MATLOTLIB_AVAILABLE = False
try:
    import matplotlib
    matplotlib.use('Agg')  # Non-interactive backend for PDF
    import matplotlib.pyplot as plt
    MATLOTLIB_AVAILABLE = True
except ImportError:
    pass


def normalize_script_display_name(name: str) -> str:
    """
    Normalize script name for display - add underscore between script name and Online/Offline.
    Examples: ITR1Online -> ITR1_Online, BulkFetchOnline -> BulkFetch_Online
    """
    if not name:
        return name
    return re.sub(r'([a-zA-Z0-9])(Online|Offline)\b', r'\1_\2', name, flags=re.IGNORECASE)


class NumberedCanvas(canvas.Canvas):
    """Custom canvas that adds page numbers to each page."""
    
    def __init__(self, *args, **kwargs):
        canvas.Canvas.__init__(self, *args, **kwargs)
        self._saved_page_states = []
    
    def showPage(self):
        self._saved_page_states.append(dict(self.__dict__))
        self._startPage()
    
    def save(self):
        """Add page numbers before saving."""
        num_pages = len(self._saved_page_states)
        for state in self._saved_page_states:
            self.__dict__.update(state)
            self.draw_page_number(num_pages)
            canvas.Canvas.showPage(self)
        canvas.Canvas.save(self)
    
    def draw_page_number(self, page_count):
        """Draw page number at the bottom of the page."""
        self.setFont("Helvetica", 9)
        page_num = f"Page {self._pageNumber} of {page_count}"
        # Draw centered at bottom
        self.drawCentredString(A4[0] / 2, 0.5 * cm, page_num)


class LRRPDFReport:
    """Generate PDF reports from LoadRunner parsed data."""
    
    def __init__(self, parser):
        """
        Initialize PDF report generator.
        
        Args:
            parser: LRRParser instance with parsed data
        """
        self.parser = parser
        self.styles = getSampleStyleSheet()
        self._setup_custom_styles()
    
    def _is_fo_script(self, script_name):
        """Determine if a script is an FO (Front Office) script."""
        import re
        script_upper = script_name.upper()
        # Exception: ITR_Collection_Report is BO, not FO
        if 'ITR_COLLECTION' in script_upper or 'ITRCOLLECTION' in script_upper:
            return False  # This is BO
        # FO scripts are ITR followed by digit (ITR1, ITR2, etc.)
        if re.match(r'^ITR\d', script_upper):
            return True
        # Contains _FO or starts with FO_
        if '_FO' in script_upper or script_upper.startswith('FO_'):
            return True
        return False
    
    def _setup_custom_styles(self):
        """Setup custom paragraph styles."""
        # Title style
        self.styles.add(ParagraphStyle(
            name='ReportTitle',
            parent=self.styles['Heading1'],
            fontSize=18,
            alignment=TA_CENTER,
            spaceAfter=20,
            textColor=colors.HexColor('#1a5276')
        ))
        
        # Section header style
        self.styles.add(ParagraphStyle(
            name='SectionHeader',
            parent=self.styles['Heading2'],
            fontSize=14,
            spaceBefore=15,
            spaceAfter=10,
            textColor=colors.HexColor('#2874a6'),
            borderWidth=1,
            borderColor=colors.HexColor('#2874a6'),
            borderPadding=5
        ))
        
        # Sub-section style
        self.styles.add(ParagraphStyle(
            name='SubSection',
            parent=self.styles['Heading3'],
            fontSize=12,
            spaceBefore=10,
            spaceAfter=5,
            textColor=colors.HexColor('#1a5276')
        ))
        
        # Info text style
        self.styles.add(ParagraphStyle(
            name='InfoText',
            parent=self.styles['Normal'],
            fontSize=10,
            spaceBefore=2,
            spaceAfter=2
        ))
    
    def generate(self, output_path: str, scenario_name: str = None, report_types: list = None, progress_callback=None):
        """
        Generate PDF report.
        
        Args:
            output_path: Path for output PDF file
            scenario_name: Optional scenario name for the report title
            report_types: List of report types to include. If None or ['all'], includes all sections.
                         Options: 'transaction_summary', 'tps', 'tps_main', 'errors'
            progress_callback: Optional callback function(percent, step_name) to report progress
        """
        def report_progress(percent, step):
            """Helper to report progress."""
            if progress_callback:
                progress_callback(percent, step)
        
        # Normalize report_types
        if report_types is None or 'all' in report_types:
            include_all = True
        else:
            include_all = False
        
        def should_include(section):
            if include_all:
                return True
            return section in report_types
        
        report_progress(5, "Initializing PDF...")
        
        doc = SimpleDocTemplate(
            output_path,
            pagesize=A4,
            rightMargin=1*cm,
            leftMargin=1*cm,
            topMargin=1.5*cm,
            bottomMargin=1.5*cm
        )
        
        elements = []
        
        # Title
        if not scenario_name:
            scenario_name = getattr(self.parser, 'scenario_name', 'LoadRunner Analysis Report')
        elements.append(Paragraph(scenario_name, self.styles['ReportTitle']))
        elements.append(Spacer(1, 10))
        
        report_progress(10, "Creating Summary Section...")
        # Summary Section - always included
        elements.extend(self._create_summary_section())
        
        # Graphs Section (VUsers and TPS) - include if tps or transaction_summary selected
        if should_include('tps') or should_include('transaction_summary'):
            report_progress(20, "Generating Graphs...")
            elements.extend(self._create_graphs_section())
        
        # Business Process Section - include if transaction_summary selected
        if should_include('transaction_summary'):
            report_progress(40, "Creating Business Process Section...")
            elements.extend(self._create_business_process_section())
        
        # Transaction Summary Section - include if transaction_summary selected
        if should_include('transaction_summary'):
            report_progress(55, "Creating Transaction Summary...")
            elements.extend(self._create_transaction_summary_section())
        
        # TPS Summary Section - include if tps or tps_main selected
        if should_include('tps') or should_include('tps_main'):
            report_progress(70, "Creating TPS Summary...")
            elements.extend(self._create_tps_summary_section())
        
        # Error Summary Section - include if errors selected
        if should_include('errors'):
            report_progress(85, "Creating Error Summary...")
            elements.extend(self._create_error_summary_section())
        
        report_progress(95, "Building PDF document...")
        # Build PDF with page numbers
        doc.build(elements, canvasmaker=NumberedCanvas)
        report_progress(100, "Complete!")
        return output_path
    
    def _create_summary_section(self):
        """Create the summary section - shows Steady State data."""
        elements = []
        elements.append(Paragraph("Analysis Summary", self.styles['SectionHeader']))
        
        # Get summary data from scenario_info dict (correct source)
        scenario_info = getattr(self.parser, 'scenario_info', {})
        max_vusers = getattr(self.parser, 'max_vusers', 0)
        avg_vusers = getattr(self.parser, 'avg_vusers', 0)
        start_time = scenario_info.get('start_time', None)
        
        # Check if user provided steady state
        user_ss = getattr(self.parser, '_user_steady_state', False)
        ss_duration = getattr(self.parser, 'steady_state_duration', 0)
        full_duration = scenario_info.get('duration_seconds', 0)
        
        # Use SS duration if available, otherwise full test duration
        if user_ss and ss_duration > 0:
            duration = ss_duration
            duration_label = "Steady State Duration:"
        else:
            duration = full_duration
            duration_label = "Duration:"
        
        # Format duration
        hours = int(duration // 3600)
        minutes = int((duration % 3600) // 60)
        seconds = int(duration % 60)
        duration_str = f"{hours:02d}:{minutes:02d}:{seconds:02d}"
        
        # Format start time
        if start_time and start_time != 'N/A':
            if isinstance(start_time, datetime):
                start_str = start_time.strftime("%Y-%m-%d %H:%M:%S")
            else:
                start_str = str(start_time)
        else:
            start_str = "N/A"
        
        # Summary table
        summary_data = [
            ["Scenario Start Time:", start_str],
            [duration_label, duration_str],
            ["Maximum Running Vusers (SS):", str(max_vusers)],
            ["Average Running Vusers (SS):", str(avg_vusers)],
        ]
        
        # Add note about steady state filtering
        if user_ss:
            summary_data.append(["Data Scope:", "Steady State Period Only"])
        
        table = Table(summary_data, colWidths=[3*inch, 3*inch])
        table.setStyle(TableStyle([
            ('FONTNAME', (0, 0), (0, -1), 'Helvetica-Bold'),
            ('FONTNAME', (1, 0), (1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 0), (-1, -1), 10),
            ('ALIGN', (0, 0), (0, -1), 'LEFT'),
            ('ALIGN', (1, 0), (1, -1), 'LEFT'),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 6),
            ('TOPPADDING', (0, 0), (-1, -1), 6),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 15))
        
        return elements
    
    def _create_graphs_section(self):
        """Create graphs section with VUsers and TPS charts."""
        elements = []
        
        # Check if matplotlib is available
        if not MATLOTLIB_AVAILABLE:
            elements.append(Paragraph("Graphs", self.styles['SectionHeader']))
            elements.append(Paragraph("Note: Graphs are not available. Install matplotlib for graph support.", 
                                      self.styles.get('InfoText', self.styles['Normal'])))
            elements.append(Spacer(1, 10))
            return elements
        
        # Try to create Full Timeline VUsers graph (with SS highlighted)
        full_vuser_graph = self._create_full_timeline_vuser_graph()
        if full_vuser_graph:
            elements.append(Paragraph("Running Vusers - Full Timeline", self.styles['SectionHeader']))
            elements.append(full_vuser_graph)
            elements.append(Spacer(1, 15))
        
        # Try to create SS-only VUsers graph (zoomed in)
        vuser_graph = self._create_vuser_graph()
        if vuser_graph:
            elements.append(Paragraph("Running Vusers - Steady State", self.styles['SectionHeader']))
            elements.append(vuser_graph)
            elements.append(Spacer(1, 15))
        
        # Try to create Hits per Second graph
        hits_graph = self._create_hits_per_second_graph()
        if hits_graph:
            elements.append(Paragraph("Hits per Second", self.styles['SectionHeader']))
            elements.append(hits_graph)
            elements.append(Spacer(1, 15))
        
        # Try to create Transaction Summary graph
        trans_summary_graph = self._create_transaction_summary_graph()
        if trans_summary_graph:
            elements.append(Paragraph("Transaction Summary", self.styles['SectionHeader']))
            elements.append(trans_summary_graph)
            elements.append(Spacer(1, 15))
        
        # Try to create Average Response Time graph
        response_time_graph = self._create_response_time_graph()
        if response_time_graph:
            elements.append(Paragraph("Average Response Time", self.styles['SectionHeader']))
            elements.append(response_time_graph)
            elements.append(Spacer(1, 15))
        
        # Try to create TPS graph
        tps_graph = self._create_tps_graph()
        if tps_graph:
            elements.append(Paragraph("Transactions per Second", self.styles['SectionHeader']))
            elements.append(tps_graph)
            elements.append(Spacer(1, 15))
        
        # Try to create TPS-Main graph (Last transactions per script)
        tps_main_graph = self._create_tps_main_graph()
        if tps_main_graph:
            elements.append(Paragraph("TPS-Main (Last Transaction per Script)", self.styles['SectionHeader']))
            elements.append(tps_main_graph)
            elements.append(Spacer(1, 15))
        
        return elements
    
    def _create_vuser_graph(self):
        """Create VUsers graph showing ONLY Steady State period (zoomed in)."""
        try:
            # Get vuser data - parser stores all_running_vusers and all_vuser_timestamps
            vusers = getattr(self.parser, 'all_running_vusers', None)
            timestamps = getattr(self.parser, 'all_vuser_timestamps', None)
            
            # Fallback to running_vusers if all_running_vusers not available
            if not vusers or len(vusers) < 2:
                vusers = getattr(self.parser, 'running_vusers', [])
                timestamps = None  # No timestamps available
            
            if not vusers or len(vusers) < 2:
                return None
            
            # Check if user provided steady state - only show SS data
            user_ss = getattr(self.parser, '_user_steady_state', False)
            ss_from_rel = getattr(self.parser, 'steady_state_from_rel', -1)
            ss_to_rel = getattr(self.parser, 'steady_state_to_rel', -1)
            max_vusers = getattr(self.parser, 'max_vusers', 0)
            avg_vusers = getattr(self.parser, 'avg_vusers', 0)
            
            # Convert SS seconds to minutes
            ss_from_min = ss_from_rel / 60 if ss_from_rel > 0 else 0
            ss_to_min = ss_to_rel / 60 if ss_to_rel > 0 else 0
            
            # Create x-axis data
            if timestamps and len(timestamps) == len(vusers):
                min_ts = min(timestamps)
                rel_times = [(ts - min_ts) / 60 for ts in timestamps]
            else:
                rel_times = list(range(len(vusers)))
            
            # Filter to steady state period only if user provided SS times
            if user_ss and ss_from_min > 0 and ss_to_min > 0:
                ss_vusers = []
                ss_times = []
                for t, v in zip(rel_times, vusers):
                    if ss_from_min <= t <= ss_to_min:
                        ss_vusers.append(v)
                        ss_times.append(t - ss_from_min)  # Relative to SS start
                
                if ss_vusers:
                    vusers = ss_vusers
                    rel_times = ss_times
            
            # Create figure
            fig, ax = plt.subplots(figsize=(7, 3))
            ax.plot(rel_times, vusers, color='#2874a6', linewidth=1.5, label='Running VUsers')
            ax.fill_between(rel_times, vusers, alpha=0.3, color='#2874a6')
            
            # Add max VUsers line
            if max_vusers > 0:
                ax.axhline(y=max_vusers, color='red', linestyle=':', linewidth=1.2, alpha=0.7)
                ax.annotate(f'Max: {max_vusers}', xy=(max(rel_times) * 0.95, max_vusers), 
                           fontsize=8, color='red', ha='right', va='bottom')
            
            ax.set_xlabel('Time (minutes from SS start)' if user_ss else 'Time (minutes)', fontsize=9)
            ax.set_ylabel('Running Vusers', fontsize=9)
            
            # Title with Max/Avg info - indicate this is SS only
            if user_ss:
                title = f'Running Vusers - Steady State Only (Max: {max_vusers}, Avg: {avg_vusers})'
            else:
                title = f'Running Vusers Over Time (Max: {max_vusers}, Avg: {avg_vusers})'
            ax.set_title(title, fontsize=10)
            
            ax.grid(True, alpha=0.3)
            ax.set_xlim(0, max(rel_times) if rel_times else 1)
            ax.set_ylim(0, max(vusers) * 1.1 if vusers else 1)
            
            # Save to buffer
            buf = io.BytesIO()
            fig.tight_layout()
            fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
            buf.seek(0)
            plt.close(fig)
            
            # Create reportlab image
            img = RLImage(buf, width=6.5*inch, height=2.5*inch)
            return img
            
        except Exception as e:
            print(f"Error creating VUser graph: {e}")
            return None
    
    def _create_full_timeline_vuser_graph(self):
        """Create VUsers graph showing full timeline with Steady State period highlighted."""
        try:
            # Get vuser data - parser stores all_running_vusers and all_vuser_timestamps
            vusers = getattr(self.parser, 'all_running_vusers', None)
            timestamps = getattr(self.parser, 'all_vuser_timestamps', None)
            
            # Fallback to running_vusers if all_running_vusers not available
            if not vusers or len(vusers) < 2:
                vusers = getattr(self.parser, 'running_vusers', [])
                timestamps = None
            
            if not vusers or len(vusers) < 2:
                return None
            
            # Get steady state info
            user_ss = getattr(self.parser, '_user_steady_state', False)
            ss_from_rel = getattr(self.parser, 'steady_state_from_rel', -1)
            ss_to_rel = getattr(self.parser, 'steady_state_to_rel', -1)
            max_vusers = getattr(self.parser, 'max_vusers', 0)
            avg_vusers = getattr(self.parser, 'avg_vusers', 0)
            
            # Convert SS seconds to minutes
            ss_from_min = ss_from_rel / 60 if ss_from_rel > 0 else None
            ss_to_min = ss_to_rel / 60 if ss_to_rel > 0 else None
            
            # Create x-axis data
            if timestamps and len(timestamps) == len(vusers):
                min_ts = min(timestamps)
                rel_times = [(ts - min_ts) / 60 for ts in timestamps]
            else:
                rel_times = list(range(len(vusers)))
            
            # Create figure
            fig, ax = plt.subplots(figsize=(7, 3))
            ax.plot(rel_times, vusers, color='#2874a6', linewidth=1.5, label='Running VUsers')
            ax.fill_between(rel_times, vusers, alpha=0.3, color='#2874a6')
            
            # Add steady state shading if user provided SS times
            if user_ss and ss_from_min is not None and ss_to_min is not None:
                ax.axvspan(ss_from_min, ss_to_min, alpha=0.25, color='green', label='Steady State')
                ax.axvline(x=ss_from_min, color='green', linestyle='--', linewidth=1.5, alpha=0.8)
                ax.axvline(x=ss_to_min, color='green', linestyle='--', linewidth=1.5, alpha=0.8)
                
                # Add max VUsers line
                if max_vusers > 0:
                    ax.axhline(y=max_vusers, color='red', linestyle=':', linewidth=1.2, alpha=0.7)
                    ax.annotate(f'Max SS: {max_vusers}', xy=(max(rel_times) * 0.95, max_vusers), 
                               fontsize=8, color='red', ha='right', va='bottom')
                
                ax.legend(loc='upper right', fontsize=8)
            
            ax.set_xlabel('Time (minutes)', fontsize=9)
            ax.set_ylabel('Running Vusers', fontsize=9)
            
            # Title
            title = 'Running Vusers - Full Timeline'
            if user_ss:
                title += f' (SS Max: {max_vusers}, SS Avg: {avg_vusers})'
            ax.set_title(title, fontsize=10)
            
            ax.grid(True, alpha=0.3)
            ax.set_xlim(0, max(rel_times) if rel_times else 1)
            ax.set_ylim(0, max(vusers) * 1.1 if vusers else 1)
            
            # Save to buffer
            buf = io.BytesIO()
            fig.tight_layout()
            fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
            buf.seek(0)
            plt.close(fig)
            
            # Create reportlab image
            img = RLImage(buf, width=6.5*inch, height=2.5*inch)
            return img
            
        except Exception as e:
            print(f"Error creating full timeline VUser graph: {e}")
            return None
    
    def _create_hits_per_second_graph(self):
        """Create Hits per Second graph (calculated from total pass counts over test duration)."""
        try:
            transaction_summary = getattr(self.parser, 'transaction_summary', [])
            scenario_info = getattr(self.parser, 'scenario_info', {})
            duration_seconds = scenario_info.get('duration_seconds', 0)
            
            if not transaction_summary or duration_seconds <= 0:
                return None
            
            # Group by script and calculate hits per second
            script_hits = {}
            for trans in transaction_summary:
                name = trans.get('transaction_name', '')
                
                # Skip init/end transactions
                if 'vuser_init' in name.lower() or 'vuser_end' in name.lower():
                    continue
                if 'action_transaction' in name.lower() or name.lower() == 'action':
                    continue
                
                # Extract script name
                match = re.search(r'_T(\d{2})', name)
                if match:
                    script = name[:match.start()]
                else:
                    script = name
                
                # Normalize script name
                script = normalize_script_display_name(script)
                
                pass_count = trans.get('pass_count', 0)
                if script not in script_hits:
                    script_hits[script] = 0
                script_hits[script] += pass_count
            
            if not script_hits:
                return None
            
            # Calculate hits per second
            for script in script_hits:
                script_hits[script] = script_hits[script] / duration_seconds
            
            # Sort by script name
            sorted_scripts = sorted(script_hits.keys())
            hits_values = [script_hits[s] for s in sorted_scripts]
            
            # Create figure
            fig_height = max(3, len(sorted_scripts) * 0.35)
            fig, ax = plt.subplots(figsize=(7, min(fig_height, 5)))
            
            y_pos = range(len(sorted_scripts))
            bars = ax.barh(y_pos, hits_values, color='#17a2b8', alpha=0.8)
            ax.set_yticks(y_pos)
            ax.set_yticklabels(sorted_scripts, fontsize=8)
            ax.set_xlabel('Hits/Second', fontsize=9)
            ax.set_title('Hits per Second by Script', fontsize=10)
            ax.grid(True, alpha=0.3, axis='x')
            
            # Add value labels
            for bar, val in zip(bars, hits_values):
                ax.text(bar.get_width() + 0.02 * max(hits_values) if hits_values else 0.1, 
                       bar.get_y() + bar.get_height()/2, 
                       f'{val:.2f}', va='center', fontsize=7)
            
            # Save to buffer
            buf = io.BytesIO()
            fig.tight_layout()
            fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
            buf.seek(0)
            plt.close(fig)
            
            img = RLImage(buf, width=6.5*inch, height=min(fig_height * 0.7, 3.5)*inch)
            return img
            
        except Exception as e:
            print(f"Error creating Hits per Second graph: {e}")
            return None
    
    def _create_transaction_summary_graph(self):
        """Create Transaction Summary graph showing pass/fail counts per script."""
        try:
            transaction_summary = getattr(self.parser, 'transaction_summary', [])
            
            if not transaction_summary:
                return None
            
            # Group by script
            script_stats = {}
            for trans in transaction_summary:
                name = trans.get('transaction_name', '')
                
                # Skip init/end transactions
                if 'vuser_init' in name.lower() or 'vuser_end' in name.lower():
                    continue
                if 'action_transaction' in name.lower() or name.lower() == 'action':
                    continue
                
                # Extract script name
                match = re.search(r'_T(\d{2})', name)
                if match:
                    script = name[:match.start()]
                else:
                    script = name
                
                # Normalize script name
                script = normalize_script_display_name(script)
                
                if script not in script_stats:
                    script_stats[script] = {'pass': 0, 'fail': 0}
                
                script_stats[script]['pass'] += trans.get('pass_count', 0)
                script_stats[script]['fail'] += trans.get('fail_count', 0)
            
            if not script_stats:
                return None
            
            # Sort by script name
            sorted_scripts = sorted(script_stats.keys())
            pass_counts = [script_stats[s]['pass'] for s in sorted_scripts]
            fail_counts = [script_stats[s]['fail'] for s in sorted_scripts]
            
            # Create figure - stacked horizontal bar chart
            fig_height = max(3, len(sorted_scripts) * 0.4)
            fig, ax = plt.subplots(figsize=(7, min(fig_height, 5)))
            
            y_pos = range(len(sorted_scripts))
            
            # Create stacked bars
            bars_pass = ax.barh(y_pos, pass_counts, color='#28a745', alpha=0.8, label='Pass')
            bars_fail = ax.barh(y_pos, fail_counts, left=pass_counts, color='#dc3545', alpha=0.8, label='Fail')
            
            ax.set_yticks(y_pos)
            ax.set_yticklabels(sorted_scripts, fontsize=8)
            ax.set_xlabel('Transaction Count', fontsize=9)
            ax.set_title('Transaction Summary by Script (Pass/Fail)', fontsize=10)
            ax.legend(loc='lower right', fontsize=8)
            ax.grid(True, alpha=0.3, axis='x')
            
            # Add total count labels
            for i, (p, f) in enumerate(zip(pass_counts, fail_counts)):
                total = p + f
                ax.text(total + 0.02 * max([p + f for p, f in zip(pass_counts, fail_counts)]) if total > 0 else 0.1, 
                       i, f'{total:,}', va='center', fontsize=7)
            
            # Save to buffer
            buf = io.BytesIO()
            fig.tight_layout()
            fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
            buf.seek(0)
            plt.close(fig)
            
            img = RLImage(buf, width=6.5*inch, height=min(fig_height * 0.7, 3.5)*inch)
            return img
            
        except Exception as e:
            print(f"Error creating Transaction Summary graph: {e}")
            return None
    
    def _create_response_time_graph(self):
        """Create Average Response Time graph showing avg response time per script."""
        try:
            transaction_summary = getattr(self.parser, 'transaction_summary', [])
            
            if not transaction_summary:
                return None
            
            # Group by script and calculate weighted average response time
            script_rt = {}  # script -> {total_time, count}
            for trans in transaction_summary:
                name = trans.get('transaction_name', '')
                
                # Skip init/end transactions
                if 'vuser_init' in name.lower() or 'vuser_end' in name.lower():
                    continue
                if 'action_transaction' in name.lower() or name.lower() == 'action':
                    continue
                
                # Extract script name
                match = re.search(r'_T(\d{2})', name)
                if match:
                    script = name[:match.start()]
                else:
                    script = name
                
                # Normalize script name
                script = normalize_script_display_name(script)
                
                avg_time = trans.get('avg_response_time', 0)
                count = trans.get('pass_count', 0) + trans.get('fail_count', 0)
                
                if script not in script_rt:
                    script_rt[script] = {'total_time': 0, 'count': 0}
                
                if avg_time > 0 and count > 0:
                    script_rt[script]['total_time'] += avg_time * count
                    script_rt[script]['count'] += count
            
            if not script_rt:
                return None
            
            # Calculate weighted average
            script_avg = {}
            for script, data in script_rt.items():
                if data['count'] > 0:
                    script_avg[script] = data['total_time'] / data['count']
            
            if not script_avg:
                return None
            
            # Sort by script name
            sorted_scripts = sorted(script_avg.keys())
            avg_times = [script_avg[s] for s in sorted_scripts]
            
            # Create figure
            fig_height = max(3, len(sorted_scripts) * 0.35)
            fig, ax = plt.subplots(figsize=(7, min(fig_height, 5)))
            
            y_pos = range(len(sorted_scripts))
            bars = ax.barh(y_pos, avg_times, color='#6f42c1', alpha=0.8)
            ax.set_yticks(y_pos)
            ax.set_yticklabels(sorted_scripts, fontsize=8)
            ax.set_xlabel('Average Response Time (seconds)', fontsize=9)
            ax.set_title('Average Response Time by Script', fontsize=10)
            ax.grid(True, alpha=0.3, axis='x')
            
            # Add value labels
            max_val = max(avg_times) if avg_times else 1
            for bar, val in zip(bars, avg_times):
                ax.text(bar.get_width() + 0.02 * max_val, 
                       bar.get_y() + bar.get_height()/2, 
                       f'{val:.3f}s', va='center', fontsize=7)
            
            # Save to buffer
            buf = io.BytesIO()
            fig.tight_layout()
            fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
            buf.seek(0)
            plt.close(fig)
            
            img = RLImage(buf, width=6.5*inch, height=min(fig_height * 0.7, 3.5)*inch)
            return img
            
        except Exception as e:
            print(f"Error creating Response Time graph: {e}")
            return None
    
    def _create_tps_graph(self):
        """Create TPS bar chart from parser data."""
        try:
            # Get TPS data (list of transaction summaries with TPS)
            tps_data = getattr(self.parser, 'tps_data', [])
            
            if not tps_data or len(tps_data) < 1:
                return None
            
            # Filter out init/end transactions and group by script
            script_tps = {}
            for entry in tps_data:
                name = entry.get('transaction_name', '')
                tps = entry.get('tps', 0)
                
                # Skip init/end transactions
                if 'vuser_init' in name.lower() or 'vuser_end' in name.lower():
                    continue
                if 'action_transaction' in name.lower() or name.lower() == 'action':
                    continue
                
                # Extract script name
                match = re.search(r'_T(\d{2})', name)
                if match:
                    script = name[:match.start()]
                else:
                    script = name
                
                # Normalize script name
                script = normalize_script_display_name(script)
                
                if script not in script_tps:
                    script_tps[script] = 0
                script_tps[script] += tps
            
            if not script_tps:
                return None
            
            # Sort by script name
            sorted_scripts = sorted(script_tps.keys())
            tps_values = [script_tps[s] for s in sorted_scripts]
            
            # Create figure - horizontal bar chart for readability
            fig_height = max(3, len(sorted_scripts) * 0.3)
            fig, ax = plt.subplots(figsize=(7, min(fig_height, 6)))
            
            y_pos = range(len(sorted_scripts))
            bars = ax.barh(y_pos, tps_values, color='#28a745', alpha=0.8)
            ax.set_yticks(y_pos)
            ax.set_yticklabels(sorted_scripts, fontsize=8)
            ax.set_xlabel('TPS', fontsize=9)
            ax.set_title('Transactions per Second by Script', fontsize=10)
            ax.grid(True, alpha=0.3, axis='x')
            
            # Add value labels
            for bar, val in zip(bars, tps_values):
                ax.text(bar.get_width() + 0.5, bar.get_y() + bar.get_height()/2, 
                       f'{val:.1f}', va='center', fontsize=7)
            
            # Save to buffer
            buf = io.BytesIO()
            fig.tight_layout()
            fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
            buf.seek(0)
            plt.close(fig)
            
            # Create reportlab image
            img = RLImage(buf, width=6.5*inch, height=min(fig_height * 0.8, 4)*inch)
            return img
            
        except Exception as e:
            print(f"Error creating TPS graph: {e}")
            return None
    
    def _create_tps_main_graph(self):
        """Create TPS-Main graph showing last transaction TPS per script (matches Excel TPS_Main sheet)."""
        try:
            response_times = getattr(self.parser, 'response_times', {})
            
            if not response_times:
                return None
            
            # Pattern to match last transaction variants
            last_trans_pattern = re.compile(r'(last_?trans|logout_?last_?trans)$', re.IGNORECASE)
            
            # Find last transactions for each script
            script_last_trans = {}  # base_script -> (trans_name, avg_tps)
            
            for trans_name, data in response_times.items():
                name_lower = trans_name.lower()
                
                # Skip vuser and action transactions
                if 'vuser_init' in name_lower or 'vuser_end' in name_lower:
                    continue
                if 'action_transaction' in name_lower or name_lower == 'action':
                    continue
                
                # Check if this is a last transaction
                if not last_trans_pattern.search(trans_name):
                    continue
                
                # Extract base script name
                base_script = re.sub(r'[_-]?(last_?trans|logout_?last_?trans)$', '', trans_name, flags=re.IGNORECASE)
                base_script = re.sub(r'_T\d{2}.*$', '', base_script)
                
                # Normalize script name
                base_script = normalize_script_display_name(base_script)
                
                # Get TPS value
                tps_values = data.get('tps_values', [])
                avg_tps = data.get('avg_tps', 0)
                if not avg_tps and tps_values:
                    avg_tps = sum(tps_values) / len(tps_values)
                
                if avg_tps > 0:
                    script_last_trans[base_script] = (trans_name, avg_tps)
            
            if not script_last_trans:
                return None
            
            # Sort by script name
            sorted_scripts = sorted(script_last_trans.keys())
            tps_values = [script_last_trans[s][1] for s in sorted_scripts]
            
            # Create figure - horizontal bar chart
            fig_height = max(3, len(sorted_scripts) * 0.4)
            fig, ax = plt.subplots(figsize=(7, min(fig_height, 6)))
            
            # Use different colors for each bar (matching LoadRunner style)
            colors_list = ['#FF0000', '#00FF00', '#0000FF', '#FFFF00', '#FF00FF', 
                          '#00FFFF', '#FFA500', '#800080', '#008000', '#FF69B4',
                          '#4169E1', '#FFD700', '#8B4513', '#20B2AA', '#DC143C', '#90EE90']
            bar_colors = [colors_list[i % len(colors_list)] for i in range(len(sorted_scripts))]
            
            y_pos = range(len(sorted_scripts))
            bars = ax.barh(y_pos, tps_values, color=bar_colors, alpha=0.8)
            ax.set_yticks(y_pos)
            ax.set_yticklabels(sorted_scripts, fontsize=8)
            ax.set_xlabel('Average TPS', fontsize=9)
            ax.set_title('TPS-Main: Last Transaction per Script', fontsize=10)
            ax.grid(True, alpha=0.3, axis='x')
            
            # Add value labels
            for bar, val in zip(bars, tps_values):
                ax.text(bar.get_width() + 0.02 * max(tps_values), 
                       bar.get_y() + bar.get_height()/2, 
                       f'{val:.3f}', va='center', fontsize=7)
            
            # Save to buffer
            buf = io.BytesIO()
            fig.tight_layout()
            fig.savefig(buf, format='png', dpi=150, bbox_inches='tight')
            buf.seek(0)
            plt.close(fig)
            
            # Create reportlab image
            img = RLImage(buf, width=6.5*inch, height=min(fig_height * 0.8, 4)*inch)
            return img
            
        except Exception as e:
            print(f"Error creating TPS-Main graph: {e}")
            return None
    
    def _create_business_process_section(self):
        """Create the Business Process section with per-script vuser counts."""
        elements = []
        elements.append(Paragraph("Business Process", self.styles['SectionHeader']))
        
        import re
        
        # Extract script names from transactions (same logic as Excel report)
        def extract_script_name(trans_name):
            match = re.search(r'_T(\d{2})', trans_name)
            if match:
                pos = match.start()
                return trans_name[:pos]
            return trans_name
        
        # Collect unique scripts from transactions
        transaction_summary = getattr(self.parser, 'transaction_summary', [])
        script_vuser_counts = getattr(self.parser, 'script_vuser_counts', {})
        
        # Build script stats from transactions
        script_stats = {}
        for trans in transaction_summary:
            name = trans.get('transaction_name', '')
            if 'vuser_init' in name.lower() or 'vuser_end' in name.lower() or 'action' in name.lower():
                continue
            
            script_name = extract_script_name(name)
            if script_name not in script_stats:
                script_stats[script_name] = {
                    'pass_count': 0,
                    'fail_count': 0,
                    'vuser_count': script_vuser_counts.get(script_name, 0)
                }
            
            script_stats[script_name]['pass_count'] += trans.get('pass_count', 0)
            script_stats[script_name]['fail_count'] += trans.get('fail_count', 0)
        
        if not script_stats:
            elements.append(Paragraph("No business process data available.", self.styles['InfoText']))
            return elements
        
        # Calculate transactions per hour for each script
        scenario_info = getattr(self.parser, 'scenario_info', {})
        duration_hours = scenario_info.get('duration_seconds', 600) / 3600
        
        # Header row
        header = ["Group Name", "User\nCount", "Pass Count", "Fail Count", "Total", "Trans/Hour"]
        
        # Data rows
        data = [header]
        total_vusers = sum(s['vuser_count'] for s in script_stats.values())
        total_pass = 0
        total_fail = 0
        
        for script_name in sorted(script_stats.keys()):
            stats = script_stats[script_name]
            vuser_count = stats['vuser_count']
            pass_count = stats['pass_count']
            fail_count = stats['fail_count']
            total_trans = pass_count + fail_count
            trans_per_hour = total_trans / duration_hours if duration_hours > 0 else 0
            
            total_pass += pass_count
            total_fail += fail_count
            
            # Apply normalization to script name (ITR1Online -> ITR1_Online)
            display_name = normalize_script_display_name(script_name)
            
            data.append([
                display_name,
                str(vuser_count) if vuser_count > 0 else "-",
                str(pass_count),
                str(fail_count),
                str(total_trans),
                f"{trans_per_hour:.1f}"
            ])
        
        # Total row
        grand_total = total_pass + total_fail
        total_trans_per_hour = grand_total / duration_hours if duration_hours > 0 else 0
        data.append(["TOTAL", str(total_vusers) if total_vusers > 0 else "-", 
                     str(total_pass), str(total_fail), str(grand_total), f"{total_trans_per_hour:.1f}"])
        
        # Create table
        col_widths = [2.5*inch, 0.7*inch, 0.9*inch, 0.9*inch, 0.8*inch, 1*inch]
        table = Table(data, colWidths=col_widths)
        
        table.setStyle(TableStyle([
            # Header style
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#2874a6')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            
            # Data style
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('ALIGN', (2, 1), (-1, -1), 'CENTER'),
            
            # Total row style
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#d5e8f0')),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            
            # Grid
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 15))
        
        return elements
    
    def _create_transaction_summary_section(self):
        """Create the Transaction Summary section."""
        elements = []
        elements.append(Paragraph("Transaction Summary", self.styles['SectionHeader']))
        
        transaction_summary = getattr(self.parser, 'transaction_summary', [])
        
        if not transaction_summary:
            elements.append(Paragraph("No transaction data available.", self.styles['InfoText']))
            return elements
        
        import re
        
        # Extract script name (same logic as Excel)
        def extract_script_name(trans_name):
            match = re.search(r'_T(\d{2})', trans_name)
            if match:
                pos = match.start()
                return trans_name[:pos]
            return trans_name
        
        # Get vuser counts
        script_vuser_counts = getattr(self.parser, 'script_vuser_counts', {})
        
        # Filter out init/end transactions and aggregate by script
        script_summary = {}
        for trans in transaction_summary:
            name = trans.get('transaction_name', '')
            
            # Skip init/end transactions
            if 'vuser_init' in name.lower() or 'vuser_end' in name.lower():
                continue
            if 'action_transaction' in name.lower() or 'action' == name.lower():
                continue
            
            script = extract_script_name(name)
            
            if script not in script_summary:
                script_summary[script] = {
                    'pass': 0,
                    'fail': 0,
                    'min_time': float('inf'),
                    'max_time': 0,
                    'avg_time': 0,
                    'total_time': 0,
                    'count': 0,
                    'vuser_count': script_vuser_counts.get(script, 0)
                }
            
            script_summary[script]['pass'] += trans.get('pass_count', 0)
            script_summary[script]['fail'] += trans.get('fail_count', 0)
            
            avg_time = trans.get('avg_response_time', trans.get('avg_time', 0))
            min_time = trans.get('min_response_time', trans.get('min_time', avg_time))
            max_time = trans.get('max_response_time', trans.get('max_time', avg_time))
            
            if avg_time > 0:
                script_summary[script]['count'] += 1
                script_summary[script]['total_time'] += avg_time
                script_summary[script]['min_time'] = min(script_summary[script]['min_time'], min_time)
                script_summary[script]['max_time'] = max(script_summary[script]['max_time'], max_time)
        
        # Header row
        header = ["Script", "User\nCount", "Pass", "Fail", "Total", "Fail %", "Avg (s)", "Min (s)", "Max (s)"]
        data = [header]
        
        total_pass = 0
        total_fail = 0
        total_vusers = 0
        
        for script, stats in sorted(script_summary.items()):
            if stats['min_time'] == float('inf'):
                stats['min_time'] = 0
            
            avg_time = stats['total_time'] / stats['count'] if stats['count'] > 0 else 0
            total = stats['pass'] + stats['fail']
            fail_pct = (stats['fail'] / total * 100) if total > 0 else 0
            
            total_pass += stats['pass']
            total_fail += stats['fail']
            total_vusers += stats['vuser_count']
            
            # Apply normalization to script name (ITR1Online -> ITR1_Online)
            display_name = normalize_script_display_name(script)
            
            data.append([
                display_name[:25],  # Truncate long names
                str(stats['vuser_count']) if stats['vuser_count'] > 0 else "-",
                str(stats['pass']),
                str(stats['fail']),
                str(total),
                f"{fail_pct:.2f}%",
                f"{avg_time:.3f}",
                f"{stats['min_time']:.3f}",
                f"{stats['max_time']:.3f}"
            ])
        
        # Total row
        grand_total = total_pass + total_fail
        total_fail_pct = (total_fail / grand_total * 100) if grand_total > 0 else 0
        data.append(["TOTAL", str(total_vusers) if total_vusers > 0 else "-", 
                     str(total_pass), str(total_fail), str(grand_total), f"{total_fail_pct:.2f}%", "", "", ""])
        
        # Create table
        col_widths = [1.8*inch, 0.6*inch, 0.7*inch, 0.6*inch, 0.6*inch, 0.6*inch, 0.7*inch, 0.7*inch, 0.7*inch]
        table = Table(data, colWidths=col_widths)
        
        table.setStyle(TableStyle([
            # Header style
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#28a745')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 8),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            
            # Data style
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 7),
            ('ALIGN', (1, 1), (-1, -1), 'CENTER'),
            
            # Total row style
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#d4edda')),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            
            # Grid
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 15))
        
        return elements
    
    def _create_tps_summary_section(self):
        """Create the TPS Summary section."""
        elements = []
        elements.append(Paragraph("Throughput (TPS) Summary", self.styles['SectionHeader']))
        
        transaction_summary = getattr(self.parser, 'transaction_summary', [])
        
        if not transaction_summary:
            elements.append(Paragraph("No TPS data available.", self.styles['InfoText']))
            return elements
        
        import re
        
        # Extract script name (same logic as Excel)
        def extract_script_name(trans_name):
            match = re.search(r'_T(\d{2})', trans_name)
            if match:
                pos = match.start()
                return trans_name[:pos]
            return trans_name
        
        # Get vuser counts
        script_vuser_counts = getattr(self.parser, 'script_vuser_counts', {})
        
        # Aggregate TPS by script
        script_tps = {}
        for trans in transaction_summary:
            name = trans.get('transaction_name', '')
            
            # Skip init/end transactions
            if 'vuser_init' in name.lower() or 'vuser_end' in name.lower():
                continue
            if 'action_transaction' in name.lower() or 'action' == name.lower():
                continue
            
            script = extract_script_name(name)
            
            if script not in script_tps:
                script_tps[script] = {
                    'avg_tps': 0,
                    'min_tps': float('inf'),
                    'max_tps': 0,
                    'count': 0,
                    'vuser_count': script_vuser_counts.get(script, 0)
                }
            
            tps = trans.get('tps', trans.get('avg_tps', 0))
            if tps > 0:
                script_tps[script]['count'] += 1
                script_tps[script]['avg_tps'] += tps
                script_tps[script]['min_tps'] = min(script_tps[script]['min_tps'], tps)
                script_tps[script]['max_tps'] = max(script_tps[script]['max_tps'], tps)
        
        # Header row
        header = ["Script", "User\nCount", "Avg TPS", "Min TPS", "Max TPS"]
        data = [header]
        
        total_tps = 0
        total_vusers = 0
        
        for script, stats in sorted(script_tps.items()):
            if stats['min_tps'] == float('inf'):
                stats['min_tps'] = 0
            
            avg_tps = stats['avg_tps'] / stats['count'] if stats['count'] > 0 else 0
            total_tps += avg_tps
            total_vusers += stats['vuser_count']
            
            # Apply normalization to script name (ITR1Online -> ITR1_Online)
            display_name = normalize_script_display_name(script)
            
            data.append([
                display_name[:30],
                str(stats['vuser_count']) if stats['vuser_count'] > 0 else "-",
                f"{avg_tps:.4f}",
                f"{stats['min_tps']:.4f}",
                f"{stats['max_tps']:.4f}"
            ])
        
        # Total row
        data.append(["TOTAL", str(total_vusers) if total_vusers > 0 else "-", f"{total_tps:.4f}", "", ""])
        
        # Create table
        col_widths = [2.5*inch, 0.8*inch, 1.2*inch, 1.2*inch, 1.2*inch]
        table = Table(data, colWidths=col_widths)
        
        table.setStyle(TableStyle([
            # Header style
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#17a2b8')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            
            # Data style
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('ALIGN', (1, 1), (-1, -1), 'CENTER'),
            
            # Total row style
            ('BACKGROUND', (0, -1), (-1, -1), colors.HexColor('#d1ecf1')),
            ('FONTNAME', (0, -1), (-1, -1), 'Helvetica-Bold'),
            
            # Grid
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 4),
            ('TOPPADDING', (0, 0), (-1, -1), 4),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 15))
        
        return elements
    
    def _create_error_summary_section(self):
        """Create the Error Summary section."""
        elements = []
        elements.append(Paragraph("Error Summary", self.styles['SectionHeader']))
        
        import re
        
        # Extract script name (same logic as Excel)
        def extract_script_name(trans_name):
            match = re.search(r'_T(\d{2})', trans_name)
            if match:
                pos = match.start()
                return trans_name[:pos]
            return trans_name
        
        transaction_summary = getattr(self.parser, 'transaction_summary', [])
        
        # Calculate error stats
        error_scripts = []
        for trans in transaction_summary:
            fail_count = trans.get('fail_count', 0)
            if fail_count > 0:
                trans_name = trans.get('transaction_name', '')
                script = extract_script_name(trans_name)
                pass_count = trans.get('pass_count', 0)
                total = pass_count + fail_count
                fail_pct = (fail_count / total * 100) if total > 0 else 0
                
                error_scripts.append({
                    'script': script,
                    'transaction': trans_name,
                    'pass': pass_count,
                    'fail': fail_count,
                    'fail_pct': fail_pct
                })
        
        if not error_scripts:
            elements.append(Paragraph("No errors recorded during test execution.", self.styles['InfoText']))
            return elements
        
        # Sort by fail count
        error_scripts.sort(key=lambda x: x['fail'], reverse=True)
        
        # Header row
        header = ["Script", "Transaction", "Pass", "Fail", "Fail %"]
        data = [header]
        
        for err in error_scripts[:20]:  # Top 20 error transactions
            data.append([
                err['script'][:20],
                err['transaction'][:30],
                str(err['pass']),
                str(err['fail']),
                f"{err['fail_pct']:.2f}%"
            ])
        
        # Create table
        col_widths = [1.5*inch, 2.5*inch, 0.8*inch, 0.8*inch, 0.8*inch]
        table = Table(data, colWidths=col_widths)
        
        table.setStyle(TableStyle([
            # Header style
            ('BACKGROUND', (0, 0), (-1, 0), colors.HexColor('#dc3545')),
            ('TEXTCOLOR', (0, 0), (-1, 0), colors.white),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 9),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            
            # Data style
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 8),
            ('ALIGN', (2, 1), (-1, -1), 'CENTER'),
            
            # Grid
            ('GRID', (0, 0), (-1, -1), 0.5, colors.grey),
            ('BOTTOMPADDING', (0, 0), (-1, -1), 3),
            ('TOPPADDING', (0, 0), (-1, -1), 3),
        ]))
        
        elements.append(table)
        elements.append(Spacer(1, 15))
        
        return elements


def generate_pdf_report(parser, output_path: str, scenario_name: str = None, report_types: list = None, progress_callback=None) -> str:
    """
    Generate PDF report from parsed LoadRunner data.
    
    Args:
        parser: LRRParser instance with parsed data
        output_path: Path for output PDF file
        scenario_name: Optional scenario name for report title
        report_types: List of report types to include (e.g., ['transaction_summary', 'tps'])
        progress_callback: Optional callback function(percent, step_name) to report progress
    
    Returns:
        Path to generated PDF file
    """
    report = LRRPDFReport(parser)
    return report.generate(output_path, scenario_name, report_types, progress_callback)
