#!/usr/bin/env python3
"""
Order-independence regression test for LRRParser.aggregate_data().

Validates that aggregating the same set of (synthetic) parser results in
any permutation of upload order produces an identical merged
`script_vuser_counts` dictionary - the data structure that feeds the
"User Count", "Adjusted User Count" and "Total VUsers" columns in the
final Excel report.

Run:
    python test_order_independence.py
"""
import itertools
import sys
from unittest.mock import MagicMock

from lrr_parser import LRRParser


def make_stub_parser(script_counts: dict, max_vusers: int = 0):
    """Build a minimal stub that quacks like an LRRParser for aggregate_data."""
    stub = MagicMock(spec=LRRParser)
    stub.script_vuser_counts = dict(script_counts)
    stub.transaction_summary = []
    stub.tps_data = []
    stub.errors = []
    stub.response_times = {}
    stub.http_statistics = {
        'response_codes': {}, 'web_connections': {},
        'web_ssl': {}, 'retries': {},
    }
    stub.http_statistics_ss = {
        'response_codes': {}, 'web_connections': {},
        'web_ssl': {}, 'retries': {},
    }
    stub.scenario_info = {}
    stub.steady_state_duration = 0
    stub.steady_state_from_rel = -1
    stub.steady_state_to_rel = -1
    stub.max_vusers = max_vusers
    stub.running_vusers = []
    return stub


def fresh_base(script_counts: dict, max_vusers: int = 0) -> LRRParser:
    """Build a fresh real-LRRParser instance pre-seeded with script counts.

    We bypass __init__ (which requires a real .lrr path) by using __new__
    and then setting only the attributes aggregate_data touches.
    """
    base = LRRParser.__new__(LRRParser)
    base.script_vuser_counts = dict(script_counts)
    base.transaction_summary = []
    base.tps_data = []
    base.errors = []
    base.response_times = {}
    base.http_statistics = {
        'response_codes': {}, 'web_connections': {},
        'web_ssl': {}, 'retries': {},
    }
    base.http_statistics_ss = {
        'response_codes': {}, 'web_connections': {},
        'web_ssl': {}, 'retries': {},
    }
    base.scenario_info = {}
    base.steady_state_duration = 0
    base.steady_state_from_rel = -1
    base.steady_state_to_rel = -1
    base.max_vusers = max_vusers
    base.running_vusers = []
    return base


def aggregate_in_order(controller_data):
    """Run aggregate_data over the controllers in the given order and
    return the resulting script_vuser_counts dict."""
    first_counts, first_max = controller_data[0]
    base = fresh_base(first_counts, first_max)
    for counts, max_vu in controller_data[1:]:
        other = make_stub_parser(counts, max_vu)
        base.aggregate_data(other)
    return dict(base.script_vuser_counts), base.max_vusers


def aggregate_full(controller_data):
    """Like aggregate_in_order but also returns:
      - total_users (sum across controllers, used in the Excel badge)
      - per-controller snapshots stored under base.all_scenario_info
    """
    first_counts, first_max = controller_data[0]
    base = fresh_base(first_counts, first_max)
    for counts, max_vu in controller_data[1:]:
        other = make_stub_parser(counts, max_vu)
        base.aggregate_data(other)
    snapshots = [(c.get('max_vusers', 0),
                  tuple(sorted((c.get('script_counts') or {}).items())))
                 for c in getattr(base, 'all_scenario_info', [])]
    return base._get_total_users_for_report(), tuple(sorted(snapshots))


def assert_order_independent(controllers, label):
    """Run every permutation of the controllers and assert all permutations
    produce the same merged dict and same max_vusers."""
    results = []
    for perm in itertools.permutations(range(len(controllers))):
        permuted = [controllers[i] for i in perm]
        counts, max_vu = aggregate_in_order(permuted)
        results.append((perm, counts, max_vu))

    baseline_perm, baseline_counts, baseline_max = results[0]
    for perm, counts, max_vu in results[1:]:
        if counts != baseline_counts or max_vu != baseline_max:
            print(f"\n[FAIL] {label}: order dependence detected")
            print(f"  Permutation {baseline_perm}: counts={baseline_counts}, max={baseline_max}")
            print(f"  Permutation {perm}: counts={counts}, max={max_vu}")
            return False
    print(f"[ OK ] {label} ({len(results)} permutations identical)")
    print(f"        counts = {baseline_counts}")
    return True


def main():
    tests = []

    # ---------------------------------------------------------------------
    # Test 1: classic order-dependence trigger - same logical script with a
    # prefixed/suffixed name variant across controllers.
    # ---------------------------------------------------------------------
    tests.append(("same script, prefix/suffix variants", [
        ({"01_Login": 100}, 100),
        ({"Login": 200}, 200),
    ]))

    # ---------------------------------------------------------------------
    # Test 2: three controllers, mixed naming, one independent script.
    # ---------------------------------------------------------------------
    tests.append(("three controllers w/ variants + extra script", [
        ({"01_Login_Final": 50, "Logout": 40}, 90),
        ({"Login_Modify": 60}, 60),
        ({"Login": 70, "Dashboard": 30}, 100),
    ]))

    # ---------------------------------------------------------------------
    # Test 3: four controllers, with one source using mapped names (RawData
    # style) and others using group names (.lrs style).
    # ---------------------------------------------------------------------
    tests.append(("4 controllers, multi-source names", [
        ({"01_UPA_Taxpayerledger": 25, "02_Assese_Communication": 30}, 55),
        ({"01_UPA_Taxpayerledger_Final_modify": 35}, 35),
        ({"UPATaxpayerledger": 20}, 20),
        ({"02_Assese_Communication_Final": 15, "06_UPA_Dashboard": 12}, 27),
    ]))

    # ---------------------------------------------------------------------
    # Test 4: completely disjoint scripts (no merging needed).
    # ---------------------------------------------------------------------
    tests.append(("disjoint scripts (no merging)", [
        ({"ScriptA": 10}, 10),
        ({"ScriptB": 20}, 20),
        ({"ScriptC": 30}, 30),
    ]))

    # ---------------------------------------------------------------------
    # Test 5: empty controller mixed in.
    # ---------------------------------------------------------------------
    tests.append(("empty controller mixed in", [
        ({"Login": 50}, 50),
        ({}, 0),
        ({"Login_Modify": 30}, 30),
    ]))

    # ---------------------------------------------------------------------
    # Test 6: realistic 4-controller scenario from the bug report.
    # ---------------------------------------------------------------------
    tests.append(("realistic 4-controller mixed naming", [
        ({"01_LoginHere_Final": 80, "02_Dashboard_Modify": 40,
          "03_ITR1_Online_AY25_26": 100}, 220),
        ({"LoginHere": 75, "Dashboard": 35, "ITR1_Online": 95}, 205),
        ({"01_LoginHere": 78, "Dashboard_AY25": 38,
          "ITR1_Online_Final": 98}, 214),
        ({"LoginHere_Modify": 82, "02_Dashboard": 36}, 118),
    ]))

    # ---------------------------------------------------------------------
    # Test 7: real-world numbers from the user's report
    # (4 controllers w/ max_vusers 5430/3730/3110/3983, sum should be 16253).
    # ---------------------------------------------------------------------
    tests.append(("real-world 4-controller totals", [
        ({"FO009_VerifyYourPan_PreLogin": 580,
          "FO009_VerifyYourPan_PostLogin": 580,
          "Prevalidate": 580}, 5430),
        ({"VerifyYourPan_PreLogin": 1100,
          "VerifyYourPan_PostLogin": 1100,
          "Prevalidate_Bank_Account": 1100}, 3730),
        ({"FO009_VerifyYourPan_PreLogin": 1000,
          "FO009_VerifyYourPan_PostLogin": 1000,
          "Prevalidate": 1000}, 3110),
        ({"VerifyYourPan_PreLogin": 635,
          "VerifyYourPan_PostLogin": 635,
          "Prevalidate": 635}, 3983),
    ]))

    all_passed = True
    for label, controllers in tests:
        ok = assert_order_independent(controllers, label)
        all_passed = all_passed and ok

    # ------------------------------------------------------------------
    # Order-independence of _get_total_users_for_report() and per-ctrl
    # script_counts snapshot (used by the new MAX-per-script Excel path)
    # ------------------------------------------------------------------
    print("\n--- total_users + per-controller snapshot ---")
    for label, controllers in tests:
        results = []
        for perm in itertools.permutations(range(len(controllers))):
            permuted = [controllers[i] for i in perm]
            results.append((perm, aggregate_full(permuted)))
        baseline_perm, (baseline_total, baseline_snap) = results[0]
        ok = True
        for perm, (total, snap) in results[1:]:
            if total != baseline_total:
                print(f"[FAIL] {label}: total_users differs "
                      f"({baseline_total} vs {total} for {perm})")
                ok = False
            if sorted(snap) != sorted(baseline_snap):
                print(f"[FAIL] {label}: per-ctrl snapshot differs for {perm}")
                ok = False
        if ok:
            print(f"[ OK ] {label}: total_users={baseline_total}, "
                  f"snapshots stable across {len(results)} permutations")
        all_passed = all_passed and ok

    print("\n" + "=" * 60)
    if all_passed:
        print("RESULT: All order-independence tests passed.")
        return 0
    print("RESULT: One or more tests FAILED (order dependence detected).")
    return 1


if __name__ == "__main__":
    sys.exit(main())
