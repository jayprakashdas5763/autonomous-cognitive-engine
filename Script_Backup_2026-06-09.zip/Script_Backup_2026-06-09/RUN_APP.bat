@echo off
title LoadRunner Report Generator
cd /d "%~dp0"

REM Check if Python is installed
python --version >nul 2>&1
if errorlevel 1 (
    echo ERROR: Python is not installed!
    echo Please install Python from https://www.python.org/downloads/
    pause
    exit /b 1
)

REM Check/Install openpyxl
pip show openpyxl >nul 2>&1
if errorlevel 1 (
    echo Installing required package...
    pip install openpyxl -q
)

REM Run the application
pythonw lrr_app.py
