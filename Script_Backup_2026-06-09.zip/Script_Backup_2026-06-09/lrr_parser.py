#!/usr/bin/env python3
"""
LoadRunner .lrr File Parser
Extracts Transaction Summary, TPS (Transactions Per Second), and Errors from LoadRunner results.
"""

import os
import re
import math
import statistics
import configparser
from collections import defaultdict
from datetime import datetime, timedelta
from typing import Dict, List, Tuple, Any

# Debug flag - set to False for production to improve performance
DEBUG = False

def debug_print(*args, **kwargs):
    """Print only when DEBUG is True."""
    if DEBUG:
        print(*args, **kwargs)

# Try to import pyodbc for Access database parsing
try:
    import pyodbc
    PYODBC_AVAILABLE = True
except ImportError:
    PYODBC_AVAILABLE = False

try:
    import openpyxl
    from openpyxl.styles import Font, Alignment, PatternFill, Border, Side
    EXCEL_AVAILABLE = True
except ImportError:
    EXCEL_AVAILABLE = False
    print("Warning: openpyxl not installed. Excel export will not be available.")
    print("Install with: pip install openpyxl")

# Built-in Target TPS lookup table for common scripts
# Note: The lookup function does fuzzy matching, so only canonical names are needed
# Updated: AY 2025-26 Target TPS values

# Script Name Mapping: Maps transaction script names to Target_TPS lookup names
# Add entries here when transaction names don't match Target_TPS names
SCRIPT_NAME_MAPPING = {
    # Back Office scripts
    '245Bulkfetchdetails': '245(2) Bulk fetch',
    '245_Bulkfetchdetails': '245(2) Bulk fetch',
    '245BulkFetch': '245(2) Bulk fetch',
    'AsseseeCommucation': 'Assesee Communication',
    'Assesee_Commucation': 'Assesee Communication',
    'AssesseeCommucation': 'Assesee Communication',
    'AsseseeCommunication': 'Assesee Communication',
    'AsseseeFilingHistory': 'Assesse Filing History',
    'Assesee_Filing_History': 'Assesse Filing History',
    'DataQuality_Check': 'Data Quality Type Screen',
    'DataQualityCheck': 'Data Quality Type Screen',
    'Data_Quality_Check': 'Data Quality Type Screen',
    'E-Proceeding': 'E-Proceedings',
    'EProceeding': 'E-Proceedings',
    'E_Proceeding': 'E-Proceedings',
    'ITR_Collection_Report': 'ITR Collection Report',
    'ITRCollectionReport': 'ITR Collection Report',
    'Refund_Demand_Status': 'Refund/Demand Status',
    'RefundDemandStatus': 'Refund/Demand Status',
    'Refund_Reissue_BulkFetch': 'Refund-Reissue Bulk Fetch',
    'RefundReissueBulkFetch': 'Refund-Reissue Bulk Fetch',
    'Refund_Reissue BulkFetch': 'Refund-Reissue Bulk Fetch',
    'Response_TO_Outstanding_Demand': 'Response to outstanding demand',
    'ResponseToOutstandingDemand': 'Response to outstanding demand',
    'TaxpayerLegder': 'Tax-Payer Ledger',
    'Taxpayer_Legder': 'Tax-Payer Ledger',
    'TaxpayerLedger': 'Tax-Payer Ledger',
    'Tax_Payer_Ledger': 'Tax-Payer Ledger',
    'UPADashboard': 'UPA Landing Screen',
    'UPA_Dashboard': 'UPA Landing Screen',
    'UPALandingScreen': 'UPA Landing Screen',
    'ViewFiled_Returns': 'View Filed Returns',
    'ViewFiledReturns': 'View Filed Returns',
    'Worklist_Screen': 'Worklist',
    'WorklistScreen': 'Worklist',
    'TrackWorkItem': 'Track Work Item',
    'Track_Work_Item': 'Track Work Item',
    'MarkCandidateForRectification': 'Mark Candidate for Rectification',
    'Mark_Candidate_Rectification': 'Mark Candidate for Rectification',
    'AbandoningReprocessing': 'Abandoning & Reprocessing',
    'Abandoning_Reprocessing': 'Abandoning & Reprocessing',
    
    # Frontend ITR scripts - ITR-1
    'ITR1Online': 'Pre-filling and filing of ITR-1 Online (AY 25-26)',
    'ITR1_Online': 'Pre-filling and filing of ITR-1 Online (AY 25-26)',
    'ITR1_ONLINE': 'Pre-filling and filing of ITR-1 Online (AY 25-26)',
    'ITR1Offline': 'Pre-filling and filing of ITR-1 Offline (AY 25-26)',
    'ITR1_Offline': 'Pre-filling and filing of ITR-1 Offline (AY 25-26)',
    'ITR1_OFFLINE': 'Pre-filling and filing of ITR-1 Offline (AY 25-26)',
    
    # Frontend ITR scripts - ITR-2
    'ITR2Online': 'Pre-filling and filing of ITR-2 Online (AY 25-26)',
    'ITR2_Online': 'Pre-filling and filing of ITR-2 Online (AY 25-26)',
    'ITR2_ONLINE': 'Pre-filling and filing of ITR-2 Online (AY 25-26)',
    'ITR2Offline': 'Pre-filling and filing of ITR-2 Offline (AY 25-26)',
    'ITR2_Offline': 'Pre-filling and filing of ITR-2 Offline (AY 25-26)',
    'ITR2_OFFLINE': 'Pre-filling and filing of ITR-2 Offline (AY 25-26)',
    
    # Frontend ITR scripts - ITR-3
    'ITR3Online': 'Pre-filling and filing of ITR-3 Online (AY 25-26)',
    'ITR3_Online': 'Pre-filling and filing of ITR-3 Online (AY 25-26)',
    'ITR3_ONLINE': 'Pre-filling and filing of ITR-3 Online (AY 25-26)',
    'ITR3Offline': 'Pre-filling and filing of ITR-3 Offline (AY 25-26)',
    'ITR3_Offline': 'Pre-filling and filing of ITR-3 Offline (AY 25-26)',
    'ITR3_OFFLINE': 'Pre-filling and filing of ITR-3 Offline (AY 25-26)',
    
    # Frontend ITR scripts - ITR-4
    'ITR4Online': 'Pre-filling and filing of ITR-4 Online (AY 25-26)',
    'ITR4_Online': 'Pre-filling and filing of ITR-4 Online (AY 25-26)',
    'ITR4_ONLINE': 'Pre-filling and filing of ITR-4 Online (AY 25-26)',
    'ITR4Offline': 'Pre-filling and filing of ITR-4 Offline (AY 25-26)',
    'ITR4_Offline': 'Pre-filling and filing of ITR-4 Offline (AY 25-26)',
    'ITR4_OFFLINE': 'Pre-filling and filing of ITR-4 Offline (AY 25-26)',
    
    # Frontend ITR scripts - ITR-6
    'ITR6Online': 'Pre-filling and filing of ITR-6 Online (AY 25-26)',
    'ITR6_Online': 'Pre-filling and filing of ITR-6 Online (AY 25-26)',
    'ITR6_ONLINE': 'Pre-filling and filing of ITR-6 Online (AY 25-26)',
    'ITR6Offline': 'Pre-filling and filing of ITR-6 Offline (AY 25-26)',
    'ITR6_Offline': 'Pre-filling and filing of ITR-6 Offline (AY 25-26)',
    'ITR6_OFFLINE': 'Pre-filling and filing of ITR-6 Offline (AY 25-26)',
    
    # Frontend common scripts (FO### prefixed)
    'FO002_LoginHere': 'Login Here',
    'LoginHere': 'Login Here',
    'Login_Here': 'Login Here',
    'FO013_Download_Prefill_Json': 'Download Prefill JSON',
    'Download_Prefill_Json': 'Download Prefill JSON',
    'DownloadPrefillJson': 'Download Prefill JSON',
    'FO006_ITR_Status_PostLogin': 'ITR Status (ITR receipt status) - Post Login',
    'ITR_Status_PostLogin': 'ITR Status (ITR receipt status) - Post Login',
    'ITRStatusPostLogin': 'ITR Status (ITR receipt status) - Post Login',
    'E_Verification': 'e-Verification for ITR',
    'EVerification': 'e-Verification for ITR',
    'Prevalidate': 'Prevalidate Bank Account',
    'PrevalidateBankAccount': 'Prevalidate Bank Account',
    'Prevalidate_Bank_Account': 'Prevalidate Bank Account',
    
    # Form scripts
    'FORM10BA': 'Form 10BA',
    'Form10BA': 'Form 10BA',
    'FORM15G': 'Form 15G',
    'Form15G': 'Form 15G',
    'FORM15H': 'Form 15H',
    'Form15H': 'Form 15H',
    'Form26Q': 'Form 26Q : TDS returns Filing',
    'FORM24Q': 'Form 24Q: TDS returns Filing',
    'Form24Q': 'Form 24Q: TDS returns Filing',
    'FORM27Q': 'Form 27Q : TDS returns Filing',
    'Form27Q': 'Form 27Q : TDS returns Filing',
    'FORM27EQ': 'Form 27EQ : TDS returns Filing',
    'Form27EQ': 'Form 27EQ : TDS returns Filing',
    
    # Password/Verification scripts
    'FO003_ForgotPassword': 'Forgot Password / Reset Password - e-File OTP',
    'ForgotPassword': 'Forgot Password / Reset Password - e-File OTP',
    'Forgot_Password': 'Forgot Password / Reset Password - e-File OTP',
    'FO009_VerifyYourPan_PostLogin': 'Verify Your PAN Details - Post Login',
    'VerifyYourPan_PostLogin': 'Verify Your PAN Details - Post Login',
    'VerifyYourPanPostLogin': 'Verify Your PAN Details - Post Login',
    'FO009_VerifyYourPan_PreLogin': 'Verify Your PAN Details - Pre Login',
    'VerifyYourPan_PreLogin': 'Verify Your PAN Details - Pre Login',
    'VerifyYourPanPreLogin': 'Verify Your PAN Details - Pre Login',
    'FO050_ChangePassword': 'Change Your Password',
    'ChangePassword': 'Change Your Password',
    'Change_Password': 'Change Your Password',
    
    # Payment API scripts
    'FO092_PaymentAPI_Bulkchallan_Generation': 'Payment API: Bulk Challan Creation',
    'PaymentAPI_Bulkchallan_Generation': 'Payment API: Bulk Challan Creation',
    'PaymentAPIBulkchallanGeneration': 'Payment API: Bulk Challan Creation',
    'FO092_PaymentAPI_DoubleVerification': 'Payment API: Double Verification',
    'PaymentAPI_DoubleVerification': 'Payment API: Double Verification',
    'PaymentAPIDoubleVerification': 'Payment API: Double Verification',
    'FO092_PaymentAPI_Validate_CRN': 'Payment API: Validate CRN-API Gateway',
    'PaymentAPI_Validate_CRN': 'Payment API: Validate CRN-API Gateway',
    'PaymentAPIValidateCRN': 'Payment API: Validate CRN-API Gateway',
    
    # Payment scripts
    'Payments_IncomeTax_26QDNetBanking': 'Payments: Net Banking: 26QD',
    'Payments_IncomeTax_Cheque': 'Payments: CHEQUE: Income Tax (Other than Companies) (0021) : TDS/TCS Regular Assessment (400) Pay Outstanding Demand',
    'Payments_IncomeTax_Debitcard': 'Payments: Debit Card: Income Tax (Other than Companies) (0021) : Minor Head (300)',
    'Payments_IncomeTax_NetBanking': 'Payments: Net Banking: Income Tax (Other than Companies) (0021) : Minor Head (100)',
    'Payments_IncomeTax_NEFTRTGS': 'Payments: NEFT / RTGS: Income Tax (Other than Companies) (0021) : Minor Head (300)',
    'Payments_IncomeTax_NEFT_RTGS': 'Payments: NEFT / RTGS: Income Tax (Other than Companies) (0021) : Minor Head (300)',
    'Payments_IncomeTax_CSIDownload': 'Payments: CSI Download',
    'Payments_IncomeTax_DownloadChallanReceipt': 'Payments: Download Challan Receipt',
    'Payments_IncomeTax_DownloadCh': 'Payments: Download Challan Receipt',
    'Payments_ViewChallanHistory': 'Payments: View Draft List; Challan List; History',
    
    # Payment Error scripts
    'Payments_IncomeTax_Debitcard_Error': 'Error: Payments: Debit Card: Income Tax (Other than Companies) (0021) : Minor Head (300)',
    'Payments_IncomeTax_NEFT_RTGS_Error': 'Error: Payments: NEFT / RTGS: Income Tax (Other than Companies) (0021) : Minor Head (300)',
    
    # Download scripts
    'Download_View_File_Returns': 'Download View File Returns',
    'DownloadViewFileReturns': 'Download View File Returns',
    
    # Profile/Dashboard scripts
    'Update_profile': 'Update Profile Details (Address Update)',
    'UpdateProfile': 'Update Profile Details (Address Update)',
    'FO013_Dashboard': 'Dashboard',
    'Dashboard': 'Dashboard',
    
    # Error scripts
    'FO002_LoginHere_InvalidPWd_Check': 'Error: Login Here',
    'FO002_LoginHere_InvalidPWd_Che': 'Error: Login Here',
    'LoginHere_InvalidPWd_Check': 'Error: Login Here',
}

# Regex patterns for dynamic ITR matching (handles prefixes like ER003_)
ITR_PATTERNS = {
    r'ITR[-_]?1[-_]?Online': 'Pre-filling and filing of ITR-1 Online (AY 25-26)',
    r'ITR[-_]?1[-_]?Offline': 'Pre-filling and filing of ITR-1 Offline (AY 25-26)',
    r'ITR[-_]?2[-_]?Online': 'Pre-filling and filing of ITR-2 Online (AY 25-26)',
    r'ITR[-_]?2[-_]?Offline': 'Pre-filling and filing of ITR-2 Offline (AY 25-26)',
    r'ITR[-_]?3[-_]?Online': 'Pre-filling and filing of ITR-3 Online (AY 25-26)',
    r'ITR[-_]?3[-_]?Offline': 'Pre-filling and filing of ITR-3 Offline (AY 25-26)',
    r'ITR[-_]?4[-_]?Online': 'Pre-filling and filing of ITR-4 Online (AY 25-26)',
    r'ITR[-_]?4[-_]?Offline': 'Pre-filling and filing of ITR-4 Offline (AY 25-26)',
    r'ITR[-_]?6[-_]?Online': 'Pre-filling and filing of ITR-6 Online (AY 25-26)',
    r'ITR[-_]?6[-_]?Offline': 'Pre-filling and filing of ITR-6 Offline (AY 25-26)',
}

# Per-script LR-group semantic hints. Consulted after exact/mapped lookups
# fail and before the strict-norm/fuzzy chain. Each entry maps a script_key
# to (must_match_regex, must_not_match_regex); the first LR group whose
# name matches `must_match` and does NOT match `must_not_match` is used.
# Intended for cases where the LR scenario naming convention diverges
# from the FinalReport script naming convention.
SCRIPT_LR_GROUP_HINTS = {
    # Convention: in this LR scenario the unqualified "VerifyPANDetails"
    # group represents the Pre-Login PAN verify flow; the explicit
    # "VerifyPan_PostLogin" group is the Post-Login variant. The
    # FinalReport script "VerifyYourPan_PreLogin" therefore must map to
    # the unqualified group (and must NOT collide with the PostLogin
    # group).
    'VerifyYourPan_PreLogin': (
        re.compile(r'verify[\W_]*pa?n[\W_]*details', re.IGNORECASE),
        re.compile(r'post[\W_]*login', re.IGNORECASE),
    ),
    'FO009_VerifyYourPan_PreLogin': (
        re.compile(r'verify[\W_]*pa?n[\W_]*details', re.IGNORECASE),
        re.compile(r'post[\W_]*login', re.IGNORECASE),
    ),
}

def normalize_script_name(name: str) -> str:
    """
    Normalize script name for fuzzy matching.
    Removes common prefixes, handles separators, and standardizes text.
    """
    if not name:
        return ""
    
    # Convert to lowercase
    normalized = name.lower()
    
    # Remove common prefixes (ER###_, numbers at start, etc.)
    normalized = re.sub(r'^[a-z]*\d+[_\-]?', '', normalized)  # Remove prefixes like ER003_, 245_, etc.
    normalized = re.sub(r'^\d+[_\-]?', '', normalized)  # Remove leading numbers
    
    # Remove all separators and spaces
    normalized = re.sub(r'[_\-\s\(\)\[\]]+', '', normalized)
    
    # Remove common suffixes
    normalized = re.sub(r'ay\d+\-?\d*$', '', normalized)  # Remove AY 25-26
    normalized = re.sub(r'screen$', '', normalized)  # Remove "Screen"
    normalized = re.sub(r'check$', '', normalized)  # Remove "Check"
    
    return normalized

def fuzzy_match_script(script_key: str, target_lookup: dict, itr_patterns: dict = None) -> float:
    """
    Advanced fuzzy matching for script names.
    Returns the Target TPS value if matched, else 0.
    
    Matching priority:
    1. Exact match in SCRIPT_NAME_MAPPING
    2. Direct match in target_lookup
    3. ITR regex patterns
    4. Normalized name matching
    5. Key word matching (for partial matches)
    """
    # Step 1: Check explicit mapping
    if script_key in SCRIPT_NAME_MAPPING:
        mapped_name = SCRIPT_NAME_MAPPING[script_key]
        if mapped_name in target_lookup:
            return target_lookup[mapped_name]
    
    # Step 2: Direct match
    if script_key in target_lookup:
        return target_lookup[script_key]
    
    # Step 3: ITR regex patterns (handles prefixes like ER003_ITR3_Offline)
    if itr_patterns:
        for pattern, canonical_name in itr_patterns.items():
            if re.search(pattern, script_key, re.IGNORECASE):
                if canonical_name in target_lookup:
                    return target_lookup[canonical_name]
    
    # Step 4: Normalized matching
    script_normalized = normalize_script_name(script_key)
    
    best_match_score = 0
    best_match_value = 0
    
    for target_name, tps_value in target_lookup.items():
        target_normalized = normalize_script_name(target_name)
        
        # Exact normalized match
        if script_normalized == target_normalized:
            return tps_value
        
        # Check if one contains the other
        if script_normalized in target_normalized or target_normalized in script_normalized:
            # Calculate similarity score based on length ratio
            len_ratio = min(len(script_normalized), len(target_normalized)) / max(len(script_normalized), len(target_normalized), 1)
            if len_ratio > best_match_score:
                best_match_score = len_ratio
                best_match_value = tps_value
    
    # Only return if match score is good enough (>60% similarity)
    if best_match_score > 0.6:
        return best_match_value
    
    # Step 5: Key word matching
    # Extract key words from script name
    key_words = set(re.findall(r'[a-z]+', script_key.lower()))
    # Remove common words
    common_words = {'and', 'the', 'of', 'for', 'to', 'in', 'at', 'by', 'pre', 'post', 'filing'}
    key_words -= common_words
    
    for target_name, tps_value in target_lookup.items():
        target_words = set(re.findall(r'[a-z]+', target_name.lower()))
        target_words -= common_words
        
        # Check overlap
        if key_words and target_words:
            overlap = len(key_words & target_words)
            total = len(key_words | target_words)
            if total > 0 and overlap / total > 0.5:  # More than 50% word overlap
                return tps_value
    
    return 0

# Back Office (BO) Usecase names - for categorization in Excel
BO_USECASES = {
    'UPA Landing Screen',
    'Assesse Filing History',
    'Assesee Communication',
    'Refund/Demand Status',
    'E-Proceedings',
    'Tax-Payer Ledger',
    'Worklist',
    'Abandoning & Reprocessing',
    'ITR Collection Report',
    'Response to outstanding demand',
    'Data Quality Type Screen',
    'Track Work Item',
    'View Filed Returns',
    'Refund-Reissue Bulk Fetch',
    'Mark Candidate for Rectification',
    '245(2) Bulk fetch',
}

TARGET_TPS_LOOKUP = {
    # =========================================================================
    # BACK OFFICE USECASES (16 scripts)
    # =========================================================================
    'UPA Landing Screen': 1.94,
    'Assesse Filing History': 0.56,
    'Assesee Communication': 0.83,
    'Refund/Demand Status': 0.28,
    'E-Proceedings': 0.28,
    'Tax-Payer Ledger': 0.28,
    'Worklist': 0.84,
    'Abandoning & Reprocessing': 0.56,
    'ITR Collection Report': 0.42,
    'Response to outstanding demand': 0.28,
    'Data Quality Type Screen': 0.14,
    'Track Work Item': 0.14,
    'View Filed Returns': 1.12,
    'Refund-Reissue Bulk Fetch': 0.14,
    'Mark Candidate for Rectification': 0.14,
    '245(2) Bulk fetch': 0.14,
    
    # =========================================================================
    # FRONTEND USECASES - AY 2025-26 (49 scripts)
    # =========================================================================
    'Login Here': 64.6,
    'Dashboard': 64.6,
    'Update Profile Details (Address Update)': 38.76,
    'Download Prefill JSON': 51.68,
    'Pre-filling and filing of ITR-1 Online (AY 25-26)': 104.43,
    'Pre-filling and filing of ITR-1 Offline (AY 25-26)': 35.04,
    'Pre-filling and filing of ITR-2 Online (AY 25-26)': 18.53,
    'Pre-filling and filing of ITR-2 Offline (AY 25-26)': 21.78,
    'Pre-filling and filing of ITR-3 Online (AY 25-26)': 19.36,
    'Pre-filling and filing of ITR-3 Offline (AY 25-26)': 33.07,
    'Pre-filling and filing of ITR-4 Online (AY 25-26)': 68.73,
    'Pre-filling and filing of ITR-4 Offline (AY 25-26)': 52.97,
    'Pre-filling and filing of ITR-6 Online (AY 25-26)': 0.74,
    'Pre-filling and filing of ITR-6 Offline (AY 25-26)': 6.47,
    'ITR Status (ITR receipt status) - Post Login': 13.57,
    'Download View File Returns': 33.56,
    'e-Verification for ITR': 74.61,
    'Forgot Password / Reset Password - e-File OTP': 23.48,
    'Change Your Password': 22.36,
    'Verify Your PAN Details - Pre Login': 22.36,
    'Verify Your PAN Details - Post Login': 22.36,
    'Prevalidate Bank Account': 46.95,
    'Form 10BA': 7.72,
    'Form 15G': 7.72,
    'Form 15H': 7.72,
    'Form 26Q : TDS returns Filing': 7.72,
    'Form 24Q: TDS returns Filing': 7.72,
    'Form 27Q : TDS returns Filing': 7.72,
    'Form 27EQ : TDS returns Filing': 7.72,
    'View Forms File Download': 7.72,
    'View Receipt Download': 333.45,
    'Error: Login Here': 6.46,
    'Error: Pre-filling and filing of ITR-1 Online (AY 25-26)': 6.94,
    'Error: Pre-filling and filing of ITR-2 Online (AY 25-26)': 1.11,
    'Error: Pre-filling and filing of ITR-3 Online (AY 25-26)': 1.67,
    'Error: Pre-filling and filing of ITR-4 Online (AY 25-26)': 5.0,
    'Payment API: Bulk Challan Creation': 36.0,
    'Payment API: Validate CRN-API Gateway': 36.0,
    'Payment API: Double Verification': 36.0,
    'Payments: Net Banking: 26QD': 0.38,
    'Payments: Net Banking: Income Tax (Other than Companies) (0021) : Minor Head (100)': 5.86,
    'Payments: Debit Card: Income Tax (Other than Companies) (0021) : Minor Head (300)': 5.86,
    'Payments: NEFT / RTGS: Income Tax (Other than Companies) (0021) : Minor Head (300)': 20.03,
    'Payments: CHEQUE: Income Tax (Other than Companies) (0021) : TDS/TCS Regular Assessment (400) Pay Outstanding Demand': 5.67,
    'Error: Payments: Debit Card: Income Tax (Other than Companies) (0021) : Minor Head (300)': 1.8,
    'Error: Payments: NEFT / RTGS: Income Tax (Other than Companies) (0021) : Minor Head (300)': 1.8,
    'Payments: Download Challan Receipt': 18.0,
    'Payments: View Draft List; Challan List; History': 36.0,
    'Payments: CSI Download': 36.0,
}


# =============================================================================
# WLM (Workload Model) workbook support
# -----------------------------------------------------------------------------
# The FinalReport can be driven from an external "Final_WLM_YYYY_YYYY.xlsx"
# workbook that owns:
#   - the authoritative usecase name list (row order = report order)
#   - the Target TPS values for those usecases
#   - the FO/BO section split (delimited by a merged "BO Usecases" row)
#   - the cell styles (fill/font/border/alignment) to apply to the
#     usecase-name-derived columns of FinalReport (SL No / Description /
#     Target TPS -- columns B/C/D)
#
# When a WLM workbook is present, FinalReport rows are emitted in WLM order.
# Every LR script gets classified BO or FO (via is_bo_script()) and then
# either matched to a WLM entry (WLM order, WLM style, WLM TPS) or appended
# to its section's tail as an unmatched row (WLM style still applied to
# B/C/D so the section looks uniform; description/TPS come from the legacy
# SCRIPT_NAME_MAPPING + TARGET_TPS_LOOKUP fallback).
#
# When no WLM workbook is available, the writer falls back to the legacy
# TARGET_TPS_LOOKUP + custom_target_tps.json pipeline (unchanged behavior).
# =============================================================================

def _normalize_wlm_name(name):
    """Normalize a usecase name for matching between LR / WLM / SCRIPT_NAME_MAPPING.

    Rules:
      1. Coerce to string.
      2. Split CamelCase / letter-digit boundaries so LR script keys like
         ``PaymentsCSIDownload`` and ``ITR1Online`` become ``Payments CSI
         Download`` and ``ITR 1 Online``.
      3. Strip AY-year suffixes in all common shapes:
           (AY 25-26) / (AY 26-27) / AY 25-26 / AY_25_26 / AY-25-26
      4. Lowercase, replace any non-alphanumeric char with a single space.
      5. Collapse runs of whitespace, trim.
      6. Apply a tiny token-canonicalization map (payments -> payment) so
         WLM "Payments: CSI Download" and legacy "Payment: CSI Download"
         collide onto the same key.
    Returns '' when the input yields no alnum content.
    """
    if name is None:
        return ''
    s = str(name)
    # 2. CamelCase / acronym / letter-digit splits (done BEFORE lower).
    s = re.sub(r'([a-z0-9])([A-Z])', r'\1 \2', s)        # aB -> a B
    s = re.sub(r'([A-Z])([A-Z][a-z])', r'\1 \2', s)      # AAb -> A Ab (e.g. PANDetails -> PAN Details)
    s = re.sub(r'([A-Za-z])([0-9])', r'\1 \2', s)        # A1 -> A 1
    s = re.sub(r'([0-9])([A-Za-z])', r'\1 \2', s)        # 1A -> 1 A
    s = s.lower()
    # 3. AY-year suffix in parens, then bare
    s = re.sub(r'\(\s*ay\s*\d{2}\s*[-_/]\s*\d{2}\s*\)', ' ', s)
    s = re.sub(r'\bay\s*\d{2}\s*[-_/]\s*\d{2}\b', ' ', s)
    # 4. non-alnum -> space
    s = re.sub(r'[^a-z0-9]+', ' ', s)
    # 5. collapse + trim
    s = re.sub(r'\s+', ' ', s).strip()
    if not s:
        return ''
    # 6. tiny token canon
    tokens = []
    for tok in s.split(' '):
        if tok == 'payments':
            tok = 'payment'
        tokens.append(tok)
    return ' '.join(tokens)


def _copy_openpyxl_style(src_cell, dst_cell):
    """Copy fill, font, border, alignment, number_format from src to dst.

    Uses ``copy.copy`` for the style objects to avoid the openpyxl
    StyleProxy binding gotcha where assigning ``dst.font = src.font``
    silently no-ops because the StyleProxy is bound to the source
    workbook.
    """
    from copy import copy as _copy
    try:
        dst_cell.fill = _copy(src_cell.fill)
    except Exception:
        pass
    try:
        dst_cell.font = _copy(src_cell.font)
    except Exception:
        pass
    try:
        dst_cell.border = _copy(src_cell.border)
    except Exception:
        pass
    try:
        dst_cell.alignment = _copy(src_cell.alignment)
    except Exception:
        pass
    try:
        if src_cell.number_format:
            dst_cell.number_format = src_cell.number_format
    except Exception:
        pass


def load_wlm_workbook(wlm_path):
    """Read a Final_WLM_YYYY_YYYY.xlsx file into a plain dict.

    Returns None if the workbook can't be opened or has no recognizable
    usecase rows -- caller should fall back to the legacy TARGET_TPS_LOOKUP
    pipeline in that case.

    Returns dict with keys:
      - 'path'         : the resolved WLM file path
      - 'sheet_name'   : name of the WLM data sheet
      - 'fo_entries'   : list of {'sl_no', 'name', 'tps', 'wlm_row'} for FO usecases
      - 'bo_entries'   : list of same shape for BO usecases
      - 'name_to_entry': dict {wlm_display_name: entry_dict}
      - 'norm_index'   : dict {normalized_name: wlm_display_name}
      - 'section_of'   : dict {wlm_display_name: 'BO'|'FO'}
      - 'header_style_row' : the raw row number of the WLM header (used for style copy)
      - 'data_style_row'   : a representative data row (used for style copy)
      - 'workbook'     : the openpyxl Workbook (kept open so callers can copy styles)
    """
    if not EXCEL_AVAILABLE or not wlm_path or not os.path.exists(wlm_path):
        return None
    try:
        wb = openpyxl.load_workbook(wlm_path, data_only=True)
    except Exception as ex:
        print(f"[WLM] Failed to open {wlm_path}: {ex}")
        return None

    # Pick the first sheet that has usecase-shaped data
    ws = wb.worksheets[0]
    sheet_name = ws.title

    # Detect header row (row that has "SL No", "Usecase Name", "Target TPS" in cols A/B/C)
    header_row = None
    for r in range(1, min(6, ws.max_row + 1)):
        c1 = str(ws.cell(row=r, column=1).value or '').strip().lower()
        c2 = str(ws.cell(row=r, column=2).value or '').strip().lower()
        c3 = str(ws.cell(row=r, column=3).value or '').strip().lower()
        if 'sl' in c1 and ('use' in c2 or 'name' in c2) and 'tps' in c3:
            header_row = r
            break
    if header_row is None:
        header_row = 1  # assume conventional layout

    # Detect the FO/BO divider: a merged row spanning A:C with "BO" in it
    bo_divider_row = None
    for m in ws.merged_cells.ranges:
        # merged like A71:C71
        if m.min_row == m.max_row and m.min_col == 1 and m.max_col >= 2:
            v = ws.cell(row=m.min_row, column=1).value
            if v and 'bo' in str(v).lower():
                bo_divider_row = m.min_row
                break

    fo_entries = []
    bo_entries = []
    name_to_entry = {}
    norm_index = {}
    section_of = {}

    for r in range(header_row + 1, ws.max_row + 1):
        sl_val = ws.cell(row=r, column=1).value
        name_val = ws.cell(row=r, column=2).value
        tps_val = ws.cell(row=r, column=3).value
        # Skip blank rows
        if name_val is None or str(name_val).strip() == '':
            continue
        # Skip the BO divider row itself
        if bo_divider_row is not None and r == bo_divider_row:
            continue

        # Determine section
        section = 'BO' if (bo_divider_row is not None and r > bo_divider_row) else 'FO'
        # Coerce TPS to float if possible
        try:
            tps_num = float(tps_val) if tps_val is not None and str(tps_val).strip() != '' else None
        except (TypeError, ValueError):
            tps_num = None

        display_name = str(name_val).strip()
        entry = {
            'sl_no': sl_val,
            'name': display_name,
            'tps': tps_num,
            'wlm_row': r,
            'section': section,
        }
        if section == 'BO':
            bo_entries.append(entry)
        else:
            fo_entries.append(entry)

        # If two WLM rows normalize to the same key, first-writer-wins so we
        # preserve WLM order.
        name_to_entry[display_name] = entry
        norm = _normalize_wlm_name(display_name)
        if norm and norm not in norm_index:
            norm_index[norm] = display_name
        section_of[display_name] = section

    if not fo_entries and not bo_entries:
        # workbook opened but no recognizable rows -- treat as absent
        return None

    # Pick a representative data row for style copying (first FO row, then first BO)
    data_style_row = None
    if fo_entries:
        data_style_row = fo_entries[0]['wlm_row']
    elif bo_entries:
        data_style_row = bo_entries[0]['wlm_row']

    return {
        'path': wlm_path,
        'sheet_name': sheet_name,
        'fo_entries': fo_entries,
        'bo_entries': bo_entries,
        'name_to_entry': name_to_entry,
        'norm_index': norm_index,
        'section_of': section_of,
        'header_style_row': header_row,
        'data_style_row': data_style_row,
        'workbook': wb,
    }


def resolve_wlm_workbook_path(explicit_path=None, search_roots=None):
    """Locate the WLM workbook to use for this run.

    Resolution order:
      1. ``explicit_path`` if provided and it exists.
      2. Env var ``LRR_WLM_WORKBOOK`` if set and file exists.
      3. For each root in ``search_roots`` (defaults to script dir + cwd):
           a) ``<root>/TargetTPS_Presets/Final_WLM_2026_2027.xlsx``
           b) most-recent ``<root>/TargetTPS_Presets/Final_WLM*.xlsx``
    Returns the resolved absolute path or None.
    """
    import glob

    def _ok(p):
        return p and os.path.isfile(p)

    if _ok(explicit_path):
        return os.path.abspath(explicit_path)

    env_path = os.environ.get('LRR_WLM_WORKBOOK')
    if _ok(env_path):
        return os.path.abspath(env_path)

    if search_roots is None:
        search_roots = []
        try:
            search_roots.append(os.path.dirname(os.path.abspath(__file__)))
        except NameError:
            pass
        search_roots.append(os.getcwd())

    seen = set()
    for root in search_roots:
        if not root:
            continue
        root_abs = os.path.abspath(root)
        if root_abs in seen:
            continue
        seen.add(root_abs)
        preset_dir = os.path.join(root_abs, 'TargetTPS_Presets')
        if not os.path.isdir(preset_dir):
            continue
        # (a) fixed name
        fixed = os.path.join(preset_dir, 'Final_WLM_2026_2027.xlsx')
        if _ok(fixed):
            return fixed
        # (b) glob fallback, most-recent
        matches = [p for p in glob.glob(os.path.join(preset_dir, 'Final_WLM*.xlsx')) if _ok(p)]
        if matches:
            matches.sort(key=lambda p: os.path.getmtime(p), reverse=True)
            return matches[0]
    return None


def match_lr_script_to_wlm(script_key, wlm_data, script_name_mapping,
                           combined_tps_lookup, find_target_tps_name_fn):
    """Return the WLM display name for an LR script_key, or None.

    Matching chain (all case/AY/punctuation-insensitive via _normalize_wlm_name):
      1. Direct: normalized script_key -> WLM
      2. Mapped: SCRIPT_NAME_MAPPING[script_key] normalized -> WLM
      3. Resolved-description: find_target_tps_name(script_key) normalized -> WLM
      4. Substring: any WLM whose normalized name is a token-boundary
         substring of the LR normalized key, or vice versa.
    """
    if not wlm_data:
        return None
    norm_index = wlm_data['norm_index']

    # 1. Direct normalized match
    n1 = _normalize_wlm_name(script_key)
    if n1 and n1 in norm_index:
        return norm_index[n1]

    # 2. Via SCRIPT_NAME_MAPPING
    mapped = script_name_mapping.get(script_key)
    if mapped:
        n2 = _normalize_wlm_name(mapped)
        if n2 and n2 in norm_index:
            return norm_index[n2]

    # 3. Via legacy find_target_tps_name (uses ITR_PATTERNS + fuzzy)
    try:
        resolved = find_target_tps_name_fn(script_key, combined_tps_lookup)
    except Exception:
        resolved = None
    if resolved:
        n3 = _normalize_wlm_name(resolved)
        if n3 and n3 in norm_index:
            return norm_index[n3]

    # 4. Substring fallback -- word-boundary aware.
    #    We require the shorter side to appear at a word boundary in the
    #    longer side to avoid "form" matching "informal" etc.
    def _boundary_contains(hay_norm, needle_norm):
        if not hay_norm or not needle_norm:
            return False
        if needle_norm == hay_norm:
            return True
        # normalized form uses single spaces as separators
        return (
            hay_norm.startswith(needle_norm + ' ')
            or hay_norm.endswith(' ' + needle_norm)
            or (' ' + needle_norm + ' ') in hay_norm
        )

    if n1:
        for wlm_norm, wlm_display in norm_index.items():
            if _boundary_contains(n1, wlm_norm) or _boundary_contains(wlm_norm, n1):
                return wlm_display
    return None


class LRRParser:
    """Parser for LoadRunner .lrr result files."""
    
    def __init__(self, lrr_path: str):
        """
        Initialize parser with path to .lrr file.
        
        Args:
            lrr_path: Path to the .lrr file or the result folder containing it
        """
        if os.path.isdir(lrr_path):
            # Find .lrr file in the folder
            lrr_files = [f for f in os.listdir(lrr_path) if f.endswith('.lrr')]
            if not lrr_files:
                raise FileNotFoundError(f"No .lrr file found in {lrr_path}")
            self.lrr_path = os.path.join(lrr_path, lrr_files[0])
            self.result_folder = lrr_path
        else:
            self.lrr_path = lrr_path
            self.result_folder = os.path.dirname(lrr_path)
        
        self.scenario_info = {}
        self.transaction_summary = []
        self.tps_data = []
        self.errors = []
        self.response_times = {}
        self.sum_dat_config = {}
        self.running_vusers = []
        self.max_vusers = 0
        self.avg_vusers = 0
        
        # HTTP Statistics (response codes, connections, retries) - Full Duration
        self.http_statistics = {
            'response_codes': {},   # HTTP_200: count, HTTP_500: count, etc.
            'web_connections': {},  # Connection metrics
            'web_ssl': {},          # SSL session metrics
            'retries': {},          # Retry reasons
        }
        
        # HTTP Statistics - Steady State filtered
        self.http_statistics_ss = {
            'response_codes': {},
            'web_connections': {},
            'web_ssl': {},
            'retries': {},
        }
        
        # API Errors with URLs (parsed from log files)
        self.api_errors = []  # List of {script, action, line, error_code, http_status, api_url, error_msg, count}
        
        # API calls per transaction (parsed from script .c files)
        self.transaction_api_calls = {}  # Dict: transaction_name -> [{service_name, api_endpoint, full_url, method}]
        
        # Script paths from .lrr [Scripts] section (for auto-discovery)
        self.script_paths = {}  # Dict: script_name -> path_to_usr_file
        
        # Per-script vuser counts (parsed from output.mdb)
        self.script_vuser_counts = {}  # Dict: script_name -> vuser_count
        
        # Per-script User Count lookup tracing (set to a list by
        # `enable_lookup_trace()` or env var LRR_LOOKUP_TRACE=1).
        # When non-None, export_to_excel records every step of the
        # Column J lookup decision and dumps it to a sidecar TSV.
        self._lookup_trace_lines = None
        
        # Steady state timing (relative to test start, in seconds)
        self.steady_state_start = 0  # Absolute timestamp or 0
        self.steady_state_end = 0    # Absolute timestamp or 0
        self.steady_state_from_rel = -1  # Relative: seconds from test start (-1 = not set)
        self.steady_state_to_rel = -1    # Relative: seconds from test start (-1 = not set)
        self.steady_state_duration = 0
        self.ramp_up_seconds = 0
        self.ramp_down_seconds = 0
        self._user_steady_state = False  # Flag to indicate user-provided steady state
        self._scenario_start_epoch = 0   # Epoch timestamp of test start
    
    def _get_total_users_for_report(self) -> int:
        """Return the value displayed for the 'User Count' badge in Excel sheets.

        Semantics:
        - Multi-controller (`aggregate_data` was called and `all_scenario_info`
          has more than one entry): SUM of each controller's max_vusers.
          This represents the total concurrent virtual user load generated by
          all controllers in parallel, which is what testers expect to see as
          the overall test user count.
        - Single-controller: `self.max_vusers` (max running vusers during SS).
        """
        all_scenarios = getattr(self, 'all_scenario_info', None)
        if all_scenarios and len(all_scenarios) > 1:
            total = 0
            for ctrl_data in all_scenarios:
                try:
                    total += int(ctrl_data.get('max_vusers', 0) or 0)
                except Exception:
                    pass
            return total
        try:
            return int(self.max_vusers or 0)
        except Exception:
            return 0
    
    def enable_lookup_trace(self):
        """Turn on per-row User Count lookup tracing for the next
        export_to_excel() call. Trace is written to
        '<output_xlsx>.lookup-trace.tsv'."""
        self._lookup_trace_lines = []
    
    def set_steady_state(self, from_seconds: int, to_seconds: int, is_absolute: bool = True):
        """
        Set user-specified steady state timing.
        Call this before parse() to override auto-detection.
        
        Args:
            from_seconds: Steady state start time in seconds (wall-clock time as HH:MM:SS converted to seconds)
            to_seconds: Steady state end time in seconds (wall-clock time as HH:MM:SS converted to seconds)
            is_absolute: If True, times are absolute wall-clock times that need conversion
        """
        self._absolute_ss_from = from_seconds if is_absolute else None
        self._absolute_ss_to = to_seconds if is_absolute else None
        self._is_absolute_ss = is_absolute
        
        # Store raw values - will be converted to relative after parsing lrr file
        self.ramp_up_seconds = from_seconds
        self.steady_state_duration = to_seconds - from_seconds
        self.steady_state_from_rel = from_seconds
        self.steady_state_to_rel = to_seconds
        self._user_steady_state = True
        
    def parse(self, progress_callback=None) -> Dict[str, Any]:
        """Parse the .lrr file and related data files.
        
        Args:
            progress_callback: Optional callable(step_name, percentage) to report progress
        """
        def report(step, pct):
            if progress_callback:
                progress_callback(step, pct)
        
        report("Reading LRR file", 5)
        self._parse_lrr_file()
        
        # Auto-discover and parse script files from paths in .lrr [Scripts] section
        report("Discovering scripts", 10)
        self._auto_discover_scripts()
        
        # If user specified steady state, calculate timestamps now that we have scenario_start
        if self._user_steady_state:
            self._apply_user_steady_state()
        
        report("Parsing config", 15)
        self._parse_sum_dat_ini()
        
        # Debug: log config info
        self._debug_info = getattr(self, '_debug_info', [])
        self._debug_info.append(f"sum_dat_config sections: {list(self.sum_dat_config.keys())}")
        
        report("Parsing graph data", 30)
        self._parse_graph_data()
        
        # DEBUG PRINT: Show what avg_tps values were found
        if DEBUG:
            debug_print("\n" + "="*60)
            debug_print("DEBUG: avg_tps values in response_times:")
            for name, data in self.response_times.items():
                if 'avg_tps' in data:
                    debug_print(f"  {name}: avg_tps={data['avg_tps']}")
            debug_print("="*60 + "\n")
        
        # Safety check: if no data was parsed, try without filtering
        report("Validating data", 70)
        if len(self.response_times) == 0 and self._user_steady_state:
            self._debug_info.append("WARNING: No data after filtering. Retrying without filter...")
            # Temporarily disable filtering
            saved_user_ss = self._user_steady_state
            self._user_steady_state = False
            self._parse_graph_data()
            self._user_steady_state = saved_user_ss
            self._debug_info.append(f"After retry without filter: {len(self.response_times)} transactions")
        
        report("Calculating summary", 85)
        self._calculate_transaction_summary()
        
        report("Done", 100)
        return self.get_all_data()
    
    def parse_vusers_only(self) -> Dict[str, Any]:
        """Lightweight parse for VUsers graph data only. Much faster than full parse()."""
        self._parse_lrr_file()
        self._parse_sum_dat_ini()
        self._parse_running_vusers()
        return {
            'running_vusers': self.running_vusers
        }
    
    def _detect_data_granularity(self) -> int:
        """Detect the data granularity (time bucket size) from graph files.
        
        LoadRunner stores data in time buckets (commonly 1s, 5s, or 10s intervals).
        This method reads a sample of graph data to determine the bucket size.
        
        Returns:
            int: Data granularity in seconds (default 5 if detection fails)
        """
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        sum_dat_path = os.path.join(sum_data_path, 'sum_dat.ini')
        
        if not os.path.exists(sum_dat_path):
            return 5  # Default fallback
        
        try:
            # Parse sum_dat.ini to find a graph file
            config = configparser.ConfigParser(interpolation=None)
            with open(sum_dat_path, 'r', encoding='utf-8-sig') as f:
                config.read_file(f)
            
            # Find es_tr_tprange_pass graph (most reliable for granularity)
            graph_section = None
            for section in config.sections():
                if config.has_option(section, 'graphtype'):
                    graph_type = config.get(section, 'graphtype')
                    if graph_type == 'es_tr_tprange_pass':
                        graph_section = section
                        break
            
            if not graph_section:
                # Fall back to any graph file
                for section in config.sections():
                    if section.startswith('graph_'):
                        graph_section = section
                        break
            
            if not graph_section:
                return 5  # Default fallback
            
            # Read sample timestamps from the graph data file
            graph_file = os.path.join(sum_data_path, f'{graph_section}.dat')
            if not os.path.exists(graph_file):
                return 5  # Default fallback
            
            timestamps = set()
            with open(graph_file, 'r', encoding='utf-8', errors='ignore') as f:
                for i, line in enumerate(f):
                    if i >= 1000:  # Sample first 1000 lines
                        break
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        try:
                            ts = int(parts[1])
                            if ts > 1000000000:  # Valid epoch timestamp
                                timestamps.add(ts)
                        except ValueError:
                            continue
            
            if len(timestamps) < 2:
                return 5  # Default fallback
            
            # Sort timestamps and find minimum difference
            sorted_ts = sorted(timestamps)
            diffs = [sorted_ts[i+1] - sorted_ts[i] for i in range(len(sorted_ts)-1) if sorted_ts[i+1] - sorted_ts[i] > 0]
            
            if diffs:
                granularity = min(diffs)
                if 1 <= granularity <= 60:  # Reasonable range
                    return granularity
            
            return 5  # Default fallback
            
        except Exception as e:
            # Any error, return default
            return 5

    def _apply_user_steady_state(self):
        """Apply user-specified steady state timing to calculate timestamps.
        
        Handles two modes:
        1. Absolute (is_absolute=True): Wall-clock time (e.g., 13:38:56 = 49136 seconds into the day)
           Converts to epoch timestamps and relative offsets.
        2. Relative (is_absolute=False): Seconds from test start (e.g., 600 = 10 minutes from start)
           Uses values directly as relative offsets.
        """
        if hasattr(self, 'scenario_info') and 'start_time' in self.scenario_info:
            try:
                test_start_dt = self.scenario_info['start_time']
                self._scenario_start_epoch = int(test_start_dt.timestamp())
                
                # Check if user input is absolute (wall clock) or relative (from test start)
                is_absolute = getattr(self, '_is_absolute_ss', True)
                
                if is_absolute:
                    # User input is absolute wall-clock time as total seconds from midnight
                    # e.g., 13:38:56 = 13*3600 + 38*60 + 56 = 49136 seconds
                    user_ss_from_seconds = self.steady_state_from_rel  # This was stored from user input
                    user_ss_to_seconds = self.steady_state_to_rel
                    
                    # Get the date portion of test start
                    test_date = test_start_dt.date()
                    
                    # Convert wall-clock seconds to datetime on the same date as test
                    ss_from_time = datetime.combine(test_date, datetime.min.time()) + timedelta(seconds=user_ss_from_seconds)
                    ss_to_time = datetime.combine(test_date, datetime.min.time()) + timedelta(seconds=user_ss_to_seconds)
                    
                    # Convert to epoch timestamps (no offset for response time data)
                    self.steady_state_start = int(ss_from_time.timestamp())
                    self.steady_state_end = int(ss_to_time.timestamp())
                    
                    # Store data granularity for pass count bucket alignment
                    self._data_granularity = self._detect_data_granularity()
                    
                    # Calculate relative offsets from test start (before alignment)
                    orig_from_rel = self.steady_state_start - self._scenario_start_epoch
                    orig_to_rel = self.steady_state_end - self._scenario_start_epoch
                    
                    # Auto-align to bucket boundaries to match LoadRunner's behavior
                    # Round start UP to next bucket boundary, end DOWN to previous boundary
                    if self._data_granularity > 0:
                        aligned_from_rel = math.ceil(orig_from_rel / self._data_granularity) * self._data_granularity
                        aligned_to_rel = math.floor(orig_to_rel / self._data_granularity) * self._data_granularity
                    else:
                        aligned_from_rel = orig_from_rel
                        aligned_to_rel = orig_to_rel
                    
                    # Update epoch timestamps with aligned values
                    self.steady_state_start = self._scenario_start_epoch + aligned_from_rel
                    self.steady_state_end = self._scenario_start_epoch + aligned_to_rel
                    
                    self.steady_state_from_rel = aligned_from_rel
                    self.steady_state_to_rel = aligned_to_rel
                    self.ramp_up_seconds = self.steady_state_from_rel
                    self.steady_state_duration = self.steady_state_to_rel - self.steady_state_from_rel
                    
                    # Debug output
                    debug_print(f"\n  === Steady State (Absolute Mode) ===")
                    debug_print(f"  From: {user_ss_from_seconds//3600:02d}:{(user_ss_from_seconds%3600)//60:02d}:{user_ss_from_seconds%60:02d} to {user_ss_to_seconds//3600:02d}:{(user_ss_to_seconds%3600)//60:02d}:{user_ss_to_seconds%60:02d}")
                    debug_print(f"  Duration: {self.steady_state_duration}s")
                    debug_print(f"  =====================================\n")
                else:
                    # User input is relative: seconds from test start
                    # e.g., 600 = 10 minutes from test start
                    rel_from = self.steady_state_from_rel
                    rel_to = self.steady_state_to_rel
                    
                    # Calculate absolute epoch timestamps (no offset for response time data)
                    self.steady_state_start = self._scenario_start_epoch + rel_from
                    self.steady_state_end = self._scenario_start_epoch + rel_to
                    
                    # Store data granularity for pass count bucket alignment
                    # Pass count data uses bucketed aggregation which needs offset
                    self._data_granularity = self._detect_data_granularity()
                    
                    # Use original user times (no auto-alignment)
                    # LoadRunner filters data by the exact user-specified boundaries
                    self.ramp_up_seconds = rel_from
                    self.steady_state_duration = rel_to - rel_from
                    
                    # Debug output
                    debug_print(f"\n  === Steady State (Relative Mode) ===")
                    debug_print(f"  From: {rel_from}s to {rel_to}s")
                    debug_print(f"  Duration: {self.steady_state_duration}s")
                    debug_print(f"  =====================================\n")
                
                # Store in scenario_info for display
                self.scenario_info['ramp_up_seconds'] = self.ramp_up_seconds
                self.scenario_info['steady_state_duration'] = self.steady_state_duration
                if is_absolute:
                    self.scenario_info['steady_state_start'] = ss_from_time
                    self.scenario_info['steady_state_end'] = ss_to_time
                else:
                    self.scenario_info['steady_state_start'] = test_start_dt + timedelta(seconds=self.steady_state_from_rel)
                    self.scenario_info['steady_state_end'] = test_start_dt + timedelta(seconds=self.steady_state_to_rel)
            except Exception as e:
                debug_print(f"  ERROR in _apply_user_steady_state: {e}")
                import traceback
                traceback.print_exc()
    
    def _is_timestamp_in_steady_state(self, timestamp: int, apply_bucket_offset: bool = False) -> bool:
        """Check if a timestamp falls within the steady state period.
        Handles both relative (seconds from test start) and absolute (epoch) timestamps.
        
        Args:
            timestamp: The timestamp to check
            apply_bucket_offset: If True, include buckets that START at or before SS end
        """
        # If no steady state filtering configured, include all data
        if not self._user_steady_state:
            return True
        
        # Must have valid steady state times configured
        if self.steady_state_to_rel < 0:
            return True
        
        # Get granularity for bucket offset - LoadRunner includes buckets that START within SS
        gran = getattr(self, '_data_granularity', 5) if apply_bucket_offset else 0
        
        # Determine if timestamp is relative or absolute
        if timestamp < 1000000000:
            # Timestamp is relative (seconds from test start)
            from_val = self.steady_state_from_rel if self.steady_state_from_rel >= 0 else 0
            # Include buckets that START at or before SS end (bucket covers data up to timestamp + gran)
            return from_val <= timestamp <= (self.steady_state_to_rel + gran)
        else:
            # Timestamp is absolute (epoch)
            if self.steady_state_start > 0 and self.steady_state_end > 0:
                return self.steady_state_start <= timestamp <= (self.steady_state_end + gran)
            # Fallback: convert absolute timestamp to relative and compare
            if self._scenario_start_epoch > 0:
                relative_ts = timestamp - self._scenario_start_epoch
                from_val = self.steady_state_from_rel if self.steady_state_from_rel >= 0 else 0
                return from_val <= relative_ts <= (self.steady_state_to_rel + gran)
            # Last fallback: no filtering if we can't determine
            return True
    
    def _parse_lrr_file(self):
        """Parse the main .lrr file for scenario information."""
        config = configparser.ConfigParser(interpolation=None)
        # Handle BOM encoding
        config.read(self.lrr_path, encoding='utf-8-sig')
        
        # Extract scenario information
        if config.has_section('Scenario'):
            self.scenario_info['product'] = config.get('Scenario', 'Product', fallback='N/A')
            self.scenario_info['version'] = config.get('Scenario', 'Version', fallback='N/A')
            self.scenario_info['result_name'] = config.get('Scenario', 'ResultName', fallback='N/A')
            
            # Try to get scenario file path (points to .lrs file)
            scenario_path = config.get('Scenario', 'Scenario', fallback=None)
            if scenario_path:
                self.scenario_info['scenario_path'] = scenario_path
            
            start_time = config.get('Scenario', 'Start_time', fallback='0')
            stop_time = config.get('Scenario', 'Stop_time', fallback='0')
            
            try:
                self.scenario_info['start_time'] = datetime.fromtimestamp(int(start_time))
                self.scenario_info['stop_time'] = datetime.fromtimestamp(int(stop_time))
                self.scenario_info['duration_seconds'] = int(stop_time) - int(start_time)
            except (ValueError, OSError):
                self.scenario_info['start_time'] = 'N/A'
                self.scenario_info['stop_time'] = 'N/A'
                self.scenario_info['duration_seconds'] = 0
        
        if config.has_section('Scenario_summary'):
            self.scenario_info['scenario_type'] = config.get('Scenario_summary', 'Scenario Type', fallback='N/A')
            self.scenario_info['mode'] = config.get('Scenario_summary', 'Mode', fallback='N/A')
            self.scenario_info['duration'] = config.get('Scenario_summary', 'Scenario Duration', fallback='N/A')
            
            # Parse steady state timing from duration string (only if not user-specified)
            if not self._user_steady_state:
                self._parse_steady_state_timing(self.scenario_info.get('duration', ''))
        
        # Extract script paths from [Scripts] section for auto-discovery
        if config.has_section('Scripts'):
            for script_name, script_path in config.items('Scripts'):
                # script_path is the full path to the .usr file
                # e.g., C:\PerformanceTesting\AY25-26\01-Scripts\...\05 ITR1_ONLINE_AY_25_26_JAN.usr
                self.script_paths[script_name] = script_path
            debug_print(f"DEBUG: Found {len(self.script_paths)} script paths in [Scripts] section")
    
    def _parse_steady_state_timing(self, duration_str: str):
        """
        Parse the scenario duration string to extract ramp-up, steady state, and ramp-down times.
        
        Example: "Start all Vusers: 10 every 00:00:01 (HH:MM:SS); Run for 00:10:00 (HH:MM:SS); Stop all Vusers: 10 every 00:00:01 (HH:MM:SS)"
        """
        if not duration_str or duration_str == 'N/A':
            return
        
        def time_str_to_seconds(time_str):
            """Convert HH:MM:SS to seconds."""
            try:
                parts = time_str.strip().split(':')
                if len(parts) == 3:
                    return int(parts[0]) * 3600 + int(parts[1]) * 60 + int(parts[2])
            except:
                pass
            return 0
        
        # Parse ramp-up: "Start all Vusers: X every HH:MM:SS"
        ramp_up_match = re.search(r'Start all Vusers:\s*(\d+)\s*every\s*(\d+:\d+:\d+)', duration_str)
        if ramp_up_match:
            num_users = int(ramp_up_match.group(1))
            ramp_interval = time_str_to_seconds(ramp_up_match.group(2))
            self.ramp_up_seconds = num_users * ramp_interval
        
        # Parse steady state: "Run for HH:MM:SS"
        steady_match = re.search(r'Run for\s*(\d+:\d+:\d+)', duration_str)
        if steady_match:
            self.steady_state_duration = time_str_to_seconds(steady_match.group(1))
        
        # Parse ramp-down: "Stop all Vusers: X every HH:MM:SS"
        ramp_down_match = re.search(r'Stop all Vusers:\s*(\d+)\s*every\s*(\d+:\d+:\d+)', duration_str)
        if ramp_down_match:
            num_users = int(ramp_down_match.group(1))
            ramp_interval = time_str_to_seconds(ramp_down_match.group(2))
            self.ramp_down_seconds = num_users * ramp_interval
        
        # Calculate steady state start and end timestamps
        if hasattr(self, 'scenario_info') and 'start_time' in self.scenario_info:
            try:
                self._scenario_start_epoch = int(self.scenario_info['start_time'].timestamp())
                self.steady_state_start = self._scenario_start_epoch + self.ramp_up_seconds
                self.steady_state_end = self.steady_state_start + self.steady_state_duration
                
                # Also set relative timestamps for filtering
                self.steady_state_from_rel = self.ramp_up_seconds
                self.steady_state_to_rel = self.ramp_up_seconds + self.steady_state_duration
                
                # Store in scenario_info for display
                self.scenario_info['ramp_up_seconds'] = self.ramp_up_seconds
                self.scenario_info['steady_state_duration'] = self.steady_state_duration
                self.scenario_info['ramp_down_seconds'] = self.ramp_down_seconds
                self.scenario_info['steady_state_start'] = datetime.fromtimestamp(self.steady_state_start)
                self.scenario_info['steady_state_end'] = datetime.fromtimestamp(self.steady_state_end)
            except:
                pass
    
    def _parse_sum_dat_ini(self):
        """Parse sum_dat.ini for graph and measurement definitions."""
        sum_dat_path = os.path.join(self.result_folder, 'sum_data', 'sum_dat.ini')
        self._debug_info = getattr(self, '_debug_info', [])
        
        if not os.path.exists(sum_dat_path):
            self._debug_info.append(f"sum_dat.ini NOT FOUND at {sum_dat_path}")
            # Check if sum_data folder exists
            sum_data_folder = os.path.join(self.result_folder, 'sum_data')
            if os.path.exists(sum_data_folder):
                files = os.listdir(sum_data_folder)[:10]
                self._debug_info.append(f"sum_data folder exists, files: {files}")
            else:
                self._debug_info.append(f"sum_data folder does NOT exist at {sum_data_folder}")
            return
        
        self._debug_info.append(f"Found sum_dat.ini at {sum_dat_path}")
        
        config = configparser.ConfigParser(interpolation=None)
        # Handle BOM encoding
        config.read(sum_dat_path, encoding='utf-8-sig')
        
        # Get general info
        if config.has_section('General'):
            self.scenario_info['graphs_number'] = config.get('General', 'GraphsNumber', fallback='0')
            self.scenario_info['scenario_duration'] = config.get('General', 'ScenarioDuration', fallback='0')
        
        # Parse each graph section
        for section in config.sections():
            if section.startswith('graph_'):
                graph_type = config.get(section, 'GraphType', fallback='')
                measurement_num = int(config.get(section, 'Measurement_num', fallback='0'))
                
                measurements = {}
                for i in range(measurement_num):
                    key = f'Measurement_{i}'
                    if config.has_option(section, key):
                        value = config.get(section, key)
                        # Parse measurement format: Name,ID or Name,ID#extra_data
                        # Handle names that may contain commas by finding the last comma before # or end
                        hash_idx = value.find('#')
                        before_hash = value[:hash_idx] if hash_idx > 0 else value
                        
                        # Find the last comma to split name and ID
                        # The ID should be a number right before the # or end
                        last_comma_idx = before_hash.rfind(',')
                        if last_comma_idx > 0:
                            name = before_hash[:last_comma_idx].strip()
                            try:
                                meas_id = int(before_hash[last_comma_idx+1:].strip())
                                measurements[meas_id] = name
                            except ValueError:
                                # Fallback to old parsing
                                parts = before_hash.split(',')
                                if len(parts) >= 2:
                                    name = parts[0]
                                    try:
                                        meas_id = int(parts[-1])
                                        measurements[meas_id] = name
                                    except ValueError:
                                        pass
                
                self.sum_dat_config[section] = {
                    'type': graph_type,
                    'measurements': measurements
                }
                
                # Parse HTTP Statistics graphs
                if graph_type == 'HTTP_RC':
                    for meas_id, name in measurements.items():
                        self.http_statistics['response_codes'][name] = meas_id
                elif graph_type == 'Web_Connections':
                    for meas_id, name in measurements.items():
                        self.http_statistics['web_connections'][name] = meas_id
                elif graph_type == 'Web_Connections_Per_Second':
                    for meas_id, name in measurements.items():
                        key = f"{name} (per sec)"
                        self.http_statistics['web_connections'][key] = meas_id
                elif graph_type == 'Web_SSL':
                    for meas_id, name in measurements.items():
                        self.http_statistics['web_ssl'][name] = meas_id
                elif graph_type == 'Retries':
                    for meas_id, name in measurements.items():
                        self.http_statistics['retries'][name] = meas_id
        
        # RAW parsing of sum_dat.ini to get full error measurement names
        # ConfigParser might truncate at special characters like quotes
        self._parse_error_measurements_raw(sum_dat_path)
        
        # Debug: Log all available graph types
        self._debug_info = getattr(self, '_debug_info', [])
        graph_types = [(s, c['type']) for s, c in self.sum_dat_config.items()]
        self._debug_info.append(f"Available graphs: {graph_types}")
    
    def _parse_error_measurements_raw(self, sum_dat_path):
        """Parse sum_dat.ini with raw file reading to get full error measurement names.
        ConfigParser may truncate at special characters like quotes in error messages.
        """
        if not os.path.exists(sum_dat_path):
            return
        
        debug_print(f"DEBUG: Raw parsing sum_dat.ini for full error measurement names")
        
        try:
            # Read file with different encodings
            content = None
            for encoding in ['utf-8-sig', 'utf-8', 'latin-1', 'cp1252']:
                try:
                    with open(sum_dat_path, 'r', encoding=encoding) as f:
                        content = f.read()
                    break
                except UnicodeDecodeError:
                    continue
            
            if not content:
                debug_print("DEBUG: Could not read sum_dat.ini with any encoding")
                return
            
            # Find all graph sections and their types first
            lines = content.split('\n')
            current_section = None
            section_types = {}  # section_name -> graph_type
            
            for line in lines:
                line = line.strip()
                
                # Check for section header
                if line.startswith('[') and line.endswith(']'):
                    current_section = line[1:-1]
                    continue
                
                # Look for GraphType
                if current_section and line.startswith('GraphType='):
                    graph_type = line.split('=', 1)[1].strip()
                    section_types[current_section] = graph_type
            
            # Find the error distribution section
            error_section = None
            for section, gtype in section_types.items():
                if gtype == 'es_tr_errors_distribution':
                    error_section = section
                    debug_print(f"DEBUG: Found error distribution in section: {error_section}")
                    break
            
            if not error_section:
                debug_print("DEBUG: No es_tr_errors_distribution section found")
                return
            
            # Now re-parse to get measurements from the error section
            current_section = None
            error_measurements = {}
            
            for line in lines:
                line = line.strip()
                
                # Check for section header
                if line.startswith('[') and line.endswith(']'):
                    current_section = line[1:-1]
                    continue
                
                # Only process measurements in the error section
                if current_section == error_section and line.startswith('Measurement_'):
                    # Format: Measurement_0=Error -26366:05_ITR1_ONLINE...,123#extra
                    eq_idx = line.find('=')
                    if eq_idx > 0:
                        meas_value = line[eq_idx+1:].strip()
                        
                        # Parse: "Error -26366:Script:Action.c(741) Error -26366 message,ID#extra"
                        # Find the last comma before # (that's followed by a number)
                        hash_idx = meas_value.find('#')
                        before_hash = meas_value[:hash_idx] if hash_idx > 0 else meas_value
                        
                        # Find the measurement ID (last number after last comma)
                        last_comma_idx = before_hash.rfind(',')
                        if last_comma_idx > 0:
                            name = before_hash[:last_comma_idx].strip()
                            try:
                                meas_id = int(before_hash[last_comma_idx+1:].strip())
                                error_measurements[meas_id] = name
                                debug_print(f"DEBUG: Raw error [{meas_id}]: {name[:100]}...")
                            except ValueError:
                                pass
            
            # Update the error config with full measurement names
            if error_measurements:
                debug_print(f"DEBUG: Found {len(error_measurements)} raw error measurements")
                for section, config in self.sum_dat_config.items():
                    if config['type'] == 'es_tr_errors_distribution':
                        # Replace with raw parsed measurements
                        config['measurements'] = error_measurements
                        debug_print(f"DEBUG: Updated {section} with raw measurements")
                        break
            
        except Exception as e:
            debug_print(f"DEBUG: Error in raw parsing: {e}")
            import traceback
            traceback.print_exc()
    
    def _parse_graph_data(self):
        """Parse graph_*.dat files for actual data."""
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        if not os.path.exists(sum_data_path):
            return
        
        # Try to read transaction summary directly from output.mdb first (matches LR Analysis exactly)
        mdb_success = self._parse_transaction_summary_from_mdb()
        
        # Parse response time data (graph_4.dat - es_tr_response_time)
        self._parse_response_time_data()
        
        # Only parse pass/fail from graphs if mdb parsing failed
        if not mdb_success:
            # Parse transaction pass counts (graph_2.dat - es_tr_tprange_pass)
            self._parse_transaction_pass_data()
            
            # Parse transaction fail counts (graph_13.dat - es_tr_tprange_fail)
            self._parse_transaction_fail_data()
        
        # Parse actual TPS values from LoadRunner graph (es_tr_tps)
        self._parse_tps_graph_data()
        
        # Parse running Vusers (user count during steady state)
        self._parse_running_vusers()
        
        # Parse per-script/group vuser counts from output.mdb
        self._parse_script_vuser_counts()
        
        # Parse error distribution (graph_7.dat - es_tr_errors_distribution)
        self._parse_error_data()
        
        # Parse HTTP statistics (response codes, connections, SSL, retries)
        self._parse_http_statistics_data()
    
    def _parse_transaction_summary_from_mdb(self):
        """Try to read transaction summary directly from output.mdb.
        This matches LoadRunner Analysis exactly since it uses the same data source.
        Returns True if successful, False if we need to fall back to graph parsing.
        """
        try:
            import pyodbc
        except ImportError:
            debug_print("DEBUG: pyodbc not available - falling back to graph parsing")
            return False
        
        output_mdb_path = os.path.join(self.result_folder, 'output.mdb')
        if not os.path.exists(output_mdb_path):
            debug_print(f"DEBUG: output.mdb not found at {output_mdb_path}")
            return False
        
        try:
            conn_str = f'DRIVER={{Microsoft Access Driver (*.mdb, *.accdb)}};DBQ={output_mdb_path};'
            conn = pyodbc.connect(conn_str)
            cursor = conn.cursor()
            
            # Get list of tables
            tables = [row.table_name for row in cursor.tables(tableType='TABLE')]
            debug_print(f"DEBUG: output.mdb tables for transaction summary: {tables}")
            
            # Look for transaction summary table
            # Common tables: TransactionEndDetail, Event_meter, TransSum
            trans_tables = ['TransactionEndDetail', 'Event_meter', 'TransSum', 'Transaction']
            
            trans_data = {}
            
            for table_name in trans_tables:
                if table_name in tables:
                    try:
                        cursor.execute(f"SELECT * FROM [{table_name}] WHERE 1=0")
                        columns = [desc[0] for desc in cursor.description]
                        debug_print(f"DEBUG: {table_name} columns: {columns}")
                        
                        # For TransactionEndDetail, filter by steady state
                        if table_name == 'TransactionEndDetail':
                            # TransactionEndDetail typically has: TransactionName, EndTime, Duration, Status
                            # Status 0 = Pass, Status 1 = Fail
                            ss_start = self.steady_state_start if self.steady_state_start > 0 else 0
                            ss_end = self.steady_state_end if self.steady_state_end > 0 else 999999999999
                            
                            # Query with SS filter
                            query = f"""
                                SELECT TransactionName, Status, COUNT(*) as cnt 
                                FROM [{table_name}] 
                                WHERE EndTime >= {ss_start} AND EndTime <= {ss_end}
                                GROUP BY TransactionName, Status
                            """
                            debug_print(f"DEBUG: Executing query: {query}")
                            cursor.execute(query)
                            rows = cursor.fetchall()
                            debug_print(f"DEBUG: Got {len(rows)} transaction summary rows")
                            
                            for row in rows:
                                trans_name = row[0]
                                status = row[1]
                                count = row[2]
                                
                                if trans_name not in trans_data:
                                    trans_data[trans_name] = {'pass_count': 0, 'fail_count': 0}
                                
                                if status == 0:  # Pass
                                    trans_data[trans_name]['pass_count'] = count
                                else:  # Fail
                                    trans_data[trans_name]['fail_count'] = count
                            
                            if trans_data:
                                debug_print(f"DEBUG: Successfully parsed {len(trans_data)} transactions from {table_name}")
                                
                                # Store in response_times
                                for trans_name, counts in trans_data.items():
                                    if trans_name not in self.response_times:
                                        self.response_times[trans_name] = {'times': [], 'count': 0}
                                    self.response_times[trans_name]['pass_count'] = counts['pass_count']
                                    self.response_times[trans_name]['fail_count'] = counts['fail_count']
                                
                                conn.close()
                                return True
                        
                    except Exception as e:
                        debug_print(f"DEBUG: Error reading {table_name}: {e}")
                        continue
            
            conn.close()
            return False
            
        except Exception as e:
            debug_print(f"DEBUG: Database error reading transaction summary: {e}")
            return False
    
    def _parse_response_time_data(self):
        """Parse response time data from es_tr_response_time graph."""
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        self._debug_info = getattr(self, '_debug_info', [])
        
        # Find the response time graph file dynamically from sum_dat.ini
        response_time_config = None
        response_time_graph_file = None
        for section, config in self.sum_dat_config.items():
            if config['type'] == 'es_tr_response_time':
                response_time_config = config
                # Extract graph number from section name (e.g., 'graph_4' -> 'graph_4.dat')
                response_time_graph_file = os.path.join(sum_data_path, f'{section}.dat')
                break
        
        if not response_time_config:
            self._debug_info.append("No es_tr_response_time config found in sum_dat.ini")
            self._debug_info.append(f"Available graph types: {[c['type'] for c in self.sum_dat_config.values()]}")
            return
        
        if not response_time_graph_file or not os.path.exists(response_time_graph_file):
            self._debug_info.append(f"Response time graph file not found: {response_time_graph_file}")
            # List available graph files
            if os.path.exists(sum_data_path):
                dat_files = [f for f in os.listdir(sum_data_path) if f.endswith('.dat')]
                self._debug_info.append(f"Available .dat files: {dat_files[:10]}")
            return
        
        # Initialize response time data structure
        self.response_times = defaultdict(lambda: {'times': [], 'count': 0})
        
        total_lines = 0
        filtered_out = 0
        included = 0
        sample_timestamps = []
        
        with open(response_time_graph_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 3:
                    try:
                        meas_id = int(parts[0])
                        timestamp = int(parts[1])
                        response_time = float(parts[2])
                        total_lines += 1
                        
                        # Collect sample timestamps for debugging
                        if len(sample_timestamps) < 5:
                            sample_timestamps.append(timestamp)
                        
                        # Filter by steady state period (if configured)
                        if not self._is_timestamp_in_steady_state(timestamp):
                            filtered_out += 1
                            continue  # Skip data outside steady state
                        
                        included += 1
                        if meas_id in response_time_config['measurements']:
                            trans_name = response_time_config['measurements'][meas_id]
                            self.response_times[trans_name]['times'].append(response_time)
                            self.response_times[trans_name]['count'] += 1
                    except (ValueError, IndexError):
                        continue
        
        # Store debug info
        self._debug_info = getattr(self, '_debug_info', [])
        self._debug_info.append(f"Response time parsing: {total_lines} lines, {included} included, {filtered_out} filtered out")
        self._debug_info.append(f"Sample timestamps: {sample_timestamps}")
        self._debug_info.append(f"SS filter: {self.steady_state_from_rel}s to {self.steady_state_to_rel}s")
        self._debug_info.append(f"Transactions captured: {len(self.response_times)}")
    
    def _parse_transaction_pass_data(self):
        """Parse transaction pass count data from es_tr_tprange_pass graph.
        The graph stores cumulative pass counts, so we need to get:
        (value at end of SS) - (value at start of SS)
        """
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        self._debug_info = getattr(self, '_debug_info', [])
        
        # Find the pass count graph file dynamically from sum_dat.ini
        pass_config = None
        pass_graph_file = None
        for section, config in self.sum_dat_config.items():
            if config['type'] == 'es_tr_tprange_pass':
                pass_config = config
                # Extract graph number from section name (e.g., 'graph_2' -> 'graph_2.dat')
                pass_graph_file = os.path.join(sum_data_path, f'{section}.dat')
                self._debug_info.append(f"Pass count graph: {section}.dat")
                break
        
        if not pass_config or not pass_graph_file or not os.path.exists(pass_graph_file):
            self._debug_info.append(f"Pass count graph not found. Config: {pass_config is not None}, File: {pass_graph_file}")
            return
        
        # Track first and last values per transaction within steady state
        # Data format: meas_id, timestamp, cumulative_count
        trans_data = defaultdict(list)  # trans_name -> [(timestamp, count), ...]
        
        with open(pass_graph_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 3:
                    try:
                        meas_id = int(parts[0])
                        timestamp = int(parts[1])
                        count = float(parts[2])
                        
                        # Filter by steady state period (if configured)
                        if not self._is_timestamp_in_steady_state(timestamp, apply_bucket_offset=True):
                            continue  # Skip data outside steady state
                        
                        if meas_id in pass_config['measurements']:
                            trans_name = pass_config['measurements'][meas_id]
                            trans_data[trans_name].append((timestamp, int(count)))
                    except (ValueError, IndexError):
                        continue
        
        # Calculate pass counts with proportional weighting for boundary buckets
        pass_counts = {}
        for trans_name, data_points in trans_data.items():
            if data_points:
                # Sort by timestamp
                data_points.sort(key=lambda x: x[0])
                
                # LoadRunner es_tr_tprange_pass data is INCREMENTAL (count per interval)
                # Simply sum all values within the SS period - no fractional weighting
                # LoadRunner counts all passes where the bucket falls within SS window
                total = sum(point[1] for point in data_points)
                
                pass_counts[trans_name] = total
        
        # Store in response_times for aggregation
        # Note: Measurement names may have :Pass suffix - strip it to match response_times keys
        for trans_name_with_suffix, count in pass_counts.items():
            # Strip :Pass suffix if present
            base_name = trans_name_with_suffix
            if base_name.endswith(':Pass'):
                base_name = base_name[:-5]
            
            if base_name not in self.response_times:
                self.response_times[base_name] = {'times': [], 'count': 0}
            self.response_times[base_name]['pass_count'] = count
    
    def _parse_transaction_fail_data(self):
        """Parse transaction fail count data from es_tr_tprange_fail graph.
        The graph stores cumulative fail counts, so we need to get:
        (value at end of SS) - (value at start of SS)
        """
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        
        # Find the fail count graph file dynamically from sum_dat.ini
        fail_config = None
        fail_graph_file = None
        for section, config in self.sum_dat_config.items():
            if config['type'] == 'es_tr_tprange_fail':
                fail_config = config
                # Extract graph number from section name (e.g., 'graph_13' -> 'graph_13.dat')
                fail_graph_file = os.path.join(sum_data_path, f'{section}.dat')
                break
        
        if not fail_config or not fail_graph_file or not os.path.exists(fail_graph_file):
            return
        
        # Track first and last values per transaction within steady state
        trans_data = defaultdict(list)  # trans_name -> [(timestamp, count), ...]
        
        with open(fail_graph_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 3:
                    try:
                        meas_id = int(parts[0])
                        timestamp = int(parts[1])
                        count = float(parts[2])
                        
                        # Filter by steady state period (if configured)
                        # Apply bucket offset for fail count data (same as pass count)
                        if not self._is_timestamp_in_steady_state(timestamp, apply_bucket_offset=True):
                            continue  # Skip data outside steady state
                        
                        if meas_id in fail_config['measurements']:
                            trans_name = fail_config['measurements'][meas_id]
                            trans_data[trans_name].append((timestamp, int(count)))
                    except (ValueError, IndexError):
                        continue
        
        # Calculate fail counts: SUM all values within steady state (incremental data)
        fail_counts = {}
        for trans_name, data_points in trans_data.items():
            if data_points:
                # Sum all values - data is incremental (count per time interval)
                total = sum(point[1] for point in data_points)
                fail_counts[trans_name] = total
        
        # Store in response_times for aggregation
        # Note: Measurement names may have :Fail suffix - strip it to match response_times keys
        for trans_name_with_suffix, count in fail_counts.items():
            # Strip :Fail suffix if present
            base_name = trans_name_with_suffix
            if base_name.endswith(':Fail'):
                base_name = base_name[:-5]
            
            if base_name not in self.response_times:
                self.response_times[base_name] = {'times': [], 'count': 0}
            self.response_times[base_name]['fail_count'] = count
    
    def _parse_tps_graph_data(self):
        """Parse TPS values from LoadRunner data.
        
        First tries es_tr_tps graph (if available).
        Falls back to calculating TPS from es_tr_tprange_pass (count / granularity).
        """
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        self._debug_info = getattr(self, '_debug_info', [])
        
        debug_print("\n--- _parse_tps_graph_data CALLED ---")
        debug_print(f"sum_dat_config has {len(self.sum_dat_config)} sections")
        
        # First, try to find es_tr_tps graph (direct TPS values)
        tps_config = None
        tps_graph_file = None
        for section, config in self.sum_dat_config.items():
            if config['type'] == 'es_tr_tps':
                tps_config = config
                tps_graph_file = os.path.join(sum_data_path, f'{section}.dat')
                debug_print(f"  FOUND es_tr_tps graph: {section}")
                break
        
        # If es_tr_tps not found, fall back to es_tr_tprange_pass
        if not tps_config:
            debug_print("  No es_tr_tps graph found, trying es_tr_tprange_pass...")
            for section, config in self.sum_dat_config.items():
                if config['type'] == 'es_tr_tprange_pass':
                    tps_config = config
                    tps_graph_file = os.path.join(sum_data_path, f'{section}.dat')
                    debug_print(f"  FOUND es_tr_tprange_pass graph: {section}")
                    self._debug_info.append(f"Using es_tr_tprange_pass for TPS calculation: {section}")
                    break
        
        if not tps_config:
            debug_print("  WARNING: No TPS or tprange_pass graph found!")
            self._debug_info.append(f"WARNING: No TPS graph found. Available: {[c['type'] for c in self.sum_dat_config.values()]}")
            return
        
        if not tps_graph_file or not os.path.exists(tps_graph_file):
            debug_print(f"  WARNING: Graph file not found: {tps_graph_file}")
            return
        
        graph_type = tps_config['type']
        is_pass_count = (graph_type == 'es_tr_tprange_pass')
        
        debug_print(f"  Using graph type: {graph_type}")
        debug_print(f"  Measurements (first 5): {list(tps_config['measurements'].values())[:5]}")
        
        # Determine raw data granularity
        raw_granularity = 1
        all_timestamps = set()
        if is_pass_count:
            with open(tps_graph_file, 'r', encoding='utf-8') as f:
                for i, line in enumerate(f):
                    if i > 200:
                        break
                    parts = line.strip().split()
                    if len(parts) >= 2:
                        try:
                            all_timestamps.add(int(parts[1]))
                        except ValueError:
                            pass
            
            if len(all_timestamps) >= 2:
                sorted_ts = sorted(all_timestamps)
                diffs = [sorted_ts[i+1] - sorted_ts[i] for i in range(min(20, len(sorted_ts)-1)) if sorted_ts[i+1] - sorted_ts[i] > 0]
                if diffs:
                    raw_granularity = min(diffs)  # Smallest interval is raw granularity
                    if raw_granularity <= 0:
                        raw_granularity = 1
        
        # Use raw granularity (from LoadRunner data) for statistics to match LoadRunner Analysis
        ss_duration = self.steady_state_duration if self.steady_state_duration > 0 else 600
        # Use raw granularity for bucket calculations (matches LoadRunner Analysis)
        bucket_granularity = raw_granularity if raw_granularity > 0 else 5
        
        debug_print(f"  Raw data granularity: {raw_granularity} seconds")
        debug_print(f"  Using bucket granularity: {bucket_granularity} seconds (matches LoadRunner)")
        
        # Parse data - collect raw (timestamp, count) per transaction
        raw_data = defaultdict(list)  # trans_name -> [(timestamp, count), ...]
        total_lines = 0
        filtered_out = 0
        
        with open(tps_graph_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 3:
                    total_lines += 1
                    try:
                        meas_id = int(parts[0])
                        timestamp = int(parts[1])
                        value = float(parts[2])
                        
                        # Filter by steady state period (if configured)
                        # Apply bucket offset for TPS data (aggregated in buckets)
                        if not self._is_timestamp_in_steady_state(timestamp, apply_bucket_offset=True):
                            filtered_out += 1
                            continue
                        
                        if meas_id in tps_config['measurements']:
                            trans_name = tps_config['measurements'][meas_id]
                            raw_data[trans_name].append((timestamp, value))
                    except (ValueError, IndexError):
                        continue
        
        debug_print(f"  Graph data: {total_lines} lines read, {filtered_out} filtered by SS")
        
        # Aggregate raw data into raw-granularity buckets for each transaction
        # This matches how LoadRunner Analysis calculates statistics
        # Use steady state start time as the base for all transactions (for alignment)
        ss_start = self.steady_state_start if self.steady_state_start > 0 else (min(all_timestamps) if all_timestamps else 0)
        
        tps_values = {}
        for trans_name, data_points in raw_data.items():
            if not data_points:
                continue
            
            # Aggregate counts into raw-granularity buckets aligned to SS start
            buckets = defaultdict(float)
            bucket_data_count = defaultdict(int)  # Track how many data points per bucket
            for ts, count in data_points:
                bucket_num = (ts - ss_start) // bucket_granularity
                buckets[bucket_num] += count
                bucket_data_count[bucket_num] += 1
            
            # Calculate TPS per bucket using raw granularity
            all_bucket_tps = []
            for bucket_num in sorted(buckets.keys()):
                tps = buckets[bucket_num] / bucket_granularity
                all_bucket_tps.append(tps)
            
            # Trim edge buckets (first 2 and last 2) for MIN/MAX/MEDIAN/STDDEV
            # LoadRunner Analysis filters out incomplete ramp-up/ramp-down periods
            if len(all_bucket_tps) > 4:
                trimmed_bucket_tps = all_bucket_tps[2:-2]
            else:
                trimmed_bucket_tps = all_bucket_tps
            
            if trimmed_bucket_tps:
                # Store both: all_buckets for AVG calculation, trimmed for other stats
                tps_values[trans_name] = {
                    'all_buckets': all_bucket_tps,
                    'trimmed_buckets': trimmed_bucket_tps
                }
        
        debug_print(f"  tps_values has {len(tps_values)} transactions (using {bucket_granularity}s raw granularity)")
        if tps_values:
            sample_names = list(tps_values.keys())[:3]
            for name in sample_names[:2]:
                data = tps_values[name]
                if data:
                    all_vals = data['all_buckets']
                    debug_print(f"    {name}: buckets={len(all_vals)}, avg={sum(all_vals)/len(all_vals):.4f}")
        
        # Debug: Log response_time keys for comparison
        rt_keys = list(self.response_times.keys())
        debug_print(f"  response_times has {len(rt_keys)} transactions")
        if rt_keys:
            debug_print(f"  Response time keys sample: {rt_keys[:3]}")
            self._debug_info.append(f"Response time keys sample: {rt_keys[:3]}")
        
        tps_matched = 0
        tps_unmatched = []
        
        for trans_name_with_suffix, bucket_data in tps_values.items():
            # Strip :Pass or :Fail suffix if present to match response_times key
            base_name = trans_name_with_suffix
            if base_name.endswith(':Pass'):
                base_name = base_name[:-5]
            elif base_name.endswith(':Fail'):
                base_name = base_name[:-5]
            
            # Check if this name exists in response_times
            if base_name in self.response_times:
                tps_matched += 1
            else:
                tps_unmatched.append(base_name[:30])
                self.response_times[base_name] = {'times': [], 'count': 0}
            
            all_buckets = bucket_data.get('all_buckets', [])
            trimmed_buckets = bucket_data.get('trimmed_buckets', [])
            
            if all_buckets:
                # Simplified TPS calculation: Pass Count / SS Duration
                if is_pass_count:
                    # Get pass_count directly if available, otherwise calculate from buckets
                    if base_name in self.response_times and 'pass_count' in self.response_times[base_name]:
                        pass_count = self.response_times[base_name]['pass_count']
                    else:
                        # Sum raw counts from buckets
                        pass_count = sum(all_buckets) * bucket_granularity
                    avg_tps = pass_count / ss_duration if ss_duration > 0 else 0
                else:
                    # For es_tr_tps graph, values are already TPS - use bucket average
                    avg_tps = sum(all_buckets) / len(all_buckets)
                
                self.response_times[base_name]['avg_tps'] = round(avg_tps, 4)
                # Store TRIMMED values for min/max/median/std statistics
                self.response_times[base_name]['tps_values'] = trimmed_buckets
                # Debug log for bulk fetch and other key transactions
                if '245' in base_name or 'Bulk' in base_name:
                    debug_print(f"  STORED TPS: {base_name} = avg={avg_tps:.4f}, trimmed_buckets={len(trimmed_buckets)}, min={min(trimmed_buckets):.3f}, max={max(trimmed_buckets):.3f}")
                    self._debug_info.append(f"TPS: {base_name}, avg_tps={avg_tps:.4f}")
        
        debug_print(f"  TPS graph: {tps_matched} matched, {len(tps_unmatched)} unmatched")
        self._debug_info.append(f"TPS graph: {tps_matched} matched, {len(tps_unmatched)} unmatched")
        if tps_unmatched:
            debug_print(f"  Unmatched TPS names: {tps_unmatched[:5]}")
            self._debug_info.append(f"Unmatched TPS names: {tps_unmatched[:5]}")
    
    def _parse_running_vusers(self):
        """Parse running Vusers data to get user count during steady state."""
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        self._debug_info = getattr(self, '_debug_info', [])
        
        # Initialize vuser data
        self.running_vusers = []
        self.max_vusers = 0
        self.avg_vusers = 0
        self.all_running_vusers = []
        self.all_vuser_timestamps = []
        
        # Find the running Vusers graph - look for es_tr_runtime_vusers type
        vuser_graph_types = [
            'es_tr_runtime_vusers', 'es_running_vusers', 'es_vuser_running', 
            'vusers_running', 'running_vusers', 'es_vusers', 'vuser_count'
        ]
        
        vuser_config = None
        vuser_graph_file = None
        vuser_section = None
        running_measurement_id = None
        
        # First pass: find the VUser graph config
        for section, config in self.sum_dat_config.items():
            graph_type = config.get('type', '').lower()
            if graph_type in [t.lower() for t in vuser_graph_types]:
                vuser_config = config
                vuser_section = section
                vuser_graph_file = os.path.join(sum_data_path, f'{section}.dat')
                self._debug_info.append(f"Found vuser graph: {section} -> {config.get('type')}")
                
                # Find the "Running" measurement ID from config
                # measurements is stored as {id: name} dict
                measurements = config.get('measurements', {})
                for meas_id, name in measurements.items():
                    if name == 'Running':
                        running_measurement_id = str(meas_id)
                        self._debug_info.append(f"Running measurement ID: {running_measurement_id}")
                        break
                break
        
        # Second pass: partial match
        if not vuser_config:
            for section, config in self.sum_dat_config.items():
                graph_type = config.get('type', '').lower()
                if 'vuser' in graph_type or 'running' in graph_type:
                    vuser_config = config
                    vuser_section = section
                    vuser_graph_file = os.path.join(sum_data_path, f'{section}.dat')
                    self._debug_info.append(f"Found vuser graph (partial match): {section} -> {config.get('type')}")
                    
                    # Try to find Running measurement in partial match too
                    measurements = config.get('measurements', {})
                    for meas_id, name in measurements.items():
                        if name == 'Running':
                            running_measurement_id = str(meas_id)
                            self._debug_info.append(f"Running measurement ID (partial): {running_measurement_id}")
                            break
                    break
        
        # Third pass: try graph_1.dat which often contains vuser data
        if not vuser_config:
            graph_1_path = os.path.join(sum_data_path, 'graph_1.dat')
            if os.path.exists(graph_1_path):
                vuser_graph_file = graph_1_path
                self._debug_info.append(f"Trying graph_1.dat for vuser data")
        
        if not vuser_graph_file or not os.path.exists(vuser_graph_file):
            self._debug_info.append(f"No Vuser graph file found")
            # List all available graph types for debugging
            all_types = [f"{s}: {c.get('type', 'N/A')}" for s, c in self.sum_dat_config.items()]
            self._debug_info.append(f"Available graphs: {all_types[:5]}")
            return
        
        # If no Running measurement ID found, try to detect it from the data
        # by finding the measurement ID with values that look like VUser counts (integers, ramping up)
        if not running_measurement_id:
            self._debug_info.append("Running measurement ID not found in config, scanning data...")
            # Scan file to find candidate measurement ID with highest max value that looks like VUsers
            with open(vuser_graph_file, 'r', encoding='utf-8') as f:
                meas_max = {}
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 3:
                        try:
                            mid = parts[0]
                            val = float(parts[2])
                            if mid not in meas_max:
                                meas_max[mid] = val
                            else:
                                meas_max[mid] = max(meas_max[mid], val)
                        except: pass
                
                # Pick measurement ID with highest max that's > 10 (likely VUsers, not percentages)
                best_id = None
                best_max = 0
                for mid, max_val in meas_max.items():
                    if max_val > 10 and max_val > best_max:
                        best_max = max_val
                        best_id = mid
                
                if best_id:
                    running_measurement_id = best_id
                    self._debug_info.append(f"Auto-detected Running measurement ID: {best_id} (max={best_max})")
                else:
                    running_measurement_id = '1'  # Default fallback
                    self._debug_info.append("Using default measurement ID: 1")
        
        vuser_values = []
        all_vuser_values = []  # Store all values for the graph
        all_timestamps = []  # Store timestamps for x-axis
        
        self._debug_info.append(f"Reading VUser data from {os.path.basename(vuser_graph_file)} with measurement ID {running_measurement_id}")
        
        with open(vuser_graph_file, 'r', encoding='utf-8') as f:
            for line in f:
                parts = line.strip().split()
                if len(parts) >= 3:
                    try:
                        measurement_id = parts[0]
                        
                        # Only read "Running" VUsers (measurement ID from config)
                        if measurement_id != running_measurement_id:
                            continue
                        
                        timestamp = int(parts[1])
                        vuser_count = float(parts[2])
                        all_vuser_values.append(vuser_count)
                        all_timestamps.append(timestamp)
                        
                        # Filter by steady state period
                        if not self._is_timestamp_in_steady_state(timestamp):
                            continue
                        
                        vuser_values.append(vuser_count)
                    except (ValueError, IndexError):
                        continue
        
        # Store all values for graph display (full timeline)
        self.all_running_vusers = all_vuser_values
        self.all_vuser_timestamps = all_timestamps
        
        # If no values in steady state but we have values overall, use max from all
        if not vuser_values and all_vuser_values:
            self._debug_info.append(f"No vusers in SS window, using all values (max={max(all_vuser_values)})")
            vuser_values = all_vuser_values
        
        if vuser_values:
            self.max_vusers = int(max(vuser_values))
            self.avg_vusers = int(round(sum(vuser_values) / len(vuser_values), 0))
            self.running_vusers = vuser_values
            
            self._debug_info.append(f"Vusers for SS duration: Max={self.max_vusers}, Avg={self.avg_vusers}")
    
    def _parse_vuser_counts_from_raw_data(self) -> bool:
        """Parse vuser counts from RawData.eve file.
        This file contains the actual scenario configuration with per-script vuser counts.
        Returns True if successful, False otherwise."""
        raw_data_path = os.path.join(self.result_folder, 'RawData.eve')
        
        if not os.path.exists(raw_data_path):
            self._debug_info.append("RawData.eve not found")
            return False
        
        try:
            import re
            
            with open(raw_data_path, 'rb') as f:
                data = f.read()
            
            # Script name mappings - map raw data script names to transaction script names
            # Some scripts use hyphen in raw data but underscore in transactions
            script_mappings = {
                '01_UPA_Taxpayerledger': 'TaxpayerLegder',
                '02_Assese_Communication': 'AsseseeCommucation',
                '03_Refund_Reissue_BulkFetch': 'Refund_Reissue_BulkFetch',
                '04_AssesseeFilingHistory': 'AsseseeFilingHistory',
                '05_UPA_E-Proceeding': 'E-Proceeding',  # Note: hyphen in raw data
                '06_UPA_Dashboard': 'UPADashboard',
                '08_ResponseToOutstandingDemand': 'Response_TO_Outstanding_Demand',
                '11_Refund_Demand_Status': 'Refund_Demand_Status',
                '12_ViewFiledReturns': 'ViewFiled_Returns',
                '13_245Bulkfetch': '245Bulkfetchdetails',
                '14_ITR_Collection_Report': 'ITR_Collection_Report',
                '15_DataQuality_Check': 'DataQuality_Check',
            }
            
            for raw_name, trans_name in script_mappings.items():
                # Find first occurrence of script name
                pos = data.find(raw_name.encode())
                if pos > 0:
                    # Get bytes before script name
                    before = data[max(0, pos-30):pos]
                    # Look for number pattern (ASCII digits followed by null bytes)
                    nums = re.findall(rb'(\d{1,3})\x00', before)
                    if nums:
                        count = int(nums[-1].decode())
                        if count > 0 and count < 500:  # Reasonable range
                            self.script_vuser_counts[trans_name] = count
                            self._debug_info.append(f"From RawData.eve: {trans_name} = {count} vusers")
            
            return len(self.script_vuser_counts) > 0
            
        except Exception as e:
            self._debug_info.append(f"Error parsing RawData.eve: {e}")
            return False
    
    def _parse_vuser_counts_from_t_rep(self) -> bool:
        """Parse vuser counts from _t_rep.eve file.
        This file contains per-script VUser events. We count unique vuser IDs per script.
        Format: 28 4 <script_name> <vuser_id> <timestamp> ...
        Returns True if successful, False otherwise."""
        t_rep_path = os.path.join(self.result_folder, '_t_rep.eve')
        
        if not os.path.exists(t_rep_path):
            self._debug_info.append("_t_rep.eve not found")
            return False
        
        try:
            from collections import defaultdict
            
            with open(t_rep_path, 'r', encoding='utf-8', errors='ignore') as f:
                content = f.read()
            
            # Count unique vuser IDs per script from type 4 lines
            # Format: 28 4 <script_name> <vuser_id> <timestamp> ...
            script_vuser_ids = defaultdict(set)
            
            for line in content.split('\n'):
                parts = line.strip().split()
                if len(parts) >= 4 and parts[0] == '28' and parts[1] == '4':
                    script_name = parts[2]
                    try:
                        vuser_id = int(parts[3])
                        script_vuser_ids[script_name].add(vuser_id)
                    except (ValueError, IndexError):
                        pass
            
            # Store counts - keep original script names from _t_rep.eve
            for script_name, vuser_ids in script_vuser_ids.items():
                count = len(vuser_ids)
                if count > 0:
                    self.script_vuser_counts[script_name] = count
                    self._debug_info.append(f"From _t_rep.eve: {script_name} = {count} vusers")
            
            return len(self.script_vuser_counts) > 0
            
        except Exception as e:
            self._debug_info.append(f"Error parsing _t_rep.eve: {e}")
            return False
    
    def _normalize_script_name_for_vuser(self, script_name: str) -> str:
        """Normalize script name from _t_rep.eve to match transaction script names.
        E.g., '13_245Bulkfetch_Final' -> '245Bulkfetchdetails'
              '06_UPA_Dashboard_Final_modify' -> 'UPADashboard'"""
        import re
        
        # Remove common prefixes like "01_", "02_", etc.
        name = re.sub(r'^\d{2}_', '', script_name)
        
        # Remove common suffixes
        for suffix in ['_Final_V2.0', '_Final_V.0', '_Final_modify', '_Final', '_final', '_V.0', '_V2.0', '_modify', '_FINAL']:
            if name.endswith(suffix):
                name = name[:-len(suffix)]
                break
        
        # Map specific script names to transaction names
        script_to_transaction = {
            'UPA_Taxpayerledger': 'TaxpayerLegder',
            'Assese_Communication': 'AsseseeCommucation',
            'Refund_Reissue_BulkFetch': 'Refund_Reissue_BulkFetch',
            'AssesseeFilingHistory': 'AsseseeFilingHistory',
            'UPA_E_Proceeding': 'E-Proceeding',
            'UPA_E-Proceeding': 'E-Proceeding',
            'UPA_Dashboard': 'UPADashboard',
            'ResponseToOutstandingDemand': 'Response_TO_Outstanding_Demand',
            'Refund_Demand_Status': 'Refund_Demand_Status',
            'ViewFiledReturns': 'ViewFiled_Returns',
            '245Bulkfetch': '245Bulkfetchdetails',
            'ITR_Collection_Report': 'ITR_Collection_Report',
            'DataQuality_Check': 'DataQuality_Check',
        }
        
        # Check for direct match
        if name in script_to_transaction:
            return script_to_transaction[name]
        
        # Check for partial match (case-insensitive)
        name_lower = name.lower().replace('_', '').replace('-', '')
        for key, value in script_to_transaction.items():
            key_lower = key.lower().replace('_', '').replace('-', '')
            if key_lower in name_lower or name_lower in key_lower:
                return value
        
        # Return cleaned name if no mapping found
        return name
    
    def _parse_vuser_counts_from_lrs(self) -> bool:
        """Parse vuser counts from .lrs scenario file.
        The .lrs file contains the actual Group configuration with Quantity values.
        Checks multiple sources for the scenario file path.
        Returns True if successful, False otherwise."""
        import re
        
        # Look for .lrs file in result folder first
        lrs_files = [f for f in os.listdir(self.result_folder) if f.endswith('.lrs')]
        
        if lrs_files:
            lrs_path = os.path.join(self.result_folder, lrs_files[0])
            self._debug_info.append(f"Found scenario file in result folder: {lrs_files[0]}")
            return self._parse_lrs_file(lrs_path)
        
        # Try scenario path from .lrr file's [Scenario] section
        if hasattr(self, 'scenario_info') and 'scenario_path' in self.scenario_info:
            scenario_path = self.scenario_info['scenario_path']
            if scenario_path and os.path.exists(scenario_path):
                self._debug_info.append(f"Using scenario file from .lrr: {scenario_path}")
                return self._parse_lrs_file(scenario_path)
            elif scenario_path:
                self._debug_info.append(f"Scenario path from .lrr not accessible: {scenario_path}")
        
        # Try to find scenario path from collate.txt
        collate_path = os.path.join(self.result_folder, 'collate.txt')
        if os.path.exists(collate_path):
            with open(collate_path, 'r', encoding='utf-8-sig') as f:
                content = f.read()
            match = re.search(r'Scenario=(.+\.lrs)', content)
            if match:
                scenario_path = match.group(1).strip()
                if os.path.exists(scenario_path):
                    self._debug_info.append(f"Using scenario file from collate.txt: {scenario_path}")
                    return self._parse_lrs_file(scenario_path)
                else:
                    self._debug_info.append(f"Scenario file not accessible: {scenario_path}")
                    self._debug_info.append(f"TIP: Copy the .lrs file to the result folder for accurate User Count values")
        
        self._debug_info.append("No .lrs file found - User Count values will be estimated from test data")
        return False
    
    def _parse_lrs_file(self, lrs_path: str) -> bool:
        """Parse a LoadRunner scenario (.lrs) file to extract Group vuser counts.
        Stores ALL scripts found, using the original group name from .lrs file."""
        import re
        
        try:
            with open(lrs_path, 'r', encoding='utf-8-sig', errors='ignore') as f:
                content = f.read()
            
            # Find all Group sections
            # Format: [Group_N] ... Name=... Count=X
            group_sections = re.findall(r'\[Group_(\d+)\](.*?)(?=\[Group_|\[|\Z)', content, re.DOTALL | re.IGNORECASE)
            
            for group_num, group_content in group_sections:
                # Find Name and Count in group section
                name_match = re.search(r'Name=(.+)', group_content)
                count_match = re.search(r'Count=(\d+)', group_content)
                
                if name_match and count_match:
                    # Get original group name (preserve case and format)
                    group_name = name_match.group(1).strip()
                    vuser_count = int(count_match.group(1))
                    
                    if vuser_count > 0:
                        # Store with original name from .lrs file
                        self.script_vuser_counts[group_name] = vuser_count
                        self._debug_info.append(f"From .lrs: {group_name} = {vuser_count} vusers")
            
            return len(self.script_vuser_counts) > 0
        
        except Exception as e:
            self._debug_info.append(f"Error parsing .lrs file: {e}")
            return False
    
    def _parse_script_vuser_counts(self):
        """Parse per-script/group vuser counts.
        Priority: 1) _t_rep.eve (actual test data), 2) .lrs scenario file, 3) RawData.eve, 4) output.mdb"""
        self._debug_info = getattr(self, '_debug_info', [])
        self.script_vuser_counts = {}
        
        # FIRST: Try .lrs scenario file (contains actual Group Quantity values matching LoadRunner Scenario Groups)
        if self._parse_vuser_counts_from_lrs():
            self._debug_info.append(f"Loaded {len(self.script_vuser_counts)} vuser counts from .lrs scenario file")
            return
        
        # Second: Try _t_rep.eve - counts unique vuser IDs that ran
        if self._parse_vuser_counts_from_t_rep():
            self._debug_info.append(f"Loaded {len(self.script_vuser_counts)} vuser counts from _t_rep.eve")
            return
        
        # Third: Try RawData.eve
        if self._parse_vuser_counts_from_raw_data():
            self._debug_info.append(f"Loaded {len(self.script_vuser_counts)} vuser counts from RawData.eve")
            return
        
        # Fourth: Try output.mdb if available
        pyodbc_available = False
        try:
            import pyodbc
            pyodbc_available = True
        except ImportError:
            self._debug_info.append("pyodbc not available")
        
        output_mdb_path = os.path.join(self.result_folder, 'output.mdb')
        
        if pyodbc_available and os.path.exists(output_mdb_path):
            try:
                # Connect to the Access database
                conn = None
                drivers = [
                    r'Microsoft Access Driver (*.mdb, *.accdb)',
                    r'Microsoft Access Driver (*.mdb)',
                ]
                
                for driver in drivers:
                    try:
                        conn_str = f'DRIVER={{{driver}}};DBQ={output_mdb_path};'
                        conn = pyodbc.connect(conn_str)
                        break
                    except pyodbc.Error:
                        continue
                
                if not conn:
                    self._debug_info.append("No Access driver found for per-script vuser counts")
                else:
                    cursor = conn.cursor()
                    
                    # Get list of all tables
                    tables = [row.table_name for row in cursor.tables(tableType='TABLE')]
                    
                    # Try different tables that might contain group/script vuser data
                    # LoadRunner uses different table names in different versions
                    vuser_tables = ['Group_meter', 'Group_Info', 'Groups', 'Vusers', 'VuserGroups']
                    
                    for table_name in vuser_tables:
                        if table_name in tables:
                            try:
                                cursor.execute(f"SELECT * FROM [{table_name}] WHERE 1=0")
                                columns = [col[0].lower() for col in cursor.description]
                                self._debug_info.append(f"Found table {table_name} with columns: {columns}")
                                
                                # Look for group name and vuser count columns
                                name_col = None
                                count_col = None
                                
                                for col in columns:
                                    if 'name' in col or 'group' in col or 'script' in col:
                                        name_col = col
                                    if 'vuser' in col or 'count' in col or 'max' in col:
                                        count_col = col
                                
                                if name_col and count_col:
                                    cursor.execute(f"SELECT [{name_col}], MAX([{count_col}]) FROM [{table_name}] GROUP BY [{name_col}]")
                                    for row in cursor.fetchall():
                                        group_name = str(row[0]).strip() if row[0] else ''
                                        vuser_count = int(row[1]) if row[1] else 0
                                        if group_name and vuser_count > 0:
                                            self.script_vuser_counts[group_name] = vuser_count
                                            self._debug_info.append(f"Script '{group_name}' has {vuser_count} vusers")
                                    
                                    if self.script_vuser_counts:
                                        break  # Found data, stop looking
                            except Exception as e:
                                self._debug_info.append(f"Error reading {table_name}: {e}")
                                continue
                    
                    conn.close()
                    
            except Exception as e:
                self._debug_info.append(f"Error parsing per-script vuser counts: {e}")
    
    def _load_vuser_presets(self):
        """Load per-script vuser counts from preset files.
        
        Priority:
        1. Scenario-specific preset file (e.g., BO_Scenario_AY26_27_vusers.txt)
        2. Generic vuser_presets.txt
        
        File format: script_name,vuser_count (one per line)
        Example:
            ITR1_Online,50
            ITR2_Offline,30
            AsseseeCommucation,10
        """
        self._debug_info = getattr(self, '_debug_info', [])
        
        # Get scenario name from .lrr file for automatic preset matching
        scenario_name = None
        try:
            import configparser
            config = configparser.ConfigParser(interpolation=None)
            config.read(self.lrr_path, encoding='utf-8-sig')
            if config.has_section('Scenario'):
                scenario_name = config.get('Scenario', 'Subject', fallback=None)
                if scenario_name:
                    self._debug_info.append(f"Detected scenario: {scenario_name}")
        except Exception as e:
            self._debug_info.append(f"Could not read scenario name: {e}")
        
        presets_folder = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'TargetTPS_Presets')
        
        # Build list of preset locations to check (in priority order)
        preset_locations = []
        
        # 1. Scenario-specific preset in result folder
        if scenario_name:
            preset_locations.append(os.path.join(self.result_folder, f'{scenario_name}_vusers.txt'))
            preset_locations.append(os.path.join(self.result_folder, f'{scenario_name}.txt'))
        
        # 2. Scenario-specific preset in TargetTPS_Presets folder
        if scenario_name:
            preset_locations.append(os.path.join(presets_folder, f'{scenario_name}_vusers.txt'))
            preset_locations.append(os.path.join(presets_folder, f'{scenario_name}.txt'))
        
        # 3. Generic preset in result folder
        preset_locations.append(os.path.join(self.result_folder, 'vuser_presets.txt'))
        
        # 4. Generic preset in TargetTPS_Presets folder
        preset_locations.append(os.path.join(presets_folder, 'vuser_presets.txt'))
        
        # 5. Generic preset in app folder
        preset_locations.append(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'vuser_presets.txt'))
        
        for preset_path in preset_locations:
            if os.path.exists(preset_path):
                self._debug_info.append(f"Loading vuser presets from: {preset_path}")
                try:
                    with open(preset_path, 'r', encoding='utf-8-sig') as f:
                        for line in f:
                            line = line.strip()
                            if not line or line.startswith('#'):
                                continue
                            parts = line.split(',')
                            if len(parts) >= 2:
                                script_name = parts[0].strip()
                                try:
                                    vuser_count = int(parts[1].strip())
                                    self.script_vuser_counts[script_name] = vuser_count
                                    self._debug_info.append(f"  Loaded: {script_name} = {vuser_count}")
                                except ValueError:
                                    continue
                    if self.script_vuser_counts:
                        self._debug_info.append(f"Loaded {len(self.script_vuser_counts)} vuser presets from {os.path.basename(preset_path)}")
                        return
                except Exception as e:
                    self._debug_info.append(f"Error loading vuser presets: {e}")
        
        self._debug_info.append("No vuser preset file found. User Count column will be empty.")
        if scenario_name:
            self._debug_info.append(f"Tip: Create '{scenario_name}_vusers.txt' in TargetTPS_Presets folder")
    
    def _parse_http_statistics_data(self):
        """Parse HTTP statistics data (response codes, connections, SSL, retries).
        First tries to read from output.mdb (same source as LoadRunner Analysis).
        Falls back to parsing graph DAT files if database not available."""
        self._debug_info = getattr(self, '_debug_info', [])
        
        # Initialize separate storage for steady state filtered stats
        self.http_statistics_ss = {
            'response_codes': {},
            'web_connections': {},
            'web_ssl': {},
            'retries': {}
        }
        
        # Try to get data from output.mdb first (matches LoadRunner Analysis exactly)
        if self._parse_http_from_database():
            return
        
        # Fallback: Parse from DAT files
        self._parse_http_from_dat_files()
    
    def _parse_http_from_database(self):
        """Try to read HTTP statistics from output.mdb database."""
        if not PYODBC_AVAILABLE:
            return False
        
        output_mdb_path = os.path.join(self.result_folder, 'output.mdb')
        if not os.path.exists(output_mdb_path):
            return False
        
        try:
            conn = None
            drivers = [
                r'Microsoft Access Driver (*.mdb, *.accdb)',
                r'Microsoft Access Driver (*.mdb)',
            ]
            
            for driver in drivers:
                try:
                    conn_str = f'DRIVER={{{driver}}};DBQ={output_mdb_path};'
                    conn = pyodbc.connect(conn_str)
                    break
                except pyodbc.Error:
                    continue
            
            if not conn:
                return False
            
            cursor = conn.cursor()
            
            # Get list of tables
            tables = [row.table_name for row in cursor.tables(tableType='TABLE')]
            debug_print(f"DEBUG: output.mdb tables: {tables}")
            
            # Look for HTTP Response Code data in various possible tables
            http_tables = ['HTTP_status_code', 'HTTP_RC', 'Web_HTTP_RC', 'HTTP_Response']
            
            for table_name in http_tables:
                if table_name in tables:
                    try:
                        cursor.execute(f"SELECT * FROM [{table_name}]")
                        rows = cursor.fetchall()
                        columns = [desc[0] for desc in cursor.description]
                        debug_print(f"DEBUG: {table_name} columns: {columns}")
                        debug_print(f"DEBUG: {table_name} has {len(rows)} rows")
                        for row in rows[:5]:
                            debug_print(f"  Row: {row}")
                    except Exception as e:
                        debug_print(f"DEBUG: Error reading {table_name}: {e}")
            
            conn.close()
            return False  # For now, still fall back to DAT parsing
            
        except Exception as e:
            debug_print(f"DEBUG: Database error: {e}")
            return False
    
    def _parse_http_from_dat_files(self):
        """Parse HTTP statistics from graph DAT files."""
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        
        # Define the graph types we want to parse
        graph_mappings = {
            'HTTP_RC': 'response_codes',
            'Web_Connections': 'web_connections', 
            'Web_Connections_Per_Second': 'web_connections_per_sec',
            'Web_SSL': 'web_ssl',
            'Retries': 'retries'
        }
        
        for graph_type, stat_key in graph_mappings.items():
            # Find the graph file for this type
            graph_config = None
            graph_file = None
            
            for section, config in self.sum_dat_config.items():
                if config['type'] == graph_type:
                    graph_config = config
                    graph_file = os.path.join(sum_data_path, f'{section}.dat')
                    break
            
            if not graph_config or not graph_file or not os.path.exists(graph_file):
                continue
            
            # Read and analyze the DAT file - read ALL rows, don't filter by meas_id yet
            full_data = defaultdict(list)
            ss_data = defaultdict(list)
            
            try:
                with open(graph_file, 'r', encoding='utf-8') as f:
                    lines = f.readlines()
                    
                    # Parse all lines
                    # Format: meas_id timestamp rate COUNT rate rate rate
                    # Column 4 (index 3) contains the ACTUAL COUNT
                    for line in lines:
                        parts = line.strip().split()
                        if len(parts) >= 4:  # Need at least 4 columns
                            try:
                                meas_id = int(parts[0])
                                timestamp = int(parts[1])
                                # parts[2] is per-second rate, parts[3] is ACTUAL COUNT
                                count = int(float(parts[3]))  # Column 4 = actual count
                                
                                if meas_id in graph_config['measurements']:
                                    name = graph_config['measurements'][meas_id]
                                    full_data[name].append((timestamp, count))
                                    # Apply bucket offset for pass count data
                                    if self._is_timestamp_in_steady_state(timestamp, apply_bucket_offset=True):
                                        ss_data[name].append((timestamp, count))
                            except (ValueError, IndexError):
                                continue
                
                # Calculate totals - sum the COUNT values (column 4)
                full_totals = {}
                ss_totals = {}
                
                for name, points in full_data.items():
                    if points:
                        # Sum of all COUNT values
                        total = sum(p[1] for p in points)
                        full_totals[name] = total
                
                for name, points in ss_data.items():
                    if points:
                        ss_totals[name] = sum(p[1] for p in points)
                
                # Update http_statistics
                if full_totals:
                    if stat_key == 'web_connections_per_sec':
                        for name, total in full_totals.items():
                            key = f"{name} (per sec)"
                            self.http_statistics['web_connections'][key] = round(total, 3)
                        for name, total in ss_totals.items():
                            key = f"{name} (per sec)"
                            self.http_statistics_ss['web_connections'][key] = round(total, 3)
                    else:
                        self.http_statistics[stat_key] = {}
                        self.http_statistics_ss[stat_key] = {}
                        for name, total in full_totals.items():
                            if stat_key in ['response_codes', 'retries']:
                                self.http_statistics[stat_key][name] = int(round(total))
                            else:
                                self.http_statistics[stat_key][name] = round(total, 3)
                        for name, total in ss_totals.items():
                            if stat_key in ['response_codes', 'retries']:
                                self.http_statistics_ss[stat_key][name] = int(round(total))
                            else:
                                self.http_statistics_ss[stat_key][name] = round(total, 3)
                    
                    self._debug_info.append(f"HTTP {stat_key}: {len(full_totals)} metrics parsed")
                    
            except Exception as e:
                self._debug_info.append(f"Error parsing {graph_type}: {e}")
    
    def _parse_error_data(self):
        """Parse error distribution data from graph file with counts."""
        sum_data_path = os.path.join(self.result_folder, 'sum_data')
        
        # Get error info from sum_dat.ini
        error_config = None
        error_graph_file = None
        for section, config in self.sum_dat_config.items():
            if config['type'] == 'es_tr_errors_distribution':
                error_config = config
                error_graph_file = os.path.join(sum_data_path, f'{section}.dat')
                break
        
        if not error_config:
            return
        
        # Parse the actual error counts from the graph data file
        error_counts = defaultdict(int)  # meas_id -> total count
        
        if error_graph_file and os.path.exists(error_graph_file):
            with open(error_graph_file, 'r', encoding='utf-8') as f:
                for line in f:
                    parts = line.strip().split()
                    if len(parts) >= 3:
                        try:
                            meas_id = int(parts[0])
                            count = int(float(parts[2]))
                            
                            # Filter by steady state if configured
                            timestamp = int(parts[1])
                            if self._is_timestamp_in_steady_state(timestamp):
                                error_counts[meas_id] += count
                        except (ValueError, IndexError):
                            continue
        
        # Try to get script names from scenario info or transaction names
        script_names_found = set()
        for trans_name in self.response_times.keys():
            # Extract script name from transaction like "05_ITR1_ONLINE_AY_25_26_JAN_T01_Login"
            parts = trans_name.split('_T')
            if len(parts) >= 2:
                script_names_found.add(parts[0])
        
        # Build error list with script name, description, and count
        for meas_id, error_name in error_config['measurements'].items():
            count = error_counts.get(meas_id, 0)
            
            # Skip errors with zero count
            if count == 0:
                continue
            
            # Debug: print actual measurement name
            debug_print(f"DEBUG ERROR: meas_id={meas_id}, error_name='{error_name}'")
            
            # Parse error_name in various LoadRunner formats
            script_name = ""
            error_description = error_name
            error_location = ""
            
            # Pattern 1: Full format with Error code: "Error -26366:ScriptName:Action.c(741) Error -26366 description"
            lr_full_pattern = r'^Error\s*-?\d+:([^:]+):(\w+)\.c\((\d+)\)\s*Error\s*-?\d+\s*(.+)$'
            match = re.match(lr_full_pattern, error_name, re.IGNORECASE)
            
            if match:
                script_name = match.group(1).strip()
                action_type = match.group(2)
                line_num = match.group(3)
                error_description = match.group(4).strip()
                error_location = f"{action_type}.c({line_num})"
            else:
                # Pattern 2: Script:Action.c(line) Error description
                lr_short_pattern = r'^([^:]+):(\w+)\.c\((\d+)\)\s*Error\s*-?\d+\s*(.+)$'
                match = re.match(lr_short_pattern, error_name, re.IGNORECASE)
                
                if match:
                    script_name = match.group(1).strip()
                    action_type = match.group(2)
                    line_num = match.group(3)
                    error_description = match.group(4).strip()
                    error_location = f"{action_type}.c({line_num})"
                else:
                    # Pattern 3: ScriptName:Action:LineNumber (3 parts)
                    simple_pattern = r'^([^:]+):(Action|Login|Logout|vuser_init|vuser_end):(\d+)$'
                    match = re.match(simple_pattern, error_name, re.IGNORECASE)
                    
                    if match:
                        script_name = match.group(1).strip()
                        action_type = match.group(2)
                        line_num = match.group(3)
                        error_location = f"{action_type}.c({line_num})"
                        error_description = f"Error at {action_type}.c line {line_num}"
                    else:
                        # Pattern 4: Just Action:LineNumber (2 parts, no script name)
                        action_line_pattern = r'^(Action|Login|Logout|vuser_init|vuser_end):(\d+)$'
                        match = re.match(action_line_pattern, error_name, re.IGNORECASE)
                        
                        if match:
                            action_type = match.group(1)
                            line_num = match.group(2)
                            error_location = f"{action_type}.c({line_num})"
                            error_description = f"Error at {action_type}.c line {line_num}"
                            # Try to find script name from transaction names
                            if script_names_found:
                                script_name = list(script_names_found)[0] if len(script_names_found) == 1 else "Multiple Scripts"
                            else:
                                script_name = "Unknown Script"
                        else:
                            # Pattern 5: Generic colon-separated
                            if ':' in error_name:
                                parts = error_name.split(':')
                                if len(parts) >= 3:
                                    # ScriptName:Action:Line
                                    script_name = parts[0].strip()
                                    error_location = f"{parts[1]}:{parts[2]}"
                                    error_description = f"Error at {parts[1]}.c line {parts[2]}"
                                elif len(parts) == 2:
                                    # Could be Action:Line or Script:Action
                                    if parts[1].isdigit():
                                        error_location = f"{parts[0]}.c({parts[1]})"
                                        error_description = f"Error at {parts[0]}.c line {parts[1]}"
                                        if script_names_found:
                                            script_name = list(script_names_found)[0] if len(script_names_found) == 1 else "Multiple Scripts"
                                        else:
                                            script_name = "Unknown Script"
                                    else:
                                        script_name = parts[0].strip()
                                        error_description = parts[1].strip()
                            else:
                                # No colon - use as-is
                                error_description = error_name
                                script_name = "Unknown Script"
            
            self.errors.append({
                'script_name': script_name,
                'error_description': error_description,
                'error_location': error_location if error_location else error_name,
                'error_count': count,
                'error_id': meas_id,
                'original_measurement': error_name  # Store original full measurement name from LoadRunner
            })
        
        # Try to get full error descriptions from output.mdb
        self._parse_error_descriptions_from_mdb()
        
        # Try to get full error descriptions from VUser log files
        self._parse_error_descriptions_from_logs()
        
        # API Errors parsing disabled - tab was removed for performance
        # self._parse_api_errors_from_logs()
    
    def _parse_error_descriptions_from_mdb(self):
        """Parse output.mdb to get full error descriptions like LoadRunner Analysis shows."""
        if not PYODBC_AVAILABLE:
            debug_print("DEBUG: pyodbc not available - cannot read output.mdb for full error descriptions")
            debug_print("DEBUG: Install with: pip install pyodbc")
            return
        
        # Find output.mdb in result folder
        output_mdb_path = os.path.join(self.result_folder, 'output.mdb')
        if not os.path.exists(output_mdb_path):
            debug_print(f"DEBUG: output.mdb not found at {output_mdb_path}")
            return
        
        debug_print(f"DEBUG: Parsing error descriptions from {output_mdb_path}")
        
        try:
            # Connect to the Access database using 32-bit or 64-bit driver
            conn = None
            drivers = [
                r'Microsoft Access Driver (*.mdb, *.accdb)',
                r'Microsoft Access Driver (*.mdb)',
            ]
            
            for driver in drivers:
                try:
                    conn_str = f'DRIVER={{{driver}}};DBQ={output_mdb_path};'
                    conn = pyodbc.connect(conn_str)
                    debug_print(f"DEBUG: Connected using driver: {driver}")
                    break
                except pyodbc.Error as e:
                    debug_print(f"DEBUG: Driver {driver} failed: {e}")
                    continue
            
            if not conn:
                debug_print("DEBUG: No Access driver found for output.mdb")
                debug_print("DEBUG: Install Microsoft Access Database Engine from:")
                debug_print("DEBUG: https://www.microsoft.com/en-us/download/details.aspx?id=54920")
                return
            
            cursor = conn.cursor()
            
            # Get list of all tables
            tables = [row.table_name for row in cursor.tables(tableType='TABLE')]
            debug_print(f"DEBUG: All tables in output.mdb: {tables}")
            
            # LoadRunner stores error data in Event_meter table
            # The full error message format is in the "Event Text" or similar column
            error_details = {}  # Key: script:action:line -> Full LoadRunner format
            
            # Check Event_meter table first (primary error source in LoadRunner)
            if 'Event_meter' in tables:
                try:
                    cursor.execute("SELECT * FROM [Event_meter] WHERE 1=0")
                    columns = [col[0] for col in cursor.description]
                    debug_print(f"DEBUG: Event_meter columns: {columns}")
                    
                    cursor.execute("SELECT * FROM [Event_meter]")
                    rows = cursor.fetchall()
                    debug_print(f"DEBUG: Event_meter has {len(rows)} rows")
                    
                    # Print first few rows for debugging
                    for i, row in enumerate(rows[:3]):
                        debug_print(f"DEBUG: Event_meter row {i}: {row}")
                    
                    for row in rows:
                        row_dict = dict(zip(columns, row))
                        
                        # Extract fields - typical columns in Event_meter:
                        # Event1 (error code), Event2 (script), Event3 (action:line), Event4 (message)
                        event_text = ""
                        script_name = ""
                        error_code = ""
                        action_line = ""
                        message = ""
                        
                        # Try to get the full event text
                        for col in ['Event_Text', 'Event Text', 'Message', 'Error_Message', 'Text']:
                            if col in row_dict and row_dict[col]:
                                event_text = str(row_dict[col])
                                break
                        
                        # Get event fields (Event1, Event2, Event3, Event4)
                        if 'Event1' in row_dict:
                            error_code = str(row_dict.get('Event1', ''))
                        if 'Event2' in row_dict:
                            script_name = str(row_dict.get('Event2', ''))
                        if 'Event3' in row_dict:
                            action_line = str(row_dict.get('Event3', ''))
                        if 'Event4' in row_dict:
                            message = str(row_dict.get('Event4', ''))
                        
                        # Build the key for matching (lowercase for comparison)
                        if script_name and action_line:
                            # Parse action_line like "Action.c(741)" to "Action:741"
                            match = re.match(r'(\w+)\.c\((\d+)\)', action_line)
                            if match:
                                key = f"{script_name.lower()}:{match.group(1).lower()}:{match.group(2)}"
                            else:
                                key = f"{script_name.lower()}:{action_line.lower()}"
                            
                            # Build full LoadRunner format measurement string
                            if error_code and message:
                                full_measurement = f"Error {error_code}:{script_name}:{action_line} Error {error_code} {message}"
                            elif event_text:
                                full_measurement = event_text
                            else:
                                full_measurement = f"{script_name}:{action_line}"
                            
                            error_details[key] = {
                                'full_measurement': full_measurement,
                                'script': script_name,
                                'error_code': error_code,
                                'message': message
                            }
                            
                except pyodbc.Error as e:
                    debug_print(f"DEBUG: Error reading Event_meter: {e}")
            
            # Also try Error_Statistics table
            for table_name in ['Error_Statistics', 'Error_Info', 'Errors']:
                if table_name in tables:
                    try:
                        cursor.execute(f"SELECT * FROM [{table_name}] WHERE 1=0")
                        columns = [col[0] for col in cursor.description]
                        debug_print(f"DEBUG: {table_name} columns: {columns}")
                        
                        cursor.execute(f"SELECT * FROM [{table_name}]")
                        rows = cursor.fetchall()
                        debug_print(f"DEBUG: {table_name} has {len(rows)} rows")
                        
                        for i, row in enumerate(rows[:3]):
                            debug_print(f"DEBUG: {table_name} row {i}: {row}")
                        
                        for row in rows:
                            row_dict = dict(zip(columns, row))
                            
                            # Try to find script, line, and message
                            script = ""
                            line = ""
                            action = "Action"
                            error_msg = ""
                            error_code = ""
                            
                            for col in row_dict:
                                val = row_dict[col]
                                if val is None:
                                    continue
                                col_lower = col.lower()
                                val_str = str(val)
                                
                                if 'script' in col_lower or 'group' in col_lower:
                                    script = val_str
                                elif 'line' in col_lower:
                                    line = val_str
                                elif 'action' in col_lower:
                                    action = val_str
                                elif 'message' in col_lower or 'description' in col_lower or 'text' in col_lower:
                                    error_msg = val_str
                                elif 'code' in col_lower or 'error' in col_lower and val_str.startswith('-'):
                                    error_code = val_str
                            
                            if script and line:
                                key = f"{script.lower()}:{action.lower()}:{line}"
                                if key not in error_details:
                                    if error_code and error_msg:
                                        full_measurement = f"Error {error_code}:{script}:{action}.c({line}) Error {error_code} {error_msg}"
                                    elif error_msg:
                                        full_measurement = f"{script}:{action}.c({line}) {error_msg}"
                                    else:
                                        full_measurement = f"{script}:{action}:{line}"
                                    
                                    error_details[key] = {
                                        'full_measurement': full_measurement,
                                        'script': script,
                                        'error_code': error_code,
                                        'message': error_msg
                                    }
                                    
                    except pyodbc.Error as e:
                        debug_print(f"DEBUG: Error reading {table_name}: {e}")
            
            conn.close()
            
            debug_print(f"DEBUG: Found {len(error_details)} error details from output.mdb")
            if error_details:
                debug_print(f"DEBUG: Sample keys: {list(error_details.keys())[:5]}")
            
            # Update our errors with full descriptions from mdb
            if error_details:
                for error in self.errors:
                    # Build key from current error location
                    orig = error.get('original_measurement', '')
                    loc = error.get('error_location', '')
                    
                    # Parse current measurement to build key
                    # Format: "12_itr4offline_ay25_26_final_1:Action:514"
                    key = orig.lower().replace('.c(', ':').replace(')', '').replace(' ', '')
                    
                    # Try to find match
                    if key in error_details:
                        error['original_measurement'] = error_details[key]['full_measurement']
                        if error_details[key]['script']:
                            error['script_name'] = error_details[key]['script']
                        debug_print(f"DEBUG: Matched error: {key} -> {error_details[key]['full_measurement'][:60]}...")
                    else:
                        # Try partial match by script and line number
                        parts = orig.split(':')
                        if len(parts) >= 3:
                            script_part = parts[0].lower()
                            line_part = parts[-1]
                            
                            for mdb_key, details in error_details.items():
                                if script_part in mdb_key and f":{line_part}" in mdb_key:
                                    error['original_measurement'] = details['full_measurement']
                                    if details['script']:
                                        error['script_name'] = details['script']
                                    debug_print(f"DEBUG: Partial match: {orig} -> {details['full_measurement'][:60]}...")
                                    break
            
        except Exception as e:
            debug_print(f"DEBUG: Error parsing output.mdb: {e}")
            import traceback
            traceback.print_exc()
    
    def _parse_error_descriptions_from_logs(self):
        """Parse VUser log files to get full error descriptions like LoadRunner Analysis shows."""
        log_folder = os.path.join(self.result_folder, 'log')
        if not os.path.exists(log_folder):
            debug_print(f"DEBUG: log folder not found at {log_folder}")
            return
        
        debug_print(f"DEBUG: Parsing error descriptions from log files in {log_folder}")
        
        # Dictionary to store error details: key = "script:action:line" -> full description
        error_details = {}
        
        # Get all .log files
        log_files = [f for f in os.listdir(log_folder) if f.endswith('.log')]
        debug_print(f"DEBUG: Found {len(log_files)} log files")
        
        # Pattern to match error lines like:
        # Action.c(1132): Error -26366: "Text=true" not found for web_reg_find
        # Action.c(496): Error -26377: No match found for the requested parameter "C_arnNumber"
        error_pattern = re.compile(
            r'(\w+\.c)\((\d+)\):\s*Error\s+(-?\d+):\s*(.+?)(?:\s*\[MsgId:|\s*$)',
            re.IGNORECASE
        )
        
        for log_file in log_files:
            # Extract script name from log file name
            # Format: "11_ITR4_Online_AY2526_FINAL_1083.log" -> script = "11_ITR4_Online_AY2526_FINAL"
            # Or: "05_ITR1_ONLINE_AY_25_26_JAN_546.log" -> script = "05_ITR1_ONLINE_AY_25_26_JAN"
            log_path = os.path.join(log_folder, log_file)
            
            # Get script name - remove vuser number suffix (usually 2-4 digits at end)
            base_name = os.path.splitext(log_file)[0]  # Remove .log
            
            # More robust vuser ID removal - try to find where the vuser ID starts
            # VUser IDs are typically 2-4 digits at the end after underscore
            script_name = base_name
            
            # Pattern 1: scriptname_XXX where XXX is 2-4 digit vuser ID
            vuser_pattern = re.match(r'^(.+)_(\d{2,4})$', base_name)
            if vuser_pattern:
                script_name = vuser_pattern.group(1)
            else:
                # Pattern 2: Check if last segment after underscore is all digits
                parts = base_name.rsplit('_', 1)
                if len(parts) == 2 and parts[1].isdigit() and len(parts[1]) >= 2:
                    script_name = parts[0]
            
            try:
                with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    
                    # Find all error matches
                    for match in error_pattern.finditer(content):
                        action_file = match.group(1)  # e.g., "Action.c"
                        line_num = match.group(2)     # e.g., "1132"
                        error_code = match.group(3)   # e.g., "-26366"
                        error_msg = match.group(4).strip()  # Full error message
                        
                        # Get action name without .c
                        action_name = action_file.replace('.c', '')
                        
                        # Build key in format matching sum_dat.ini: "script:action:line"
                        key = f"{script_name.lower()}:{action_name.lower()}:{line_num}"
                        
                        # Build full measurement in LoadRunner Analysis format:
                        # "Error -26366:11_ITR4_Online_AY2526_FINAL_1:Action.c(1132) Error -26366 "Text=true" not found"
                        full_measurement = f"Error {error_code}:{script_name}:{action_file}({line_num}) Error {error_code} {error_msg}"
                        
                        if key not in error_details:
                            error_details[key] = {
                                'full_measurement': full_measurement,
                                'script': script_name,
                                'action': action_name,
                                'line': line_num,
                                'error_code': error_code,
                                'message': error_msg
                            }
                            
            except Exception as e:
                debug_print(f"DEBUG: Error reading log file {log_file}: {e}")
        
        debug_print(f"DEBUG: Found {len(error_details)} unique errors from log files")
        if error_details:
            sample_keys = list(error_details.keys())[:5]
            debug_print(f"DEBUG: Sample log error keys: {sample_keys}")
            for k in sample_keys[:2]:
                debug_print(f"DEBUG: {k} -> {error_details[k]['full_measurement'][:80]}...")
        
        # Update our errors with full descriptions from log files
        if error_details:
            matched_count = 0
            for error in self.errors:
                # Skip if already has full description from output.mdb
                orig = error.get('original_measurement', '')
                if 'Error -' in orig and '.c(' in orig:
                    continue  # Already has full format
                
                # Parse current measurement to build key
                # Format from sum_dat.ini: "12_itr4offline_ay25_26_final_1:Action:514"
                parts = orig.split(':')
                if len(parts) >= 3:
                    script_part = parts[0].lower()
                    action_part = parts[1].lower() if len(parts) > 1 else 'action'
                    line_part = parts[-1]  # Last part is line number
                    
                    key = f"{script_part}:{action_part}:{line_part}"
                    
                    # Try exact match
                    if key in error_details:
                        error['original_measurement'] = error_details[key]['full_measurement']
                        error['script_name'] = error_details[key]['script']
                        matched_count += 1
                        debug_print(f"DEBUG: Exact log match: {key}")
                    else:
                        # Extract key identifiers for flexible matching
                        itr_match = re.search(r'itr[-_]?(\d+)', script_part)
                        itr_num = itr_match.group(1) if itr_match else None
                        is_online = 'online' in script_part
                        is_offline = 'offline' in script_part
                        
                        # Normalize script name - remove date suffixes, version numbers etc
                        script_normalized = re.sub(r'[_\-\s]+', '', script_part)
                        script_normalized = re.sub(r'(ay\d+[-_]?\d*|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|final|modified|v\d+).*$', '', script_normalized, flags=re.IGNORECASE)
                        
                        best_match = None
                        best_score = 0
                        
                        for log_key, details in error_details.items():
                            log_parts = log_key.split(':')
                            if len(log_parts) >= 3:
                                log_script = log_parts[0]
                                log_line = log_parts[-1]
                                
                                # Line number must match
                                if log_line != line_part:
                                    continue
                                
                                score = 0
                                
                                # Extract ITR info from log script
                                log_itr_match = re.search(r'itr[-_]?(\d+)', log_script)
                                log_itr_num = log_itr_match.group(1) if log_itr_match else None
                                log_is_online = 'online' in log_script
                                log_is_offline = 'offline' in log_script
                                
                                # Check if ITR type matches
                                if itr_num and log_itr_num:
                                    if itr_num == log_itr_num:
                                        score += 50  # Same ITR number
                                        # Check online/offline match
                                        if is_online == log_is_online and is_offline == log_is_offline:
                                            score += 30  # Same online/offline status
                                    else:
                                        continue  # Different ITR types, skip
                                
                                # Normalize log script name
                                log_normalized = re.sub(r'[_\-\s]+', '', log_script)
                                log_normalized = re.sub(r'(ay\d+[-_]?\d*|jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec|final|modified|v\d+|\d{3,}$).*$', '', log_normalized, flags=re.IGNORECASE)
                                
                                # Check substring match on normalized names
                                if script_normalized in log_normalized or log_normalized in script_normalized:
                                    score += 20
                                
                                # Check if script names start similarly (first chars match)
                                if len(script_normalized) >= 4 and len(log_normalized) >= 4:
                                    if script_normalized[:4] == log_normalized[:4]:
                                        score += 10
                                
                                if score > best_score:
                                    best_score = score
                                    best_match = details
                        
                        if best_match and best_score >= 50:  # Require at least ITR type match
                            error['original_measurement'] = best_match['full_measurement']
                            error['script_name'] = best_match['script']
                            matched_count += 1
                            debug_print(f"DEBUG: Fuzzy log match (score={best_score}): {orig}")
                        elif best_match is None:
                            # Try even more flexible matching - just line number + action type
                            for log_key, details in error_details.items():
                                log_parts = log_key.split(':')
                                if len(log_parts) >= 3:
                                    log_line = log_parts[-1]
                                    log_action = log_parts[1] if len(log_parts) > 1 else 'action'
                                    
                                    if log_line == line_part and log_action == action_part:
                                        # Check if both have similar structure (ITR scripts)
                                        if self._scripts_match(script_part, log_parts[0]):
                                            error['original_measurement'] = details['full_measurement']
                                            error['script_name'] = details['script']
                                            matched_count += 1
                                            debug_print(f"DEBUG: Fallback log match: {orig} -> {log_key}")
                                            break
                                    debug_print(f"DEBUG: Fuzzy log match: {orig} -> {log_key}")
                                    break
            
            debug_print(f"DEBUG: Matched {matched_count} errors from log files")
    
    def _scripts_match(self, script1: str, script2: str) -> bool:
        """Check if two script names are similar enough to be the same script."""
        # Normalize: lowercase, remove common variations
        s1 = script1.lower().replace('_', '').replace('-', '').replace(' ', '')
        s2 = script2.lower().replace('_', '').replace('-', '').replace(' ', '')
        
        # Check substring match
        if s1 in s2 or s2 in s1:
            return True
        
        # Check if main identifiers match (ITR1, ITR2, etc.)
        itr_pattern = re.compile(r'(itr\d+)')
        m1 = itr_pattern.search(s1)
        m2 = itr_pattern.search(s2)
        if m1 and m2 and m1.group(1) == m2.group(1):
            # Same ITR type - check for online/offline match
            is_online1 = 'online' in s1
            is_online2 = 'online' in s2
            is_offline1 = 'offline' in s1
            is_offline2 = 'offline' in s2
            
            if is_online1 == is_online2 and is_offline1 == is_offline2:
                return True
        
        return False

    def _parse_transaction_api_calls_from_logs(self):
        """Placeholder - API calls are now parsed from script .c files via parse_script_folder()."""
        pass

    def _auto_discover_scripts(self):
        """
        Automatically discover and parse script files from paths in the [Scripts] section of .lrr file.
        
        This allows zero-configuration API call extraction when the report is generated on the
        same machine where tests ran (controller machine) and script paths are still accessible.
        """
        if not self.script_paths:
            debug_print("DEBUG: No script paths found in .lrr file [Scripts] section")
            return
        
        accessible_scripts = []
        inaccessible_scripts = []
        
        debug_print(f"\n=== AUTO-DISCOVERING SCRIPTS FROM .LRR FILE ===")
        debug_print(f"Found {len(self.script_paths)} scripts referenced in .lrr file")
        
        for script_name, usr_path in self.script_paths.items():
            # .usr file path points to the script folder
            # e.g., C:\PerformanceTesting\...\05 ITR1_ONLINE\05 ITR1_ONLINE.usr
            script_folder = os.path.dirname(usr_path)
            action_c_path = os.path.join(script_folder, 'Action.c')
            
            if os.path.exists(action_c_path):
                debug_print(f"  [OK] Found: {script_name} -> {script_folder}")
                accessible_scripts.append(script_folder)
            else:
                debug_print(f"  [--] Not found: {script_name} -> {script_folder}")
                inaccessible_scripts.append((script_name, script_folder))
        
        if accessible_scripts:
            debug_print(f"\nParsing {len(accessible_scripts)} accessible script folder(s)...")
            # Parse each accessible script folder
            for script_folder in accessible_scripts:
                self._parse_single_script_folder(script_folder)
            
            total_calls = sum(len(v) for v in self.transaction_api_calls.values())
            debug_print(f"Total: {total_calls} API calls across {len(self.transaction_api_calls)} transactions")
        else:
            debug_print(f"\n== NO SCRIPTS ACCESSIBLE ==")
            debug_print("Scripts are stored on the controller machine where the test ran.")
            debug_print("Original paths:")
            for script_name, folder in inaccessible_scripts[:3]:
                debug_print(f"  • {folder}")
            if len(inaccessible_scripts) > 3:
                debug_print(f"  ... and {len(inaccessible_scripts) - 3} more")
            debug_print("\nAPI details will be extracted from error logs as a fallback.")
        
        debug_print("=" * 50 + "\n")
    
    def _parse_single_script_folder(self, script_folder: str):
        """Parse a single script folder and merge results into transaction_api_calls."""
        from urllib.parse import urlparse
        
        # Find .c files in this folder only (not recursive - just this script)
        c_files = []
        for f in os.listdir(script_folder):
            if f.endswith('.c'):
                c_files.append(os.path.join(script_folder, f))
        
        if not c_files:
            return
        
        # Patterns for transaction boundaries
        trans_start_pattern = re.compile(
            r'lr_start_transaction\s*\(\s*"([^"]+)"', re.IGNORECASE
        )
        trans_end_pattern = re.compile(
            r'lr_end_transaction\s*\(\s*"([^"]+)"', re.IGNORECASE
        )
        
        # Patterns for API calls
        web_custom_start = re.compile(r'web_custom_request\s*\(\s*"([^"]+)"', re.IGNORECASE)
        web_url_start = re.compile(r'web_url\s*\(\s*"([^"]+)"', re.IGNORECASE)
        web_submit_start = re.compile(r'web_submit_data\s*\(\s*"([^"]+)"', re.IGNORECASE)
        
        url_param_pattern = re.compile(r'"(?:URL|Action)\s*=\s*(https?://[^"]+)"', re.IGNORECASE)
        method_param_pattern = re.compile(r'"Method\s*=\s*(GET|POST|PUT|DELETE|PATCH|OPTIONS|HEAD)"', re.IGNORECASE)
        
        # Pattern for web_add_header
        header_pattern = re.compile(r'web_add_header\s*\(\s*"([^"]+)"\s*,\s*"([^"]+)"', re.IGNORECASE)
        # Pattern for headers in ITEMDATA: "Name=Content-Type", "Value=application/json", ENDITEM
        itemdata_header_pattern = re.compile(r'"Name=([^"]+)"\s*,\s*"Value=([^"]+)"\s*,\s*ENDITEM', re.IGNORECASE)
        
        # Track pending headers (set via web_add_header before API call)
        pending_headers = []
        
        for c_file in c_files:
            try:
                with open(c_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
                
                current_transaction = None
                i = 0
                while i < len(lines):
                    line = lines[i]
                    stripped = line.strip()
                    
                    if stripped.startswith('//') or stripped.startswith('/*'):
                        i += 1
                        continue
                    
                    # Check for web_add_header (captures headers set before API calls)
                    m_header = header_pattern.search(line)
                    if m_header:
                        header_name = m_header.group(1)
                        header_value = m_header.group(2)
                        # Don't store correlation parameters as headers
                        if not header_value.startswith('{') and not 'CorrelationParameter' in header_value:
                            pending_headers.append({'name': header_name, 'value': header_value})
                        i += 1
                        continue
                    
                    m_start = trans_start_pattern.search(line)
                    if m_start:
                        current_transaction = m_start.group(1)
                        if current_transaction not in self.transaction_api_calls:
                            self.transaction_api_calls[current_transaction] = []
                        i += 1
                        continue
                    
                    m_end = trans_end_pattern.search(line)
                    if m_end:
                        current_transaction = None
                        i += 1
                        continue
                    
                    if not current_transaction:
                        i += 1
                        continue
                    
                    service_name = ''
                    call_type = ''
                    
                    m_wcr = web_custom_start.search(line)
                    m_wu = web_url_start.search(line)
                    m_ws = web_submit_start.search(line)
                    
                    if m_wcr:
                        service_name = m_wcr.group(1)
                        call_type = 'web_custom_request'
                    elif m_wu:
                        service_name = m_wu.group(1)
                        call_type = 'web_url'
                    elif m_ws:
                        service_name = m_ws.group(1)
                        call_type = 'web_submit_data'
                    
                    if call_type:
                        block = line
                        j = i + 1
                        paren_depth = line.count('(') - line.count(')')
                        while j < len(lines) and paren_depth > 0:
                            block += ' ' + lines[j]
                            paren_depth += lines[j].count('(') - lines[j].count(')')
                            j += 1
                        
                        m_url = url_param_pattern.search(block)
                        full_url = m_url.group(1) if m_url else ''
                        
                        m_method = method_param_pattern.search(block)
                        method = m_method.group(1).upper() if m_method else ''
                        
                        if not method:
                            if call_type == 'web_submit_data':
                                method = 'POST'
                            elif call_type == 'web_url':
                                method = 'GET'
                        
                        api_endpoint = ''
                        if full_url:
                            try:
                                parsed = urlparse(full_url)
                                api_endpoint = parsed.path
                            except Exception:
                                api_endpoint = full_url
                        
                        # Extract headers from ITEMDATA in the block
                        block_headers = []
                        for m_hdr in itemdata_header_pattern.finditer(block):
                            hdr_name = m_hdr.group(1)
                            hdr_value = m_hdr.group(2)
                            # Skip correlation parameters and dynamic values
                            if not hdr_value.startswith('{') and not 'Correlation' in hdr_value:
                                block_headers.append({'name': hdr_name, 'value': hdr_value})
                        
                        # Combine pending headers (from web_add_header) with block headers
                        all_headers = pending_headers + block_headers
                        
                        self.transaction_api_calls[current_transaction].append({
                            'service_name': service_name,
                            'method': method,
                            'api_endpoint': api_endpoint,
                            'full_url': full_url,
                            'headers': all_headers
                        })
                        
                        # Clear pending headers after API call
                        pending_headers = []
                    
                    i += 1
                    
            except Exception as e:
                debug_print(f"DEBUG: Error reading {c_file}: {e}")

    def parse_script_folder(self, script_folder: str):
        """Parse LoadRunner .c script files to extract API calls within each transaction.
        
        Reads Action.c and similar files to find:
        - lr_start_transaction("TransactionName") / lr_end_transaction("TransactionName")
        - web_custom_request("ServiceName", "URL=https://...", "Method=POST", ...)
        - web_url("ServiceName", "URL=https://...", ...)
        - web_submit_data("ServiceName", "Action=https://...", ...)
        
        Maps each API call to the transaction it belongs to.
        Can be called multiple times - results are merged (not replaced).
        """
        from urllib.parse import urlparse
        
        # Don't reset - merge with existing data if called multiple times
        if not hasattr(self, 'transaction_api_calls') or self.transaction_api_calls is None:
            self.transaction_api_calls = {}
        
        # Find all .c files
        c_files = []
        for root, dirs, files in os.walk(script_folder):
            for f in files:
                if f.endswith('.c'):
                    c_files.append(os.path.join(root, f))
        
        if not c_files:
            debug_print(f"DEBUG: No .c files found in {script_folder}")
            return
        
        debug_print(f"DEBUG: Parsing {len(c_files)} .c files from {script_folder}")
        
        # Patterns for transaction boundaries
        trans_start_pattern = re.compile(
            r'lr_start_transaction\s*\(\s*"([^"]+)"', re.IGNORECASE
        )
        trans_end_pattern = re.compile(
            r'lr_end_transaction\s*\(\s*"([^"]+)"', re.IGNORECASE
        )
        
        # Patterns for API calls - capture multi-line parameters
        # web_custom_request("ServiceName", "URL=...", "Method=...", ...)
        web_custom_start = re.compile(
            r'web_custom_request\s*\(\s*"([^"]+)"', re.IGNORECASE
        )
        # web_url("ServiceName", "URL=...", ...)
        web_url_start = re.compile(
            r'web_url\s*\(\s*"([^"]+)"', re.IGNORECASE
        )
        # web_submit_data("ServiceName", "Action=...", ...)
        web_submit_start = re.compile(
            r'web_submit_data\s*\(\s*"([^"]+)"', re.IGNORECASE
        )
        
        # Pattern to extract URL from parameters
        url_param_pattern = re.compile(r'"(?:URL|Action)\s*=\s*(https?://[^"]+)"', re.IGNORECASE)
        # Pattern to extract Method from parameters
        method_param_pattern = re.compile(r'"Method\s*=\s*(GET|POST|PUT|DELETE|PATCH|OPTIONS|HEAD)"', re.IGNORECASE)
        # Pattern for web_add_header
        header_pattern = re.compile(r'web_add_header\s*\(\s*"([^"]+)"\s*,\s*"([^"]+)"', re.IGNORECASE)
        # Pattern for headers in ITEMDATA: "Name=Content-Type", "Value=application/json", ENDITEM
        itemdata_header_pattern = re.compile(r'"Name=([^"]+)"\s*,\s*"Value=([^"]+)"\s*,\s*ENDITEM', re.IGNORECASE)
        
        # Track pending headers (set via web_add_header before API call)
        pending_headers = []
        
        for c_file in c_files:
            try:
                with open(c_file, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    lines = content.split('\n')
                
                current_transaction = None
                
                i = 0
                while i < len(lines):
                    line = lines[i]
                    stripped = line.strip()
                    
                    # Skip comments
                    if stripped.startswith('//') or stripped.startswith('/*'):
                        i += 1
                        continue
                    
                    # Check for web_add_header (captures headers set before API calls)
                    m_header = header_pattern.search(line)
                    if m_header:
                        header_name = m_header.group(1)
                        header_value = m_header.group(2)
                        # Don't store correlation parameters as headers
                        if not header_value.startswith('{') and not 'CorrelationParameter' in header_value:
                            pending_headers.append({'name': header_name, 'value': header_value})
                        i += 1
                        continue
                    
                    # Check transaction start
                    m_start = trans_start_pattern.search(line)
                    if m_start:
                        current_transaction = m_start.group(1)
                        if current_transaction not in self.transaction_api_calls:
                            self.transaction_api_calls[current_transaction] = []
                        i += 1
                        continue
                    
                    # Check transaction end
                    m_end = trans_end_pattern.search(line)
                    if m_end:
                        current_transaction = None
                        i += 1
                        continue
                    
                    # Only capture API calls within a transaction
                    if not current_transaction:
                        i += 1
                        continue
                    
                    # Check for web_custom_request, web_url, web_submit_data
                    service_name = ''
                    call_type = ''
                    
                    m_wcr = web_custom_start.search(line)
                    m_wu = web_url_start.search(line)
                    m_ws = web_submit_start.search(line)
                    
                    if m_wcr:
                        service_name = m_wcr.group(1)
                        call_type = 'web_custom_request'
                    elif m_wu:
                        service_name = m_wu.group(1)
                        call_type = 'web_url'
                    elif m_ws:
                        service_name = m_ws.group(1)
                        call_type = 'web_submit_data'
                    
                    if call_type:
                        # Read ahead to find URL and Method parameters (could span multiple lines)
                        block = line
                        j = i + 1
                        paren_depth = line.count('(') - line.count(')')
                        while j < len(lines) and paren_depth > 0:
                            block += ' ' + lines[j]
                            paren_depth += lines[j].count('(') - lines[j].count(')')
                            j += 1
                        
                        # Extract URL
                        m_url = url_param_pattern.search(block)
                        full_url = m_url.group(1) if m_url else ''
                        
                        # Extract Method
                        m_method = method_param_pattern.search(block)
                        method = m_method.group(1).upper() if m_method else ''
                        
                        # Default method based on call type
                        if not method:
                            if call_type == 'web_submit_data':
                                method = 'POST'
                            elif call_type == 'web_url':
                                method = 'GET'
                        
                        # Extract API endpoint from URL
                        api_endpoint = ''
                        if full_url:
                            try:
                                parsed = urlparse(full_url)
                                api_endpoint = parsed.path
                            except Exception:
                                api_endpoint = full_url
                        
                        # Extract headers from ITEMDATA in the block
                        block_headers = []
                        for m_hdr in itemdata_header_pattern.finditer(block):
                            hdr_name = m_hdr.group(1)
                            hdr_value = m_hdr.group(2)
                            # Skip correlation parameters and dynamic values
                            if not hdr_value.startswith('{') and not 'Correlation' in hdr_value:
                                block_headers.append({'name': hdr_name, 'value': hdr_value})
                        
                        # Combine pending headers (from web_add_header) with block headers
                        all_headers = pending_headers + block_headers
                        
                        # Add to transaction API calls
                        self.transaction_api_calls[current_transaction].append({
                            'service_name': service_name,
                            'method': method,
                            'api_endpoint': api_endpoint,
                            'full_url': full_url,
                            'headers': all_headers
                        })
                        
                        # Clear pending headers after API call
                        pending_headers = []
                    
                    i += 1
                    
            except Exception as e:
                debug_print(f"DEBUG: Error reading script file {c_file}: {e}")
        
        # Remove empty transactions
        self.transaction_api_calls = {k: v for k, v in self.transaction_api_calls.items() if v}
        
        total_calls = sum(len(v) for v in self.transaction_api_calls.values())
        debug_print(f"DEBUG: Found {total_calls} unique API calls across {len(self.transaction_api_calls)} transactions")
        if self.transaction_api_calls:
            for tname in list(self.transaction_api_calls.keys())[:5]:
                calls = self.transaction_api_calls[tname]
                debug_print(f"DEBUG:   {tname}: {len(calls)} API calls")
                for c in calls[:3]:
                    debug_print(f"DEBUG:     [{c['method']}] {c['service_name']} - {c['api_endpoint'][:60]}")

    def parse_script_zip(self, zip_path: str, progress_callback=None):
        """Parse LoadRunner .c script files directly from ZIP without extraction.
        
        This is MUCH faster than extracting all files first.
        Only reads Action.c and other .c files, skipping everything else.
        
        Args:
            zip_path: Path to the ZIP file containing scripts
            progress_callback: Optional callback(current, total, message) for progress updates
        """
        import zipfile
        from urllib.parse import urlparse
        
        if not hasattr(self, 'transaction_api_calls') or self.transaction_api_calls is None:
            self.transaction_api_calls = {}
        
        try:
            with zipfile.ZipFile(zip_path, 'r') as zf:
                # Get list of .c files only
                all_files = zf.namelist()
                c_files = [f for f in all_files if f.lower().endswith('.c')]
                
                if progress_callback:
                    progress_callback(0, len(c_files), f"Found {len(c_files)} script files in ZIP")
                
                debug_print(f"DEBUG: Found {len(c_files)} .c files in ZIP (out of {len(all_files)} total files)")
                
                if not c_files:
                    return
                
                # Patterns for transaction boundaries
                trans_start_pattern = re.compile(
                    r'lr_start_transaction\s*\(\s*"([^"]+)"', re.IGNORECASE
                )
                trans_end_pattern = re.compile(
                    r'lr_end_transaction\s*\(\s*"([^"]+)"', re.IGNORECASE
                )
                
                # Patterns for API calls
                web_custom_start = re.compile(
                    r'web_custom_request\s*\(\s*"([^"]+)"', re.IGNORECASE
                )
                web_url_start = re.compile(
                    r'web_url\s*\(\s*"([^"]+)"', re.IGNORECASE
                )
                web_submit_start = re.compile(
                    r'web_submit_data\s*\(\s*"([^"]+)"', re.IGNORECASE
                )
                
                url_param_pattern = re.compile(r'"(?:URL|Action)\s*=\s*(https?://[^"]+)"', re.IGNORECASE)
                method_param_pattern = re.compile(r'"Method\s*=\s*(GET|POST|PUT|DELETE|PATCH|OPTIONS|HEAD)"', re.IGNORECASE)
                header_pattern = re.compile(r'web_add_header\s*\(\s*"([^"]+)"\s*,\s*"([^"]+)"', re.IGNORECASE)
                itemdata_header_pattern = re.compile(r'"Name=([^"]+)"\s*,\s*"Value=([^"]+)"\s*,\s*ENDITEM', re.IGNORECASE)
                
                # Process each .c file directly from ZIP
                for idx, c_file in enumerate(c_files):
                    if progress_callback and idx % 10 == 0:
                        progress_callback(idx, len(c_files), f"Parsing {idx}/{len(c_files)} scripts...")
                    
                    try:
                        # Read file content directly from ZIP (no extraction needed)
                        content = zf.read(c_file).decode('utf-8', errors='ignore')
                        lines = content.split('\n')
                        
                        current_transaction = None
                        pending_headers = []
                        
                        i = 0
                        while i < len(lines):
                            line = lines[i]
                            stripped = line.strip()
                            
                            if stripped.startswith('//') or stripped.startswith('/*'):
                                i += 1
                                continue
                            
                            # Check for web_add_header
                            m_header = header_pattern.search(line)
                            if m_header:
                                header_name = m_header.group(1)
                                header_value = m_header.group(2)
                                if not header_value.startswith('{') and not 'CorrelationParameter' in header_value:
                                    pending_headers.append({'name': header_name, 'value': header_value})
                                i += 1
                                continue
                            
                            # Check transaction start
                            m_start = trans_start_pattern.search(line)
                            if m_start:
                                current_transaction = m_start.group(1)
                                if current_transaction not in self.transaction_api_calls:
                                    self.transaction_api_calls[current_transaction] = []
                                i += 1
                                continue
                            
                            # Check transaction end
                            m_end = trans_end_pattern.search(line)
                            if m_end:
                                current_transaction = None
                                i += 1
                                continue
                            
                            if not current_transaction:
                                i += 1
                                continue
                            
                            # Check for API calls
                            service_name = ''
                            call_type = ''
                            
                            m_wcr = web_custom_start.search(line)
                            m_wu = web_url_start.search(line)
                            m_ws = web_submit_start.search(line)
                            
                            if m_wcr:
                                service_name = m_wcr.group(1)
                                call_type = 'web_custom_request'
                            elif m_wu:
                                service_name = m_wu.group(1)
                                call_type = 'web_url'
                            elif m_ws:
                                service_name = m_ws.group(1)
                                call_type = 'web_submit_data'
                            
                            if call_type:
                                block = line
                                j = i + 1
                                paren_depth = line.count('(') - line.count(')')
                                while j < len(lines) and paren_depth > 0:
                                    block += ' ' + lines[j]
                                    paren_depth += lines[j].count('(') - lines[j].count(')')
                                    j += 1
                                
                                m_url = url_param_pattern.search(block)
                                full_url = m_url.group(1) if m_url else ''
                                
                                m_method = method_param_pattern.search(block)
                                method = m_method.group(1).upper() if m_method else ''
                                
                                if not method:
                                    if call_type == 'web_submit_data':
                                        method = 'POST'
                                    elif call_type == 'web_url':
                                        method = 'GET'
                                
                                api_endpoint = ''
                                if full_url:
                                    try:
                                        parsed = urlparse(full_url)
                                        api_endpoint = parsed.path
                                    except Exception:
                                        api_endpoint = full_url
                                
                                block_headers = []
                                for m_hdr in itemdata_header_pattern.finditer(block):
                                    hdr_name = m_hdr.group(1)
                                    hdr_value = m_hdr.group(2)
                                    if not hdr_value.startswith('{') and not 'Correlation' in hdr_value:
                                        block_headers.append({'name': hdr_name, 'value': hdr_value})
                                
                                all_headers = pending_headers + block_headers
                                
                                self.transaction_api_calls[current_transaction].append({
                                    'service_name': service_name,
                                    'method': method,
                                    'api_endpoint': api_endpoint,
                                    'full_url': full_url,
                                    'headers': all_headers
                                })
                                
                                pending_headers = []
                            
                            i += 1
                            
                    except Exception as e:
                        debug_print(f"DEBUG: Error reading {c_file} from ZIP: {e}")
                
                if progress_callback:
                    progress_callback(len(c_files), len(c_files), "Complete!")
        
        except Exception as e:
            debug_print(f"DEBUG: Error opening ZIP {zip_path}: {e}")
            return
        
        # Remove empty transactions
        self.transaction_api_calls = {k: v for k, v in self.transaction_api_calls.items() if v}
        
        total_calls = sum(len(v) for v in self.transaction_api_calls.values())
        debug_print(f"DEBUG: Found {total_calls} API calls across {len(self.transaction_api_calls)} transactions from ZIP")

    def _parse_api_errors_from_logs(self):
        """Parse VUser log files to extract API URLs for failed requests."""
        log_folder = os.path.join(self.result_folder, 'log')
        if not os.path.exists(log_folder):
            debug_print(f"DEBUG: log folder not found at {log_folder}")
            return
        
        debug_print(f"DEBUG: Parsing API errors from log files in {log_folder}")
        
        # Dictionary to count API errors: key = (script, action, line, api_url, http_status) -> count
        api_error_counts = {}
        
        # Get all .log files
        log_files = [f for f in os.listdir(log_folder) if f.endswith('.log')]
        
        # Pattern to match HTTP errors with URLs like:
        # Action.c(591): Error -26611: HTTP Status-Code=500 (Internal Server Error) for "https://..."
        http_error_pattern = re.compile(
            r'(\w+\.c)\((\d+)\):\s*Error\s+(-?\d+):\s*HTTP\s+Status-Code=(\d+)\s*\([^)]+\)\s+for\s+"([^"]+)"',
            re.IGNORECASE
        )
        
        # Pattern for other errors with URLs
        url_error_pattern = re.compile(
            r'(\w+\.c)\((\d+)\):\s*Error\s+(-?\d+):\s*(.+?)"(https?://[^"]+)"',
            re.IGNORECASE
        )
        
        for log_file in log_files:
            log_path = os.path.join(log_folder, log_file)
            
            # Get script name from log file name
            base_name = os.path.splitext(log_file)[0]
            parts = base_name.rsplit('_', 1)
            if len(parts) == 2 and parts[1].isdigit():
                script_name = parts[0]
            else:
                script_name = base_name
            
            try:
                with open(log_path, 'r', encoding='utf-8', errors='ignore') as f:
                    content = f.read()
                    
                    # Find HTTP status errors with URLs
                    for match in http_error_pattern.finditer(content):
                        action_file = match.group(1)
                        line_num = match.group(2)
                        error_code = match.group(3)
                        http_status = match.group(4)
                        api_url = match.group(5)
                        
                        action_name = action_file.replace('.c', '')
                        
                        # Create unique key
                        key = (script_name, action_name, line_num, api_url, http_status, error_code)
                        api_error_counts[key] = api_error_counts.get(key, 0) + 1
                    
                    # Also find other URL-related errors
                    for match in url_error_pattern.finditer(content):
                        action_file = match.group(1)
                        line_num = match.group(2)
                        error_code = match.group(3)
                        error_msg = match.group(4).strip()
                        api_url = match.group(5)
                        
                        action_name = action_file.replace('.c', '')
                        
                        # Create unique key (no http_status for these)
                        key = (script_name, action_name, line_num, api_url, '', error_code)
                        if key not in api_error_counts:
                            api_error_counts[key] = api_error_counts.get(key, 0) + 1
                            
            except Exception as e:
                debug_print(f"DEBUG: Error reading log file {log_file}: {e}")
        
        # Convert to list of API error objects
        for key, count in api_error_counts.items():
            script_name, action_name, line_num, api_url, http_status, error_code = key
            
            # Extract API endpoint from full URL
            try:
                from urllib.parse import urlparse
                parsed = urlparse(api_url)
                api_endpoint = parsed.path
            except:
                api_endpoint = api_url
            
            self.api_errors.append({
                'script': script_name,
                'action': action_name,
                'line': line_num,
                'api_url': api_url,
                'api_endpoint': api_endpoint,
                'http_status': http_status,
                'error_code': error_code,
                'count': count
            })
        
        # Sort by count descending
        self.api_errors.sort(key=lambda x: x['count'], reverse=True)
        
        debug_print(f"DEBUG: Found {len(self.api_errors)} unique API errors from log files")
        if self.api_errors:
            for api in self.api_errors[:3]:
                debug_print(f"DEBUG: {api['script']}:{api['action']}({api['line']}) HTTP {api['http_status']} - {api['api_endpoint'][:50]}... ({api['count']}x)")

    def _calculate_transaction_summary(self):
        """Calculate transaction summary with aggregated metrics (steady state only)."""
        # Use steady state duration for TPS calculation if available
        if self.steady_state_duration > 0:
            duration = self.steady_state_duration
        else:
            duration = self.scenario_info.get('duration_seconds', 1) or 1
        
        debug_print(f"\n--- CALCULATE TRANSACTION SUMMARY ---")
        debug_print(f"Duration: {duration} seconds")
        debug_print(f"response_times has {len(self.response_times)} transactions")
        
        # Debug: Check if pass_count exists in any transaction
        has_pass_count = sum(1 for data in self.response_times.values() if 'pass_count' in data)
        debug_print(f"Transactions with pass_count: {has_pass_count}")
        
        for trans_name, data in self.response_times.items():
            times = data.get('times', [])
            fail_count = data.get('fail_count', 0)
            
            # Pass_count: Priority 1) from graph data (es_tr_tprange_pass), 2) from response times
            # TPS: pass_count / ss_duration (matches LoadRunner Analysis)
            if 'pass_count' in data and data['pass_count'] > 0:
                pass_count = data['pass_count']  # Use actual graph pass count
                tps = pass_count / duration if duration > 0 else 0
                
                # Debug: ScheduleB transactions
                if 'ScheduleB' in trans_name and ('T12' in trans_name or 'T13' in trans_name):
                    debug_print(f"  SUMMARY ScheduleB: {trans_name} pass_count={pass_count} (from graph)")
            elif 'avg_tps' in data:
                tps = data['avg_tps']
                pass_count = int(round(tps * duration))  # Estimate from TPS
            else:
                # Fallback: use response time count
                pass_count = len(times)
                tps = pass_count / duration if duration > 0 else 0
            
            total_count = pass_count + fail_count
            
            # Debug: Log specific transaction data
            if 'ITR1_Online_T01' in trans_name or 'ITR1_Offline_T01' in trans_name:
                debug_print(f"  SUMMARY {trans_name}: pass_count={pass_count} (from graph: {'pass_count' in data})")
                self._debug_info.append(f"DEBUG {trans_name}: pass_count={pass_count}, graph_pass={data.get('pass_count', 'N/A')}, avg_tps={data.get('avg_tps', 'N/A')}")
            
            if times:
                avg_response = sum(times) / len(times)
                min_response = min(times)
                max_response = max(times)
                
                # Calculate standard deviation
                if len(times) > 1:
                    variance = sum((t - avg_response) ** 2 for t in times) / len(times)
                    std_deviation = math.sqrt(variance)
                else:
                    std_deviation = 0
                
                # Calculate 95th percentile using linear interpolation (matches LoadRunner Analysis)
                sorted_times = sorted(times)
                n = len(sorted_times)
                if n > 0:
                    # Linear interpolation formula (same as numpy percentile with method='linear')
                    idx = 0.95 * (n - 1)
                    lower_idx = int(idx)
                    upper_idx = min(lower_idx + 1, n - 1)
                    weight = idx - lower_idx
                    p95_response = sorted_times[lower_idx] * (1 - weight) + sorted_times[upper_idx] * weight
                else:
                    p95_response = max_response
            else:
                avg_response = min_response = max_response = p95_response = std_deviation = 0
            
            self.transaction_summary.append({
                'transaction_name': trans_name,
                'pass_count': pass_count,
                'fail_count': fail_count,
                'total_count': total_count,
                'avg_response_time': round(avg_response, 3),
                'min_response_time': round(min_response, 3),
                'max_response_time': round(max_response, 3),
                'std_deviation': round(std_deviation, 3),
                '95th_percentile': round(p95_response, 3),
                'tps': round(tps, 4)
            })
        
        # Sort by transaction name
        self.transaction_summary.sort(key=lambda x: x['transaction_name'])
        
        # Generate TPS data (using steady state duration)
        self.tps_data = [{
            'transaction_name': t['transaction_name'],
            'tps': t['tps'],
            'pass_count': t['pass_count'],
            'fail_count': t['fail_count'],
            'duration_seconds': duration,
            'is_steady_state': self.steady_state_duration > 0
        } for t in self.transaction_summary]
    
    def _lookup_target_tps(self, script_name: str) -> float:
        """
        Look up the target TPS for a script from the built-in lookup table.
        Tries exact match first, then partial/fuzzy matching.
        
        Args:
            script_name: The script name to look up
            
        Returns:
            Target TPS value or None if not found
        """
        if not script_name:
            return None
        
        # Try exact match first
        if script_name in TARGET_TPS_LOOKUP:
            return TARGET_TPS_LOOKUP[script_name]
        
        # Try case-insensitive match
        script_lower = script_name.lower()
        for key, value in TARGET_TPS_LOOKUP.items():
            if key.lower() == script_lower:
                return value
        
        # Try partial match (script_name contains key or key contains script_name)
        for key, value in TARGET_TPS_LOOKUP.items():
            key_clean = key.replace('_', '').replace('-', '').replace(' ', '').lower()
            script_clean = script_name.replace('_', '').replace('-', '').replace(' ', '').lower()
            if key_clean in script_clean or script_clean in key_clean:
                return value
        
        return None
    
    def get_transaction_summary(self) -> List[Dict]:
        """Get transaction summary data."""
        return self.transaction_summary
    
    def get_tps_data(self) -> List[Dict]:
        """Get TPS (Transactions Per Second) data."""
        return self.tps_data
    
    def get_errors(self) -> List[Dict]:
        """Get error data."""
        return self.errors
    
    def get_scenario_info(self) -> Dict:
        """Get scenario information."""
        return self.scenario_info
    
    def get_all_data(self) -> Dict[str, Any]:
        """Get all parsed data."""
        return {
            'scenario_info': self.scenario_info,
            'transaction_summary': self.transaction_summary,
            'tps_data': self.tps_data,
            'errors': self.errors
        }
    
    def aggregate_data(self, other_parser: 'LRRParser'):
        """
        Aggregate data from another parser (for multiple controller support).
        Combines transaction counts, recalculates TPS, etc.
        """
        # Create a mapping of existing transactions
        trans_map = {t['transaction_name']: t for t in self.transaction_summary}
        
        # Aggregate from other parser
        for other_trans in other_parser.transaction_summary:
            name = other_trans['transaction_name']
            if name in trans_map:
                # Add counts
                trans_map[name]['pass_count'] += other_trans['pass_count']
                trans_map[name]['fail_count'] += other_trans['fail_count']
                trans_map[name]['total_count'] += other_trans['total_count']
                
                # Average the response times (weighted average would be better but this is simpler)
                trans_map[name]['avg_response_time'] = round(
                    (trans_map[name]['avg_response_time'] + other_trans['avg_response_time']) / 2, 3)
                
                # Take min/max
                trans_map[name]['min_response_time'] = min(
                    trans_map[name]['min_response_time'], other_trans['min_response_time'])
                trans_map[name]['max_response_time'] = max(
                    trans_map[name]['max_response_time'], other_trans['max_response_time'])
                
                # Average std deviation
                trans_map[name]['std_deviation'] = round(
                    (trans_map[name].get('std_deviation', 0) + other_trans.get('std_deviation', 0)) / 2, 3)
                
                # Average 95th percentile
                trans_map[name]['95th_percentile'] = round(
                    (trans_map[name]['95th_percentile'] + other_trans['95th_percentile']) / 2, 3)
                
                # Add TPS (since they ran in parallel)
                trans_map[name]['tps'] = round(trans_map[name]['tps'] + other_trans['tps'], 4)
            else:
                # Add new transaction
                self.transaction_summary.append(other_trans.copy())
                trans_map[name] = other_trans
        
        # Update tps_data
        duration = self.steady_state_duration if self.steady_state_duration > 0 else self.scenario_info.get('duration_seconds', 1)
        self.tps_data = [{
            'transaction_name': t['transaction_name'],
            'tps': t['tps'],
            'pass_count': t['pass_count'],
            'fail_count': t.get('fail_count', 0),
            'duration_seconds': duration,
            'is_steady_state': self.steady_state_duration > 0
        } for t in self.transaction_summary]
        
        # Aggregate errors
        existing_errors = {e['error_location'] for e in self.errors}
        for error in other_parser.errors:
            if error['error_location'] not in existing_errors:
                self.errors.append(error)
        
        # Aggregate response_times (which contains tps_values and times)
        for name, data in other_parser.response_times.items():
            if name in self.response_times:
                # Merge times lists
                if 'times' in data:
                    self.response_times[name].setdefault('times', []).extend(data['times'])
                # Merge tps_values lists
                if 'tps_values' in data:
                    self.response_times[name].setdefault('tps_values', []).extend(data['tps_values'])
                # Sum counts
                self.response_times[name]['count'] = self.response_times[name].get('count', 0) + data.get('count', 0)
                self.response_times[name]['pass_count'] = self.response_times[name].get('pass_count', 0) + data.get('pass_count', 0)
                self.response_times[name]['fail_count'] = self.response_times[name].get('fail_count', 0) + data.get('fail_count', 0)
            else:
                # Add new transaction - copy the data
                self.response_times[name] = {
                    'times': list(data.get('times', [])),
                    'tps_values': list(data.get('tps_values', [])),
                    'count': data.get('count', 0),
                    'pass_count': data.get('pass_count', 0),
                    'fail_count': data.get('fail_count', 0),
                }
        
        # Aggregate scenario info from all controllers BEFORE modifying max_vusers
        # Store each controller's ORIGINAL max_vusers value AND snapshot its
        # per-script vuser-count dict. The snapshot is what the multi-controller
        # Excel export uses to compute Column J = MAX across controllers
        # (treating each controller as an independent run rather than summing
        # contributions, which inflates user counts when the same logical
        # script appears under multiple group names per controller).
        if not hasattr(self, 'all_scenario_info'):
            # First time - initialize with self's ORIGINAL scenario info
            self.all_scenario_info = [{
                'scenario_info': self.scenario_info.copy(),
                'steady_state_duration': self.steady_state_duration,
                'steady_state_from_rel': self.steady_state_from_rel,
                'steady_state_to_rel': self.steady_state_to_rel,
                'max_vusers': self.max_vusers,  # Original value before aggregation
                'script_counts': dict(self.script_vuser_counts),  # Pre-aggregation snapshot
            }]
        
        # Add other parser's scenario info with its ORIGINAL max_vusers
        self.all_scenario_info.append({
            'scenario_info': other_parser.scenario_info.copy(),
            'steady_state_duration': other_parser.steady_state_duration,
            'steady_state_from_rel': other_parser.steady_state_from_rel,
            'steady_state_to_rel': other_parser.steady_state_to_rel,
            'max_vusers': other_parser.max_vusers,
            'script_counts': dict(other_parser.script_vuser_counts),  # Pre-aggregation snapshot
        })
        
        # Aggregate Vuser counts - take max across all controllers (AFTER storing individual values)
        if other_parser.max_vusers > 0:
            self.max_vusers = max(self.max_vusers, other_parser.max_vusers)
            # Combine running vusers lists
            self.running_vusers.extend(other_parser.running_vusers)
            if self.running_vusers:
                self.avg_vusers = round(sum(self.running_vusers) / len(self.running_vusers), 0)
        
        # Aggregate HTTP Statistics (Full Duration)
        for stat_type in ['response_codes', 'web_connections', 'web_ssl', 'retries']:
            for name, value in other_parser.http_statistics.get(stat_type, {}).items():
                if name in self.http_statistics.get(stat_type, {}):
                    self.http_statistics[stat_type][name] += value
                else:
                    self.http_statistics.setdefault(stat_type, {})[name] = value
        
        # Aggregate HTTP Statistics (Steady State)
        other_http_ss = getattr(other_parser, 'http_statistics_ss', {})
        for stat_type in ['response_codes', 'web_connections', 'web_ssl', 'retries']:
            for name, value in other_http_ss.get(stat_type, {}).items():
                if name in self.http_statistics_ss.get(stat_type, {}):
                    self.http_statistics_ss[stat_type][name] += value
                else:
                    self.http_statistics_ss.setdefault(stat_type, {})[name] = value
        
        # Aggregate script_vuser_counts from other controllers (C2, C3, C4)
        # using normalized keys to keep counts stable when script names vary slightly.
        #
        # ORDER-INDEPENDENT AGGREGATION:
        # The previous implementation iterated `self.script_vuser_counts.keys()`
        # in dict insertion order and broke at the first normalized match. The
        # surviving key (the one that absorbed the sum) therefore depended on
        # which controller was uploaded first, which in turn changed how the
        # downstream Excel lookup matched transaction names and produced
        # different values for "User Count", "Adjusted User Count" and
        # "Total VUsers" across runs with the same input folders.
        #
        # This rewrite:
        #   1) Pools all (key, count) entries from BOTH the base parser and the
        #      incoming parser into a single list.
        #   2) Groups them by their normalized name.
        #   3) Within each normalized group, sums the counts and stores the
        #      result under the *lexicographically smallest* original key.
        #   4) Rebuilds `self.script_vuser_counts` from this canonical mapping.
        #
        # Because grouping is commutative and the canonical key is chosen
        # deterministically (alphabetical minimum), the resulting dict is
        # identical regardless of the order in which controllers are passed
        # to aggregate_data().
        def _norm_script_name(name):
            n = str(name or '').strip().lower()
            n = re.sub(r'^\d+[._-]?', '', n)
            # Strip alpha+digit prefixes like 'fo009_', 'er003_', 'bo123_' that
            # LoadRunner scripts commonly use. Require >=3 digits so that
            # genuine identifiers like 'itr1_', 'itr2_', 'itr4_' are NOT
            # stripped (those use 1 digit and ARE meaningful).
            n = re.sub(r'^[a-z]+\d{3,}_', '', n)
            n = re.sub(r'_(final|modify|modified|new|ntb|act\d+|v\d+.*|ay\d+_?\d*).*$', '', n)
            n = re.sub(r'[^a-z0-9]', '', n)
            return n

        def _to_int(value):
            try:
                return int(float(value))
            except Exception:
                return 0

        # Pool entries from BOTH parsers so the merged dict is rebuilt from a
        # symmetric, order-independent source. Sorting the inputs is not
        # strictly required for correctness but makes debugging deterministic.
        combined_entries = sorted(
            list(self.script_vuser_counts.items())
            + list(other_parser.script_vuser_counts.items()),
            key=lambda kv: str(kv[0])
        )

        # Group by normalized name. Keys that normalize to an empty string
        # (rare edge case: punctuation-only names) are preserved verbatim so we
        # never silently drop data.
        normalized_groups = defaultdict(list)
        unnormalizable = []
        for key, value in combined_entries:
            norm = _norm_script_name(key)
            if norm:
                normalized_groups[norm].append((str(key), _to_int(value)))
            else:
                unnormalizable.append((str(key), _to_int(value)))

        # Rebuild the dict with a single canonical key per normalized group.
        new_counts = {}
        for norm in sorted(normalized_groups.keys()):
            entries = normalized_groups[norm]
            canonical_key = min(entry[0] for entry in entries)
            total_count = sum(entry[1] for entry in entries)
            new_counts[canonical_key] = total_count

        # Append any un-normalizable entries (summing duplicates if any).
        for key, value in unnormalizable:
            new_counts[key] = new_counts.get(key, 0) + value

        self.script_vuser_counts = new_counts

        debug_print(f"Aggregated script_vuser_counts: {len(self.script_vuser_counts)} scripts total")
    
    def merge(self, other_parser: 'LRRParser'):
        """
        Merge data from another parser (alias for aggregate_data).
        Used for combining results from multiple controllers.
        """
        self.aggregate_data(other_parser)
    
    def export_to_excel(self, output_path: str = None, report_type = 'all', target_tps: float = None, script_name: str = None, custom_target_tps: dict = None, adj_user_pct: float = 0.25, custom_script_categories: dict = None, wlm_workbook_path: str = None) -> str:
        """
        Export data to Excel file.
        
        Args:
            output_path: Output file path. If None, creates in result folder.
            report_type: Type of report - can be a string ('all', 'transaction_summary', 'tps', 'tps_main', 'errors')
                        or a list of types (['transaction_summary', 'tps'])
            target_tps: Target TPS value for FinalReport calculation (deprecated, use custom_target_tps)
            wlm_workbook_path: Optional path to a Final_WLM_YYYY_YYYY.xlsx workbook.
                        When provided (or auto-detected in TargetTPS_Presets/), the
                        FinalReport is generated from WLM data (row order, Target
                        TPS, cell styles for cols B/C/D) filtered to LR-tested
                        usecases. When absent, falls back to the legacy
                        TARGET_TPS_LOOKUP + custom_target_tps pipeline.
            script_name: Script name/description for FinalReport
            custom_target_tps: Dictionary mapping script name to target TPS value (from user Excel file)
            adj_user_pct: Adjustment percentage for Adj User Count column (0.25 = 25%, 0.5 = 50%, etc.)
                         Formula: (User Count / TPS%) × adj_user_pct
            custom_script_categories: Dictionary mapping script name to category ('BO' or 'FO') for user-added scripts
            
        Returns:
            Path to the created Excel file.
        """
        # Store for use in Target_TPS sheet
        self._custom_script_categories = custom_script_categories or {}
        
        # Store adj_user_pct for use in Final Report sheet
        self._adj_user_pct = adj_user_pct
        
        # Enable Column J lookup tracing if env var is set and not already on.
        # Setting LRR_LOOKUP_TRACE=1 in the environment makes export_to_excel
        # write a <output>.lookup-trace.tsv sidecar file describing every
        # match decision for the FinalReport User Count column.
        if self._lookup_trace_lines is None:
            _trace_env = os.environ.get('LRR_LOOKUP_TRACE', '').strip()
            if _trace_env and _trace_env.lower() not in ('0', 'false', 'no', 'off'):
                self.enable_lookup_trace()
        
        # Normalize report_type to a list
        if isinstance(report_type, str):
            report_types = [report_type]
        else:
            report_types = report_type
        
        # Helper function to check if a specific report should be included
        def should_include(type_name):
            return 'all' in report_types or type_name in report_types
        
        # DEBUG: Show what TPS data is available
        if DEBUG:
            debug_print("\n" + "="*60)
            debug_print("DEBUG: export_to_excel - Checking TPS data availability")
            debug_print("="*60)
            tps_count = 0
            times_count = 0
            for name, data in self.response_times.items():
                if data.get('tps_values'):
                    tps_count += 1
                    if '245' in name or 'Bulk' in name:
                        vals = data['tps_values']
                        debug_print(f"  FOUND TPS: {name}")
                        debug_print(f"    tps_values: count={len(vals)}, avg={sum(vals)/len(vals):.4f}, min={min(vals):.4f}, max={max(vals):.4f}")
                if data.get('times'):
                    times_count += 1
                    if '245' in name or 'Bulk' in name:
                        if not data.get('tps_values'):
                            debug_print(f"  NO TPS (using times fallback): {name}")
                            vals = data['times']
                            debug_print(f"    times: count={len(vals)}, avg={sum(vals)/len(vals):.4f}")
            debug_print(f"\nSUMMARY: {tps_count} transactions have tps_values, {times_count} have times")
            debug_print("="*60 + "\n")
        
        if not EXCEL_AVAILABLE:
            raise ImportError("openpyxl is required for Excel export. Install with: pip install openpyxl")
        
        if output_path is None:
            result_name = self.scenario_info.get('result_name', 'LoadRunner_Report')
            output_path = os.path.join(self.result_folder, f'{result_name}_Report.xlsx')
        
        wb = openpyxl.Workbook()
        
        # Styles
        header_font = Font(bold=True, color='FFFFFF')
        header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
        header_alignment = Alignment(horizontal='center', vertical='center')
        border = Border(
            left=Side(style='thin'),
            right=Side(style='thin'),
            top=Side(style='thin'),
            bottom=Side(style='thin')
        )
        
        def apply_header_style(cell):
            cell.font = header_font
            cell.fill = header_fill
            cell.alignment = header_alignment
            cell.border = border
        
        def apply_cell_style(cell):
            cell.border = border
            cell.alignment = Alignment(horizontal='left')
        
        sheets_created = []
        
        # Scenario Info sheet (always include)
        ws_info = wb.active
        ws_info.title = 'Scenario Info'
        sheets_created.append('Scenario Info')
        
        # Check if we have multiple controllers
        all_scenarios = getattr(self, 'all_scenario_info', None)
        
        if all_scenarios and len(all_scenarios) > 1:
            # Multiple controllers - show each one's info
            current_row = 1
            
            for ctrl_idx, ctrl_data in enumerate(all_scenarios, 1):
                scenario = ctrl_data['scenario_info']
                
                # Controller header
                header_cell = ws_info.cell(row=current_row, column=1, value=f'Controller {ctrl_idx}')
                header_cell.font = Font(bold=True, size=12, color='2F5496')
                ws_info.merge_cells(f'A{current_row}:B{current_row}')
                current_row += 1
                
                # Property headers
                h1 = ws_info.cell(row=current_row, column=1, value='Property')
                h2 = ws_info.cell(row=current_row, column=2, value='Value')
                apply_header_style(h1)
                apply_header_style(h2)
                current_row += 1
                
                # Helper function to format seconds as HH:MM:SS
                def format_seconds_to_hhmmss(seconds):
                    if seconds is None or seconds < 0:
                        return 'N/A'
                    hours = int(seconds // 3600)
                    minutes = int((seconds % 3600) // 60)
                    secs = int(seconds % 60)
                    return f"{hours:02d}:{minutes:02d}:{secs:02d}"
                
                ss_from_rel = ctrl_data.get('steady_state_from_rel', -1)
                ss_to_rel = ctrl_data.get('steady_state_to_rel', -1)
                ss_duration = ctrl_data.get('steady_state_duration', 0)
                
                info_data = [
                    ('Result Name', scenario.get('result_name', 'N/A')),
                    ('Product', scenario.get('product', 'N/A')),
                    ('Version', scenario.get('version', 'N/A')),
                    ('Scenario Type', scenario.get('scenario_type', 'N/A')),
                    ('Mode', scenario.get('mode', 'N/A')),
                    ('Start Time', str(scenario.get('start_time', 'N/A'))),
                    ('Stop Time', str(scenario.get('stop_time', 'N/A'))),
                    ('Duration (seconds)', scenario.get('duration_seconds', 'N/A')),
                    ('Steady State Duration (seconds)', ss_duration),
                    ('Steady State From (seconds)', format_seconds_to_hhmmss(ss_from_rel) if ss_from_rel >= 0 else 'N/A'),
                    ('Steady State To (seconds)', format_seconds_to_hhmmss(ss_to_rel) if ss_to_rel >= 0 else 'N/A'),
                    ('User Count (Max Vusers)', ctrl_data.get('max_vusers', 'N/A')),
                ]
                
                for prop, value in info_data:
                    cell_prop = ws_info.cell(row=current_row, column=1, value=prop)
                    cell_val = ws_info.cell(row=current_row, column=2, value=value)
                    apply_cell_style(cell_prop)
                    apply_cell_style(cell_val)
                    current_row += 1
                
                current_row += 1  # Empty row between controllers
            
            # Total summary at the end
            summary_header = ws_info.cell(row=current_row, column=1, value='Combined Summary')
            summary_header.font = Font(bold=True, size=12, color='2F5496')
            ws_info.merge_cells(f'A{current_row}:B{current_row}')
            current_row += 1
            
            total_vusers = sum(c.get('max_vusers', 0) for c in all_scenarios)
            combined_data = [
                ('Total Controllers', len(all_scenarios)),
                ('Combined User Count', total_vusers),
            ]
            
            for prop, value in combined_data:
                cell_prop = ws_info.cell(row=current_row, column=1, value=prop)
                cell_val = ws_info.cell(row=current_row, column=2, value=value)
                cell_prop.font = Font(bold=True)
                cell_prop.border = border
                cell_val.font = Font(bold=True)
                cell_val.border = border
                current_row += 1
        else:
            # Single controller - original format
            info_headers = ['Property', 'Value']
            for col, header in enumerate(info_headers, 1):
                cell = ws_info.cell(row=1, column=col, value=header)
                apply_header_style(cell)
            
            # Helper function to format seconds as HH:MM:SS
            def format_seconds_to_hhmmss(seconds):
                if seconds is None or seconds < 0:
                    return 'N/A'
                hours = int(seconds // 3600)
                minutes = int((seconds % 3600) // 60)
                secs = int(seconds % 60)
                return f"{hours:02d}:{minutes:02d}:{secs:02d}"
            
            info_data = [
                ('Result Name', self.scenario_info.get('result_name', 'N/A')),
                ('Product', self.scenario_info.get('product', 'N/A')),
                ('Version', self.scenario_info.get('version', 'N/A')),
                ('Scenario Type', self.scenario_info.get('scenario_type', 'N/A')),
                ('Mode', self.scenario_info.get('mode', 'N/A')),
                ('Start Time', str(self.scenario_info.get('start_time', 'N/A'))),
                ('Stop Time', str(self.scenario_info.get('stop_time', 'N/A'))),
                ('Duration (seconds)', self.scenario_info.get('duration_seconds', 'N/A')),
                ('Steady State Duration (seconds)', self.steady_state_duration),
                ('Steady State From (seconds)', format_seconds_to_hhmmss(self.steady_state_from_rel) if self.steady_state_from_rel >= 0 else 'N/A'),
                ('Steady State To (seconds)', format_seconds_to_hhmmss(self.steady_state_to_rel) if self.steady_state_to_rel >= 0 else 'N/A'),
                ('User Count (Max Vusers)', self.max_vusers),
            ]
            
            for row, (prop, value) in enumerate(info_data, 2):
                cell_prop = ws_info.cell(row=row, column=1, value=prop)
                cell_val = ws_info.cell(row=row, column=2, value=value)
                apply_cell_style(cell_prop)
                apply_cell_style(cell_val)
        
        ws_info.column_dimensions['A'].width = 30
        ws_info.column_dimensions['B'].width = 50
        
        # Transaction Summary sheet
        if should_include('transaction_summary'):
            ws_summary = wb.create_sheet('Transaction Summary')
            sheets_created.append('Transaction Summary')
            
            # Add SS Duration and User Count at top right (yellow highlight)
            yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
            
            ss_minutes = round(self.steady_state_duration / 60, 2) if self.steady_state_duration > 0 else 0
            ss_from = self.steady_state_from_rel if self.steady_state_from_rel >= 0 else 0
            ss_to = self.steady_state_to_rel if self.steady_state_to_rel >= 0 else 0
            
            # Display SS timings and User Count
            # User Count shown here is the TOTAL across all controllers
            # (sum of each controller's max_vusers) for multi-controller runs,
            # or the single controller's max_vusers otherwise.
            ss_label = ws_summary.cell(row=1, column=11, value='SS Duration:')
            ss_value = ws_summary.cell(row=1, column=12, value=f'{ss_minutes} min ({ss_from}s to {ss_to}s)')
            vu_label = ws_summary.cell(row=2, column=11, value='User Count:')
            vu_value = ws_summary.cell(row=2, column=12, value=f'{self._get_total_users_for_report()}')
            
            for cell in [ss_label, ss_value, vu_label, vu_value]:
                cell.fill = yellow_fill
                cell.font = Font(bold=True)
                cell.border = border
            
            ws_summary.column_dimensions['K'].width = 12
            ws_summary.column_dimensions['L'].width = 25
            
            # Headers with Script column for pivot table support
            summary_headers = [
                'Script', 'Transaction Name', 'Minimum', 'Average', 'Maximum',
                'Std. Deviation', '95 Percent', 'Pass', 'Fail', 'Stop', 'Last Trans'
            ]
            
            for col, header in enumerate(summary_headers, 1):
                cell = ws_summary.cell(row=1, column=col, value=header)
                apply_header_style(cell)
            
            # Helper function to normalize script name variations
            # Handles cases like ITR1Online vs ITR1_Online (treats them as same)
            def normalize_script_name(name):
                """Normalize script name - add underscore between ITR+digit and Online/Offline."""
                # ITR1Online -> ITR1_Online, ITR2Online -> ITR2_Online, etc.
                # Use word boundary instead of $ to handle both standalone and prefixed cases
                # Generic normalization: Add underscore before Online/Offline if missing
                # Examples: ITR1Online -> ITR1_Online, BulkFetchOnline -> BulkFetch_Online
                normalized = re.sub(r'([a-zA-Z0-9])(Online|Offline)\b', r'\1_\2', name, flags=re.IGNORECASE)
                return normalized
            
            # Helper function to normalize full transaction name
            def normalize_trans_name(trans_name):
                """Normalize transaction name - handles ITR1Online_T01 -> ITR1_Online_T01."""
                return re.sub(r'([a-zA-Z0-9])(Online|Offline)', r'\1_\2', trans_name, flags=re.IGNORECASE)
            
            # Helper function to extract script name
            # Splits at _T followed by exactly 2 digits (e.g., _T01, _T02, _T15)
            # Examples:
            #   Bulkfetch_T01_Launch -> Bulkfetch
            #   Bulkfetch_TDS_T02_Something -> Bulkfetch_TDS
            def extract_script_name(trans_name):
                # Find _T followed by exactly 2 digits (the actual transaction marker)
                match = re.search(r'_T(\d{2})', trans_name)
                if match:
                    pos = match.start()
                    raw_name = trans_name[:pos]
                    return normalize_script_name(raw_name)
                return normalize_script_name(trans_name)
            
            # First pass: Count occurrences per script and assign sequence numbers
            script_occurrence_count = {}  # script_name -> count of transactions
            transaction_occurrence = {}   # transaction_name -> occurrence number within script
            
            # Sort transactions by script name for proper grouping
            def get_sort_key(trans):
                name = trans['transaction_name']
                script = extract_script_name(name)
                # Extract T## number for secondary sort within script
                match = re.search(r'_T(\d{2})', name)
                trans_num = int(match.group(1)) if match else 999
                return (script.lower(), trans_num)
            
            sorted_transactions = sorted(self.transaction_summary, key=get_sort_key)
            
            for trans in sorted_transactions:
                name = trans['transaction_name']
                if 'vuser_init' in name.lower() or 'vuser_end' in name.lower() or 'action' in name.lower():
                    continue
                script_name = extract_script_name(name)
                if script_name not in script_occurrence_count:
                    script_occurrence_count[script_name] = 0
                script_occurrence_count[script_name] += 1
                transaction_occurrence[name] = script_occurrence_count[script_name]
            
            current_row = 2
            for trans in sorted_transactions:
                name = trans['transaction_name']
                # Skip vuser and action transactions
                if 'vuser_init' in name.lower() or 'vuser_end' in name.lower() or 'action' in name.lower():
                    continue
                
                # Extract script name (everything before _T##)
                script_name = extract_script_name(name)
                # Get occurrence number (1, 2, 3...) for this transaction within its script
                occurrence_num = transaction_occurrence.get(name, '')
                
                # Normalize transaction name for display
                normalized_trans_name = normalize_trans_name(trans['transaction_name'])
                
                data = [
                    script_name,  # Script column (already normalized)
                    normalized_trans_name,  # Transaction Name (normalized)
                    trans['min_response_time'],
                    trans['avg_response_time'],
                    trans['max_response_time'],
                    trans['std_deviation'],
                    trans['95th_percentile'],
                    trans['pass_count'],
                    trans['fail_count'],
                    trans.get('stop_count', 0),  # Stop count (stopped transactions)
                    occurrence_num  # Last Trans: occurrence count (1, 2, 3...) within script
                ]
                for col, value in enumerate(data, 1):
                    cell = ws_summary.cell(row=current_row, column=col, value=value)
                    apply_cell_style(cell)
                current_row += 1
            
            # Auto-adjust column widths
            ws_summary.column_dimensions['A'].width = 30  # Script
            ws_summary.column_dimensions['B'].width = 60  # Transaction Name
            for col in ['C', 'D', 'E', 'F', 'G']:
                ws_summary.column_dimensions[col].width = 15
            for col in ['H', 'I', 'J', 'K']:
                ws_summary.column_dimensions[col].width = 12
        
        # TPS sheet - Now shows response time statistics in LoadRunner Analysis format
        if should_include('tps'):
            ws_tps = wb.create_sheet('TPS Report')
            sheets_created.append('TPS Report')
            
            # Add SS Duration and User Count at top right (yellow highlight)
            yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
            
            ss_minutes = round(self.steady_state_duration / 60, 2) if self.steady_state_duration > 0 else 0
            ss_label = ws_tps.cell(row=1, column=9, value='SS Duration:')
            ss_value = ws_tps.cell(row=1, column=10, value=f'{ss_minutes} min')
            vu_label = ws_tps.cell(row=2, column=10, value='User Count:')
            # Total user count across all controllers (sum) for multi-controller runs.
            vu_value = ws_tps.cell(row=2, column=11, value=f'{self._get_total_users_for_report()}')
            
            for cell in [ss_label, ss_value, vu_label, vu_value]:
                cell.fill = yellow_fill
                cell.font = Font(bold=True)
                cell.border = border
            
            ws_tps.column_dimensions['J'].width = 12
            ws_tps.column_dimensions['K'].width = 10
            
            # LoadRunner Analysis format headers with Script column for pivot support
            tps_headers = ['Script', 'Color', 'Scale', 'Measurement', 'Graph Minimum', 'Average', 'Graph Maximum', 'Graph Median', 'Graph Std. Deviation']
            
            for col, header in enumerate(tps_headers, 1):
                cell = ws_tps.cell(row=1, column=col, value=header)
                apply_header_style(cell)
            
            # Define colors to cycle through (matching LoadRunner colors)
            colors = [
                'FF0000',  # Red
                '00FF00',  # Green
                '008000',  # Dark Green
                'FFFF00',  # Yellow
                '0000FF',  # Blue
                '00FFFF',  # Cyan
                'FF00FF',  # Magenta
                'FFA500',  # Orange
                '90EE90',  # Light Green
                'FF69B4',  # Pink
            ]
            
            current_row = 2
            color_idx = 0
            
            # Sort by script name and transaction number for proper grouping
            def get_tps_sort_key(item):
                trans_name = item[0]
                # Extract script name (everything before _T##)
                match = re.search(r'_T(\d{2})', trans_name)
                if match:
                    script = trans_name[:match.start()]
                    trans_num = int(match.group(1))
                else:
                    script = trans_name
                    trans_num = 999
                # Normalize for sorting (ITR1Online -> ITR1_Online)
                script = re.sub(r'([a-zA-Z0-9])(Online|Offline)\b', r'\1_\2', script, flags=re.IGNORECASE)
                return (script.lower(), trans_num)
            
            sorted_response_times = sorted(self.response_times.items(), key=get_tps_sort_key)
            
            # Iterate through response_times to get TPS statistics for Pass transactions
            for trans_name, data in sorted_response_times:
                # Skip vuser and action transactions
                if 'vuser_init' in trans_name.lower() or 'vuser_end' in trans_name.lower() or 'action' in trans_name.lower():
                    continue
                
                # Use TPS values from the TPS graph if available, else fall back to response times
                tps_values = data.get('tps_values', [])
                times = data.get('times', [])
                
                # Prefer TPS values, fall back to times
                if tps_values:
                    values = tps_values
                elif times:
                    values = times
                else:
                    continue
                
                # Calculate TPS statistics (using population std dev to match LoadRunner)
                min_val = min(values)
                # Use pre-calculated avg_tps (total count / duration) to match LoadRunner
                avg_val = data.get('avg_tps', sum(values) / len(values))
                max_val = max(values)
                median_val = statistics.median(values)
                # Population std dev (divide by n, not n-1) to match LoadRunner
                mean_for_std = sum(values) / len(values)
                if len(values) > 1:
                    variance = sum((t - mean_for_std) ** 2 for t in values) / len(values)
                    std_dev = math.sqrt(variance)
                else:
                    std_dev = 0.0
                
                # Extract script name (everything before _T## - T followed by 2 digits)
                match = re.search(r'_T\d{2}', trans_name)
                script_name = trans_name[:match.start()] if match else trans_name
                # Normalize script name (e.g., ITR1Online -> ITR1_Online)
                script_name = re.sub(r'([a-zA-Z0-9])(Online|Offline)\b', r'\1_\2', script_name, flags=re.IGNORECASE)
                
                # Add :Pass suffix for display and normalize the transaction name
                normalized_trans = re.sub(r'([a-zA-Z0-9])(Online|Offline)', r'\1_\2', trans_name, flags=re.IGNORECASE)
                display_name = f"{normalized_trans}:Pass"
                
                # Color cell with fill
                color_fill = PatternFill(start_color=colors[color_idx % len(colors)], 
                                        end_color=colors[color_idx % len(colors)], 
                                        fill_type='solid')
                
                row_data = [
                    script_name,  # Script column for pivot support
                    '',  # Color placeholder (we'll fill the cell instead)
                    1,   # Scale is always 1
                    display_name,
                    round(min_val, 3),
                    round(avg_val, 3),
                    round(max_val, 3),
                    round(median_val, 3),
                    round(std_dev, 3)
                ]
                
                for col, value in enumerate(row_data, 1):
                    cell = ws_tps.cell(row=current_row, column=col, value=value)
                    apply_cell_style(cell)
                    if col == 2:  # Color column - fill with color
                        cell.fill = color_fill
                
                current_row += 1
                color_idx += 1
            
            ws_tps.column_dimensions['A'].width = 30  # Script
            ws_tps.column_dimensions['B'].width = 8   # Color
            ws_tps.column_dimensions['C'].width = 8   # Scale
            ws_tps.column_dimensions['D'].width = 55  # Measurement
            ws_tps.column_dimensions['E'].width = 15  # Graph Minimum
            ws_tps.column_dimensions['F'].width = 12  # Average
            ws_tps.column_dimensions['G'].width = 15  # Graph Maximum
            ws_tps.column_dimensions['H'].width = 15  # Graph Median
            ws_tps.column_dimensions['I'].width = 18  # Graph Std. Deviation
        
        # TPS_Main sheet - Shows only the Last_Trans/Logout transactions in LoadRunner Analysis format
        if should_include('tps_main'):
            ws_tps_main = wb.create_sheet('TPS_Main')
            sheets_created.append('TPS_Main')
            
            # Add SS Duration and User Count at top right (yellow highlight)
            yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
            
            ss_minutes = round(self.steady_state_duration / 60, 2) if self.steady_state_duration > 0 else 0
            ss_label = ws_tps_main.cell(row=1, column=10, value='SS Duration:')
            ss_value = ws_tps_main.cell(row=1, column=11, value=f'{ss_minutes} min')
            vu_label = ws_tps_main.cell(row=2, column=10, value='User Count:')
            # Total user count across all controllers (sum) for multi-controller runs.
            vu_value = ws_tps_main.cell(row=2, column=11, value=f'{self._get_total_users_for_report()}')
            
            for cell in [ss_label, ss_value, vu_label, vu_value]:
                cell.fill = yellow_fill
                cell.font = Font(bold=True)
                cell.border = border
            
            ws_tps_main.column_dimensions['J'].width = 12
            ws_tps_main.column_dimensions['K'].width = 10
            
            # LoadRunner Analysis format headers with Script column
            tps_main_headers = ['Script', 'Color', 'Scale', 'Measurement', 'Graph Minimum', 'Average', 'Graph Maximum', 'Graph Median', 'Graph Std. Deviation']
            
            for col, header in enumerate(tps_main_headers, 1):
                cell = ws_tps_main.cell(row=1, column=col, value=header)
                apply_header_style(cell)
            
            # Define colors to cycle through (matching LoadRunner colors) - 16 colors for up to 16 scripts
            colors = [
                'FF0000',  # Red
                '00FF00',  # Green
                '008000',  # Dark Green
                'FFFF00',  # Yellow
                '0000FF',  # Blue
                '00FFFF',  # Cyan
                'FF00FF',  # Magenta
                'FFA500',  # Orange
                '90EE90',  # Light Green
                'FF69B4',  # Pink
                '800080',  # Purple
                '4169E1',  # Royal Blue
                'FFD700',  # Gold
                '8B4513',  # Saddle Brown
                '20B2AA',  # Light Sea Green
                'DC143C',  # Crimson
            ]
            
            # Automatically find the LAST transaction of each script
            # Priority order:
            # 1. Transactions with Last_Trans/Logout_Last_Trans pattern (highest T##)
            # 2. Fallback: Highest T## transaction per script
            current_row = 2
            color_idx = 0
            
            # Pattern to match last transaction variants (case-insensitive):
            # Last_Trans, LastTrans, last_trans, Logout_Last_Trans, Select_Logout_Last_Trans, etc.
            # Match anywhere in the name, not just at the end (handles _Select_Logout_Last_Trans)
            last_trans_pattern = re.compile(r'(last_?trans|logout.*last_?trans)', re.IGNORECASE)
            
            # Step 1: Collect all transactions grouped by script
            script_all_trans = {}  # base_script -> [(trans_name, t_num, data, is_last_trans), ...]
            
            for trans_name, data in self.response_times.items():
                name_lower = trans_name.lower()
                
                # Skip vuser and standalone action transactions
                if 'vuser_init' in name_lower or 'vuser_end' in name_lower:
                    continue
                if name_lower == 'action' or name_lower.endswith(':action'):
                    continue
                
                # Check for TPS values or response times
                tps_values = data.get('tps_values', [])
                times = data.get('times', [])
                if not tps_values and not times:
                    continue
                
                # Extract script prefix and T## number
                match = re.search(r'_T(\d{2})', trans_name)
                if match:
                    t_num = int(match.group(1))
                    full_prefix = trans_name[:match.start()]
                    
                    # Remove Action# suffix if present
                    action_match = re.search(r'_Action\d+$', full_prefix, re.IGNORECASE)
                    if action_match:
                        base_script = full_prefix[:action_match.start()]
                    else:
                        base_script = full_prefix
                    
                    # Normalize script name
                    base_script = re.sub(r'([a-zA-Z0-9])(Online|Offline)\b', r'\1_\2', base_script, flags=re.IGNORECASE)
                    
                    # Check if this is a "last transaction" pattern
                    is_last_trans = bool(last_trans_pattern.search(trans_name))
                    
                    if base_script not in script_all_trans:
                        script_all_trans[base_script] = []
                    script_all_trans[base_script].append((trans_name, t_num, data, is_last_trans))
            
            # Step 2: For each script, select the best "last" transaction
            script_last_trans = {}  # base_script -> (trans_name, data)
            
            for base_script, trans_list in script_all_trans.items():
                # First try: Find Last_Trans transactions and pick highest T##
                last_trans_only = [(name, t_num, data) for name, t_num, data, is_last in trans_list if is_last]
                
                if last_trans_only:
                    # Pick the one with highest T## number
                    best = max(last_trans_only, key=lambda x: x[1])
                    script_last_trans[base_script] = (best[0], best[2])
                else:
                    # Fallback: No Last_Trans found, use highest T## transaction
                    best = max(trans_list, key=lambda x: x[1])
                    script_last_trans[base_script] = (best[0], best[2])
            
            # Step 3: Write the last transaction of each script
            for base_script in sorted(script_last_trans.keys()):
                trans_name, data = script_last_trans[base_script]
                # Use TPS values from the TPS graph if available, else fall back to response times
                tps_values = data.get('tps_values', [])
                times = data.get('times', [])
                
                # Prefer TPS values, fall back to times
                if tps_values:
                    values = tps_values
                elif times:
                    values = times
                else:
                    continue
                
                # Calculate TPS statistics (using population std dev to match LoadRunner)
                min_val = min(values)
                # Use pre-calculated avg_tps (total count / duration) to match LoadRunner
                avg_val = data.get('avg_tps', sum(values) / len(values))
                max_val = max(values)
                median_val = statistics.median(values)
                # Population std dev (divide by n, not n-1) to match LoadRunner
                mean_for_std = sum(values) / len(values)
                if len(values) > 1:
                    variance = sum((t - mean_for_std) ** 2 for t in values) / len(values)
                    std_dev = math.sqrt(variance)
                else:
                    std_dev = 0.0
                
                # Add :Pass suffix for display and normalize the transaction name
                # Normalize Script1Online -> Script1_Online in the display name
                normalized_trans = re.sub(r'([a-zA-Z0-9])(Online|Offline)', r'\1_\2', trans_name, flags=re.IGNORECASE)
                display_name = f"{normalized_trans}:Pass"
                
                # Color cell with fill
                color_fill = PatternFill(start_color=colors[color_idx % len(colors)], 
                                        end_color=colors[color_idx % len(colors)], 
                                        fill_type='solid')
                
                row_data = [
                    base_script,  # Script column for pivot support (base script name)
                    '',  # Color placeholder
                    1,   # Scale is always 1
                    display_name,
                    round(min_val, 3),
                    round(avg_val, 3),
                    round(max_val, 3),
                    round(median_val, 3),
                    round(std_dev, 3)
                ]
                
                for col, value in enumerate(row_data, 1):
                    cell = ws_tps_main.cell(row=current_row, column=col, value=value)
                    apply_cell_style(cell)
                    if col == 2:  # Color column - fill with color
                        cell.fill = color_fill
                
                current_row += 1
                color_idx += 1
            
            if current_row == 2:  # No data written
                cell = ws_tps_main.cell(row=2, column=1, value='No transactions found')
                apply_cell_style(cell)
            
            ws_tps_main.column_dimensions['A'].width = 30  # Script
            ws_tps_main.column_dimensions['B'].width = 8   # Color
            ws_tps_main.column_dimensions['C'].width = 8   # Scale
            ws_tps_main.column_dimensions['D'].width = 55  # Measurement
            ws_tps_main.column_dimensions['E'].width = 15  # Graph Minimum
            ws_tps_main.column_dimensions['F'].width = 12  # Average
            ws_tps_main.column_dimensions['G'].width = 15  # Graph Maximum
            ws_tps_main.column_dimensions['H'].width = 15  # Graph Median
            ws_tps_main.column_dimensions['I'].width = 18  # Graph Std. Deviation
        
        # Target_TPS sheet - Shows all Target TPS values (BO and FO)
        # This sheet reflects the values from Target TPS button and can be used for reference
        if should_include('all') or should_include('tps') or should_include('tps_main'):
            ws_target = wb.create_sheet('Target_TPS')
            sheets_created.append('Target_TPS')
            
            # Build combined Target TPS lookup
            combined_tps = {}
            combined_tps.update(TARGET_TPS_LOOKUP)
            if custom_target_tps:
                combined_tps.update(custom_target_tps)
            
            # Headers
            target_headers = ['SL No', 'Script Name', 'Category', 'Target TPS', 'Source']
            header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
            
            for col, header in enumerate(target_headers, 1):
                cell = ws_target.cell(row=1, column=col, value=header)
                cell.font = Font(bold=True, color='FFFFFF')
                cell.fill = header_fill
                cell.border = border
                cell.alignment = Alignment(horizontal='center')
            
            # Separate BO and FO scripts - preserve original order from TARGET_TPS_LOOKUP
            bo_scripts = []
            fo_scripts = []
            processed_scripts = set()
            
            # First, process scripts in TARGET_TPS_LOOKUP order
            for script_name in TARGET_TPS_LOOKUP.keys():
                if script_name in combined_tps:
                    tps_value = combined_tps[script_name]
                    source = 'Custom' if custom_target_tps and script_name in custom_target_tps else 'Built-in'
                    processed_scripts.add(script_name)
                    # Check custom categories first, then fall back to BO_USECASES
                    if self._custom_script_categories and script_name in self._custom_script_categories:
                        category = self._custom_script_categories[script_name]
                        if category == 'BO':
                            bo_scripts.append((script_name, tps_value, 'BO', source))
                        else:
                            fo_scripts.append((script_name, tps_value, 'FO', source))
                    elif script_name in BO_USECASES:
                        bo_scripts.append((script_name, tps_value, 'BO', source))
                    else:
                        fo_scripts.append((script_name, tps_value, 'FO', source))
            
            # Then add any custom scripts not in TARGET_TPS_LOOKUP (in their custom order)
            if custom_target_tps:
                for script_name, tps_value in custom_target_tps.items():
                    if script_name not in processed_scripts:
                        source = 'Custom'
                        if self._custom_script_categories and script_name in self._custom_script_categories:
                            category = self._custom_script_categories[script_name]
                            if category == 'BO':
                                bo_scripts.append((script_name, tps_value, 'BO', source))
                            else:
                                fo_scripts.append((script_name, tps_value, 'FO', source))
                        else:
                            fo_scripts.append((script_name, tps_value, 'FO', source))
            
            # Write BO section header
            current_row = 2
            bo_header_fill = PatternFill(start_color='FFC000', end_color='FFC000', fill_type='solid')  # Orange for BO
            ws_target.merge_cells(f'A{current_row}:E{current_row}')
            bo_section = ws_target.cell(row=current_row, column=1, value=f'BACK OFFICE USECASES ({len(bo_scripts)} scripts)')
            bo_section.font = Font(bold=True, size=11)
            bo_section.fill = bo_header_fill
            bo_section.border = border
            current_row += 1
            
            # Write BO scripts
            bo_fill = PatternFill(start_color='FFF2CC', end_color='FFF2CC', fill_type='solid')  # Light orange
            for idx, (script_name, tps_value, category, source) in enumerate(bo_scripts, 1):
                ws_target.cell(row=current_row, column=1, value=idx).border = border
                ws_target.cell(row=current_row, column=2, value=script_name).border = border
                ws_target.cell(row=current_row, column=3, value=category).border = border
                cell_tps = ws_target.cell(row=current_row, column=4, value=tps_value)
                cell_tps.border = border
                cell_tps.number_format = '0.00'
                ws_target.cell(row=current_row, column=5, value=source).border = border
                # Apply light fill
                for col in range(1, 6):
                    ws_target.cell(row=current_row, column=col).fill = bo_fill
                current_row += 1
            
            # Empty row between sections
            current_row += 1
            
            # Write FO section header
            fo_header_fill = PatternFill(start_color='5B9BD5', end_color='5B9BD5', fill_type='solid')  # Blue for FO
            ws_target.merge_cells(f'A{current_row}:E{current_row}')
            fo_section = ws_target.cell(row=current_row, column=1, value=f'FRONTEND USECASES ({len(fo_scripts)} scripts)')
            fo_section.font = Font(bold=True, size=11, color='FFFFFF')
            fo_section.fill = fo_header_fill
            fo_section.border = border
            current_row += 1
            
            # Write FO scripts
            fo_fill = PatternFill(start_color='DEEBF7', end_color='DEEBF7', fill_type='solid')  # Light blue
            for idx, (script_name, tps_value, category, source) in enumerate(fo_scripts, 1):
                ws_target.cell(row=current_row, column=1, value=idx).border = border
                ws_target.cell(row=current_row, column=2, value=script_name).border = border
                ws_target.cell(row=current_row, column=3, value=category).border = border
                cell_tps = ws_target.cell(row=current_row, column=4, value=tps_value)
                cell_tps.border = border
                cell_tps.number_format = '0.00'
                ws_target.cell(row=current_row, column=5, value=source).border = border
                # Apply light fill
                for col in range(1, 6):
                    ws_target.cell(row=current_row, column=col).fill = fo_fill
                current_row += 1
            
            # Set column widths
            ws_target.column_dimensions['A'].width = 8   # SL No
            ws_target.column_dimensions['B'].width = 60  # Script Name
            ws_target.column_dimensions['C'].width = 12  # Category
            ws_target.column_dimensions['D'].width = 12  # Target TPS
            ws_target.column_dimensions['E'].width = 12  # Source
        
        # Errors sheet - LoadRunner Analysis format with Color, Scale, Measurement, Value (Steady State Only)
        if should_include('errors'):
            ws_errors = wb.create_sheet('Errors (SS Only)')
            sheets_created.append('Errors (SS Only)')
            
            # LoadRunner Analysis style headers
            error_headers = ['Color', 'Scale', 'Measurement', 'Value']
            
            for col, header in enumerate(error_headers, 1):
                cell = ws_errors.cell(row=1, column=col, value=header)
                apply_header_style(cell)
            
            if self.errors:
                # Sort by count descending
                sorted_errors = sorted(self.errors, key=lambda x: x.get('error_count', 0), reverse=True)
                
                # Colors for error rows (matching LoadRunner Analysis)
                colors = [
                    'FF0000',  # Red
                    '00AA00',  # Green
                    'FFCC00',  # Yellow/Orange
                    '0066CC',  # Blue
                    '00CCCC',  # Cyan
                    'CC6600',  # Brown/Orange
                    'FF6600',  # Orange
                    'FFFF00',  # Yellow
                    '9900CC',  # Purple
                    '009999',  # Teal
                    'CC0066',  # Pink
                    '666666',  # Gray
                ]
                
                current_row = 2
                for idx, error in enumerate(sorted_errors):
                    # Get the original measurement name (full LoadRunner format)
                    measurement = error.get('original_measurement', '')
                    if not measurement:
                        # Reconstruct from parts if original not available
                        measurement = error.get('error_location', error.get('error_description', ''))
                    
                    count = error.get('error_count', 0)
                    
                    # Color fill for this row
                    color_fill = PatternFill(start_color=colors[idx % len(colors)], 
                                            end_color=colors[idx % len(colors)], 
                                            fill_type='solid')
                    
                    row_data = [
                        '',           # Color placeholder (filled with color)
                        1,            # Scale is always 1
                        measurement,  # Full error measurement string
                        float(count)  # Value as float like LoadRunner shows
                    ]
                    
                    for col, value in enumerate(row_data, 1):
                        cell = ws_errors.cell(row=current_row, column=col, value=value)
                        apply_cell_style(cell)
                        if col == 1:  # Color column - fill with color
                            cell.fill = color_fill
                    
                    current_row += 1
            else:
                cell = ws_errors.cell(row=2, column=1, value='No errors recorded')
                apply_cell_style(cell)
            
            ws_errors.column_dimensions['A'].width = 8   # Color
            ws_errors.column_dimensions['B'].width = 8   # Scale
            ws_errors.column_dimensions['C'].width = 120  # Measurement (wide for full error text)
            ws_errors.column_dimensions['D'].width = 12  # Value
        
        # API Errors sheet - REMOVED for performance
        # Parsing vuser logs is time consuming and this tab was removed per user request
        
        # HTTP Statistics sheet - REMOVED (data in sum_data files is incomplete)
        # The sum_data graph files only contain partial HTTP statistics data
        # Full HTTP stats require parsing the proprietary RawData.eve binary format
        
        # Slow Transactions sheet - Transactions with 95th percentile >= 2 seconds
        # Now includes related API details from the same script
        if should_include('tps'):
            ws_slow = wb.create_sheet('Slow Transactions')
            sheets_created.append('Slow Transactions')
            
            # Headers
            slow_headers = ['Transaction Name', 'Min (sec)', 'Avg (sec)', 'Max (sec)', 
                           '95th Pctl', 'Std Dev', 'Pass Count', 'Fail Count', 'TPS', 'Status']
            
            for col, header in enumerate(slow_headers, 1):
                cell = ws_slow.cell(row=1, column=col, value=header)
                apply_header_style(cell)
            
            # Threshold for slow transactions (2 seconds)
            slow_threshold = 2.0
            
            # Find slow transactions - use correct field name '95th_percentile'
            slow_transactions = []
            for trans in self.transaction_summary:
                name = trans.get('transaction_name', '')
                # Skip vuser and action transactions
                if 'vuser_init' in name.lower() or 'vuser_end' in name.lower() or 'action' in name.lower():
                    continue
                pct_95 = trans.get('95th_percentile', 0) or 0
                
                # Check if 95th percentile >= threshold
                if pct_95 >= slow_threshold:
                    slow_transactions.append(trans)
            
            # Sort by 95th percentile descending
            slow_transactions.sort(key=lambda x: x.get('95th_percentile', 0) or 0, reverse=True)
            
            if slow_transactions:
                # Add summary row
                summary_cell = ws_slow.cell(row=2, column=1, 
                    value=f"Found {len(slow_transactions)} transactions with 95th percentile >= {slow_threshold} sec (with API call details)")
                summary_cell.font = Font(bold=True, color='C00000')
                ws_slow.merge_cells(start_row=2, start_column=1, end_row=2, end_column=10)
                
                current_row = 4  # Start data after summary
                
                # Red fill for critical slow (>= 5 sec), yellow for slow (>= 2 sec)
                red_fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
                yellow_fill = PatternFill(start_color='FFEB9C', end_color='FFEB9C', fill_type='solid')
                light_blue_fill = PatternFill(start_color='DAEEF3', end_color='DAEEF3', fill_type='solid')
                
                for trans in slow_transactions:
                    name = trans.get('transaction_name', '')
                    
                    # Get 95th percentile using correct field name
                    pct_95 = trans.get('95th_percentile', 0) or 0
                    
                    # Determine status
                    if pct_95 >= 5.0:
                        status = "CRITICAL"
                        row_fill = red_fill
                    elif pct_95 >= 3.0:
                        status = "HIGH"
                        row_fill = PatternFill(start_color='FFCC99', end_color='FFCC99', fill_type='solid')
                    else:
                        status = "WARNING"
                        row_fill = yellow_fill
                    
                    row_data = [
                        name,
                        round(trans.get('min_response_time', 0) or 0, 3),
                        round(trans.get('avg_response_time', 0) or 0, 3),
                        round(trans.get('max_response_time', 0) or 0, 3),
                        round(pct_95, 3),
                        round(trans.get('std_deviation', 0) or 0, 3),
                        trans.get('pass_count', 0),
                        trans.get('fail_count', 0),
                        round(trans.get('tps', 0) or 0, 4),
                        status
                    ]
                    
                    for col, value in enumerate(row_data, 1):
                        cell = ws_slow.cell(row=current_row, column=col, value=value)
                        apply_cell_style(cell)
                        # Highlight 95th percentile column if >= threshold
                        if col == 5 and pct_95 >= slow_threshold:
                            cell.fill = row_fill
                        elif col == 10:  # Status column
                            cell.fill = row_fill
                            cell.font = Font(bold=True)
                    
                    current_row += 1
                    
                    # Find API details for this transaction
                    # First: Check if we have script-parsed API calls (from auto-discovery or manual script folder)
                    # Second: Fall back to error logs if scripts weren't accessible
                    
                    matched_apis = []
                    api_source = ''  # Track where API data came from
                    
                    # Check if transaction exists in script-parsed API calls
                    # Use flexible matching: exact match first, then normalized match
                    matched_trans_name = None
                    if self.transaction_api_calls:
                        # Try exact match first
                        if name in self.transaction_api_calls:
                            matched_trans_name = name
                        else:
                            # Try normalized matching (case-insensitive, ignore underscores)
                            name_normalized = name.lower().replace('_', '').replace(' ', '')
                            for script_trans in self.transaction_api_calls.keys():
                                script_normalized = script_trans.lower().replace('_', '').replace(' ', '')
                                if name_normalized == script_normalized:
                                    matched_trans_name = script_trans
                                    break
                                # Also try partial match (e.g., "ITR1_Online_T18" matches "ITR1Online_T18")
                                # Extract transaction number pattern like T01, T02, T18 etc
                                name_match = re.search(r't(\d+)', name_normalized)
                                script_match = re.search(r't(\d+)', script_normalized)
                                if name_match and script_match and name_match.group(1) == script_match.group(1):
                                    # Same transaction number - check if same script type
                                    name_type = re.search(r'(itr\d+).*?(online|offline)', name_normalized)
                                    script_type = re.search(r'(itr\d+).*?(online|offline)', script_normalized)
                                    if name_type and script_type:
                                        if name_type.group(1) == script_type.group(1) and name_type.group(2) == script_type.group(2):
                                            matched_trans_name = script_trans
                                            break
                    
                    if matched_trans_name:
                        api_source = 'script'
                        for api_call in self.transaction_api_calls[matched_trans_name]:
                            matched_apis.append({
                                'service_name': api_call.get('service_name', ''),
                                'method': api_call.get('method', ''),
                                'api_endpoint': api_call.get('api_endpoint', ''),
                                'full_url': api_call.get('full_url', ''),
                                'headers': api_call.get('headers', []),
                            })
                    
                    # Fallback: Use error logs matched by ITR type and mode
                    if not matched_apis:
                        api_source = 'error_logs'
                        trans_lower = name.lower()
                        itr_match = re.search(r'(itr\d+)', trans_lower)
                        itr_type = itr_match.group(1) if itr_match else ''
                        is_online = 'online' in trans_lower
                        is_offline = 'offline' in trans_lower
                        
                        seen_endpoints = set()
                        for api_error in self.api_errors:
                            script_lower = api_error.get('script', '').lower()
                            if itr_type and itr_type in script_lower:
                                script_online = 'online' in script_lower
                                script_offline = 'offline' in script_lower
                                if (is_online and script_online) or (is_offline and script_offline) or (not is_online and not is_offline):
                                    endpoint = api_error.get('api_endpoint', '')
                                    full_url = api_error.get('api_url', '')
                                    if endpoint and endpoint not in seen_endpoints:
                                        seen_endpoints.add(endpoint)
                                        # Extract Service Name from URL path
                                        path_parts = [p for p in endpoint.split('/') if p]
                                        service_name = ''
                                        if len(path_parts) >= 2:
                                            service_name = path_parts[1]
                                        elif len(path_parts) == 1:
                                            service_name = path_parts[0]
                                        
                                        matched_apis.append({
                                            'service_name': service_name,
                                            'method': '',
                                            'api_endpoint': endpoint,
                                            'full_url': full_url,
                                        })
                    
                    # Add API details sub-section
                    if matched_apis:
                        current_row += 1
                        source_label = "from scripts" if api_source == 'script' else "from error logs"
                        api_header_cell = ws_slow.cell(row=current_row, column=1, 
                            value=f"    └── API Details ({len(matched_apis)} {source_label}):")
                        api_header_cell.font = Font(bold=True, italic=True, size=10)
                        api_header_cell.fill = light_blue_fill
                        ws_slow.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=10)
                        current_row += 1
                        
                        # Headers: Service Name, Method (if from script), API Endpoint, Headers
                        if api_source == 'script':
                            api_sub_headers = ['', 'Service Name', 'Method', 'API Endpoint', 'Headers', '', '', '', '', '']
                        else:
                            api_sub_headers = ['', 'Service Name', 'API Endpoint', 'Full URL', '', '', '', '', '', '']
                        for col, header in enumerate(api_sub_headers, 1):
                            if header:
                                cell = ws_slow.cell(row=current_row, column=col, value=header)
                                cell.font = Font(bold=True, size=9)
                                cell.fill = light_blue_fill
                        current_row += 1
                        
                        for api_call in matched_apis:
                            # Format headers as "Name: Value; Name2: Value2"
                            headers_list = api_call.get('headers', [])
                            if headers_list:
                                headers_str = '; '.join([f"{h.get('name', '')}: {h.get('value', '')}" for h in headers_list])
                            else:
                                headers_str = '-'
                            
                            if api_source == 'script':
                                api_row = [
                                    '    →',
                                    api_call.get('service_name', ''),
                                    api_call.get('method', ''),
                                    api_call.get('api_endpoint', ''),
                                    headers_str,
                                ]
                            else:
                                api_row = [
                                    '    →',
                                    api_call.get('service_name', ''),
                                    api_call.get('api_endpoint', ''),
                                    api_call.get('full_url', ''),
                                ]
                            for col, value in enumerate(api_row, 1):
                                cell = ws_slow.cell(row=current_row, column=col, value=value)
                                cell.font = Font(size=9)
                                cell.fill = light_blue_fill
                            current_row += 1
                            
                            # If headers exist and from script, show Full URL on next row
                            if api_source == 'script' and api_call.get('full_url'):
                                url_cell = ws_slow.cell(row=current_row, column=2, value=f"URL: {api_call.get('full_url', '')}")
                                url_cell.font = Font(size=8, italic=True, color='666666')
                                ws_slow.merge_cells(start_row=current_row, start_column=2, end_row=current_row, end_column=10)
                                current_row += 1
                        
                        current_row += 1  # Extra space after API section
                    
                    current_row += 1  # Space between slow transactions
                
                # Add note based on data source
                current_row += 1
                has_script_data = bool(self.transaction_api_calls)
                if has_script_data:
                    note_text = "Note: API details extracted from LoadRunner script files (web_submit_data, web_url, web_custom_request)."
                else:
                    note_text = "Note: API details extracted from VUser error logs. For complete API coverage, run report on the controller machine where scripts are accessible."
                note_cell = ws_slow.cell(row=current_row, column=1, value=note_text)
                note_cell.font = Font(italic=True, color='666666')
                ws_slow.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=10)
            else:
                cell = ws_slow.cell(row=2, column=1, 
                    value=f"No transactions found with 95th percentile >= {slow_threshold} sec")
                cell.font = Font(color='006600')
                apply_cell_style(cell)
            
            ws_slow.column_dimensions['A'].width = 55   # Transaction Name / Arrow
            ws_slow.column_dimensions['B'].width = 25   # Min / Service Name
            ws_slow.column_dimensions['C'].width = 12   # Avg / Method
            ws_slow.column_dimensions['D'].width = 40   # Max / API Endpoint
            ws_slow.column_dimensions['E'].width = 60   # 95th / Headers
            ws_slow.column_dimensions['F'].width = 12   # Std Dev
            ws_slow.column_dimensions['G'].width = 12   # Pass Count
            ws_slow.column_dimensions['H'].width = 12   # Fail Count
            ws_slow.column_dimensions['I'].width = 10   # TPS
            ws_slow.column_dimensions['J'].width = 12   # Status
        
        # FinalReport sheet - Script-level summary with target vs achieved TPS (one row per script)
        if should_include('all'):
            # Build combined Target TPS lookup: user-provided (from UI button) + built-in fallback
            combined_tps_lookup = {}
            # First add built-in values
            combined_tps_lookup.update(TARGET_TPS_LOOKUP)
            # Then override with user-provided values (from Target TPS button)
            if custom_target_tps:
                combined_tps_lookup.update(custom_target_tps)

            # -----------------------------------------------------------
            # WLM (Workload Model) workbook: authoritative source when
            # present. See load_wlm_workbook() docstring for structure.
            # Resolution:
            #   1. explicit wlm_workbook_path arg
            #   2. env var LRR_WLM_WORKBOOK
            #   3. TargetTPS_Presets/Final_WLM_2026_2027.xlsx (auto)
            # If nothing found, wlm_data stays None and the writer takes
            # the legacy TARGET_TPS_LOOKUP path below.
            # -----------------------------------------------------------
            wlm_search_roots = []
            try:
                wlm_search_roots.append(os.path.dirname(os.path.abspath(__file__)))
            except NameError:
                pass
            if output_path:
                wlm_search_roots.append(os.path.dirname(os.path.abspath(output_path)))
            resolved_wlm_path = resolve_wlm_workbook_path(
                explicit_path=wlm_workbook_path,
                search_roots=wlm_search_roots,
            )
            wlm_data = load_wlm_workbook(resolved_wlm_path) if resolved_wlm_path else None
            # WLM entries that got a matched LR script (used for validation sheet).
            # NOTE: multiple LR scripts may match the same WLM display name
            # (e.g. legacy "FORM26Q" + new "Form26Q" both match "Form 26Q :
            # TDS returns Filing -1961 ACT"). We keep ALL of them so they
            # can be emitted consecutively at that WLM row's position,
            # preserving the WLM 26-27 order for every LR script instead
            # of dumping duplicates into the unmatched tail.
            wlm_match_map = {}          # wlm_display_name -> [script_key, ...]
            unmatched_lr_scripts = []    # LR script_keys with no WLM match
            if wlm_data:
                print(f"[WLM] Using {resolved_wlm_path}")
                print(f"[WLM]   FO usecases: {len(wlm_data['fo_entries'])}, "
                      f"BO usecases: {len(wlm_data['bo_entries'])}")
                # WLM TPS values take precedence over legacy lookup so that
                # find_target_tps_name() fuzzy-matches against WLM display
                # names when possible. Legacy entries remain as fallbacks
                # for unmatched LR scripts written to the UNMATCHED section.
                for _display_name, _entry in wlm_data['name_to_entry'].items():
                    if _entry['tps'] is not None:
                        combined_tps_lookup[_display_name] = _entry['tps']
            
            # Create FinalReport sheet
            ws_final = wb.create_sheet('FinalReport')
            sheets_created.append('FinalReport')
            
            # Add Steady State info at top right corner (yellow highlight)
            # For multi-controller runs use MIN across all controllers'
            # steady_state_duration - this represents the overlap window
            # during which all controllers were simultaneously in steady
            # state and is order-independent (unlike self.steady_state_duration
            # which reflects only the primary/first-loaded controller).
            ss_durations = []
            if hasattr(self, 'all_scenario_info') and self.all_scenario_info:
                ss_durations = [
                    entry.get('steady_state_duration', 0)
                    for entry in self.all_scenario_info
                    if entry.get('steady_state_duration', 0) > 0
                ]
            if ss_durations:
                effective_ss_seconds = min(ss_durations)
            else:
                effective_ss_seconds = self.steady_state_duration
            steady_state_minutes = round(effective_ss_seconds / 60, 2) if effective_ss_seconds > 0 else 0
            steady_state_label = ws_final.cell(row=1, column=13, value='Steady State:')
            steady_state_value = ws_final.cell(row=1, column=14, value=f'{steady_state_minutes} min')
            
            # Add User Count next to Steady State (yellow highlight).
            # Badge = peak concurrent VUsers during steady state
            # (max_vusers from the RunningVusers metric, or SUM of each
            # controller's max_vusers in multi-controller runs). This is
            # the "combined user count" LR itself reports and is the
            # authoritative test load figure.
            #
            # It CAN differ from SUM(J:J) because col J is the configured
            # LR VUser Group Quantity per script, and multiple LR groups
            # may have overlapping ramp/schedule windows -- so the peak
            # concurrent load can be less than the sum of all group
            # quantities. Both numbers are useful, this badge shows the
            # peak-load one.
            user_count_label = ws_final.cell(row=2, column=13, value='User Count:')
            user_count_value = ws_final.cell(row=2, column=14, value=f'{self._get_total_users_for_report()}')
            
            # Yellow highlight for steady state and user count cells
            yellow_fill = PatternFill(start_color='FFFF00', end_color='FFFF00', fill_type='solid')
            steady_state_label.fill = yellow_fill
            steady_state_value.fill = yellow_fill
            steady_state_label.font = Font(bold=True)
            steady_state_value.font = Font(bold=True)
            steady_state_label.border = border
            steady_state_value.border = border
            
            # User count with yellow highlight
            user_count_label.fill = yellow_fill
            user_count_value.fill = yellow_fill
            user_count_label.font = Font(bold=True)
            user_count_value.font = Font(bold=True)
            user_count_label.border = border
            user_count_value.border = border
            
            # ============================================================
            # CONDITIONAL FORMATTING SETTINGS (User-editable thresholds)
            # ============================================================
            settings_header_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
            settings_input_fill = PatternFill(start_color='D9EAD3', end_color='D9EAD3', fill_type='solid')  # Light green for input
            
            # Settings Section Header
            ws_final.cell(row=4, column=13, value='CONDITIONAL FORMATTING SETTINGS')
            ws_final.merge_cells(start_row=4, start_column=13, end_row=4, end_column=15)
            for col in range(13, 16):
                cell = ws_final.cell(row=4, column=col)
                cell.fill = settings_header_fill
                cell.font = Font(bold=True, color='FFFFFF')
                cell.border = border
            
            # Fail% Settings
            ws_final.cell(row=5, column=13, value='Fail% Threshold:').font = Font(bold=True)
            ws_final.cell(row=5, column=13).border = border
            fail_threshold_cell = ws_final.cell(row=5, column=14, value=1)  # Default: >= 1% is bad
            fail_threshold_cell.fill = settings_input_fill
            fail_threshold_cell.border = border
            fail_threshold_cell.alignment = Alignment(horizontal='center')
            ws_final.cell(row=5, column=15, value='% (>=Red, <Green)').font = Font(italic=True, size=9)
            ws_final.cell(row=5, column=15).border = border
            
            # TPS% Settings
            ws_final.cell(row=6, column=13, value='TPS% Threshold:').font = Font(bold=True)
            ws_final.cell(row=6, column=13).border = border
            tps_threshold_cell = ws_final.cell(row=6, column=14, value=20)  # Default: <= 20% is bad
            tps_threshold_cell.fill = settings_input_fill
            tps_threshold_cell.border = border
            tps_threshold_cell.alignment = Alignment(horizontal='center')
            ws_final.cell(row=6, column=15, value='% (>Green, <=Red)').font = Font(italic=True, size=9)
            ws_final.cell(row=6, column=15).border = border
            
            # Adj User Count % Target - user can change this value and all Adj User Count will recalculate
            # User can also manually override individual cells by typing a value directly
            ws_final.cell(row=7, column=13, value='Adj User Target%:').font = Font(bold=True)
            ws_final.cell(row=7, column=13).border = border
            adj_pct = getattr(self, '_adj_user_pct', 1.0)  # Default 100%
            adj_pct_display = int(adj_pct * 100)
            adj_target_cell = ws_final.cell(row=7, column=14, value=adj_pct_display)  # User can edit this
            adj_target_cell.fill = settings_input_fill
            adj_target_cell.border = border
            adj_target_cell.alignment = Alignment(horizontal='center')
            ws_final.cell(row=7, column=15, value='% (change to recalc all)').font = Font(italic=True, size=9)
            ws_final.cell(row=7, column=15).border = border
            
            # Instructions
            instructions_cell = ws_final.cell(row=8, column=13, value='Change N7 for all, or type value in K column')
            instructions_cell.font = Font(italic=True, color='666666', size=9)
            ws_final.merge_cells(start_row=8, start_column=13, end_row=8, end_column=15)
            
            ws_final.column_dimensions['M'].width = 20
            ws_final.column_dimensions['N'].width = 12
            ws_final.column_dimensions['O'].width = 18
            
            # Headers matching user's Excel format
            # Column K formula uses $N$7 reference cell - user can change N7 or override individual cells
            final_headers = ['Script', 'SL No', 'Description', 'Target TPS', 'Pass', 'Fail', 'Fail%', 'Achieved TPS', 'TPS %', 'User Count', 'Adjusted Usercount for the next run']
            
            for col, header in enumerate(final_headers, 1):
                cell = ws_final.cell(row=1, column=col, value=header)
                apply_header_style(cell)
            
            # Group transactions by script name (prefix before _T## - T followed by 2 digits)
            # Examples:
            #   Bulkfetch_T01_Launch -> Bulkfetch
            #   Bulkfetch_TDS_T02_Something -> Bulkfetch_TDS
            script_data = {}
            
            # Pattern to match last transaction names (same as LoadRunner Analysis filter)
            last_trans_pattern = re.compile(r'(last_?trans|logout|_last_)', re.IGNORECASE)
            
            # First pass: identify all script names from _T## transactions
            script_names = set()
            for trans in self.transaction_summary:
                name = trans['transaction_name']
                match = re.search(r'_T(\d{2})', name)
                if match:
                    script_key = name[:match.start()]
                    script_key = re.sub(r'([a-zA-Z0-9])(Online|Offline)\b', r'\1_\2', script_key, flags=re.IGNORECASE)
                    script_names.add(script_key)
            
            # Second pass: process all transactions
            for trans in self.transaction_summary:
                name = trans['transaction_name']
                # Skip vuser and action transactions
                if 'vuser_init' in name.lower() or 'vuser_end' in name.lower() or 'action' in name.lower():
                    continue
                
                # Extract script name (everything before _T## - T followed by exactly 2 digits)
                match = re.search(r'_T(\d{2})', name)
                if match:
                    script_key = name[:match.start()]
                    trans_num = int(match.group(1))
                    has_trans_num = True
                else:
                    # For transactions without _T## (Login, Password, etc.), try to find matching script
                    # by checking if any known script name is a prefix of this transaction name
                    script_key = None
                    trans_num = -1
                    has_trans_num = False
                    name_lower = name.lower()
                    for known_script in script_names:
                        if name_lower.startswith(known_script.lower()):
                            script_key = known_script
                            break
                    if not script_key:
                        # Skip if we can't match to a known script
                        continue
                
                # Check if this is a "last transaction" (Logout, Last_Trans pattern)
                is_last_trans = bool(last_trans_pattern.search(name))
                
                # Normalize script name (e.g., ITR1Online -> ITR1_Online)
                script_key = re.sub(r'([a-zA-Z0-9])(Online|Offline)\b', r'\1_\2', script_key, flags=re.IGNORECASE)
                
                if script_key not in script_data:
                    script_data[script_key] = {
                        'total_pass': 0,
                        'total_fail': 0,
                        'last_pass': 0,
                        'last_tps': 0,
                        'last_trans_num': -1,
                        'has_explicit_last': False  # Flag for Last_Trans/Logout pattern
                    }
                
                # Count ALL failures from all transactions (including Login, Password, etc.)
                script_data[script_key]['total_fail'] += trans['fail_count']
                
                # Only process _T## transactions for pass count and TPS (last transaction only)
                if not has_trans_num:
                    continue
                
                script_data[script_key]['total_pass'] += trans['pass_count']
                
                # Priority: 1) Explicit Last_Trans/Logout pattern, 2) Highest T## as fallback
                if is_last_trans:
                    # If this is first explicit last_trans or has higher T## than previous
                    if not script_data[script_key]['has_explicit_last'] or trans_num > script_data[script_key]['last_trans_num']:
                        script_data[script_key]['has_explicit_last'] = True
                        script_data[script_key]['last_trans_num'] = trans_num
                        script_data[script_key]['last_trans_name'] = name  # Store transaction name
                        script_data[script_key]['last_pass'] = trans['pass_count']
                        # Use avg_tps from TPS graph if available, else fall back to trans['tps']
                        rt = self.response_times.get(name, {})
                        if 'avg_tps' in rt:
                            script_data[script_key]['last_tps'] = rt['avg_tps']
                        else:
                            script_data[script_key]['last_tps'] = trans['tps']
                elif not script_data[script_key]['has_explicit_last']:
                    # Fallback: use highest T## only if no explicit Last_Trans found
                    if trans_num > script_data[script_key]['last_trans_num']:
                        script_data[script_key]['last_trans_num'] = trans_num
                        script_data[script_key]['last_trans_name'] = name  # Store transaction name
                        script_data[script_key]['last_pass'] = trans['pass_count']
                        # Use avg_tps from TPS graph if available, else fall back to trans['tps']
                        rt = self.response_times.get(name, {})
                        if 'avg_tps' in rt:
                            script_data[script_key]['last_tps'] = rt['avg_tps']
                        else:
                            script_data[script_key]['last_tps'] = trans['tps']
            
            # Helper function to check if script is BO usecase
            def is_bo_script(script_key):
                # Check explicit mapping first
                mapped_name = SCRIPT_NAME_MAPPING.get(script_key, script_key)
                if mapped_name in BO_USECASES:
                    return True
                # Check normalized match
                script_normalized = normalize_script_name(script_key)
                for bo_name in BO_USECASES:
                    bo_normalized = normalize_script_name(bo_name)
                    if script_normalized == bo_normalized or bo_normalized in script_normalized or script_normalized in bo_normalized:
                        return True
                return False
            
            # Helper function to find the matching Target TPS entry name for a script
            def find_target_tps_name(script_key, combined_lookup):
                """Find the full Target TPS name that matches a script key."""
                # Direct match first
                if script_key in combined_lookup:
                    return script_key
                
                # Try mapped name
                mapped_name = SCRIPT_NAME_MAPPING.get(script_key, None)
                if mapped_name and mapped_name in combined_lookup:
                    return mapped_name
                
                # Try ITR_PATTERNS matching (pattern -> canonical name)
                for pattern, canonical_name in ITR_PATTERNS.items():
                    if re.search(pattern, script_key, re.IGNORECASE):
                        if canonical_name in combined_lookup:
                            return canonical_name
                
                # Try fuzzy matching
                script_lower = script_key.lower().replace('_', '')
                
                for tps_name in combined_lookup.keys():
                    tps_lower = tps_name.lower().replace('_', '')
                    tps_clean = re.sub(r'\s*\(.*?\)', '', tps_name).lower().replace(' ', '').replace('-', '').replace('_', '')
                    
                    # Check if script key is contained in TPS name (case-insensitive)
                    if script_lower in tps_clean or tps_lower in script_lower:
                        return tps_name
                
                return script_key  # Return original if no match found
            
            # Helper function to write a script row
            def write_script_row(ws, row, sl_no, script_key, data, combined_lookup, description_name=None):
                last_pass = data['last_pass']
                total_fail = data['total_fail']
                last_tps = round(data['last_tps'], 4)
                target_tps_value = fuzzy_match_script(script_key, combined_lookup, ITR_PATTERNS)
                
                # Use provided description_name or find it
                if description_name is None:
                    description_name = find_target_tps_name(script_key, combined_lookup)
                
                # Lookup per-script vuser count if available
                script_vuser_count = ''
                
                def _safe_int(value):
                    """Convert vuser count to int safely."""
                    try:
                        return int(float(value))
                    except Exception:
                        return 0
                
                def _norm_tokens(name):
                    """Normalize a script/group name to (joined, token_starts, tokens).

                    Performed steps (in order):
                      1. Strip leading numeric/version prefix like ``38.1_`` or ``01_``.
                      2. Strip leading alpha+digit prefix like ``FO092_`` (>=3 digits
                         so genuine ids ``ITR1_``, ``ITR2_``, ``ITR4_`` are preserved).
                      3. Strip middle ``_IncomeTax`` because FinalReport rows often
                         carry it while LR group names do not.
                      4. Strip trailing version/AY/ACT/Final suffixes — including
                         ``_AY_25_26`` (underscore between AY and digits).
                      5. Split CamelCase into underscore-separated tokens.
                      6. Lowercase, collapse non-alnum to underscores, dedupe.
                      7. Token-level singular/plural: ``payments`` -> ``payment``.
                    Returns ``(joined, token_starts, tokens)``:
                      - ``joined``: lowercase alnum-only string (no underscores).
                      - ``token_starts``: set of positions in ``joined`` that mark
                        the start of a token (used for token-boundary-aware fuzzy
                        substring matching).
                      - ``tokens``: list of normalized token strings.
                    """
                    s = str(name or '').strip()
                    if not s:
                        return '', set(), []
                    # 1. leading "38.1_" / "01_"
                    s = re.sub(r'^[\d.]+[._]', '', s)
                    # 2. leading alpha+digits>=3 + underscore  (FO092_, BO123_, ...)
                    s = re.sub(r'^[a-zA-Z]+\d{3,}_', '', s)
                    # 3. middle "_IncomeTax"
                    s = re.sub(r'_IncomeTax', '', s, flags=re.IGNORECASE)
                    # 4. trailing suffixes
                    s = re.sub(
                        r'_(?:'
                        r'final|finalv?\d*|modify|modified|new|ntb|'
                        r'act\d+(?:_ay[_]?\d+_?\d*)?|'
                        r'v\d+[\w.]*|'
                        r'ay[_]?\d+_?\d*'
                        r').*$',
                        '', s, flags=re.IGNORECASE
                    )
                    # 5. CamelCase -> underscored
                    s = re.sub(r'([a-z0-9])([A-Z])', r'\1_\2', s)
                    s = re.sub(r'([A-Z])([A-Z][a-z])', r'\1_\2', s)
                    # 6. lowercase, normalize separators
                    s = s.lower()
                    s = re.sub(r'[^a-z0-9_]+', '_', s)
                    s = re.sub(r'_+', '_', s).strip('_')
                    if not s:
                        return '', set(), []
                    # 7. tokenize + singular/plural + typo canonicalization
                    #    Token-level corrections applied here are LR-data
                    #    workarounds, not display renames -- e.g. the LR
                    #    scenario ``21_Prevaliate_AY_26_27`` is a known typo
                    #    of ``Prevalidate`` in the controller setup. Mapping
                    #    the misspelled token to the canonical spelling lets
                    #    the strict-norm step match without touching the
                    #    actual LR group name (which would invalidate
                    #    historical results) or SCRIPT_NAME_MAPPING (which
                    #    drives display labels elsewhere in the report).
                    _TOKEN_CANON = {
                        'payments': 'payment',
                        'prevaliate': 'prevalidate',  # LR-scenario typo
                    }
                    tokens = []
                    for tok in s.split('_'):
                        if not tok:
                            continue
                        tok = _TOKEN_CANON.get(tok, tok)
                        tokens.append(tok)
                    if not tokens:
                        return '', set(), []
                    joined = ''.join(tokens)
                    starts = set()
                    cur = 0
                    for tok in tokens:
                        starts.add(cur)
                        cur += len(tok)
                    return joined, starts, tokens

                def _normalize_script_for_match(name):
                    """Back-compat wrapper returning only the joined alnum form."""
                    joined, _starts, _tokens = _norm_tokens(name)
                    return joined

                # --- Lookup trace plumbing (no-op when disabled) ---------
                _trace_lines = self._lookup_trace_lines
                def _trace(controller='', step='', candidate='', score='',
                           count='', accepted='', notes=''):
                    if _trace_lines is None:
                        return
                    _trace_lines.append({
                        'script_key': script_key,
                        'controller': controller,
                        'step': step,
                        'candidate': candidate,
                        'score': score,
                        'count': count,
                        'accepted': accepted,
                        'notes': notes,
                    })

                if self.script_vuser_counts:
                    # --------------------------------------------------------
                    # Helper: look up `script_key` inside ONE controller's
                    # script_vuser_counts dict using a strict, side-effect-free
                    # chain: exact -> SCRIPT_NAME_MAPPING -> strict normalized
                    # sum (within that one controller) -> per-controller
                    # score-based fuzzy match.
                    #
                    # The score-based fuzzy match is run PER CONTROLLER (not
                    # over the merged dict). Each controller's dict is small
                    # (~10-20 keys, all from the same scenario), so the
                    # cross-script-collision risk that produced bogus values
                    # like 3315 showing for VerifyYourPan_PreLogin,
                    # VerifyYourPan_PostLogin and Prevalidate alike is
                    # eliminated: a controller that doesn't actually contain
                    # those scripts will yield 0 instead of a false match.
                    # --------------------------------------------------------
                    def _lookup_in_one_ctrl(ctrl_counts, ctrl_label=''):
                        if not ctrl_counts:
                            _trace(ctrl_label, 'ctrl-empty', accepted=False,
                                   notes='no script_counts captured for this controller')
                            return 0
                        # 1) Exact match
                        if script_key in ctrl_counts:
                            v = _safe_int(ctrl_counts[script_key])
                            _trace(ctrl_label, 'exact', candidate=script_key,
                                   count=v, accepted=True)
                            return v
                        _trace(ctrl_label, 'exact', candidate=script_key,
                               accepted=False, notes='not in ctrl_counts')
                        # 2) SCRIPT_NAME_MAPPING -> canonical name in the dict
                        mapped_name = SCRIPT_NAME_MAPPING.get(script_key, None)
                        if mapped_name and mapped_name in ctrl_counts:
                            v = _safe_int(ctrl_counts[mapped_name])
                            _trace(ctrl_label, 'mapped', candidate=mapped_name,
                                   count=v, accepted=True)
                            return v
                        _trace(ctrl_label, 'mapped',
                               candidate=mapped_name or '',
                               accepted=False,
                               notes='no SCRIPT_NAME_MAPPING entry'
                                     if not mapped_name
                                     else 'mapped name not in ctrl_counts')
                        # 2.5) SCRIPT_LR_GROUP_HINTS - explicit semantic
                        #      override for scripts whose LR group naming
                        #      convention diverges from the FinalReport
                        #      script naming. Used when the script's
                        #      tokens (e.g. "PreLogin") don't appear in
                        #      any LR group name but a semantically
                        #      equivalent group does exist.
                        hint = SCRIPT_LR_GROUP_HINTS.get(script_key)
                        if hint is not None:
                            must_match_re, must_not_match_re = hint
                            hint_best_count = 0
                            hint_best_name = ''
                            for group_name, count in sorted(
                                ctrl_counts.items(),
                                key=lambda kv: str(kv[0]).lower()
                            ):
                                if not must_match_re.search(str(group_name)):
                                    continue
                                if must_not_match_re and must_not_match_re.search(str(group_name)):
                                    continue
                                v = _safe_int(count)
                                if v > hint_best_count:
                                    hint_best_count = v
                                    hint_best_name = group_name
                            if hint_best_count > 0:
                                _trace(ctrl_label, 'hint-match',
                                       candidate=hint_best_name,
                                       count=hint_best_count, accepted=True,
                                       notes=f'matched via SCRIPT_LR_GROUP_HINTS for {script_key}')
                                return hint_best_count
                            _trace(ctrl_label, 'hint-no-match',
                                   accepted=False,
                                   notes=f'no LR group matched SCRIPT_LR_GROUP_HINTS rule for {script_key}')
                        # 3) Strict normalized MAX WITHIN this controller.
                        #    When several group keys (e.g. ``38.1_…``,
                        #    ``38.2_…``, ``38.9_…``) all normalize to the same
                        #    canonical script, use MAX rather than SUM so a
                        #    script reported under 9 numbered variants of 10
                        #    vusers each yields 10, not 90. Same MAX semantic
                        #    applied across controllers is documented in the
                        #    user spec ("MAX of that script across
                        #    controllers"); we extend it consistently to
                        #    within-controller duplicates.
                        script_norm = _normalize_script_for_match(script_key)
                        strict_max = 0
                        strict_matches = 0
                        if script_norm:
                            for group_name, count in sorted(
                                ctrl_counts.items(),
                                key=lambda kv: str(kv[0]).lower()
                            ):
                                group_norm = _normalize_script_for_match(group_name)
                                if not group_norm:
                                    continue
                                if group_norm == script_norm:
                                    v = _safe_int(count)
                                    if v > strict_max:
                                        strict_max = v
                                    strict_matches += 1
                                    _trace(ctrl_label, 'norm-match',
                                           candidate=group_name,
                                           score=group_norm,
                                           count=v,
                                           accepted=True,
                                           notes=f'script_norm={script_norm}')
                        if strict_matches > 0 and strict_max > 0:
                            _trace(ctrl_label, 'norm-result',
                                   candidate=f'{strict_matches} match(es)',
                                   count=strict_max, accepted=True,
                                   notes=f'script_norm={script_norm}, using MAX of {strict_matches} matches')
                            return strict_max
                        _trace(ctrl_label, 'norm-result',
                               candidate=f'{strict_matches} match(es)',
                               count=strict_max, accepted=False,
                               notes=f'script_norm={script_norm or "<empty>"}, no usable match')
                        # 4) Per-controller score-based fuzzy fallback.
                        #    Reuses the same scoring heuristics as the
                        #    single-controller path but is bounded to ONE
                        #    controller's keys at a time. Pre-filters require
                        #    matching "key characteristic" tokens
                        #    (error/csi/history/payment-method/etc.) to
                        #    prevent unrelated scripts from collapsing onto
                        #    the same best match.
                        s_lower = script_key.lower()
                        s_no_us = s_lower.replace('_', '')
                        s_has_invalid = 'invalid' in s_lower
                        s_has_error = 'error' in s_lower or '_err' in s_lower or '_er' in s_lower
                        s_has_csi = 'csi' in s_lower
                        s_has_history = 'history' in s_lower
                        s_has_debit = 'debit' in s_lower
                        s_has_neft = 'neft' in s_lower or 'rtgs' in s_lower
                        s_has_cheque = 'cheque' in s_lower
                        s_has_netbank = 'netbank' in s_lower
                        s_has_26qd = '26qd' in s_lower

                        best_score = -1
                        best_count = 0
                        best_name = ''
                        # Precompute the script's token-aware normalization
                        # once (cheap, but the loop body would otherwise do
                        # this work redundantly per group key).
                        s_joined, s_starts, s_tokens = _norm_tokens(script_key)
                        s_tokenset = set(s_tokens)
                        for group_name, count in sorted(
                            ctrl_counts.items(),
                            key=lambda kv: str(kv[0]).lower()
                        ):
                            g_lower = group_name.lower()
                            # Key-characteristic pre-filters
                            g_has_invalid = 'invalid' in g_lower
                            g_has_error = 'error' in g_lower or '_err' in g_lower
                            g_has_csi = 'csi' in g_lower
                            g_has_history = 'history' in g_lower
                            g_has_debit = 'debit' in g_lower
                            g_has_neft = 'neft' in g_lower or 'rtgs' in g_lower
                            g_has_cheque = 'cheque' in g_lower
                            g_has_netbank = 'netbank' in g_lower
                            g_has_26qd = '26qd' in g_lower

                            if s_has_invalid != g_has_invalid:
                                _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                       candidate=group_name, count=_safe_int(count),
                                       accepted=False,
                                       notes=f'invalid mismatch (script={s_has_invalid}, group={g_has_invalid})')
                                continue
                            if s_has_error != g_has_error:
                                _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                       candidate=group_name, count=_safe_int(count),
                                       accepted=False,
                                       notes=f'error mismatch (script={s_has_error}, group={g_has_error})')
                                continue
                            if s_has_csi != g_has_csi:
                                _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                       candidate=group_name, count=_safe_int(count),
                                       accepted=False,
                                       notes=f'csi mismatch (script={s_has_csi}, group={g_has_csi})')
                                continue
                            if s_has_history != g_has_history:
                                _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                       candidate=group_name, count=_safe_int(count),
                                       accepted=False,
                                       notes=f'history mismatch (script={s_has_history}, group={g_has_history})')
                                continue
                            if 'payment' in s_lower:
                                if s_has_debit != g_has_debit:
                                    _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                           candidate=group_name, count=_safe_int(count),
                                           accepted=False,
                                           notes=f'payment/debit mismatch (script={s_has_debit}, group={g_has_debit})')
                                    continue
                                if s_has_neft != g_has_neft:
                                    _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                           candidate=group_name, count=_safe_int(count),
                                           accepted=False,
                                           notes=f'payment/neft|rtgs mismatch (script={s_has_neft}, group={g_has_neft})')
                                    continue
                                if s_has_cheque != g_has_cheque:
                                    _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                           candidate=group_name, count=_safe_int(count),
                                           accepted=False,
                                           notes=f'payment/cheque mismatch (script={s_has_cheque}, group={g_has_cheque})')
                                    continue
                                if s_has_netbank != g_has_netbank:
                                    _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                           candidate=group_name, count=_safe_int(count),
                                           accepted=False,
                                           notes=f'payment/netbank mismatch (script={s_has_netbank}, group={g_has_netbank})')
                                    continue
                                if s_has_26qd != g_has_26qd:
                                    _trace(ctrl_label, 'fuzzy-prefilter-reject',
                                           candidate=group_name, count=_safe_int(count),
                                           accepted=False,
                                           notes=f'payment/26qd mismatch (script={s_has_26qd}, group={g_has_26qd})')
                                    continue

                            # Token-aware normalization of the group name.
                            # Replaces the old ad-hoc g_clean computation so
                            # both sides of the fuzzy comparison use the same
                            # rules as the strict-norm path above.
                            g_joined, g_starts, g_tokens = _norm_tokens(group_name)
                            g_tokenset = set(g_tokens)

                            score = 0
                            score_reason = ''
                            if s_lower == g_lower:
                                score = 1000
                                score_reason = 'exact lowercase'
                            elif s_joined and s_joined == g_joined:
                                # Should normally be caught by strict-norm step
                                # but keep here as a safety net.
                                score = 900
                                score_reason = 'normalized equal'
                            elif s_lower.startswith(g_lower) and g_lower:
                                score = 800 + len(g_lower)
                                score_reason = f's startswith g ({len(g_lower)})'
                            elif g_lower.startswith(s_lower) and s_lower:
                                score = 700 + len(s_lower)
                                score_reason = f'g startswith s ({len(s_lower)})'
                            elif s_joined and g_joined and s_joined in g_joined:
                                # Script is a substring of group. Require that
                                # it starts at a token boundary in the GROUP so
                                # we never borrow chars from inside another
                                # token (this is what produced the bogus
                                # ``everification`` -> ``doubleverification``
                                # match).
                                pos = g_joined.find(s_joined)
                                if pos in g_starts:
                                    score = 600 + len(s_joined)
                                    score_reason = f's_joined at g token-start pos={pos} ({len(s_joined)})'
                                else:
                                    score_reason = f's_joined inside g but pos={pos} not token-start (starts={sorted(g_starts)})'
                            elif s_joined and g_joined and g_joined in s_joined:
                                # Group is a substring of script. Require token
                                # boundary alignment in the SCRIPT.
                                pos = s_joined.find(g_joined)
                                if pos in s_starts:
                                    score = 500 + len(g_joined)
                                    score_reason = f'g_joined at s token-start pos={pos} ({len(g_joined)})'
                                else:
                                    score_reason = f'g_joined inside s but pos={pos} not token-start (starts={sorted(s_starts)})'
                            else:
                                # Form pattern fallback (e.g. ``form15g``).
                                form_match = re.search(r'form(\d+\w*)', s_joined or '')
                                if form_match:
                                    form_id = form_match.group(1)
                                    if g_joined and f'form{form_id}' in g_joined:
                                        score = 400 + len(form_id)
                                        score_reason = f'form{form_id} match'

                                # Jaccard token-overlap fallback. Triggers
                                # only when the SMALLER token-set is FULLY
                                # CONTAINED in the larger (overlap ==
                                # smaller, with overlap >= 2). This bridges
                                # benign extra-word cases like
                                # ``VerifyYourPan_PostLogin`` (5 tokens) ->
                                # ``VerifyPan_PostLogin`` (4 tokens, all 4
                                # contained) while rejecting near-misses
                                # that swap a single discriminating token
                                # such as ``Pre`` for ``Post`` -- e.g.
                                # ``VerifyYourPan_PreLogin`` vs
                                # ``VerifyPan_PostLogin`` shares only 3 of
                                # the group's 4 tokens (``post`` differs)
                                # and is therefore rejected.
                                if score == 0 and s_tokenset and g_tokenset:
                                    overlap = s_tokenset & g_tokenset
                                    smaller = min(len(s_tokenset), len(g_tokenset))
                                    if len(overlap) >= 2 and len(overlap) == smaller:
                                        score = 300 + len(overlap) * 10
                                        score_reason = (
                                            f'jaccard fully-contained overlap={sorted(overlap)} '
                                            f'(|s|={len(s_tokenset)}, |g|={len(g_tokenset)})'
                                        )

                            _trace(ctrl_label, 'fuzzy-candidate',
                                   candidate=group_name, score=score,
                                   count=_safe_int(count), accepted=False,
                                   notes=f's_joined={s_joined}|g_joined={g_joined}|reason={score_reason or "no-rule"}')

                            if score > best_score:
                                best_score = score
                                best_count = _safe_int(count)
                                best_name = group_name
                            elif score == best_score and _safe_int(count) > best_count:
                                best_count = _safe_int(count)
                                best_name = group_name

                        if best_score > 0 and best_count > 0:
                            _trace(ctrl_label, 'fuzzy-best',
                                   candidate=best_name, score=best_score,
                                   count=best_count, accepted=True,
                                   notes='returned as ctrl value')
                            _trace(ctrl_label, 'ctrl-result',
                                   candidate=best_name, score=best_score,
                                   count=best_count, accepted=True,
                                   notes='via fuzzy')
                            return best_count
                        _trace(ctrl_label, 'fuzzy-best',
                               candidate='', score=best_score if best_score >= 0 else '',
                               count=best_count, accepted=False,
                               notes='no candidate scored > 0')
                        _trace(ctrl_label, 'ctrl-result',
                               candidate='', count=0, accepted=False,
                               notes='all steps missed; returning 0')
                        return 0

                    all_scenarios = getattr(self, 'all_scenario_info', None)
                    if all_scenarios and len(all_scenarios) > 1:
                        # MULTI-CONTROLLER: per-script MAX across controllers.
                        # Each controller is treated as an independent run
                        # (matches user expectation: "MAX of that script
                        # across controllers", not a sum of contributions).
                        per_ctrl_values = []
                        for ctrl_idx, ctrl_data in enumerate(all_scenarios, 1):
                            ctrl_label = f'C{ctrl_idx}'
                            ctrl_counts = ctrl_data.get('script_counts', {}) or {}
                            # Emit the available-keys dump for this controller
                            # so blank/wrong-match rows can be diagnosed.
                            if _trace_lines is not None:
                                for k, v in sorted(
                                    ctrl_counts.items(),
                                    key=lambda kv: str(kv[0]).lower()
                                ):
                                    _trace(ctrl_label, 'available-keys',
                                           candidate=k,
                                           score=_normalize_script_for_match(k),
                                           count=_safe_int(v),
                                           accepted='')
                            value = _lookup_in_one_ctrl(ctrl_counts, ctrl_label)
                            if value > 0:
                                per_ctrl_values.append(value)
                        if per_ctrl_values:
                            script_vuser_count = max(per_ctrl_values)
                        # else: leave script_vuser_count as '' (no match)
                    elif script_key in self.script_vuser_counts:
                        # SINGLE-CONTROLLER: keep the historical lookup chain
                        # (exact -> mapped -> strict-norm sum -> score-based
                        # fuzzy fallback) so single-controller reports do not
                        # regress for transactions whose script_key does not
                        # exactly or strictly match any group name.
                        script_vuser_count = self.script_vuser_counts[script_key]
                    else:
                        # Try using SCRIPT_NAME_MAPPING to get canonical name
                        mapped_name = SCRIPT_NAME_MAPPING.get(script_key, None)
                        if mapped_name and mapped_name in self.script_vuser_counts:
                            script_vuser_count = self.script_vuser_counts[mapped_name]
                        else:
                            # Prefer summing strict normalized matches across folders/serial uploads.
                            # This avoids undercounting when the same script appears with suffix/prefix variations.
                            # Sorted iteration is not required for correctness (sum is commutative)
                            # but guarantees deterministic processing under any future tie-breaker.
                            script_norm = _normalize_script_for_match(script_key)
                            strict_total = 0
                            strict_matches = 0
                            for group_name, count in sorted(self.script_vuser_counts.items(), key=lambda kv: str(kv[0]).lower()):
                                group_norm = _normalize_script_for_match(group_name)
                                if not script_norm or not group_norm:
                                    continue
                                if group_norm == script_norm:
                                    strict_total += _safe_int(count)
                                    strict_matches += 1

                            if strict_matches > 0 and strict_total > 0:
                                script_vuser_count = strict_total
                            else:
                                # Use best-match scoring instead of first-match
                                # This ensures the most specific match wins
                                script_lower = script_key.lower()
                                script_lower_no_underscore = script_lower.replace('_', '')
                            
                                # Extract key identifiers from script name for precise matching
                                script_has_invalid = 'invalid' in script_lower
                                script_has_error = 'error' in script_lower or '_err' in script_lower or '_er' in script_lower
                                script_has_download = 'download' in script_lower
                                script_has_csi = 'csi' in script_lower
                                script_has_challan = 'challan' in script_lower
                                script_has_history = 'history' in script_lower
                                script_has_debit = 'debit' in script_lower
                                script_has_neft = 'neft' in script_lower or 'rtgs' in script_lower
                                script_has_cheque = 'cheque' in script_lower
                                script_has_netbank = 'netbank' in script_lower
                                script_has_26qd = '26qd' in script_lower
                            
                                best_match_score = -1
                                best_match_count = ''
                            
                                for group_name, count in sorted(self.script_vuser_counts.items(), key=lambda x: str(x[0]).lower()):
                                    group_lower = group_name.lower()
                                    group_lower_no_underscore = group_lower.replace('_', '')
                                
                                    # Skip if key characteristics don't match
                                    group_has_invalid = 'invalid' in group_lower
                                    group_has_error = 'error' in group_lower or '_err' in group_lower
                                    group_has_download = 'download' in group_lower
                                    group_has_csi = 'csi' in group_lower
                                    group_has_challan = 'challan' in group_lower
                                    group_has_history = 'history' in group_lower
                                    group_has_debit = 'debit' in group_lower
                                    group_has_neft = 'neft' in group_lower or 'rtgs' in group_lower
                                    group_has_cheque = 'cheque' in group_lower
                                    group_has_netbank = 'netbank' in group_lower
                                    group_has_26qd = '26qd' in group_lower
                                
                                    # Must match on key characteristics
                                    if script_has_invalid != group_has_invalid:
                                        continue
                                    if script_has_error != group_has_error:
                                        continue
                                    if script_has_csi != group_has_csi:
                                        continue
                                    if script_has_history != group_has_history:
                                        continue
                                
                                    # For payment scripts, be more specific
                                    if 'payment' in script_lower:
                                        if script_has_debit != group_has_debit:
                                            continue
                                        if script_has_neft != group_has_neft:
                                            continue
                                        if script_has_cheque != group_has_cheque:
                                            continue
                                        if script_has_netbank != group_has_netbank:
                                            continue
                                        if script_has_26qd != group_has_26qd:
                                            continue
                                
                                    score = 0
                                
                                    # Normalize group name: remove prefix numbers, suffixes
                                    group_clean = re.sub(r'^\d+[._]', '', group_name)  # Remove "01_" or "01." prefix
                                    group_clean = re.sub(r'_(final|modify|ay\d+_?\d*|ntb|new|modified|v\d+.*|act\d+).*$', '', group_clean, flags=re.IGNORECASE)
                                    group_clean_lower = group_clean.lower().replace('_', '')
                                
                                    # Check for matching patterns and score them
                                    if script_lower == group_lower:
                                        score = 1000  # Exact match
                                    elif script_lower_no_underscore == group_clean_lower:
                                        score = 900  # Exact match after normalization
                                    elif script_lower.startswith(group_lower):
                                        score = 800 + len(group_lower)  # Prefix match, longer is better
                                    elif group_lower.startswith(script_lower):
                                        score = 700 + len(script_lower)
                                    elif script_lower_no_underscore.startswith(group_clean_lower):
                                        score = 600 + len(group_clean_lower)
                                    elif group_clean_lower.startswith(script_lower_no_underscore):
                                        score = 500 + len(script_lower_no_underscore)
                                    elif script_lower_no_underscore in group_clean_lower:
                                        score = 400 + len(script_lower_no_underscore)
                                    elif group_clean_lower in script_lower_no_underscore:
                                        score = 300 + len(group_clean_lower)
                                    else:
                                        # Check partial match for form names
                                        form_match = re.search(r'form(\d+\w*)', script_lower_no_underscore)
                                        if form_match:
                                            form_id = form_match.group(1)
                                            if f'form{form_id}' in group_clean_lower:
                                                score = 200 + len(form_id)
                                
                                    if score > best_match_score:
                                        best_match_score = score
                                        best_match_count = count
                                    elif score == best_match_score and _safe_int(count) > _safe_int(best_match_count):
                                        best_match_count = count

                                script_vuser_count = best_match_count
                
                # Column A: Script Name
                cell = ws.cell(row=row, column=1, value=script_key)
                apply_cell_style(cell)
                
                # Column B: SL No
                cell = ws.cell(row=row, column=2, value=sl_no)
                apply_cell_style(cell)
                
                # Column C: Description (full Target TPS name)
                cell = ws.cell(row=row, column=3, value=description_name)
                apply_cell_style(cell)
                cell.fill = light_blue
                
                # Column D: Target TPS
                cell = ws.cell(row=row, column=4, value=target_tps_value)
                apply_cell_style(cell)
                cell.fill = light_blue
                
                # Column E: Pass
                cell = ws.cell(row=row, column=5, value=last_pass)
                apply_cell_style(cell)
                
                # Column F: Fail
                cell = ws.cell(row=row, column=6, value=total_fail)
                apply_cell_style(cell)
                
                # Column G: Fail% (with % symbol)
                fail_pct_formula = f'=IF((E{row}+F{row})>0,TEXT(ROUND(F{row}/(E{row}+F{row})*100,2),"0.00")&"%","0%")'
                cell = ws.cell(row=row, column=7, value=fail_pct_formula)
                apply_cell_style(cell)
                cell.alignment = Alignment(horizontal='right', vertical='center')
                
                # Column H: Achieved TPS
                cell = ws.cell(row=row, column=8, value=last_tps)
                apply_cell_style(cell)
                
                # Column I: TPS % (with % symbol and 2 decimal places)
                tps_pct_formula = f'=IF(D{row}>0,TEXT(ROUND(H{row}/D{row}*100,2),"0.00")&"%","0%")'
                cell = ws.cell(row=row, column=9, value=tps_pct_formula)
                apply_cell_style(cell)
                cell.alignment = Alignment(horizontal='right', vertical='center')
                
                # Column J: User Count (auto-filled if available, else editable)
                _trace('', 'final',
                       candidate=script_key,
                       count=script_vuser_count if script_vuser_count else 0,
                       accepted=bool(script_vuser_count),
                       notes='value written to Column J')
                cell = ws.cell(row=row, column=10, value=script_vuser_count if script_vuser_count else '')
                apply_cell_style(cell)
                if not script_vuser_count:
                    cell.fill = light_blue  # Sky blue if editable
                
                # Column K: Adj User Count = (User Count / TPS%) × (Target% / 100)
                # References $N$7 for target percentage - user can change that cell to recalculate all
                adj_user_formula = f'=IF(AND(J{row}<>"",I{row}<>"0%",VALUE(SUBSTITUTE(I{row},"%",""))>0),ROUND((J{row}/(VALUE(SUBSTITUTE(I{row},"%",""))/100))*($N$7/100),0),"")'
                cell = ws.cell(row=row, column=11, value=adj_user_formula)
                apply_cell_style(cell)
            
            # Separate scripts into BO and FO categories
            bo_scripts = {}
            fo_scripts = {}
            for script_key, data in script_data.items():
                if is_bo_script(script_key):
                    bo_scripts[script_key] = data
                else:
                    fo_scripts[script_key] = data
            
            current_row = 2
            sl_no = 1
            light_blue = PatternFill(start_color='D6EAF8', end_color='D6EAF8', fill_type='solid')  # Light sky blue for editable cells
            blue_fill = PatternFill(start_color='4472C4', end_color='4472C4', fill_type='solid')
            
            # Helper to find which script_key matches a Target TPS name
            def find_script_for_tps_name(tps_name, script_dict):
                """Find the script_key in script_dict that matches a Target TPS name."""
                # Direct match
                if tps_name in script_dict:
                    return tps_name
                
                # Check SCRIPT_NAME_MAPPING reverse lookup
                for mapped_key, mapped_name in SCRIPT_NAME_MAPPING.items():
                    if mapped_name == tps_name and mapped_key in script_dict:
                        return mapped_key
                
                # Check if tps_name matches any ITR_PATTERNS canonical name, then match script
                for pattern, canonical_name in ITR_PATTERNS.items():
                    if canonical_name == tps_name:
                        # Find script that matches this pattern
                        for script_key in script_dict.keys():
                            if re.search(pattern, script_key, re.IGNORECASE):
                                return script_key
                
                # Fuzzy match
                tps_lower = tps_name.lower().replace(' ', '').replace('-', '').replace('_', '')
                tps_clean = re.sub(r'\(.*?\)', '', tps_name).lower().replace(' ', '').replace('-', '').replace('_', '')
                
                for script_key in script_dict.keys():
                    script_lower = script_key.lower().replace('_', '')
                    
                    # Check if script appears in TPS name
                    if script_lower in tps_clean or tps_clean in script_lower:
                        return script_key
                
                return None
            
            # Write BO Section Header
            if wlm_data:
                # ================================================================
                # WLM-DRIVEN BRANCH
                # ================================================================
                # Every LR script is first matched to a WLM usecase (WLM
                # display name). Matched rows appear in WLM row order.
                # Unmatched LR scripts are classified BO or FO via
                # is_bo_script() and appended to the tail of their
                # section (alphabetical) so nothing is silently dropped.
                # WLM cell styles are copied onto FinalReport columns
                # B (SL No), C (Description), D (Target TPS) -- the
                # three WLM-native columns -- for BOTH matched and
                # unmatched rows so the section looks uniform. Columns
                # A, E-K keep their existing styles and formulas.
                # ----------------------------------------------------------------

                # 1) Match every LR script to a WLM entry. Multiple LR
                #    scripts CAN share one WLM entry -- they're grouped
                #    and emitted consecutively at that WLM row's
                #    position so the WLM 26-27 order is preserved for
                #    every LR script.
                all_scripts_map = {}
                all_scripts_map.update(bo_scripts)
                all_scripts_map.update(fo_scripts)
                for _sk in sorted(all_scripts_map.keys(), key=str.lower):
                    matched_wlm = match_lr_script_to_wlm(
                        _sk, wlm_data, SCRIPT_NAME_MAPPING,
                        combined_tps_lookup, find_target_tps_name,
                    )
                    if matched_wlm:
                        wlm_match_map.setdefault(matched_wlm, []).append(_sk)
                    else:
                        unmatched_lr_scripts.append(_sk)

                # 2) Prepare style templates from the WLM workbook
                _wlm_ws = wlm_data['workbook'][wlm_data['sheet_name']]
                _wlm_header_row = wlm_data['header_style_row']
                _wlm_data_row = wlm_data['data_style_row']
                # FinalReport dst col -> WLM src col:
                #   B (SL No)       <- WLM col 1 (SL No)
                #   C (Description) <- WLM col 2 (Usecase Name)
                #   D (Target TPS)  <- WLM col 3 (Target TPS)
                _wlm_col_map = [('B', 2, 1), ('C', 3, 2), ('D', 4, 3)]
                _wlm_header_srcs = {
                    dst_col_letter: _wlm_ws.cell(row=_wlm_header_row, column=src_col)
                    for dst_col_letter, _dst_col_idx, src_col in _wlm_col_map
                }
                _wlm_data_srcs = {}
                if _wlm_data_row:
                    for dst_col_letter, _dst_col_idx, src_col in _wlm_col_map:
                        _wlm_data_srcs[dst_col_letter] = _wlm_ws.cell(
                            row=_wlm_data_row, column=src_col)

                # 3) Re-style the FinalReport header row (row 1). WLM's
                #    header style (dark blue #4472C4 with bold white
                #    Calibri) is applied to ALL 11 columns of the header
                #    row so the entire row visually matches WLM. We use
                #    the WLM "Usecase Name" header cell as the single
                #    template (it carries the fill/font/border/alignment
                #    reliably; the WLM "SL No" cell in some WLM sheets
                #    has no fill defined). WLM's own cells for cols
                #    B/C/D are copied first so any column-specific
                #    tweak (e.g., number format on col D) is preserved.
                for dst_col_letter, dst_col_idx, _src_col in _wlm_col_map:
                    _copy_openpyxl_style(
                        _wlm_header_srcs[dst_col_letter],
                        ws_final.cell(row=1, column=dst_col_idx),
                    )
                _wlm_hdr_template = _wlm_header_srcs['C']
                for dst_col_idx in (1, 2, 5, 6, 7, 8, 9, 10, 11):
                    _copy_openpyxl_style(
                        _wlm_hdr_template,
                        ws_final.cell(row=1, column=dst_col_idx),
                    )

                def _apply_wlm_data_style_to_row(row_num, wlm_src_row=None):
                    """Copy WLM per-row style (fill/font/border/alignment)
                    onto ALL 11 FinalReport data columns so each row
                    reproduces WLM's category-specific color (peach for
                    ITR filing, green for Forms, gray for Payments,
                    light blue for basic usecases, etc.). WLM stores
                    these as theme+tint fills, which are preserved by
                    ``copy.copy`` on the fill/font objects.

                    Args:
                      row_num: FinalReport row to style.
                      wlm_src_row: WLM row to copy styling from. When
                        None, falls back to the first WLM data row
                        captured at load time (used for unmatched LR
                        scripts appended after the WLM entries).
                    """
                    src_row = wlm_src_row if wlm_src_row is not None else _wlm_data_row
                    if not src_row:
                        return
                    # Col D uses its exact WLM source (preserves any
                    # number format on target TPS).
                    src_d = _wlm_ws.cell(row=src_row, column=3)
                    _copy_openpyxl_style(src_d, ws_final.cell(row=row_num, column=4))
                    # All other cols (A + B + C + E-K) use the row's
                    # "Usecase Name" cell (WLM col 2) as template so the
                    # entire FinalReport row shows the same WLM color.
                    src_name = _wlm_ws.cell(row=src_row, column=2)
                    for dst_col_idx in (1, 2, 3, 5, 6, 7, 8, 9, 10, 11):
                        _copy_openpyxl_style(
                            src_name,
                            ws_final.cell(row=row_num, column=dst_col_idx),
                        )

                def _lookup_script(script_key):
                    """Return (data_dict, source_label) for a script_key from bo/fo."""
                    if script_key in bo_scripts:
                        return bo_scripts[script_key], 'BO'
                    if script_key in fo_scripts:
                        return fo_scripts[script_key], 'FO'
                    return None, ''

                # 4) BO section (blue band -- kept per user choice) using WLM BO order.
                #    Then append LR scripts classified as BO by is_bo_script()
                #    that had no WLM match, so nothing is silently dropped.
                _bo_matched_scripts = {e['name']: wlm_match_map[e['name']]
                                       for e in wlm_data['bo_entries']
                                       if e['name'] in wlm_match_map}
                _bo_unmatched_scripts = [sk for sk in unmatched_lr_scripts
                                         if is_bo_script(sk)]
                if _bo_matched_scripts or _bo_unmatched_scripts:
                    for col in range(1, 12):
                        cell = ws_final.cell(row=current_row, column=col,
                                             value='BACK OFFICE (BO) USECASES' if col == 1 else '')
                        cell.fill = blue_fill
                        cell.font = Font(bold=True, color='FFFFFF')
                        cell.border = border
                    ws_final.merge_cells(start_row=current_row, start_column=1,
                                         end_row=current_row, end_column=11)
                    current_row += 1
                    # 4a) Matched BO usecases in WLM order.
                    #     De-duplication: when multiple LR script_keys
                    #     map to the same WLM entry (e.g. LR result has
                    #     both "FORM26Q_T##" and "Form26Q_T##" spellings
                    #     that bucket into two script_data entries even
                    #     though they represent the same LR VUser group),
                    #     pick ONE row per WLM entry -- the script with
                    #     the highest pass count (most representative LR
                    #     data). No summing/merging: original LR values
                    #     are preserved as-is.
                    for entry in wlm_data['bo_entries']:
                        wlm_name = entry['name']
                        script_keys = wlm_match_map.get(wlm_name) or []
                        best_key = None
                        best_pass = -1
                        best_data = None
                        for _sk in script_keys:
                            _data, _ = _lookup_script(_sk)
                            if _data is None:
                                continue
                            _pass = int(_data.get('total_pass', 0) or 0)
                            if _pass > best_pass or (_pass == best_pass and best_key is None):
                                best_pass = _pass
                                best_key = _sk
                                best_data = _data
                        if best_key is None:
                            continue
                        write_script_row(
                            ws_final, current_row, sl_no, best_key, best_data,
                            combined_tps_lookup, wlm_name,
                        )
                        # Override Target TPS (col D) with authoritative WLM
                        # value -- write_script_row internally does fuzzy
                        # lookup which can pick up legacy AY 25-26 entries.
                        if entry['tps'] is not None:
                            ws_final.cell(row=current_row, column=4, value=entry['tps'])
                        # Copy styling from THIS entry's WLM row so the
                        # per-row WLM color (peach for ITR, gray for
                        # Payments, green for Forms, etc.) is preserved.
                        _apply_wlm_data_style_to_row(current_row, wlm_src_row=entry['wlm_row'])
                        current_row += 1
                        sl_no += 1
                    # 4b) Unmatched LR scripts classified as BO (appended, alphabetical)
                    for script_key in sorted(_bo_unmatched_scripts, key=str.lower):
                        data, _src = _lookup_script(script_key)
                        if data is None:
                            continue
                        desc_name = find_target_tps_name(script_key, combined_tps_lookup)
                        write_script_row(
                            ws_final, current_row, sl_no, script_key, data,
                            combined_tps_lookup, desc_name,
                        )
                        # Apply WLM style band to keep the section visually
                        # uniform even for rows that don't have a direct WLM
                        # entry.
                        _apply_wlm_data_style_to_row(current_row)
                        current_row += 1
                        sl_no += 1
                    current_row += 1  # gap between sections

                # 5) FO section (green band) using WLM FO order.
                #    Then append unmatched FO-classified LR scripts.
                _fo_matched_scripts = {e['name']: wlm_match_map[e['name']]
                                       for e in wlm_data['fo_entries']
                                       if e['name'] in wlm_match_map}
                _fo_unmatched_scripts = [sk for sk in unmatched_lr_scripts
                                         if not is_bo_script(sk)]
                if _fo_matched_scripts or _fo_unmatched_scripts:
                    green_header_fill = PatternFill(start_color='70AD47',
                                                    end_color='70AD47', fill_type='solid')
                    for col in range(1, 12):
                        cell = ws_final.cell(row=current_row, column=col,
                                             value='FRONT OFFICE (FO) USECASES' if col == 1 else '')
                        cell.fill = green_header_fill
                        cell.font = Font(bold=True, color='FFFFFF')
                        cell.border = border
                    ws_final.merge_cells(start_row=current_row, start_column=1,
                                         end_row=current_row, end_column=11)
                    current_row += 1
                    # 5a) Matched FO usecases in WLM order.
                    #     De-duplication: same rule as BO branch above --
                    #     one row per WLM entry, pick the script with the
                    #     highest pass count when multiple LR script_keys
                    #     map to one WLM entry.
                    for entry in wlm_data['fo_entries']:
                        wlm_name = entry['name']
                        script_keys = wlm_match_map.get(wlm_name) or []
                        best_key = None
                        best_pass = -1
                        best_data = None
                        for _sk in script_keys:
                            _data, _ = _lookup_script(_sk)
                            if _data is None:
                                continue
                            _pass = int(_data.get('total_pass', 0) or 0)
                            if _pass > best_pass or (_pass == best_pass and best_key is None):
                                best_pass = _pass
                                best_key = _sk
                                best_data = _data
                        if best_key is None:
                            continue
                        write_script_row(
                            ws_final, current_row, sl_no, best_key, best_data,
                            combined_tps_lookup, wlm_name,
                        )
                        # Override Target TPS (col D) with authoritative WLM
                        # value -- see note in BO branch above.
                        if entry['tps'] is not None:
                            ws_final.cell(row=current_row, column=4, value=entry['tps'])
                        # Copy styling from THIS entry's WLM row so the
                        # per-row WLM color is preserved.
                        _apply_wlm_data_style_to_row(current_row, wlm_src_row=entry['wlm_row'])
                        current_row += 1
                        sl_no += 1
                    # 5b) Unmatched LR scripts classified as FO (appended, alphabetical)
                    for script_key in sorted(_fo_unmatched_scripts, key=str.lower):
                        data, _src = _lookup_script(script_key)
                        if data is None:
                            continue
                        desc_name = find_target_tps_name(script_key, combined_tps_lookup)
                        write_script_row(
                            ws_final, current_row, sl_no, script_key, data,
                            combined_tps_lookup, desc_name,
                        )
                        _apply_wlm_data_style_to_row(current_row)
                        current_row += 1
                        sl_no += 1
            elif bo_scripts:
                for col in range(1, 12):
                    cell = ws_final.cell(row=current_row, column=col, value='BACK OFFICE (BO) USECASES' if col == 1 else '')
                    cell.fill = blue_fill
                    cell.font = Font(bold=True, color='FFFFFF')
                    cell.border = border
                ws_final.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=11)
                current_row += 1
                
                # Write BO scripts in TARGET_TPS_LOOKUP order
                written_bo_scripts = set()
                written_bo_descs = set()  # de-dup leftover pass by resolved description (handles case-variant aliases)
                # First: scripts that match TARGET_TPS_LOOKUP entries (in order)
                for tps_name in TARGET_TPS_LOOKUP.keys():
                    if tps_name in BO_USECASES:
                        script_key = find_script_for_tps_name(tps_name, bo_scripts)
                        if script_key and script_key not in written_bo_scripts:
                            write_script_row(ws_final, current_row, sl_no, script_key, bo_scripts[script_key], combined_tps_lookup, tps_name)
                            written_bo_scripts.add(script_key)
                            written_bo_descs.add(tps_name)
                            current_row += 1
                            sl_no += 1
                # Second: any remaining BO scripts not matched to TARGET_TPS_LOOKUP (alphabetically)
                for script_key in sorted(bo_scripts.keys()):
                    if script_key not in written_bo_scripts:
                        desc_name = find_target_tps_name(script_key, combined_tps_lookup)
                        # Skip if another alias with the same description was already written
                        # (prevents duplicate rows for case-variants like FORM26Q vs Form26Q)
                        if desc_name and desc_name in written_bo_descs:
                            continue
                        write_script_row(ws_final, current_row, sl_no, script_key, bo_scripts[script_key], combined_tps_lookup, desc_name)
                        written_bo_scripts.add(script_key)
                        if desc_name:
                            written_bo_descs.add(desc_name)
                        current_row += 1
                        sl_no += 1
                
                # Empty row between sections
                current_row += 1
            
            # Write FO Section Header
            if not wlm_data and fo_scripts:
                green_header_fill = PatternFill(start_color='70AD47', end_color='70AD47', fill_type='solid')
                for col in range(1, 12):
                    cell = ws_final.cell(row=current_row, column=col, value='FRONT OFFICE (FO) USECASES' if col == 1 else '')
                    cell.fill = green_header_fill
                    cell.font = Font(bold=True, color='FFFFFF')
                    cell.border = border
                ws_final.merge_cells(start_row=current_row, start_column=1, end_row=current_row, end_column=11)
                current_row += 1
                
                # Write FO scripts in TARGET_TPS_LOOKUP order
                written_fo_scripts = set()
                written_fo_descs = set()  # de-dup leftover pass by resolved description (handles case-variant aliases)
                # First: scripts that match TARGET_TPS_LOOKUP entries (in order)
                for tps_name in TARGET_TPS_LOOKUP.keys():
                    if tps_name not in BO_USECASES:
                        script_key = find_script_for_tps_name(tps_name, fo_scripts)
                        if script_key and script_key not in written_fo_scripts:
                            write_script_row(ws_final, current_row, sl_no, script_key, fo_scripts[script_key], combined_tps_lookup, tps_name)
                            written_fo_scripts.add(script_key)
                            written_fo_descs.add(tps_name)
                            current_row += 1
                            sl_no += 1
                # Second: any remaining FO scripts not matched to TARGET_TPS_LOOKUP (alphabetically)
                for script_key in sorted(fo_scripts.keys()):
                    if script_key not in written_fo_scripts:
                        desc_name = find_target_tps_name(script_key, combined_tps_lookup)
                        # Skip if another alias with the same description was already written
                        # (prevents duplicate rows for case-variants like FORM26Q vs Form26Q)
                        if desc_name and desc_name in written_fo_descs:
                            continue
                        write_script_row(ws_final, current_row, sl_no, script_key, fo_scripts[script_key], combined_tps_lookup, desc_name)
                        written_fo_scripts.add(script_key)
                        if desc_name:
                            written_fo_descs.add(desc_name)
                        current_row += 1
                        sl_no += 1
            
            # Apply conditional formatting for Fail% and TPS % columns
            # Thresholds reference settings cells: N5 = Fail% threshold, N6 = TPS% threshold
            from openpyxl.formatting.rule import FormulaRule
            
            # Light red (salmon) for errors - matches user's Excel
            light_red_fill = PatternFill(start_color='FFC7CE', end_color='FFC7CE', fill_type='solid')
            # Parrot green for success - matches user's Excel
            parrot_green_fill = PatternFill(start_color='C6EFCE', end_color='C6EFCE', fill_type='solid')
            
            if current_row > 2:
                # Fail% >= $N$5 (threshold) -> Light Red (Column G)
                ws_final.conditional_formatting.add(
                    f'G2:G{current_row-1}',
                    FormulaRule(formula=['VALUE(SUBSTITUTE(G2,"%",""))>=$N$5'], fill=light_red_fill)
                )
                # Fail% < $N$5 (threshold) -> Parrot Green (Column G)
                ws_final.conditional_formatting.add(
                    f'G2:G{current_row-1}',
                    FormulaRule(formula=['VALUE(SUBSTITUTE(G2,"%",""))<$N$5'], fill=parrot_green_fill)
                )
                
                # TPS % > $N$6 (threshold) -> Parrot Green (Column I)
                ws_final.conditional_formatting.add(
                    f'I2:I{current_row-1}',
                    FormulaRule(formula=['VALUE(SUBSTITUTE(I2,"%",""))>$N$6'], fill=parrot_green_fill)
                )
                # TPS % <= $N$6 (threshold) -> Light Red (Column I)
                ws_final.conditional_formatting.add(
                    f'I2:I{current_row-1}',
                    FormulaRule(formula=['VALUE(SUBSTITUTE(I2,"%",""))<=$N$6'], fill=light_red_fill)
                )
            
            # Column widths matching user's format
            ws_final.column_dimensions['A'].width = 30   # Script
            ws_final.column_dimensions['B'].width = 8    # SL No
            ws_final.column_dimensions['C'].width = 45   # Description
            ws_final.column_dimensions['D'].width = 12   # Target TPS
            ws_final.column_dimensions['E'].width = 10   # Pass
            ws_final.column_dimensions['F'].width = 10   # Fail
            ws_final.column_dimensions['G'].width = 10   # Fail%
            ws_final.column_dimensions['H'].width = 14   # Achieved TPS
            ws_final.column_dimensions['I'].width = 10   # TPS %
            ws_final.column_dimensions['J'].width = 12   # User Count
            ws_final.column_dimensions['K'].width = 28   # Adjusted Usercount for the next run

        wb.save(output_path)

        # --- Lookup trace dump (only when enabled) -----------------
        # Activated by setting env var LRR_LOOKUP_TRACE=1 before
        # running the app, or by calling parser.enable_lookup_trace()
        # programmatically. Writes a TSV next to the .xlsx so each
        # script in FinalReport can be audited end-to-end:
        # script_key | controller | step | candidate | score | count |
        # accepted | notes
        if getattr(self, '_lookup_trace_lines', None) is not None and self._lookup_trace_lines:
            trace_path = output_path + '.lookup-trace.tsv'
            try:
                with open(trace_path, 'w', encoding='utf-8') as tf:
                    tf.write('script_key\tcontroller\tstep\tcandidate\tscore\tcount\taccepted\tnotes\n')
                    for r in self._lookup_trace_lines:
                        tf.write('\t'.join(
                            str(r.get(k, '')).replace('\t', ' ').replace('\n', ' ')
                            for k in ('script_key', 'controller', 'step',
                                      'candidate', 'score', 'count',
                                      'accepted', 'notes')
                        ) + '\n')
                print(f"[lookup-trace] Wrote {len(self._lookup_trace_lines)} rows to {trace_path}")
            except Exception as ex:
                print(f"[lookup-trace] Failed to write trace TSV: {ex}")

        return output_path


def main():
    """Main function for testing the parser."""
    import sys
    import argparse
    
    arg_parser = argparse.ArgumentParser(description='Parse LoadRunner .lrr files and generate reports')
    arg_parser.add_argument('lrr_path', help='Path to .lrr file or results folder')
    arg_parser.add_argument('--output', '-o', help='Output folder for Excel report (default: same as results folder)')
    
    args = arg_parser.parse_args()
    
    lrr_path = args.lrr_path
    output_folder = args.output
    
    try:
        parser = LRRParser(lrr_path)
        data = parser.parse()
        
        print("\n" + "=" * 80)
        print(" LOADRUNNER RESULT ANALYSIS ")
        print("=" * 80)
        
        print("\n--- SCENARIO INFO ---")
        for key, value in data['scenario_info'].items():
            print(f"  {key}: {value}")
        
        print("\n--- TRANSACTION SUMMARY ---")
        print(f"{'Transaction Name':<60} {'Pass':>8} {'Fail':>8} {'Avg RT':>10} {'TPS':>10}")
        print("-" * 100)
        for trans in data['transaction_summary']:
            print(f"{trans['transaction_name']:<60} {trans['pass_count']:>8} {trans['fail_count']:>8} {trans['avg_response_time']:>10.3f} {trans['tps']:>10.4f}")
        
        print("\n--- ERRORS ---")
        if data['errors']:
            print(f"{'Script Name':<40} {'Error Description':<60} {'Count':>8}")
            print("-" * 110)
            for error in data['errors']:
                script = error.get('script_name', error.get('error_location', ''))
                desc = error.get('error_description', error.get('error_location', ''))
                count = error.get('error_count', 0)
                print(f"  {script:<38} {desc:<58} {count:>8}")
        else:
            print("  No errors recorded")
        
        # Export to Excel
        if EXCEL_AVAILABLE:
            if output_folder:
                # Save to custom output folder
                os.makedirs(output_folder, exist_ok=True)
                result_name = data['scenario_info'].get('result_name', 'LoadRunner_Report')
                excel_output = os.path.join(output_folder, f'{result_name}_Report.xlsx')
                excel_path = parser.export_to_excel(excel_output)
            else:
                excel_path = parser.export_to_excel()
            print(f"\n--- EXCEL REPORT ---")
            print(f"  Report exported to: {excel_path}")
        
    except FileNotFoundError as e:
        print(f"Error: {e}")
        sys.exit(1)
    except Exception as e:
        print(f"Error parsing file: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)


if __name__ == "__main__":
    main()
