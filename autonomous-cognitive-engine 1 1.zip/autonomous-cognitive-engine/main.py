'''from langchain_mistralai import ChatMistralAI

model = ChatMistralAI(
    mistral_api_key="MyEVojbpfeW6QKD31QdRYJadUtY99S2Z",
    model="mistral-large-latest"
)

response = model.invoke("explain llm")
print(response.content)'''

from graph import build_graph

def main():
    graph = build_graph()
    user_goal = input("Enter your goal: ")
    state = {
        "messages": [user_goal],
        "todos": [],
        "current_task": "",
        "files": {},
        "results": []
    }

    result = graph.invoke(state)
    print("\n===== FINAL REPORT =====\n")
    print(result["files"]["final_report.txt"])

 

if __name__ == "__main__":

    main()
