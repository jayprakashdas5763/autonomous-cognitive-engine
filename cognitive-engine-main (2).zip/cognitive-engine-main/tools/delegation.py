import re
from agents.researcher import researcher
from agents.summarizer import summarizer
from tools.datetime_tool import get_current_datetime
from logging_config import get_logger

logger = get_logger(__name__)

# Keywords that indicate the user wants a date/time lookup.
# Matched as whole words to avoid false positives (e.g. "update", "holiday").
_DATETIME_WORDS = frozenset([
    "date", "time", "today", "now", "morning", "night",
    "evening", "afternoon", "timestamp", "datetime", "clock",
])

# Keywords that indicate a research / web-search task.
_RESEARCH_WORDS = frozenset([
    "research", "search", "find", "investigate", "explore",
    "latest", "recent", "news", "trends", "trend",
    "what is", "what are", "who is", "who are",
    "overview", "facts", "information",
    # analytical tasks that benefit from web search
    "compare", "comparison", "analyze", "analysis", "examine",
    "how does", "how do", "differences", "similarities",
    "purpose", "features", "capabilities",
])


def _matches_any(text: str, keywords: frozenset) -> bool:
    """Return True if any keyword appears as a whole word/phrase in text."""
    for kw in keywords:
        # \b is a word boundary — prevents matching inside longer words
        # e.g. "\bday\b" does NOT match inside "holiday" or "update"
        pattern = r"\b" + re.escape(kw) + r"\b"
        if re.search(pattern, text, re.IGNORECASE):
            return True
    return False


def delegate(task: str) -> str:
    """Route a task to the appropriate agent or tool."""
    if not task or not task.strip():
        logger.warning("delegate() received an empty task.")
        return "No task provided."

    task_clean = task.strip()

    if _matches_any(task_clean, _DATETIME_WORDS):
        logger.info("Routing to datetime tool: %.60s", task_clean)
        return get_current_datetime()

    if _matches_any(task_clean, _RESEARCH_WORDS):
        logger.info("Routing to researcher: %.60s", task_clean)
        return researcher(task_clean)

    logger.info("Routing to summarizer: %.60s", task_clean)
    return summarizer(task_clean)