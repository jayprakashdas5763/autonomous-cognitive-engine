import streamlit as st
import os
from dotenv import load_dotenv
load_dotenv()  # Must run before setup_langsmith so .env vars are available
from logging_config import get_logger, setup_langsmith
setup_langsmith()
from graph import build_graph, MAX_EXECUTOR_ITERATIONS
from state import AgentState
import time
from io import BytesIO
try:
    from reportlab.lib.pagesizes import letter
    from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
    from reportlab.lib.units import inch
    from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, PageBreak
    REPORTLAB_AVAILABLE = True
except ImportError:
    REPORTLAB_AVAILABLE = False

logger = get_logger(__name__)

# Maximum number of characters allowed in the user goal input.
MAX_GOAL_LENGTH = 500


def normalize_report_markdown(report_text):
    """Convert legacy plain report output into readable markdown."""
    text = (report_text or "").strip()
    if not text:
        return "No report generated."

    if text.startswith("Research Result for:"):
        lines = [line.strip() for line in text.splitlines() if line.strip()]
        if len(lines) >= 3:
            requested_goal = lines[1]
            body = "\n".join(lines[2:])
            return f"# Research Brief\n\n## Goal\n{requested_goal}\n\n## Findings\n{body}"

    return text


def generate_pdf(goal: str, report_text: str) -> BytesIO:
    """Generate a PDF document from goal and report text. Returns BytesIO object."""
    if not REPORTLAB_AVAILABLE:
        return None
    
    pdf_buffer = BytesIO()
    doc = SimpleDocTemplate(pdf_buffer, pagesize=letter, topMargin=0.75*inch, bottomMargin=0.75*inch)
    
    styles = getSampleStyleSheet()
    story = []
    
    # Title
    title_style = ParagraphStyle(
        'CustomTitle',
        parent=styles['Heading1'],
        fontSize=24,
        textColor='#1a202c',
        spaceAfter=12,
        alignment=1
    )
    story.append(Paragraph("Autonomous Cognitive Engine Report", title_style))
    story.append(Spacer(1, 0.2*inch))
    
    # Goal section
    goal_style = ParagraphStyle(
        'CustomHeading',
        parent=styles['Heading2'],
        fontSize=14,
        textColor='#2d3748',
        spaceAfter=6
    )
    story.append(Paragraph("Goal", goal_style))
    story.append(Paragraph(goal[:200], styles['Normal']))
    story.append(Spacer(1, 0.15*inch))
    
    # Report section (simplified markdown to plain text)
    story.append(Paragraph("Report", goal_style))
    report_clean = report_text.replace("# ", "").replace("## ", "").replace("### ", "")[:3000]
    story.append(Paragraph(report_clean, styles['Normal']))
    
    doc.build(story)
    pdf_buffer.seek(0)
    return pdf_buffer

st.set_page_config(
    page_title="Autonomous Cognitive Engine",
    layout="wide",
    initial_sidebar_state="expanded",
    menu_items=None
)

# Custom CSS
st.markdown("""
    <style>
    [data-testid="stMainBlockContainer"] {
        padding-top: 2rem;
        padding-bottom: 2rem;
    }
    .header-title {
        text-align: center;
        margin-bottom: 1rem;
    }
    .task-item {
        background: #f8fafc;
        color: #111827;
        padding: 1rem 1.25rem;
        margin: 0.5rem 0;
        border: 1px solid #e5e7eb;
        border-left: 4px solid #667eea;
        border-radius: 8px;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
        font-size: 0.95rem;
        line-height: 1.5;
    }
    .task-item b {
        color: #111827;
    }
    .task-done-icon {
        color: #22c55e;
        font-weight: bold;
    }
    .task-pending-icon {
        color: #f59e0b;
    }
    .stat-box {
        background: white;
        padding: 1.5rem;
        border-radius: 10px;
        text-align: center;
        box-shadow: 0 4px 12px rgba(0, 0, 0, 0.08);
        margin: 0.5rem;
    }
    .stat-number {
        font-size: 2rem;
        font-weight: bold;
        color: #667eea;
    }
    .stat-label {
        color: #666;
        font-size: 0.9rem;
        margin-top: 0.5rem;
    }
    .task-card {
        background: #ffffff;
        color: #111827;
        padding: 1rem;
        border-radius: 10px;
        border: 1px solid #e5e7eb;
        margin-bottom: 0.8rem;
        font-weight: 500;
        box-shadow: 0 2px 8px rgba(0, 0, 0, 0.05);
    }
    .task-card * { color: #111827 !important; }
    .task-title {
        font-size: 1rem;
        font-weight: 700;
        margin-bottom: 0.35rem;
    }
    .task-description {
        font-size: 0.95rem;
        margin-bottom: 0.35rem;
    }
    .task-done { color: #22c55e !important; font-weight: bold; }
    .task-pending { color: #f59e0b !important; font-weight: bold; }
    .task-failed { color: #ef4444 !important; font-weight: bold; }
    .task-unknown { color: #6b7280 !important; font-weight: bold; }
    /* Sidebar metric cards — force readable text on white background */
    [data-testid="stSidebar"] [data-testid="stMetric"] {
        background: #ffffff !important;
        color: #111827 !important;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        padding: 0.75rem !important;
    }
    [data-testid="stSidebar"] [data-testid="stMetricValue"] {
        color: #111827 !important;
    }
    [data-testid="stSidebar"] [data-testid="stMetricLabel"] {
        color: #374151 !important;
    }
    [data-testid="stSidebar"] .stMetric {
        background: #ffffff !important;
        color: #111827 !important;
        border: 1px solid #e5e7eb;
        border-radius: 8px;
        padding: 0.75rem;
    }
    [data-testid="stSidebar"] .stMetric label,
    [data-testid="stSidebar"] .stMetric div {
        color: #111827 !important;
    }
    /* Pipeline workflow banner */
    .pipeline-banner {
        background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
        padding: 1rem 2rem;
        border-radius: 12px;
        margin-bottom: 1.25rem;
        text-align: center;
        box-shadow: 0 4px 12px rgba(102, 126, 234, 0.3);
    }
    .pipeline-text {
        color: white;
        font-size: 1.1rem;
        font-weight: 600;
        letter-spacing: 0.05em;
    }
    .input-label {
        color: #374151;
        font-size: 1.05rem;
        font-weight: 600;
        margin-bottom: 0.75rem;
    }
""", unsafe_allow_html=True)

# Header
st.markdown('<div class="header-title">', unsafe_allow_html=True)
col1, col2, col3 = st.columns([1, 2, 1])
with col2:
    st.markdown("# 🧠 Autonomous Cognitive Engine")
    st.markdown("*Intelligent task planning & execution with AI agents*")
st.markdown('</div>', unsafe_allow_html=True)

st.divider()

# --- Safe session state initialization ---
if "goal" not in st.session_state:
    st.session_state.goal = ""
if "result" not in st.session_state:
    st.session_state.result = ""
if "todos" not in st.session_state:
    st.session_state.todos = []
if "current_status" not in st.session_state:
    st.session_state.current_status = "Idle"
if "langsmith_enabled" not in st.session_state:
    st.session_state.langsmith_enabled = (
        os.getenv("LANGSMITH_TRACING", "").lower() == "true"
        and bool(os.getenv("LANGSMITH_API_KEY"))
    )
if "running" not in st.session_state:
    st.session_state.running = False
if "elapsed" not in st.session_state:
    st.session_state.elapsed = None

# --- Sidebar (status, stats, observability) ---
with st.sidebar:
    st.markdown("## 🧠 Autonomous Cognitive Engine")
    st.caption(
        "Multi-agent research assistant powered by LangGraph, Mistral, Tavily, "
        "and optional LangSmith tracing."
    )

    st.divider()

    # Run status
    _status = st.session_state.get("current_status", "Idle")
    _status_icon = {
        "Idle": "🟦",
        "Running": "🟡",
        "Completed": "🟢",
        "Failed": "🔴",
    }.get(_status, "⚪")
    st.markdown(f"**Run Status:** {_status_icon} {_status}")

    # Current goal preview
    _current_goal = st.session_state.get("goal", "")
    if _current_goal:
        st.markdown("**Current Goal:**")
        st.info(
            _current_goal[:150] + ("..." if len(_current_goal) > 150 else "")
        )

    st.divider()

    # Task stats
    st.markdown("### 📋 Task Stats")
    _sb_todos = st.session_state.get("todos", [])
    _sb_total = len(_sb_todos)
    _sb_done = len([t for t in _sb_todos if t.get("status") == "done"])
    _sb_pending = len([t for t in _sb_todos if t.get("status") == "pending"])
    _sb_failed = len([t for t in _sb_todos if t.get("status") == "failed"])

    _ca, _cb = st.columns(2)
    _ca.metric("Total", _sb_total)
    _cb.metric("Completed", _sb_done)
    _ca.metric("Pending", _sb_pending)
    _cb.metric("Failed", _sb_failed)

    st.divider()

    # LangSmith observability
    st.markdown("### 🔭 Observability")
    if st.session_state.get("langsmith_enabled", False):
        _ls_project = os.getenv("LANGSMITH_PROJECT", "cognitive-engine")
        st.success("**LangSmith:** Enabled")
        st.markdown(f"**Project:** `{_ls_project}`")
        st.markdown("[Open LangSmith Dashboard](https://smith.langchain.com)")
    else:
        st.warning("**LangSmith:** Disabled")
        st.caption(
            "Add `LANGSMITH_TRACING=true` and `LANGSMITH_API_KEY` in `.env` "
            "to enable tracing."
        )

# Input Section
st.markdown('''
    <div class="pipeline-banner">
        <span class="pipeline-text">Plan &rarr; Execute &rarr; Research &rarr; Summarize &rarr; Report</span>
    </div>
''', unsafe_allow_html=True)
st.markdown('<p class="input-label">🎯 What do you want to accomplish?</p>', unsafe_allow_html=True)

col1, col2 = st.columns([5, 1])
with col1:
    user_goal = st.text_input(
        "Enter your goal:",
        placeholder="e.g., Research the latest AI breakthroughs and create a summary",
        label_visibility="collapsed",
        key="goal_input"
    )

with col2:
    run_button = st.button("Execute", use_container_width=True, type="primary", key="run_btn")

# Process
if run_button and user_goal:
    goal_clean = user_goal.strip()

    # --- Input validation ---
    if not goal_clean:
        st.error("Please enter a goal before clicking Execute.")
    elif len(goal_clean) > MAX_GOAL_LENGTH:
        st.error(
            f"Goal is too long ({len(goal_clean)} characters). "
            f"Please keep it under {MAX_GOAL_LENGTH} characters."
        )
    else:
        st.session_state.running = True
        st.session_state.current_status = "Running"

        try:
            t_total_start = time.perf_counter()

            # st.status shows a live expandable panel that updates as steps run
            with st.status("Running Cognitive Engine...", expanded=True) as status:
                st.write("🔄 Step 1 / 3 — Building task plan with Mistral...")
                graph = build_graph()
                state: AgentState = {
                    "messages": [goal_clean],
                    "todos": [],
                    "current_task": "",
                    "files": {},
                    "results": [],
                    "goal": "",  # Will be populated by planner_node
                }

                logger.info("Starting graph execution for goal: %.80s", goal_clean)

                # Run the full graph (planner + executor loop + synthesizer)
                st.write("🚀 Step 2 / 3 — Executing tasks (web search & summarization)...")
                result = graph.invoke(
                    state,
                    config={"recursion_limit": MAX_EXECUTOR_ITERATIONS}
                )

                st.write("✨ Step 3 / 3 — Synthesizing final report...")

                t_total_elapsed = time.perf_counter() - t_total_start
                status.update(
                    label=f"✅ Done in {t_total_elapsed:.1f}s",
                    state="complete",
                    expanded=False
                )

            st.session_state.result = result["files"].get("final_report.txt", "No results")
            st.session_state.goal = goal_clean
            st.session_state.todos = result.get("todos", [])
            st.session_state.elapsed = round(t_total_elapsed, 1)
            st.session_state.current_status = "Completed"
            logger.info("[TIMING] Total wall-clock time: %.2fs", t_total_elapsed)

            st.session_state.running = False
            st.rerun()

        except Exception as e:
            error_str = str(e).lower()
            if "api_key" in error_str or "mistral" in error_str:
                st.error(
                    "❌ **API Configuration Issue**\n\n"
                    "The application cannot connect to Mistral AI. Please ensure:\n"
                    "1. You have a valid Mistral API key from https://console.mistral.ai/\n"
                    "2. It is set in `.env` as `MISTRAL_API_KEY=your_key_here`\n"
                    "3. The `.env` file is in the project root directory"
                )
            elif "tavily" in error_str:
                st.error(
                    "❌ **Search Service Issue**\n\n"
                    "The application cannot connect to Tavily search. Please ensure:\n"
                    "1. You have a valid Tavily API key from https://app.tavily.com/\n"
                    "2. It is set in `.env` as `TAVILY_API_KEY=your_key_here`\n"
                    "3. Your API key has not exceeded rate limits"
                )
            elif "recursion" in error_str:
                st.error(
                    "❌ **Task Execution Limit Reached**\n\n"
                    "The engine couldn't complete your goal within the maximum number of steps.\n"
                    "Try simplifying your request or breaking it into smaller goals."
                )
            else:
                st.error(
                    "❌ **Unexpected Error**\n\n"
                    "Something went wrong. Try again or simplify your goal.\n\n"
                    f"*Debug info: {str(e)[:100]}*"
                )
            logger.error("Graph execution error: %s", e)
            st.session_state.running = False
            st.session_state.current_status = "Failed"

# Display results
if st.session_state.result:
    st.divider()

    # Stats
    st.markdown("### 📊 Execution Summary")
    stats_col1, stats_col2, stats_col3, stats_col4 = st.columns(4)

    with stats_col1:
        st.markdown(f'''
            <div class="stat-box">
                <div class="stat-number">{len(st.session_state.todos)}</div>
                <div class="stat-label">Tasks Planned</div>
            </div>
        ''', unsafe_allow_html=True)

    with stats_col2:
        completed = sum(1 for t in st.session_state.todos if t.get("status") == "done")
        st.markdown(f'''
            <div class="stat-box">
                <div class="stat-number">{completed}</div>
                <div class="stat-label">Tasks Completed</div>
            </div>
        ''', unsafe_allow_html=True)

    with stats_col3:
        st.markdown('''
            <div class="stat-box">
                <div class="stat-number">100%</div>
                <div class="stat-label">Success Rate</div>
            </div>
        ''', unsafe_allow_html=True)

    with stats_col4:
        elapsed_display = f"{st.session_state.elapsed}s" if st.session_state.elapsed else "N/A"
        st.markdown(f'''
            <div class="stat-box">
                <div class="stat-number">{elapsed_display}</div>
                <div class="stat-label">Total Time</div>
            </div>
        ''', unsafe_allow_html=True)

    # Task breakdown with summary metrics + status cards
    todos = st.session_state.get("todos", [])
    if todos:
        st.markdown("### 📋 Task Breakdown")

        # Summary metrics
        total_tasks = len(todos)
        completed_tasks = len([t for t in todos if t.get("status") == "done"])
        pending_tasks = len([t for t in todos if t.get("status") == "pending"])
        failed_tasks = len([t for t in todos if t.get("status") == "failed"])

        m1, m2, m3, m4 = st.columns(4)
        m1.metric("Total Tasks", total_tasks)
        m2.metric("Completed", completed_tasks)
        m3.metric("Pending", pending_tasks)
        m4.metric("Failed", failed_tasks)

        st.markdown("")  # vertical spacer

        # Status-aware cards
        icon_map = {"done": "✅", "pending": "⏳", "failed": "❌"}
        for i, task in enumerate(todos, 1):
            task_id = task.get("id", i)
            description = task.get("description", "N/A")
            status = task.get("status", "unknown")
            icon = icon_map.get(status, "⚪")
            status_class = (
                f"task-{status}"
                if status in ("done", "pending", "failed")
                else "task-unknown"
            )
            st.markdown(f'''
                <div class="task-card">
                    <div class="task-title">{icon} Task {task_id}</div>
                    <div class="task-description">{description}</div>
                    <div class="{status_class}">Status: {status}</div>
                </div>
            ''', unsafe_allow_html=True)

    # Results
    st.divider()
    with st.container(border=True):
        st.markdown("### 📄 Final Report")
        formatted_report = normalize_report_markdown(st.session_state.result)
        formatted_tab, raw_tab = st.tabs(["Formatted", "Raw text"])

        with formatted_tab:
            st.markdown(formatted_report)

        with raw_tab:
            st.text_area(
                "Result:",
                value=st.session_state.result,
                height=300,
                disabled=True,
                label_visibility="collapsed"
            )

    # Download section
    col1, col2, col3, col4 = st.columns([1, 1, 1, 1])
    with col1:
        st.download_button(
            label="📥 Download Report",
            data=formatted_report,
            file_name="report.md",
            mime="text/markdown",
            use_container_width=True
        )
    with col2:
        if REPORTLAB_AVAILABLE:
            _pdf_goal = st.session_state.get("goal", "Autonomous Cognitive Engine Report")
            _pdf_result = st.session_state.get("result", formatted_report)
            pdf_buffer = generate_pdf(_pdf_goal, _pdf_result)
            if pdf_buffer:
                st.download_button(
                    label="📄 Download PDF",
                    data=pdf_buffer,
                    file_name="report.pdf",
                    mime="application/pdf",
                    use_container_width=True
                )
        else:
            st.button("📄 PDF (install reportlab)", disabled=True, use_container_width=True)
    with col3:
        if st.button("🔄 New Task", use_container_width=True):
            st.session_state.result = ""
            st.session_state.goal = ""
            st.session_state.todos = []
            st.session_state.elapsed = None
            st.session_state.current_status = "Idle"
            st.rerun()

    st.success("✨ Task completed successfully!")

# Footer
st.divider()
st.markdown("""
    <div style="text-align: center; color: #888; font-size: 0.85rem; margin-top: 2rem;">
    <p>🤖 Powered by LangGraph & Mistral AI | 🔍 Web Search by Tavily</p>
    </div>
""", unsafe_allow_html=True)
