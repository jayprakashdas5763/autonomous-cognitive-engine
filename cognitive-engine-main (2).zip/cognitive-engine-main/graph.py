from langgraph.graph import StateGraph, END
from state import AgentState
from nodes.planner import planner_node
from nodes.executor import executor_node
from nodes.synthesizer import synthesizer_node
from logging_config import get_logger

logger = get_logger(__name__)

# Maximum number of executor loop iterations before LangGraph stops.
# Import this constant in app.py / main.py to keep the limit consistent.
MAX_EXECUTOR_ITERATIONS = 25


def build_graph():
    graph = StateGraph(AgentState)
    graph.add_node("planner", planner_node)
    graph.add_node("executor", executor_node)
    graph.add_node("synthesizer", synthesizer_node)
    graph.set_entry_point("planner")
    graph.add_edge("planner", "executor")

    def check_done(state):
        todos = state.get("todos", [])

        # No tasks at all — go straight to synthesizer
        if not todos:
            logger.warning("No todos in state; routing directly to synthesizer.")
            return True

        # Use .get() so a missing "status" key doesn’t crash the check
        done = all(task.get("status") == "done" for task in todos)
        pending = sum(1 for t in todos if t.get("status") != "done")

        if done:
            logger.info("All %d task(s) completed. Moving to synthesizer.", len(todos))
        else:
            logger.debug("%d task(s) still pending.", pending)

        return done

    graph.add_conditional_edges(
        "executor",
        check_done,
        {
            True: "synthesizer",
            False: "executor",
        },
    )

    graph.add_edge("synthesizer", END)

    return graph.compile()