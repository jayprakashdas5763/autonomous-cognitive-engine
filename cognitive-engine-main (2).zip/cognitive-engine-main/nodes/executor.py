﻿import time
from tools.delegation import delegate
from tools.file_system import write_file
from logging_config import get_logger

logger = get_logger(__name__)


def executor_node(state):
    for task in state["todos"]:
        if task.get("status") == "pending":
            task_id = task.get("id", "?")
            description = task.get("description", "")
            logger.info("Executing task %s: %.80s", task_id, description)
            t_start = time.perf_counter()
            try:
                result = delegate(description)
                elapsed = time.perf_counter() - t_start
                state["results"].append(result)
                filename = f"task_{task_id}.txt"
                write_file(state, filename, result)
                task["status"] = "done"
                logger.info("[TIMING] Task %s completed in %.2fs.", task_id, elapsed)
            except Exception as exc:
                elapsed = time.perf_counter() - t_start
                logger.error("Task %s failed after %.2fs: %s", task_id, elapsed, exc)
                # Mark done to avoid an infinite loop on a broken task
                task["status"] = "done"
                state["results"].append(f"Task {task_id} failed: {exc}")
            break  # Execute one task per node visit

    return state
