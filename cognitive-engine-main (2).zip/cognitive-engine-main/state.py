from typing import TypedDict, List, Dict

class AgentState(TypedDict):

    messages: List[str]

    todos: List[dict]

    current_task: str

    files: Dict[str, str]

    results: List[str]

    goal: str  # Original user goal stored by planner; used by synthesizer