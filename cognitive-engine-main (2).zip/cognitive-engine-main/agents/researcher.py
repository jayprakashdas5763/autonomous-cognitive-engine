import time
from tools.search_tool import web_search
from agents.summarizer import summarize_research
from logging_config import get_logger

logger = get_logger(__name__)


def _parse_sources(raw_result):
    sources = []
    for block in [part.strip() for part in raw_result.split("\n\n") if part.strip()]:
        title = "Untitled source"
        url = ""
        snippet = ""

        for line in block.splitlines():
            line = line.strip()
            if line.startswith("Title:"):
                title = line.replace("Title:", "", 1).strip()
            elif line.startswith("URL:"):
                url = line.replace("URL:", "", 1).strip()
            elif line.startswith("Snippet:"):
                snippet = line.replace("Snippet:", "", 1).strip()

        if snippet:
            sources.append({"title": title, "url": url, "snippet": snippet})

    return sources


def _fallback_markdown_report(task, raw_result):
    sources = _parse_sources(raw_result)
    key_points = sources[:5]

    report_lines = [
        "# AI Breakthrough Brief",
        "",
        "## Goal",
        task,
        "",
        "## Key Developments",
    ]

    if key_points:
        for item in key_points:
            report_lines.append(f"- {item['snippet']}")
    else:
        report_lines.append("- No concise highlights were extracted from search results.")

    report_lines.extend(["", "## Sources"])

    if sources:
        for item in sources:
            if item["url"] and item["url"] != "N/A":
                report_lines.append(f"- [{item['title']}]({item['url']})")
            else:
                report_lines.append(f"- {item['title']}")
    else:
        report_lines.append("- No sources found.")

    return "\n".join(report_lines)

def researcher(task):
    t_start = time.perf_counter()
    raw_result = web_search(task)
    if raw_result.startswith("Error during web search"):
        return raw_result

    formatted_report = summarize_research(task, raw_result)
    if formatted_report.startswith("Error during research report synthesis"):
        result = _fallback_markdown_report(task, raw_result)
    else:
        result = formatted_report

    elapsed = time.perf_counter() - t_start
    logger.info("[TIMING] Full researcher pipeline took %.2fs", elapsed)
    return result
