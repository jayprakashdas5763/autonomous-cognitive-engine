from typing import TypedDict, List, Dict

class AgentState(TypedDict):

    messages: List[str]
    todos: List[dict]
    current_task: str
    files: Dict[str, str]
    results: List[str]  
    needs_retry: bool
    retry_count: int
    max_tasks: int
    
    research_percentage: int
    code_percentage: int
    summarizer_percentage: int
