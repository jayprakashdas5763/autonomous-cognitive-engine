from langchain_mistralai.chat_models import ChatMistralAI
from dotenv import load_dotenv

load_dotenv()

llm = ChatMistralAI(
    model="mistral-small",
    temperature=0.3
)

def summarizer(text):

    prompt = f"""
Provide a clear and complete answer in 80-100 words.

Rules:
- Keep sentences COMPLETE (no cutting)
- Use simple, professional language
- Use 2–3 short bullet points if helpful
- Do NOT exceed 100 words
- Always use "." after a sentence complete

Topic:
{text}
"""

    response = llm.invoke(prompt)
    return response.content.strip()
