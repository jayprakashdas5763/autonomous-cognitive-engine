from tools.search_tool import web_search
from agents.summarizer import summarizer

def researcher(task):

    raw_data = web_search(task)

    # ✅ Summarize search result
    return summarizer(raw_data)
