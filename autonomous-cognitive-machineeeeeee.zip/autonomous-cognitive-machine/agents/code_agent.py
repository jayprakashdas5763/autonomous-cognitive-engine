from langchain_mistralai.chat_models import ChatMistralAI
from dotenv import load_dotenv

load_dotenv()

llm = ChatMistralAI(
    model="mistral-small",
    temperature=0.2
)


def code_agent(task):
    prompt = f"""
You are a professional software engineer.

Task:
{task}

Instructions:
- Provide a working code solution for the requested language.
- If the user asks for a script or function, include only the code block and a brief explanation.
- Do NOT include analysis or unrelated commentary.
- If the task is not a coding request, respond briefly that this is not a code task.
- Keep the response concise and directly useful.

Deliverable:
"""

    response = llm.invoke(prompt)
    return response.content.strip()
