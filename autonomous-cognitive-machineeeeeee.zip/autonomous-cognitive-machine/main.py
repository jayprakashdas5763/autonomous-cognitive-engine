from graph import build_graph

def main():
    graph = build_graph()

    user_goal = input("Enter your goal: ")

    state = {
    "messages": [user_goal],
    "todos": [],
    "current_task": "",
    "files": {},
    "results": [],
    "needs_retry": False,
    "retry_count": 0,
    "max_tasks": 6


    }

    result = graph.invoke(state)

    # ✅ Show TODOs
    print("\n===== GENERATED TODO TASKS =====\n")

    for i, task in enumerate(result.get("todos", []), 1):
        print(f"{i}. {task['title']}")
        print(f"   → {task['description']}")
        print(f"   Status: {'✅ done' if task['status']=='done' else '⏳ pending'}\n")

    # ✅ Show memory files
    print("\n===== VIRTUAL MEMORY FILES =====\n")

    for file_name in result.get("files", {}):
        print(f"📄 {file_name}")

    # ✅ Final report
    print("\n===== FINAL REPORT =====\n")
    print(result["files"].get("final_report.txt", "No report generated"))

if __name__ == "__main__":
    main()