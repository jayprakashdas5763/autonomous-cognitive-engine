def reviewer_node(state):
    last_result = state["results"][-1]

    # ✅ trim result for faster checking
    last_result = last_result.strip()[:300]

    # ✅ initialize retry_count
    if "retry_count" not in state:
        state["retry_count"] = 0

    # ✅ better quality check (less strict = fewer retries)
    if len(last_result) < 50 or "error" in last_result.lower() or "not sure" in last_result.lower():

        # ✅ retry logic (max 2 times)
        if state["retry_count"] < 2:
            state["needs_retry"] = True
            state["retry_count"] += 1
            print(f"🔁 Retrying task (attempt {state['retry_count']})")
        else:
            state["needs_retry"] = False
            state["retry_count"] = 0
            print("⚠️ Max retries reached, continuing...")

    else:
        state["needs_retry"] = False
        state["retry_count"] = 0
        print("✅ Task passed review")

    return state