import code
from xml.sax.saxutils import escape
from reportlab.lib.pagesizes import letter
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer
from reportlab.lib.styles import getSampleStyleSheet
import state
from tools.agent_metrics import calculate_agent_contribution


def create_pdf(text, filename="final_report.pdf"):

    doc = SimpleDocTemplate(filename, pagesize=letter)
    styles = getSampleStyleSheet()
    normal_style = styles["Normal"]

    story = []

    # ✅ clean markdown-like formatting and escape XML/HTML characters
    text = text.replace("**", "")
    text = text.replace("- ", "• ")

    lines = text.split("\n")

    for line in lines:
        if line.strip():
            safe_line = escape(line)
            story.append(Paragraph(safe_line, normal_style))
            story.append(Spacer(1, 10))

    doc.build(story)



def synthesizer_node(state):

    final_output = []

    for content in state["files"].values():
        final_output.append(content.strip())

    final_text = "\n\n".join(final_output)

    # ✅ Save text version
    state["files"]["final_report.txt"] = final_text

    # ✅ CREATE PDF FILE
    create_pdf(final_text)

    # ✅ Store info (optional)
    state["files"]["final_report.pdf"] = "PDF Generated"

    research, code, summary = calculate_agent_contribution(
    state["todos"]
)
   

    state["research_percentage"] = research
    state["code_percentage"] = code
    state["summarizer_percentage"] = summary

    return state
