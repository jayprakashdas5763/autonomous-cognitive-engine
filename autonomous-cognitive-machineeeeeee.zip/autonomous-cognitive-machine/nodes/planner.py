from tools.planning import write_todos

def planner_node(state):
    goal = state["messages"][-1]

    raw_todos = write_todos(goal)

    structured_todos = []

    for item in raw_todos:
        structured_todos.append({
            "title": item.get("title", "Untitled Task"),
            "description": item.get("description", "No description"),
            "status": "pending"
        })

    state["todos"] = structured_todos

    return state