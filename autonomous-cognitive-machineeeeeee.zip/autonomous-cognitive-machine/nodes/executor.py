from tools.delegation import delegate
from tools.file_system import write_file


def executor_node(state):

    for i, task in enumerate(state["todos"], start=1):

        if task["status"] == "pending":

            # =====================================================
            # CURRENT TASK
            # =====================================================

            state["current_task"] = task["description"]

            # =====================================================
            # DELEGATE TASK TO CORRECT AGENT
            # =====================================================

            agent, result = delegate(task["description"])
           
            task["agent"] = agent
           

            # =====================================================
            # STORE WHICH AGENT EXECUTED THE TASK
            # =====================================================
            

            # =====================================================
            # CLEAN RESULT
            # =====================================================

            result = result.strip()

            # =====================================================
            # STORE RESULT IN MEMORY
            # =====================================================

            state["results"].append(result)

            # =====================================================
            # SAVE RESULT AS FILE
            # =====================================================

            filename = f"task_{i}.txt"

            write_file(state, filename, result)

            # =====================================================
            # UPDATE FILE LIST
            # =====================================================

            state["file_names"] = list(state["files"].keys())

            # =====================================================
            # MARK TASK COMPLETED
            # =====================================================

            task["status"] = "done"

            # =====================================================
            # EXECUTE ONLY ONE TASK PER GRAPH ITERATION
            # =====================================================

            break

    return state