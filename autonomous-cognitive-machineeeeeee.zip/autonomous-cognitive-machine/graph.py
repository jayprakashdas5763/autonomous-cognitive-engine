from langgraph.graph import StateGraph, END
from state import AgentState
from nodes.planner import planner_node
from nodes.executor import executor_node
from nodes.synthesizer import synthesizer_node
from nodes.reviewer import reviewer_node

def build_graph():
    graph = StateGraph(AgentState)

    # ✅ Nodes
    graph.add_node("planner", planner_node)
    graph.add_node("executor", executor_node)
    graph.add_node("reviewer", reviewer_node)
    graph.add_node("synthesizer", synthesizer_node)

    # ✅ Start
    graph.set_entry_point("planner")

    # ✅ Correct Flow
    graph.add_edge("planner", "executor")
    graph.add_edge("executor", "reviewer")   # ✅ FIXED

    # ✅ Condition logic
    def review_condition(state):

        completed = sum(1 for t in state["todos"] if t["status"] == "done")

        # ✅ finish when ALL tasks done
        if completed >= len(state["todos"]):
            return "synthesizer"

        # ✅ retry failed task
        if state["needs_retry"]:
            return "executor"

        # ✅ continue next task
        for task in state["todos"]:
            if task["status"] == "pending":
                return "executor"

        return "synthesizer"

    # ✅ Conditional routing
    graph.add_conditional_edges(
        "reviewer",
        review_condition,
        {
            "executor": "executor",
            "synthesizer": "synthesizer"
        }
    )

    # ✅ End
    graph.add_edge("synthesizer", END)

    return graph.compile()
