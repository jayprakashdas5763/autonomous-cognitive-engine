def calculate_agent_contribution(todos):

    research = 0
    code = 0
    summary = 0

    total = len(todos)

    if total == 0:
        return 0, 0, 0

    for task in todos:

        agent = task.get("agent", "").lower()

        if "research" in agent:
            research += 1

        elif "code" in agent:
            code += 1

        elif "summary" in agent or "summarizer" in agent:
            summary += 1

    research_percentage = round(research * 100 / total)
    code_percentage = round(code * 100 / total)
    summary_percentage = round(summary * 100 / total)

    return (
        research_percentage,
        code_percentage,
        summary_percentage
    )