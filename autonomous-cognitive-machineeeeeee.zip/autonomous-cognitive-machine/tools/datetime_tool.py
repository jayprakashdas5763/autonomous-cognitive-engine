from datetime import datetime

def get_current_datetime():
    now = datetime.now()

    current_date = now.strftime("%A, %d %B %Y")
    current_time = now.strftime("%I:%M %p")

    hour = now.hour

    if 5<=hour < 12:
        greeting = "Good Morning..."
    elif 12<= hour < 17:
        greeting = "Good Afternoon..."
    elif 17<= hour < 21:
        greeting = "Good Evening..."
    else:
        greeting = "Good Night..."

    return f"""
{greeting}
Today is:
{current_date}
Current Time:
{current_time}
"""
