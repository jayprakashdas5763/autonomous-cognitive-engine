'''from tavily import TavilyClient
from dotenv import load_dotenv

import os

load_dotenv()

client = TavilyClient(
    api_key=os.getenv("TAVILY_API_KEY")
)


def web_search(query):
    response = client.search(
        query=query,
        max_results=3
    )

    results = []

    for r in response["results"]:
        results.append(
            f"{r['title']}\n{r['content']}"
        )

    return "\n\n".join(results)'''

from tavily import TavilyClient
from dotenv import load_dotenv
import os

# Load .env
load_dotenv()

# Get API key
api_key = os.getenv("TAVILY_API_KEY")
print("API Key:", api_key)  # Debug print

# Initialize client
client = TavilyClient(api_key=api_key)

# Function
def web_search(query):
    response = client.search(
        query=query,
        max_results=3
    )

    results = []

    for r in response["results"]:
        results.append(
            f"{r['title']}\n{r['content']}"
        )

    return "\n\n".join(results)

