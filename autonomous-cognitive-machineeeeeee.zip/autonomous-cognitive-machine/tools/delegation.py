from agents.code_agent import code_agent
from agents.researcher import researcher
from agents.summarizer import summarizer
from tools.datetime_tool import get_current_datetime

# =========================================================
# CODE DETECTION RULES
# =========================================================

CODE_STRONG_CODE_TRIGGERS = [
    "write a python",
    "write a javascript",
    "write a java",
    "write a typescript",
    "write a c#",
    "write a c++",
    "write a bash",
    "write a shell",
    "write a sql",
    "implement a python",
    "implement a javascript",
    "implement a function",
    "implement a class",
    "create a python",
    "create a javascript",
    "create a script",
    "build a script",
    "generate code",
    "generate a script",
    "generate a function"
]

CODE_WEAK_CODE_TRIGGERS = [
    "write a",
    "write an",
    "write the",
    "implement",
    "create a",
    "create an",
    "build a",
    "build an",
    "generate a",
    "generate an",
    "fix ",
    "debug ",
    "refactor",
    "translate",
    "convert",
    "code snippet",
    "code example",
    "program",
    "script",
    "api",
    "endpoint"
]

CODE_LANGUAGE_TERMS = [
    "python",
    "javascript",
    "java",
    "typescript",
    "c#",
    "c++",
    "go",
    "rust",
    "ruby",
    "php",
    "bash",
    "shell",
    "sql",
    "html",
    "css",
    "react",
    "node",
    "express",
    "django",
    "flask",
    "fastapi"
]

CODE_FALLBACK_PHRASES = [
    "not a code task",
    "not a coding task",
    "not related to coding",
    "cannot provide code",
    "cannot complete this as code",
    "no code task",
    "no coding task",
    "not a code request",
    "not a coding request"
]

# =========================================================
# DETECT CODE TASK
# =========================================================

def is_code_task(task_lower: str):

    if any(trigger in task_lower for trigger in CODE_STRONG_CODE_TRIGGERS):
        return True

    if any(trigger in task_lower for trigger in CODE_WEAK_CODE_TRIGGERS) and any(
        keyword in task_lower
        for keyword in [
            "code",
            "script",
            "function",
            "class",
            "program",
            "library",
            "app",
            "api",
            "endpoint",
        ] + CODE_LANGUAGE_TERMS
    ):
        return True

    return False


# =========================================================
# DELEGATION ROUTER
# =========================================================

def delegate(task):

    task_lower = task.lower()

    # -----------------------------------------------------
    # DATE / TIME TOOL
    # -----------------------------------------------------

    if any(phrase in task_lower for phrase in [
        "current date",
        "current time",
        "today's date",
        "today date",
        "what time",
        "what is the time",
        "now time",
        "current day"
    ]):

        result = get_current_datetime()

        return "tool", result


    # -----------------------------------------------------
    # RESEARCH AGENT
    # -----------------------------------------------------

    if any(word in task_lower for word in [
        "research",
        "study",
        "analyze",
        "analyse",
        "explore",
        "investigate",
        "compare",
        "find",
        "collect",
        "information"
    ]):

        print("🔍 Research Agent Selected")

        result = researcher(task)

        return "research", result.strip()


    # -----------------------------------------------------
    # CODE AGENT
    # -----------------------------------------------------

    if is_code_task(task_lower):

        print("💻 Code Agent Selected")

        code_result = code_agent(task).strip()

        result_lower = code_result.lower()

        if any(x in result_lower for x in CODE_FALLBACK_PHRASES) or len(code_result) < 30:

            print("⚠ Code Agent returned poor output.")
            print("➡ Switching to Summarizer Agent")

            summary = summarizer(task)

            return "summary", summary.strip()

        return "code", code_result.strip()


    # -----------------------------------------------------
    # SUMMARIZER AGENT
    # -----------------------------------------------------

    print("📝 Summarizer Agent Selected")

    summary = summarizer(task)

    return "summary", summary.strip()