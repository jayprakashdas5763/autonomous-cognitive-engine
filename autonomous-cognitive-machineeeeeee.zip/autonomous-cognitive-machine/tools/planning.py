from langchain_mistralai.chat_models import ChatMistralAI

from dotenv import load_dotenv

load_dotenv()

llm = ChatMistralAI(

    model="mistral-large-latest",

    temperature=0.3

)

def write_todos(goal):

    prompt = f"""

You are an expert AI Planner.

Break the user's goal into 4 to 6 actionable tasks.

Rules:

- One task per line

- No numbering

- No bullet points

- No JSON

- No explanations

- Tasks must be specific

- Tasks must be unique

- Tasks must help accomplish the goal

Goal:

{goal}

"""

    try:

        response = llm.invoke(prompt).content.strip()

        lines = [

            line.strip("-•1234567890. ")

            for line in response.split("\n")

            if line.strip()

        ]

        todos = []

        for i, task in enumerate(lines, start=1):

            todos.append({

                "id": i,

                "description": task,

                "status": "pending"

            })

        if len(todos) >= 3:

            return todos

    except Exception as e:

        print("Planner Error:", e)

    # Fallback Tasks

    import re
from langchain_mistralai.chat_models import ChatMistralAI
from dotenv import load_dotenv

load_dotenv()

# ✅ Use optimized model
llm = ChatMistralAI(
    model="mistral-small",
    temperature=0.3
)

def write_todos(goal):

    prompt = f"""
You are an expert AI Task Planner.

Your job is to break a user goal into HIGH-QUALITY, PRACTICAL, and ACTIONABLE tasks.

TASK REQUIREMENTS:
- Generate 4 to 6 tasks depending on complexity
- Each task must represent a DIFFERENT aspect of the goal
- Tasks must be SPECIFIC and REAL-WORLD focused
- Do NOT repeat words or phrases from the goal
- Do NOT use generic words like "introduction", "basics", "overview"
- Each task should describe a clear action or exploration step

FORMAT RULES:
- One task per line
- NO numbering
- NO bullet points
- NO symbols
- NO explanation before or after
- Only plain task sentences

GOOD EXAMPLE:

Goal: Explore AI in Healthcare

Output:
Analyze how AI is used in medical diagnosis systems  
Study AI-powered robotic surgical technologies  
Examine AI applications in drug discovery and research  
Explore real-time patient monitoring using AI  
Evaluate challenges in implementing AI in healthcare  

BAD EXAMPLE (DO NOT DO THIS):
Basics of AI in healthcare  
Introduction to AI in healthcare  
Overview of AI  

NOW CREATE TASKS FOR:

Goal:
{goal}
"""


    try:
        response = llm.invoke(prompt).content.strip()

        # ✅ Clean response
        lines = [
            line.strip("-•1234567890. ")
            for line in response.split("\n")
            if line.strip()
        ]

        todos = []

        for i, task in enumerate(lines, start=1):
            todos.append({
                "id": i,
                "description": task,
                "status": "pending"
            })

        # ✅ Keep only valid number of tasks (4–6)
        if len(todos) < 4:
            raise Exception("Too few tasks")

        if len(todos) > 6:
            todos = todos[:6]

        return todos

    except Exception as e:
        print("Planner Error:", e)

    # ✅ ✅ ✅ DYNAMIC FALLBACK (FIXED ✅)

    fallback_tasks = [
        f"Understand key concepts of {goal}",
        "Identify core methods and techniques",
        "Explore practical real-world applications",
        "Analyze challenges and limitations",
        "Compare with similar approaches",
        "Summarize key insights and findings"
    ]

    todos = []

    for i, task in enumerate(fallback_tasks, start=1):
        todos.append({
            "id": i,
            "description": task,
            "status": "pending"
        })

    # ✅ Return consistent number (4–6)
    return todos[:5]


