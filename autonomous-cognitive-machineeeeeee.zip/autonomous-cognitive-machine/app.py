import streamlit as st
from graph import build_graph

# =========================================================
# PAGE CONFIG
# =========================================================

st.set_page_config(
    page_title="Cognix",
    page_icon="🤖",
    layout="wide",
)
# =========================================================
# SESSION STATE INITIALIZATION
# =========================================================

if "research" not in st.session_state:
    st.session_state["research"] = 0

if "code" not in st.session_state:
    st.session_state["code"] = 0

if "summary" not in st.session_state:
    st.session_state["summary"] = 0

# =========================================================
# CUSTOM CSS
# =========================================================

st.markdown("""
<style>

.stApp {
    background: radial-gradient(circle at top left, #1e3a8a 0%, #020617 60%);
}



.block-container {
    padding-top: 2rem;
    padding-bottom: 2rem;
}

h1 {
    color: white;
    text-align: center;
    font-size: 3rem;
    margin-bottom: 0.5rem;
}

h2, h3 {
    color: white;
}

.stTextArea textarea {
    background: rgba(30,41,59,0.6);
    color: white;
    border-radius: 16px;
    border: 1px solid rgba(255,255,255,0.1);
    backdrop-filter: blur(10px);
}

.stButton button { 
    width: auto;
    padding: 0 25px;
    height: 3rem;
    border-radius: 12px;
    background: linear-gradient(135deg, #3b82f6, #6366f1, #8b5cf6);
    color: white;
    font-size: 18px;
    font-weight: bold;
    border: none;
}

.stButton button:hover {
    background: linear-gradient(135deg, #2563eb, #4f46e5, #7c3aed);
    transform: translateY(-3px);
    box-shadow: 0 10px 30px rgba(99,102,241,0.6);
}

.todo-box {
    background-color: #1e293b;
    padding: 15px;
    border-radius: 12px;
    margin-bottom: 12px;
    color: white;
    border: 1px solid #334155;
}

.result-box {
    background-color: #111827;
    padding: 20px;
    border-radius: 12px;
    color: white;
    border: 1px solid #374151;
    white-space: pre-wrap;
}

.file-box {
    background-color: #172554;
    padding: 12px;
    border-radius: 10px;
    margin-bottom: 10px;
    color: white;
    border: 1px solid #3b82f6;
}

.success-text {
    color: #4ade80;
    font-weight: bold;
}

.header-text {
    text-align: center;
    color: lightgray;
    margin-bottom: 30px;
    font-size: 18px;
}

/* ✅ Move Cognix to top beside toggle */
.top-cognix {
    position: fixed;
    top: 1px;
    left: 20px;   /* ✅ aligns next to toggle button */
    z-index: 1000;
}

/* Title */
.top-cognix-title {
    font-size: 30px;
    font-weight: 700;
    color: white;
}

/* Subtitle */
.top-cognix-sub {
    font-size: 16px;
    color: #94a3b8;
    margin-top: -4px;
}

/* ✅ push sidebar content down so it doesn't overlap */
section[data-testid="stSidebar"] .block-container {
    padding-top: 70px;
}

            
.main-card {
    background: rgba(15, 23, 42, 0.55);
    border: 1px solid rgba(255,255,255,0.08);
    border-radius: 26px;
    padding: 40px;
    margin-top: 20px;
    box-shadow: 0 30px 80px rgba(0,0,0,0.7);
    backdrop-filter: blur(18px);
    width: 100%;
}


/* Glow wave */
.stApp::before {
    content: "";
    position: fixed;
    bottom: 0;
    width: 100%;
    height: 250px;
    background: radial-gradient(circle, rgba(99,102,241,0.25), transparent);
    filter: blur(60px);
}

            

.sidebar-list div {
    color: #e2e8f0;
    margin-top: 10px;
    display: flex;
    align-items: center;
    font-size: 16px;
}

            

            
.check-icon {
    height: 10px;
    width: 10px;
    background-color: #22c55e;
    border-radius: 3px;
    display: inline-block;
    margin-right: 10px;
    box-shadow: 0 0 8px #22c55e;
}


            

.dot {
    height: 6px;
    width: 6px;
    background-color: white;
    border-radius: 50%;
    display: inline-block;
    margin-right: 10px;
    box-shadow: 0 0 8px #3b82f6;
}


.core-list div {
    color: white;
    margin-bottom: 10px;
    display: flex;
    align-items: center;
    font-size: 16px;
}
            
.main-card::before {
    content: "";
    position: absolute;
    inset: 0;
    border-radius: 26px;
    background: linear-gradient(120deg, transparent, rgba(139,92,246,0.1), transparent);
    pointer-events: none;
}


    .cognix-box {
        background-color: #3b4d6b;
        padding: 15px;
        border-radius: 12px;
        text-align: center;
        margin-top: 0;
        color: #e6f0ff;
        font-weight: 600;
        font-size: 28px;
    }


</style>
""", unsafe_allow_html=True)

















# =========================================================
# HEADER
# =========================================================

st.markdown('<div class="main-card">', unsafe_allow_html=True)

st.markdown("""
<h1 style='text-align:center; display:flex; justify-content:center; align-items:center; gap:12px;'>

<span style="
font-size:40px;
background: linear-gradient(135deg,#3b82f6,#8b5cf6);
border-radius: 50%;
padding: 8px;
box-shadow: 0 0 20px rgba(139,92,246,0.5);
">🤖</span>

<span>
Autonomous Cognitive
<span style="
background: linear-gradient(90deg,#3b82f6,#8b5cf6);
-webkit-background-clip:text;
-webkit-text-fill-color:transparent;">
Engine
</span>
</span>

</h1>
""", unsafe_allow_html=True)

st.markdown("""
<div class="header-text">
AI Multi-Agent Research System using LangGraph + Mistral AI
</div>
""", unsafe_allow_html=True)


# =========================================================
# SIDEBAR
# =========================================================

with st.sidebar:

    st.markdown("""
    <div class="cognix-box">
         🧑‍💻 Cognix
    </div>

    <span style="font-size:13px; color:#cbd5e1;">
        AI Multi-Agent Platform
    </span>
    """, unsafe_allow_html=True)

    st.markdown(
        "<hr style='border:1px solid rgba(255,255,255,0.1);'>",
        unsafe_allow_html=True
    )

    st.markdown("""
<div style="color:#3b82f6;font-size:18px;font-weight:600;">
🔧 CORE TECHNOLOGIES
</div>

<div class="core-list">
<div><span class="dot"></span> LangGraph</div>
<div><span class="dot"></span> LangChain</div>
<div><span class="dot"></span> LangSmith</div>
<div><span class="dot"></span> Mistral AI</div>
<div><span class="dot"></span> Tavily Search API</div>
<div><span class="dot"></span> Streamlit</div>
</div>
""", unsafe_allow_html=True)

    st.markdown(
        "<hr style='border:1px solid rgba(255,255,255,0.1);'>",
        unsafe_allow_html=True
    )

    st.subheader("🤖 Agent Contribution")

    st.write("🔍 Research Agent")
    st.progress(st.session_state.get("research", 0) / 100)
    st.write(f"**{st.session_state.get('research', 0)}%**")

    st.write("💻 Code Agent")
    st.progress(st.session_state.get("code", 0) / 100)
    st.write(f"**{st.session_state.get('code', 0)}%**")

    st.write("📝 Summarizer Agent")
    st.progress(st.session_state.get("summary", 0) / 100)
    st.write(f"**{st.session_state.get('summary', 0)}%**")

    st.markdown(
        "<hr style='border:1px solid rgba(255,255,255,0.1);'>",
        unsafe_allow_html=True
    )

    st.info("Powered by Mistral AI")


# =========================================================
# INPUT SECTION
# =========================================================

goal = st.text_area(
    "🟣 Enter Your Research Topic :",
    height=180,
    placeholder="Give me a Topic and I'll break it down for you ...."
)
# =========================================================
# START BUTTON
# =========================================================

if st.button("🚀 Start Research"):

    if goal.strip() == "":
        st.warning("Please enter a goal.")
        st.stop()

    # =====================================================
    # INITIAL STATE
    # =====================================================

    state = {

        "messages": [goal],
        "todos": [],
        "current_task": "",
        "files": {},
        "results": [],
        "needs_retry": False,
        "retry_count": 0,
        "max_tasks": 6,

        # Agent Performance
        "research_percentage": 0,
        "code_percentage": 0,
        "summarizer_percentage": 0
    }

    # =====================================================
    # BUILD GRAPH
    # =====================================================

    app = build_graph()

    # =====================================================
    # EXECUTE GRAPH
    # =====================================================

    with st.spinner("🤖 Autonomous Agents are Working..."):

        result = app.invoke(state)
    #    st.write(result["todos"])

    # =====================================================
    # UPDATE SIDEBAR PERFORMANCE
    # =====================================================

    st.session_state["research"] = result.get("research_percentage", 0)
    st.session_state["code"] = result.get("code_percentage", 0)
    st.session_state["summary"] = result.get("summarizer_percentage", 0)

    # =====================================================
    # SHOW TODO TASKS
    # =====================================================

    st.subheader("📋 Generated TODO Tasks")

    for task in result["todos"]:

        st.markdown(f"""
        <div class="todo-box">

        <b>{task['description']}</b>

        <br><br>

        <span class="success-text">

        Status : {task['status']}

        </span>

        </div>
        """, unsafe_allow_html=True)
        # =====================================================
    # SHOW MEMORY FILES
    # =====================================================

    st.subheader("📂 Virtual Memory Files")

    if len(result["files"]) > 0:

        for file_name, content in result["files"].items():

            with st.expander(f"📄 {file_name}"):

                st.markdown(
                    f"""
                    <div class="file-box">
                    <pre>{content}</pre>
                    </div>
                    """,
                    unsafe_allow_html=True
                )

    # =====================================================
    # FINAL REPORT
    # =====================================================

    st.subheader("📑 Final Generated Report")

    final_report = result["files"].get(
        "final_report.txt",
        "No report generated."
    )

    st.markdown(
        f"""
        <div class="result-box">
        <pre>{final_report}</pre>
        </div>
        """,
        unsafe_allow_html=True
    )

    # =====================================================
    # DOWNLOAD PDF
    # =====================================================

    try:

        with open("final_report.pdf", "rb") as pdf_file:

            st.download_button(

                label="⬇ Download Final Report (PDF)",

                data=pdf_file,

                file_name="final_report.pdf",

                mime="application/pdf"

            )

    except FileNotFoundError:

        st.warning("PDF not generated.")

# =========================================================
# FOOTER
# =========================================================

st.markdown("---")

st.markdown(
    """
<div style='text-align:center;color:gray;'>

Built using ❤️ LangGraph + LangChain + Mistral AI + Streamlit

</div>
""",
    unsafe_allow_html=True,
)

st.markdown("</div>", unsafe_allow_html=True)